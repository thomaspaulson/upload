<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class KRUX_Controller extends CI_Controller {

var $ran_string;
var $ran_string20;
function __construct() {
       		parent::__construct();
 $this->load->helper('string'); 
 $this->ran_string= random_string('alnum',100); 
 $this->ran_string20= random_string('alnum',20);	
    	}


public function get_comp_logo($id='')
{
$comp_logo=$this->getid_model->get_comp_logo($id);
$comp_logo=base_url().'uploads/company_logo'.'/'.$comp_logo;
return $comp_logo;
}



}

