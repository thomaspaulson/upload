<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staff_login extends CI_Controller {

	public function index()
	{

		$this->load->view('staff/staff.php');
	}

        public function staff_login(){



        }
}