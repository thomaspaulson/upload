<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specialpackage extends CI_Controller {

 	function __construct() {
       		parent::__construct();
$this->load->helper('string');
		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'manager') ){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}


    	}

	public function index($page=0)
	{

$comp_id=$this->session->userdata('comp_id');
 $br_id=$this->session->userdata('branch_id');
		//$data['packages'] = $this->package_model->all_packages();
$this->db->where('comp_id', $comp_id); 
 		
$query = $this->db->get('specialpackage');
		$total = $query->num_rows(); 
	
		$array = $query->result_array();
		
		$data['packages'] = $array;
$this->load->library('pagination');
		
		$config['base_url'] = base_url()."/index.php/specialpackage/index/";
		$config['total_rows'] = $total;
		$config['per_page'] =30;
		$config['uri_segment'] = 4;
		$config['num_links'] = 2;
		//$config['page_query_string'] = TRUE;
		//$config['full_tag_open'] = '<a class ="number">';
		//$config['full_tag_close'] = '</a>';
		$config['first_link'] = '&laquo; First';
		//$config['first_tag_open'] = '<span>';
		//$config['first_tag_close'] = '</span>';
		$config['last_link'] = 'Last &raquo;';
		//$config['last_tag_open'] = '<span>';
		//$config['last_tag_close'] = '</span>';
		$config['next_link'] = 'Next &raquo;';
		$config['prev_link'] = '&laquo; Previous';
		$config['cur_tag_open'] = '<a class ="number current">';
		$config['cur_tag_close'] = '</a>';
		
		
		
		$this->pagination->initialize($config);
		$data['page'] = $page;
		
$this->db->order_by('specialp_id','desc');
$this->db->where('comp_id', $comp_id); 
		$query = $this->db->get('specialpackage', $config['per_page'], $page);
		$data['paages'] = $this->pagination->create_links();
		//print_r($data['paages']);
//exit();
		$array = $query->result_array();
		
		$data['packages'] = $array;
		$this->load->view('headermerged',$data);

		$this->load->view('specialpackage/specialpackage',$data);
		
	}
	
	public function add_package(){


	        //$this->output->enable_profiler();
$comp_id=$this->session->userdata('comp_id');

		$name = $this->input->post('name');
		$qty = $this->input->post('qty');			        
		$slug = random_slug(30);
                $slug = "ghfgH";
		$data = array('comp_id' => $comp_id,
			'name' => $name,
			'qty' => $qty, 
			'slug' => $slug,
		
		);

		$result = $this->package_model->add_package($data);	
		if($result = 1){
			redirect(base_url().'specialpackage', 'refresh');
		}	
	
	
	}
	
	public function add_new_package(){
                $data['random_value'] =  random_slug(30);
        	$this->load->view('specialpackage/add_new_package.php',$data);
        }
        
        public function edit_package($slug=''){
        	$table_name='specialpackage';
        	$primary_key = 'specialp_id';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Package Doesnt Exists !');
        		redirect(base_url().'specialpackage', 'refresh');
        		exit();
        	}
        	$data['packages'] = $this->package_model->get_package_details($id);
        	$data['id'] = $id;
$this->load->view('newheader',$data);
        	$this->load->view('specialpackage/edit_package',$data);  
$this->load->view('newfooter',$data);      
        }
        
        
        
        public function edit_existing_package(){
	        $id = $this->input->post('id');
		$name = $this->input->post('name');
		$qty = $this->input->post('qty');		

		$data = array(
			'name' => $name,
			'id' => $id,
			'qty' => $qty,
		);
		$result = $this->package_model->edit_package($data);	
		if($result = 1){
			redirect(base_url().'specialpackage', 'refresh');
		}		       
        }        
        
        public function delete_package($slug=''){
        	$table_name='specialpackage';
        	$primary_key = 'specialp_id';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Package Doesnt Exists !');
        		redirect(base_url().'specialpackage', 'refresh');
        		exit();
        	}		        	
        	$result = $this->package_model->delete_package($id);
		if($result == 1){
			redirect(base_url().'specialpackage', 'refresh');
		}        
        } 
        
        public function activate_package($slug=''){
        	$table_name='specialpackage';
        	$primary_key = 'specialp_id';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Package Doesnt Exists !');
        		redirect(base_url().'specialpackage', 'refresh');
        		exit();
        	}		        	
        	$result = $this->package_model->activate_package($id);
		if($result == 1){
			redirect(base_url().'specialpackage', 'refresh');
		}        
        }   
function changestatus($cid=null){
				$query = $this->db->get_where('specialpackage', array('specialp_id' => $cid));
				$array = $query->result_array();
				$status=($array[0]['current_status']=="active")?"inactive":"active";  

		$data = array(
				   'current_status' => $status
				);
			$this->db->update('specialpackage', $data, array('specialp_id' => $cid));
			redirect("specialpackage");	
		}

             
}