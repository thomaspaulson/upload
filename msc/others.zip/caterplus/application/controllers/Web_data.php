<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Web_data extends CI_Controller {

       public function index() {
     	 $this->load->model('web_data_model');
       	$data['view']= $this->web_data_model->view_all('customer');
        $this->load->view('web_data/index',$data);
    }
      public function menulist()
      {
        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');
      
       
        $this->db->where('comp_id', $comp_id);
        $query = $this->db->get('Item');
        $total = $query->num_rows();
        $array = $query->result_array();
        $data['contents'] = $array;
        
        $this->load->view('web_data/menulist', $data);

      }
      // for reset all special orders. 
     
       public function reset_orders()
    {
        // we have to empty tables named all,evening,evening_payment,morning,night,special_order,special_order_quantity
       // $this->db->truncate('test');
        $this->db->truncate('evening');
        $this->db->truncate('morning');
        $this->db->truncate('night');
        $this->db->truncate('specialorder');
        $this->db->truncate('specialorderquantity');
        $this->db->truncate('afternoon');
         $this->session->set_flashdata("message","All Orders has been Reset successfully");
           redirect('admin_home');
    }
}