<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createevent extends CI_Controller{

	function __construct()
	{
		parent::__construct();		
		$this->load->model('ingredientquantity_model');
		$this->load->library('form_validation');			
	}
	
	function index(){
		$this->load->view('event/eventheader'); 
	 	$this->load->view('event/create_event'); 
     	$this->load->view('admin/admin_footer');
	}
}	