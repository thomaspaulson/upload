<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    
    class Specialingredients extends CI_Controller {
    
public $comp_id;
public $br_id; 

	function __construct()
	{
		parent::__construct();


 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'manager') ){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
 $this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');
$this->load->helper('url');


            
                $this->load->model('ingredientquantity_model');
        }
        
        function index(){
            
         
        }
        
        
        function listall($msg='',$page=0){	 
            $data['msg'] =$msg;	
 $this->comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $this->comp_id); 
$this->db->where('ing_status','active');
$this->db->order_by('ingredientid','desc');				
            $query = $this->db->get('specialingredient');
            $total = $query->num_rows(); 	
            $array = $query->result_array();		
            $data['contents'] = $array;
$this->load->library('pagination');
		
		$config['base_url'] = base_url()."/index.php/specialingredients/index/";
		$config['total_rows'] = $total;
		$config['per_page'] =45;
		$config['uri_segment'] = 4;
		$config['num_links'] = 2;
		//$config['page_query_string'] = TRUE;
		//$config['full_tag_open'] = '<a class ="number">';
		//$config['full_tag_close'] = '</a>';
		$config['first_link'] = '&laquo; First';
		//$config['first_tag_open'] = '<span>';
		//$config['first_tag_close'] = '</span>';
		$config['last_link'] = 'Last &raquo;';
		//$config['last_tag_open'] = '<span>';
		//$config['last_tag_close'] = '</span>';
		$config['next_link'] = 'Next &raquo;';
		$config['prev_link'] = '&laquo; Previous';
		$config['cur_tag_open'] = '<a class ="number current">';
		$config['cur_tag_close'] = '</a>';
		
		
		
		$this->pagination->initialize($config);
		$data['page'] = $page;
 $this->comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $this->comp_id); 
		$this->db->where('ing_status','active');
$this->db->order_by('ingredientid','desc');
		$query = $this->db->get('specialingredient', $config['per_page'], $page);
		$data['paages'] = $this->pagination->create_links();
		//print_r($data['paages']);
//exit();
		$array = $query->result_array();
		
		$data['contents'] = $array;
		$this->load->view('headermerged',$data);
        
            $this->load->view('ingredient/ingredient',$data);
          
        }
        
        
        
        
        function addform($msg=''){       
		$this->db->order_by('unit_name','asc');
		$data['units'] = $this->db->get('units')->result_array();
		//$this->load->view('headerform',$data);
$this->load->view('newheader',$data);     
		$this->load->view('ingredient/addingredient',$data);
$this->load->view('newfooter',$data);
		//$this->load->view('footerform',$data);
        }
    
    
            
  public  function insert(){
 $this->comp_id=$this->session->userdata('comp_id');

    
                                        $data = array( 'comp_id' => $this->comp_id,	
                               'ingredientname' => ucwords($this->input->post('ingredientname')),		
                              'ingredientdescription' =>$this->input->post('ingredientdescription'),
                                                      'ingredientprice' =>$this->input->post('ingredientprice'),
                               'ingredientqtytype' =>$this->input->post('ingredientqtytype'),
    
                                    );
    
                        $this->db->insert('specialingredient',$data); 
                            
                $insert_id = $this->db->insert_id();
 
    $datas = array('comp_id'=>$this->comp_id,'br_id'=> $this->br_id,
    'current_stock' =>$this->input->post('currquantity'),
    'ingredient_id' =>$insert_id,
    'reorder_level' =>$this->input->post('reorderlevel')
    );
    $this->db->insert('raw_stock',$datas); 
    
    
    
    
    
    
                redirect("specialingredients/listall/added");
    
    }
            
        
    
    function updateform($ingid=null,$msg=''){
            
            if($ingid!=null){
            $this->db->where('ingredientid',$ingid);
            $query = $this->db->get('specialingredient');
            $array = $query->result_array();
            $data['data'] = $array[0];
            }
    
                $this->db->order_by('unit_name','asc');
                $data['units'] = $this->db->get('units')->result_array();
    
    //
    if($ingid!=null){
            $this->db->where('ingredient_id',$ingid);
            $query2 = $this->db->get('raw_stock');
            $array2 = $query2->result_array();
            
            }
    
    //
    
            $array = $query->result_array();
            $data['contents'] = $array; $data['cont'] = $array2;
           // $this->load->view('headerform',$data);
$this->load->view('newheader',$data);    
            $this->load->view('ingredient/editingredient',$data);
$this->load->view('newfooter',$data);    

   // $this->load->view('footerform',$data);
    
        }
        
    function update($msg=''){
    
    
                                            
                    $data = array(
                               'ingredientname' => ucwords($this->input->post('ingredientname')),		
                              'ingredientdescription' =>$this->input->post('ingredientdescription'),
                                  'ingredientqty'=>$this->input->post('ingredientqty'),
                                                      'ingredientprice'=>$this->input->post('ingredientprice'),
                               'ingredientqtytype' =>$this->input->post('ingredientqtytype')
                                    );
    
                    $q = $this->db->query("select * from specialingredient where  ingredientid='".$this->input->post('ingredientid')."'");
    
    //
    $datas = array('current_stock' =>$this->input->post('currstock'),'reorder_level' =>$this->input->post('reorderlevel'));
    //
    
    
                     if($q->num_rows != 0)
                     {
                        
    //print_r($data);
        $this->db->update('specialingredient', $data, array('ingredientid' => $this->input->post('ingredientid')));
    
    //
    $this->db->update('raw_stock', $datas, array('ingredient_id' => $this->input->post('ingredientid')));
    //
    
    
                        
                        redirect("specialingredients/listall/0/edited");
                     }else{
                        
                        redirect("specialingredients/updateform/updated");
                     }				
                    
        }
    
    
        
    
        
	function delete($ingid=null){     
		$data = array(
			'ing_status' => 'inactive',
		);
		$this->db->where('ingredientid',$ingid);
		$this->db->update('specialingredient',$data);                
		redirect("specialingredients/listall/deleted");	
	}
	
	function activate($ingid=null){     
		$data = array(
			'ing_status' => 'active',
		);
		$this->db->where('ingredientid',$ingid);
		$this->db->update('specialingredient',$data);                
		redirect("specialingredients/listall/deleted");	
	}	
                
function changestatus($cid=null){
				$query = $this->db->get_where('specialingredient', array('ingredientid' => $cid));
				$array = $query->result_array();
				$status=($array[0]['ing_status']=="active")?"inactive":"active";  

		$data = array(
				   'ing_status' => $status
				);
			$this->db->update('specialingredient', $data, array('ingredientid' => $cid));
			redirect("specialingredients/listall/");	
		}
function fetchdetailslist()
{
 $search_term = str_replace(' ', '',$this->input->post('ingredientname'));

// Use a model to retrieve the results.
        $data['contents'] = $this->search_model->get_ingredientdetailslist($search_term);
        // Pass the results to the view.
       
       $data['paages']='';
//$this->load->view('headerform',$data);
$this->load->view('headermerged',$data);
		$this->load->view('ingredient/ingredient',$data);
			
}
        
}
    