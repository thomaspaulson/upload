<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Menu extends CI_Controller {

public $comp_id;
public $br_id;
	function __construct()
	{
		parent::__construct();
$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');
		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}

		$this->load->helper('url');
		
	}
	
	function index(){
		
	 
	}

function search(){
		$data['msg'] = '';
	$search_term = $this->input->post('menutypename');
		 $data['search_term'] = $search_term ;
		$data['contents'] = $this->search_model->search_menu($search_term);
		
	
		$this->load->view('headermerged',$data);
		$this->load->view('menu/menu',$data);
$this->load->view('footerform');
	}
	
	
function listall($msg='',$page=0){
	 
	$data['msg'] =$msg;	
		
		
$this->db->where('comp_id',$this->comp_id);
		$query = $this->db->get('menutype');
		$total = $query->num_rows(); 
	
		$array = $query->result_array();
		
		$data['contents'] = $array;
$this->load->library('pagination');
		
		$config['base_url'] = base_url()."/index.php/menu/index/";
		$config['total_rows'] = $total;
		$config['per_page'] =$total;
		$config['uri_segment'] = 4;
		$config['num_links'] = 2;
		//$config['page_query_string'] = TRUE;
		//$config['full_tag_open'] = '<a class ="number">';
		//$config['full_tag_close'] = '</a>';
		$config['first_link'] = '&laquo; First';
		//$config['first_tag_open'] = '<span>';
		//$config['first_tag_close'] = '</span>';
		$config['last_link'] = 'Last &raquo;';
		//$config['last_tag_open'] = '<span>';
		//$config['last_tag_close'] = '</span>';
		$config['next_link'] = 'Next &raquo;';
		$config['prev_link'] = '&laquo; Previous';
		$config['cur_tag_open'] = '<a class ="number current">';
		$config['cur_tag_close'] = '</a>';
		
		
		
		$this->pagination->initialize($config);
		$data['page'] = $page;
		
$this->db->order_by('menutypeid','desc');
		$query = $this->db->get('menutype', $config['per_page'], $page);
		$data['paages'] = $this->pagination->create_links();
		//print_r($data['paages']);
//exit();
		$array = $query->result_array();
		
		$data['contents'] = $array;
		$this->load->view('headermerged',$data);

		$this->load->view('menu/menu',$data);
				

	}
	
	
	
	
	function addform($msg=''){ 
      
		$this->load->view('newheader');
		$this->load->view('menu/addmenu');
                $this->load->view('newfooter');      
	}


		
function insert(){


$data = array( 'comp_id' => $this->comp_id,
						   'menutypename' => ucwords($this->input->post('menutypename')),		
						  'menutypedescription	' =>$this->input->post('menutypedescription')
					         
								);



			$this->db->insert('menutype',$data); 
						
			$insert_id = $this->db->insert_id();
			
			
			
			//-----------------------------------------------
			//Image upload		
			
			$allowedExts = array("gif", "jpeg", "jpg", "png");
			$temp = explode(".", $_FILES["userfile"]["name"]);
			$extension = end($temp);
			$extension = strtolower($extension );
			
			if (in_array($extension, $allowedExts)) {
			      move_uploaded_file($_FILES["userfile"]["tmp_name"],
			      $_SERVER['DOCUMENT_ROOT']."/uploads/menu/" . $insert_id .'.'.$extension);
			} 
	
			//end of image upload	
			//-------------------------------------------------	
			if($insert_id){
				$data = array(
					'menu_image' => $insert_id .'.'.$extension,
				);
				
				$this->db->where('menutypeid', $insert_id);
				$this->db->update('menutype', $data);
				redirect("menu/listall/added");
			}


}
		
	

function updateform($menuid=null,$msg=''){
		
		if($menuid!=null){
		$this->db->where('menutypeid',$menuid);
		$query = $this->db->get('menutype');
		$array = $query->result_array();
		$data['data'] = $array[0];
		}

		$array = $query->result_array();
		$data['contents'] = $array;
		$this->load->view('newheader');
		$this->load->view('menu/editmenu',$data);
$this->load->view('newfooter');
	}
function update($msg=''){


		         $this->db->where('menutypeid',$this->input->post('menutypeid'));
					$query = $this->db->get('menutype');
					$array = $query->result_array();
					$data['data'] = $array[0];
					
				$data = array(
						  'menutypename' => ucwords($this->input->post('menutypename')),		
						  'menutypedescription	' =>$this->input->post('menutypedescription')
								);
$comp_id=$this->comp_id;
				$q = $this->db->query("select * from menutype where comp_id='$comp_id' and menutypename='".addslashes($this->input->post('menutypename'))."' and menutypeid!='".$this->input->post('menutypeid')."'");


				 if($q->num_rows == 0)
				 {
					
//print_r($data);
					$this->db->update('menutype', $data, array('menutypeid' => $this->input->post('menutypeid')));
					
						$insert_id = $this->input->post('menutypeid');
						if($_FILES["userfile"]["name"]){						
							//-----------------------------------------------
							//Image upload		
							
							$allowedExts = array("gif", "jpeg", "jpg", "png");
							$temp = explode(".", $_FILES["userfile"]["name"]);
							$extension = end($temp);
							$extension = strtolower($extension );
							
							if (in_array($extension, $allowedExts)) {
							      move_uploaded_file($_FILES["userfile"]["tmp_name"],
							      $_SERVER['DOCUMENT_ROOT']."/uploads/menu/" . $insert_id .'.'.$extension);
							} 
					
							//end of image upload	
							//-------------------------------------------------	
							if($insert_id){
								$data = array(
									'menu_image' => $insert_id .'.'.$extension,
								);
								
								$this->db->where('menutypeid', $insert_id);
								$this->db->update('menutype', $data);
							}						
						
						}

					
					redirect("menu/listall/edited");
				 }else{
					
				 	redirect("menu/updateform/updated");
				 }				
				
	}
function delete($menuid=null){

			$this->db->delete('menutype', array('menutypeid' => $menuid)); 
			
			redirect("menu/listall/deleted");	
		}
function changestatus($cid=null){
				$query = $this->db->get_where('menutype', array('menutypeid' => $cid));
				$array = $query->result_array();
				$status=($array[0]['menu_status']=="active")?"inactive":"active";  

		$data = array(
				   'menu_status' => $status
				);
			$this->db->update('menutype', $data, array('menutypeid' => $cid));
			redirect("menu/listall/");	
		}

function fetchdetailslist()
{
 $search_term = str_replace(' ', '',$this->input->post('menutypename'));

// Use a model to retrieve the results.
        $data['contents'] = $this->search_model->get_menudetailslist($search_term);
        // Pass the results to the view.
       
       $data['paages']='';
//$this->load->view('headerform',$data);
$this->load->view('headermerged',$data);
		$this->load->view('menu/menu',$data);
		$this->load->view('footerform',$data);	
}
			
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */