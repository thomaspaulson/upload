<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_home extends CI_Controller {
 	function __construct() {
       		parent::__construct();
		



    	}

	public function index()
	{      
    // $this->load->view('headerform');
		$this->load->view('admin/admin_home'); 
     $this->load->view('footerform');
 
	}
	     
}