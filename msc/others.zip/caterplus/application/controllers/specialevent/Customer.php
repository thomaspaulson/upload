<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Customer extends CI_Controller {

    public $comp_id;
    public $br_id;

    function __construct() {
        parent::__construct();
        $this->load->helper('url');

        $this->comp_id = $this->session->userdata('comp_id');
        $this->br_id = $this->session->userdata('branch_id');

        if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'order')||($this->session->userdata('type') == 'manager')||($this->session->userdata('type') == 'office')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}

    }

    public function index($page = 0) {
        $this->db->where('customerstatus', 'active');
        $this->db->order_by('customerId', 'desc');
        $query = $this->db->get('customer');
        $total = $query->num_rows();

        $array = $query->result_array();

        $data['contents'] = $array;


        $this->load->library('pagination');

        $config['base_url'] = base_url() . "/index.php/specialevent/customer/index/";
        $config['total_rows'] = $total;
        $config['per_page'] = 20;
        $config['uri_segment'] = 4;
        $config['num_links'] = 2;
        //$config['page_query_string'] = TRUE;
        //$config['full_tag_open'] = '<a class ="number">';
        //$config['full_tag_close'] = '</a>';
        $config['first_link'] = '&laquo; First';
        //$config['first_tag_open'] = '<span>';
        //$config['first_tag_close'] = '</span>';
        $config['last_link'] = 'Last &raquo;';
        //$config['last_tag_open'] = '<span>';
        //$config['last_tag_close'] = '</span>';
        $config['next_link'] = 'Next &raquo;';
        $config['prev_link'] = '&laquo; Previous';
        $config['cur_tag_open'] = '<a class ="number current">';
        $config['cur_tag_close'] = '</a>';



        $this->pagination->initialize($config);
        $data['page'] = $page;
        $this->db->where('customerstatus', 'active');
        $this->db->order_by('customerId', 'desc');
        $query = $this->db->get('customer', $config['per_page'], $page);
        $data['paages'] = $this->pagination->create_links();
        //print_r($data['paages']);
//exit();
        $array = $query->result_array();

        $data['contents'] = $array;

        $this->load->view('headermerged', $data);
        $this->load->view('specialevent/specialorder/customerlist', $data);
        $this->load->view('footerform', $data);
    }

    public function new_customer() {
        $data['order_id'] = $this->input->get('order_id');
        //$this->load->view('headerform',$data);	
        $this->load->view('headermerged', $data);
        //$this->load->view('specialevent/specialorder/customer',$data);
        $this->load->view('specialevent/specialorder/customer', $data);
        $this->load->view('footerform', $data);
    }

    public function add_customer() {
        $this->load->view('newheader');
        $this->load->view('specialevent/specialorder/addcustomer');
        $this->load->view('newfooter');
    }

    public function listcustomer($page = 0) {
        $this->db->where('comp_id', $this->comp_id);
        $this->db->where('br_id', $this->br_id);
        $query = $this->db->get('customer');
        $total = $query->num_rows();

        $array = $query->result_array();

        $data['contents'] = $array;
        $this->load->library('pagination');

        $config['base_url'] = base_url() . "/index.php/specialevent/customer/listcustomer/";
        $config['total_rows'] = $total;
        $config['per_page'] = 45;
        $config['uri_segment'] = 4;
        $config['num_links'] = 2;
        //$config['page_query_string'] = TRUE;
        //$config['full_tag_open'] = '<a class ="number">';
        //$config['full_tag_close'] = '</a>';
        $config['first_link'] = '&laquo; First';
        //$config['first_tag_open'] = '<span>';
        //$config['first_tag_close'] = '</span>';
        $config['last_link'] = 'Last &raquo;';
        //$config['last_tag_open'] = '<span>';
        //$config['last_tag_close'] = '</span>';
        $config['next_link'] = 'Next &raquo;';
        $config['prev_link'] = '&laquo; Previous';
        $config['cur_tag_open'] = '<a class ="number current">';
        $config['cur_tag_close'] = '</a>';



        $this->pagination->initialize($config);
        $data['page'] = $page;
        $this->db->where('customerstatus', 'active');
        $this->db->order_by('customerId', 'desc');

        $this->db->where('comp_id', $this->comp_id);
        $this->db->where('br_id', $this->br_id);
        $query = $this->db->get('customer', $config['per_page'], $page);
        $data['paages'] = $this->pagination->create_links();
        //print_r($data['paages']);
//exit();
        $array = $query->result_array();

        $data['contents'] = $array;
        $this->load->view('headermerged', $data);
        $this->load->view('specialevent/specialorder/customerlisting', $data);
        $this->load->view('footerform', $data);
    }

    public function save_customer() {
        
        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');

        $name = $this->input->post('name');
        $address = $this->input->post('address');
        $phone = $this->input->post('phone');
        $mobile1 = $this->input->post('mobile1');
        $mobile2 = $this->input->post('mobile2');
        $email = $this->input->post('email');
        $email2 = $this->input->post('email2');
        //$customerphoneext= $this->input->post('customerphoneext');
        //$country= $this->input->post('country');
        $pincode = $this->input->post('pincode');
        $state = $this->input->post('state');
        $city = $this->input->post('city');
        $specifictime = $this->input->post('specifictime');
        $deliverydate = $this->input->post('specificdate');
        if(strstr($deliverydate,"-")){
            $nedate=explode("-",$deliverydate);
            $deliverydate=$nedate[2]."-".$nedate[1]."-".$nedate[0];
        }
        //$specificdate = date("Y-m-d", strtotime($specificdate));
        //$specificdate=date("Y-m-d");

        $data = array(
            'comp_id' => $comp_id,
            'br_id' => $br_id,
            'customername' => $name,
            'customeraddress' => $address,
            'customeremail' => $email,
            'customeremail2' => $email2,
            'customerphone' => $phone,
            //'customerphoneext' => $customerphoneext,
            'customermobile1' => $mobile1,
            'customermobile2' => $mobile2,
            'pincode' => $pincode,
            //  'country' =>$country,
            'state' => $state,
            'city' => $city
        );
        $customer_id = $this->specialitem_model->save_customer($data);
        $insertid = $this->db->insert_id();

        $custslug = random_slug(5);
        $custslug = $custslug . "-" . $insertid;
        $custslug = $custslug . random_slug(5);

        $d = array('customerslug' => $custslug);

        $this->db->update('customer', $d, array('customerId' => $insertid));



        $datas = array(
            'customer_id' => $insertid, 'deliverydate' =>$deliverydate , 'deliverytime' => $specifictime,
        );
        $orderslug = $this->specialitem_model->save_order_table($datas); //saves to special oreder 

        redirect('/specialevent/takeorder/index/' . $orderslug . '/' . $custslug);
//redirect('/specialevent/takeorder/getcollectiontime/'.$orderslug.'/'.$custslug);			
    }

    public function insert_customer() {

        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');

        $name = $this->input->post('name');
        $address = $this->input->post('address');
        $phone = $this->input->post('phone');
        $mobile1 = $this->input->post('mobile1');
        $mobile2 = $this->input->post('mobile2');
        $email = $this->input->post('email');
        $email2 = $this->input->post('email2');
        $customerphoneext = $this->input->post('customerphoneext');
        $country = $this->input->post('country');
        $pincode = $this->input->post('pincode');
        $state = $this->input->post('state');
        $city = $this->input->post('city');

        $data = array(
            'comp_id' => $comp_id,
            'br_id' => $br_id,
            'customername' => $name,
            'customeraddress' => $address,
            'customeremail' => $email,
            'customeremail2' => $email2,
            'customerphone' => $phone,
            'customerphoneext' => $customerphoneext,
            'customermobile1' => $mobile1,
            'customermobile2' => $mobile2,
            'pincode' => $pincode,
            'country' => $country,
            'state' => $state,
            'city' => $city
        );
        $customer_id = $this->specialitem_model->save_customer($data);
        $insertid = $this->db->insert_id();

        $custslug = random_slug(5);
        $custslug = $custslug . "-" . $insertid;
        $custslug = $custslug . random_slug(5);

        $d = array('customerslug' => $custslug);

        $this->db->update('customer', $d, array('customerId' => $insertid));
        redirect('/specialevent/customer/listcustomer/');
    }

    function customerfetchdetails() {
        $search_term = str_replace(' ', '', $this->input->post('customemail'));

// Use a model to retrieve the results.
        $data['contents'] = $this->search_model->get_custdetails($search_term);
        // Pass the results to the view.

        $data['paages'] = '';
//$this->load->view('headerform',$data);
        $this->load->view('headermerged', $data);
        $this->load->view('specialevent/specialorder/customerlist', $data);
        $this->load->view('footerform', $data);
    }

    function customerfetchdetailslist() {
        $search_term = str_replace(' ', '', $this->input->post('customemail'));

// Use a model to retrieve the results.
        $data['contents'] = $this->search_model->get_custdetailslist($search_term);
        // Pass the results to the view.

        $data['paages'] = '';
//$this->load->view('headerform',$data);
        $this->load->view('headermerged', $data);
        $this->load->view('specialevent/specialorder/customerlisting', $data);
        $this->load->view('footerform', $data);
    }

    function showcust($custid = '') {

        $query = $this->db->query("select * from customer where customerId='$custid'"); //
        $data['results'] = $query->result_array();
// Use a model to retrieve the results.
        //$deliverydate = $this->input->post('deliverydate');
        $deliverydate =date("d-m-Y");
        $this->session->unset_userdata('temprdate');
        $this->session->set_userdata('temprdate', $deliverydate);
        

        $this->load->view('headermerged', $data);
        $this->load->view('specialevent/specialorder/customerdetails', $data);
        $this->load->view('footerform', $data);
    }

    public function updatecustomer() {
        $name = $this->input->post('name');
        $address = $this->input->post('address');
        $phone = $this->input->post('phone');
        $mobile1 = $this->input->post('mobile1');
        $mobile2 = $this->input->post('mobile2');
        $email = $this->input->post('email');
        $email2 = $this->input->post('email2');
        $customerphoneext = $this->input->post('customerphoneext');
        $country = $this->input->post('country');
        $pincode = $this->input->post('pincode');
        $state = $this->input->post('state');
        $city = $this->input->post('city');
        $customerId = $this->input->post('customerId');
        $specifictime = $this->input->post('specifictime');
        $specificdate = $this->input->post('specificdate');
        $specificdate = date("Y-m-d", strtotime($specificdate));
//$specificdate="2016-07-05";
 $delivery_date =  $this->input->post('delivery_date');

        $data = array(
            'customername' => $name,
            'customeraddress' => $address,
            'customeremail' => $email,
            'customeremail2' => $email2,
            'customerphone' => $phone,
            'customerphoneext' => $customerphoneext,
            'customermobile1' => $mobile1,
            'customermobile2' => $mobile2,
            'pincode' => $pincode,
            'country' => $country,
            'state' => $state,
            'city' => $city
        );
        $this->db->update('customer', $data, array('customerId' => $customerId));


//get slug


        $query = $this->db->query("select * from customer where customerId='$customerId'");
        $totalslug = $query->result_array();

        foreach ($totalslug as $tg) {
            $custslug = $tg['customerslug'];
        }

        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');

        $datas = array('comp_id' => $comp_id, 'br_id' => $br_id,
            'customer_id' => $customerId, 'deliverydate' => $delivery_date, 'deliverytime' => $specifictime,
        );
        $orderslug = $this->specialitem_model->save_order_table($datas); //saves to special oreder 


        redirect('/specialevent/takeorder/index/' . $orderslug . '/' . $custslug);
    }

    function changestatus($cid = null) {
        $query = $this->db->get_where('customer', array('customerId' => $cid));
        $array = $query->result_array();
        $status = ($array[0]['customerstatus'] == "active") ? "inactive" : "active";

        $data = array(
            'customerstatus' => $status
        );
        $this->db->update('customer', $data, array('customerId' => $cid));
        redirect("specialevent/customer/listcustomer");
    }

    public function updatecustomerdetails() {
        $name = $this->input->post('name');
        $address = $this->input->post('address');
        $phone = $this->input->post('phone');
        $mobile1 = $this->input->post('mobile1');
        $mobile2 = $this->input->post('mobile2');
        $email = $this->input->post('email');
        $email2 = $this->input->post('email2');
        $customerphoneext = $this->input->post('customerphoneext');
        $country = $this->input->post('country');
        $pincode = $this->input->post('pincode');
        $state = $this->input->post('state');
        $city = $this->input->post('city');
        $customerId = $this->input->post('customerId');
        $data = array(
            'customername' => $name,
            'customeraddress' => $address,
            'customeremail' => $email,
            'customeremail2' => $email2,
            'customerphone' => $phone,
            'customerphoneext' => $customerphoneext,
            'customermobile1' => $mobile1,
            'customermobile2' => $mobile2,
            'pincode' => $pincode,
            'country' => $country,
            'state' => $state,
            'city' => $city
        );
        $this->db->update('customer', $data, array('customerId' => $customerId));


        redirect('/specialevent/customer/listcustomer');
    }

    function updateform($custid = null) {

        $this->db->where('customerId', $custid);
        $query = $this->db->get('customer');

        $array = $query->result_array();
        $data['results'] = $array;
        $this->load->view('newheader');
        $this->load->view('specialevent/specialorder/editcustomer', $data);
        $this->load->view('newfooter');
    }

    function search() {
        $data['msg'] = '';
        $search_term = $this->input->get('search');
        $data['search_term'] = $search_term;
        if (is_numeric($search_term)) {
            $data['contents'] = $this->customer_model->one_search_item_by_number($search_term);
        } else {
            $data['contents'] = $this->customer_model->one_search_item($search_term);
        }

        $this->load->view('headerform', $data);
        $this->load->view('specialevent/specialorder/found_customer', $data);
        $this->load->view('footerform', $data);
    }

    public function get_search() {
        $data['msg'] = '';
        $search_term = $this->input->get('search_keyword');
        $data['search_term'] = $search_term;
        if (is_numeric($search_term)) {
            $data['contents'] = $this->customer_model->search_items_by_number($search_term);
            $this->load->view('specialevent/specialorder/search_customer_by_number', $data);
        } else {
            $data['contents'] = $this->customer_model->search_items($search_term);
            $this->load->view('specialevent/specialorder/search_customer', $data);
        }
    }

}