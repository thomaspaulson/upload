<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Orderlist extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->helper('url');
        if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'order')||($this->session->userdata('type') == 'manager')||($this->session->userdata('type') == 'office')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}

        $this->load->library('functions');
    }

    public function indexx($page = 0) { /*some body edited code..recoded below index*/
        $this->load->database();
        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');

        $query = $this->db->query("select * from specialorder spo,customer 
cu where cu.customerId=spo.customer_id and spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id' ORDER BY spo.orderid DESC");

        //print "select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id' ORDER BY spo.orderid DESC";
        $data['contents'] = $query->result_array();
        //print_r($data);
        
        $total = $query->num_rows();
        //echo $total;
        $this->load->library('pagination');

        $config['base_url'] = base_url() . "/index.php/specialevent/orderlist/index/";
        $config['total_rows'] = $total;
        $config['per_page'] = 20;
        $config['uri_segment'] = 4;
        $config['num_links'] = 2;
        //$config['page_query_string'] = TRUE;
        //$config['full_tag_open'] = '<a class ="number">';
        //$config['full_tag_close'] = '</a>';
        $config['first_link'] = '&laquo; First';
        //$config['first_tag_open'] = '<span>';
        //$config['first_tag_close'] = '</span>';
        $config['last_link'] = 'Last &raquo;';
        //$config['last_tag_open'] = '<span>';
        //$config['last_tag_close'] = '</span>';
        $config['next_link'] = 'Next &raquo;';
        $config['prev_link'] = '&laquo; Previous';
        $config['cur_tag_open'] = '<a class ="number current">';
        $config['cur_tag_close'] = '</a>';


        $this->pagination->initialize($config);
        $data['page'] = $page;
        //print_r($config);
        //exit();
        $perpage = $config['per_page'];
        //echo $perpage;	
        //print_r($page);



        $array = $this->db->query("select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id'  ORDER BY spo.orderid DESC limit $page,$perpage")->result();

        //print "select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id'  ORDER BY spo.orderid DESC limit $page,$perpage";
        $data['paages'] = $this->pagination->create_links();

        //$array = $query->result_array();

        //print_r($array);

        $data['contents'] = $array;
        //print_r($data['contents']);
        $this->load->view('headermerged');
        $this->load->view('specialevent/specialorder/orderlistview', $data);
        //$this->load->view('footerform');
    }


public function index($page=0){

        $comp_id=$this->session->userdata('comp_id');
        $br_id=$this->session->userdata('branch_id');

		$query=$this->db->query("select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and 
		spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id' ORDER BY spo.orderid ASC");
		$data['contents']=$query->result_array();
		$total = $query->num_rows(); 
		//echo $total;
		$this->load->library('pagination');
				
		$config['base_url'] = base_url()."/index.php/specialevent/orderlist/index/";
		$config['total_rows'] = $total;
		$config['per_page'] =100;
		$config['uri_segment'] = 4;
		$config['num_links'] = 2;
		//$config['page_query_string'] = TRUE;
		//$config['full_tag_open'] = '<a class ="number">';
		//$config['full_tag_close'] = '</a>';
		$config['first_link'] = '&laquo; First';
		//$config['first_tag_open'] = '<span>';
		//$config['first_tag_close'] = '</span>';
		$config['last_link'] = 'Last &raquo;';
		//$config['last_tag_open'] = '<span>';
		//$config['last_tag_close'] = '</span>';
		$config['next_link'] = 'Next &raquo;';
		$config['prev_link'] = '&laquo; Previous';
		$config['cur_tag_open'] = '<a class ="number current">';
		$config['cur_tag_close'] = '</a>';
		
		
		$this->pagination->initialize($config);
		$data['page'] = $page;
		//print_r($config);
		//exit();
		$perpage =$config['per_page'];
		//echo $perpage;	
		//print_r($page);



		$query=$this->db->query("select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id'  ORDER BY spo.orderid ASC limit $page,$perpage");
		$data['paages'] = $this->pagination->create_links();
				
		$array = $query->result_array();
				
		$data['contents'] = $array;
		//print_r($data['contents']);
		$this->load->view('headermerged');
		$this->load->view('specialevent/specialorder/orderlistview',$data);
		//$this->load->view('footerform');
	}
















    public function cancelorder($orderslug) {
        //order
        $table_name = 'specialorder';
        $primary_key = 'orderid';
        $slug_column_name = 'orderslug';
        $orderid = $this->functions->get_id($orderslug, $table_name, $primary_key, $slug_column_name);
        //order slug
        //adding code to decrease stock
        $this->db->where('orderid', $orderid);
        $itemlist = $this->db->get('specialorderquantity')->result_array();
        if ($itemlist) {
            foreach ($itemlist as $list) {
                $tqty_perpkg_item = $list['total_item'];
                $getitemid = $list['itemid'];
                $data['ingredients'] = $this->ingredientquantity_model->get_item_ingredients($getitemid); // update ingredient stock while taking order- line 1
                $this->ingredientquantity_model->restore_raw_stock($data['ingredients'], $tqty_perpkg_item); // added two lines only- line 2
            }
        }

        //adding code to decrease stock end


        $this->db->query("delete from specialorder where orderslug='$orderslug'");
        $this->db->query("delete from specialorderquantity  where orderid='$orderid'");
        $this->db->query("delete from specialorder_container where order_id='$orderid'");

        redirect('specialevent/orderlist/index');
    }

    public function searchorder() {
        $orderid = $this->input->post("orderno");
        $query = $this->db->query("select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and spo.orderid like '$orderid%'");
//$query=$this->db->query("select * from specialorder spo,customer cu where cu.customerId=spo.customer_id or spo.orderid like '$orderid%' or cu.customername like '$orderid%' or cu.customerphone like '$orderid%' ");
        $data['contents'] = $query->result_array();
        //print_r($data['contents']);
        $this->load->view('headermerged');
        $this->load->view('specialevent/specialorder/orderlistview', $data);
        //$this->load->view('footerform');
    }


public function searchorderbymobno() {
        $mob_no= $this->input->post("mob_no");
        $query = $this->db->query("select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and cu.customermobile1 like '$mob_no%'");
 
        $data['contents'] = $query->result_array();
        //print_r($data['contents']);
        $this->load->view('headermerged');
        $this->load->view('specialevent/specialorder/orderlistview', $data);
        //$this->load->view('footerform');
    }











//        public function get_orderlist($search_term='default')
//        {
//      
//        
//
//          $query=$this->db->query("select * from customer where customermobile1 like '$search_term%' or customername like  '$search_term%'");
    // Execute the query.
    // Return the results.
//          return $query->result_array();
//       
//        }


    public function get_search() {
        $data['msg'] = '';
        $search_term = $this->input->get('search_keyword');
        $data['search_term'] = $search_term;
        $data['contents'] = $this->customer_model->search_order_by_order_id($search_term);

        $this->load->view('specialevent/specialorder/search_order_by_order_id', $data);
    }

    function search() {
        $data['msg'] = '';
        $search_term = $this->input->get('search');
        $data['search_term'] = $search_term;
        $data['contents'] = $this->customer_model->one_order_by_order_id($search_term);
        $this->load->view('headermerged', $data);
        $this->load->view('specialevent/specialorder/found_order_by_order_id', $data);
        //$this->load->view('footerform',$data);	
    }

    
    
    public function asd(){
        
        $this->load->database();
        $query = $this->db->query("select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id' ORDER BY spo.orderid DESC");

        print "select * from specialorder spo,customer cu where cu.customerId=spo.customer_id and spo.orderstatus='confirmed' and spo.comp_id='$comp_id'  and spo.br_id='$br_id' ORDER BY spo.orderid DESC";
        $data['contents'] = $query->result_array();
        
        print_r($data);
      
    }
    
    
}