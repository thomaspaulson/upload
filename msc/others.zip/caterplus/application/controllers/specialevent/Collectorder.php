<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Collectorder extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'collection')||($this->session->userdata('type') == 'manager')||($this->session->userdata('type') == 'office')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
	$this->load->library('functions');	
	}
	public function index()
	{
$data['orderlist']=$this->ordercollection_model->getorderforcollection();
//print_r($data['orderlist']);
$this->load->view('ordercollection_header.php');
$this->load->view('specialevent/ordercollection/collectorderindex',$data);
 }






public function fetchorder()
	{
$orderno=$this->input->post("orderno");
$order_detail_item=$this->ordercollection_model->select_order_uncollected($orderno);
$data['orderitem']=$order_detail_item;

$orderedcontainer=$this->ordercollection_model->select_orderedcontainer_uncollected($orderno);
$data['ordercontainer']=$orderedcontainer;


if(($order_detail_item)||($orderedcontainer))
{
//print_r($order_detail_item);
//print_r($orderedcontainer);
$this->load->view('ordercollection_header.php');
$this->load->view('specialevent/ordercollection/collectorder',$data);
}
else
{
redirect(base_url().'specialevent/collectorder/index');
}
}



public function confirmcollection()
	{
$orderid=$this->input->post('orderid');
$this->db->query("update specialorder set collection_status ='collected' where orderid='$orderid'");
redirect(base_url().'specialevent/collectorder');


}




public function samplecheck()
	{
//$orderid=$this->input->post('orderid');


}


}