<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Printorder extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		

	
$this->load->library('functions');
	}
	
	
	


public function index($orderslug)
{


//orderid
$table_name='specialorder';
$primary_key_column='orderid';
$slug_column_name='orderslug';
$orderid= $this->functions->get_id($orderslug,$table_name,$primary_key_column,$slug_column_name);
//orderid

//get paid amount
$data['paidamount']=$this->payment_model->get_paidamount($orderid);
//get paid amount

//get balpay
$data['balpay']=$this->payment_model->get_balpay($orderid);
//get balpay

$data['orderid']=$orderid;
$data['order_detail_item']=$this->ordercollection_model->select_order($orderid);
$data['orderedcontainer']=$this->ordercollection_model->select_orderedcontainer($orderid);
$this->load->view('specialevent/print/printview',$data);
		
}
}