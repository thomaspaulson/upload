<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Email extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		
	$this->load->library('functions');		
	}
	
	public function orderconfirmemail($orderslug)  // to both admin and cust
{
	         

$this->load->helper('url');
$this->load->helper('form');
$this->load->library('email');
$config['protocol'] = 'mail';
$config['mailtype'] = 'html';
$config['mailpath'] = '';
$config['charset'] = 'utf-8';
$config['crlf'] = '\r\n';
$config['wordwrap'] = TRUE;
$this->email->initialize($config);
$baseurl = base_url();
			
		        
	$content_head	=	'<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"> 
									
													<title>Iqbal Catering Service</title>
													<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
													</head>
													<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
													<table width="600" cellpadding="0" cellspacing="0" border="0" align="center">
													<tr>
													<td align="left" valign="top">
														<img src="'.base_url().'extras/extra/images/caterplus_logo.png" alt="'.base_url().'" width="600" height="137" border="1px normal #000;"></td>
													</tr>
													<tr>
													<td width="600" align="left" valign="top"><table width="600" border="0" cellspacing="0" cellpadding="0">
													<tr>
													<td width="10" bgcolor="#EEEEEE">&nbsp;</td>
													<td style="font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#666; padding: 0 10px;">';
						






$content_tail 			=  '</td>
													<td width="10" bgcolor="#EEEEEE">&nbsp;</td>
													</tr>
													</table></td>
													</tr>
													<tr>
													<td align="left" valign="top">
													</td>
													</tr>
													<tr>
													<td align="left" valign="top" bgcolor="#666666" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#f2f2f2; padding:5px 10px;">&copy;'.date('Y').'. '.base_url().' . All Rights Reserved.
													</tr>
													</table>
													</body>
													</html>';






$a=$this->functions->createmail($orderslug);
$content=$a['content'];
$adminmail=$a['adminmail'];
$customeremail=$a['customeremail'];


$content=$content_head.$content;
$content .= base_url().'</p><br/>'.$content_tail;


$this->email->from('IqbalCatering');	        
$this->email->to($adminmail);
$this->email->to($customeremail);
$this->email->subject('Iqbal Catering Service');

			
$this->email->message($content);
$msg =  $this->email->send();	

redirect('specialevent/printorder/index/'.$orderslug); 
		
	}
	




	public function orderconfirmemailadmin($orderslug)  // to admin only
{
	         

$this->load->helper('url');
$this->load->helper('form');
$this->load->library('email');
$config['protocol'] = 'mail';
$config['mailtype'] = 'html';
$config['mailpath'] = '';
$config['charset'] = 'utf-8';
$config['crlf'] = '\r\n';
$config['wordwrap'] = TRUE;
$this->email->initialize($config);
$baseurl = base_url();
			





		        
	$content_head	=	'<html>
									<head>
													<title>Iqbal Catering Service</title>
													<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
													</head>
													<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
													<table width="600" cellpadding="0" cellspacing="0" border="0" align="center">
													<tr>
													<td align="left" valign="top">
														<img src="'.base_url().'extras/extra/images/caterplus_logo.png" alt="'.base_url().'" width="600" height="137" border="1px normal #000;"></td>
													</tr>
													<tr>
													<td width="600" align="left" valign="top"><table width="600" border="0" cellspacing="0" cellpadding="0">
													<tr>
													<td width="10" bgcolor="#EEEEEE">&nbsp;</td>
													<td style="font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#666; padding: 0 10px;">';
						






$content_tail 			=  '</td>
													<td width="10" bgcolor="#EEEEEE">&nbsp;</td>
													</tr>
													</table></td>
													</tr>
													<tr>
													<td align="left" valign="top">
													</td>
													</tr>
													<tr>
													<td align="left" valign="top" bgcolor="#666666" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#f2f2f2; padding:5px 10px;">&copy;'.date('Y').'. '.base_url().' . All Rights Reserved.
													</tr>
													</table>
													</body>
													</html>';




$a=$this->functions->createmail($orderslug);
$content=$a['content'];
$adminmail=$a['adminmail'];



$content=$content_head.$content;
$content .= base_url().'</p><br/>'.$content_tail;


$this->email->from('IqbalCatering');	        
$this->email->to($adminmail);
$this->email->subject('Iqbal Catering Service');

			
$this->email->message($content);
$msg =  $this->email->send();	

redirect('specialevent/printorder/index/'.$orderslug); 
		
	}
	





}