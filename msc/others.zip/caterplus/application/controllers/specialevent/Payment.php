<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Payment extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		

		
	}
	
	public function index()
	{
    		$data['orders'] = $this->specialitem_model->get_unpaid_orders();
    		$data['order_id'] = $this->input->post('order_id');
    		$this->load->view('specialevent/specialorder/payment',$data);	
	}
	
	public function new_customer(){
		$data['order_id'] = $this->input->get('order_id');
		$this->load->view('specialevent/specialorder/customer',$data);	
	}
	
	public function save_customer(){
		$this->output->enable_profiler();
		$name = $this->input->post('name');
		$address = $this->input->post('address');
		$phone= $this->input->post('phone');
		$mobile1 = $this->input->post('mobile1');
		$mobile2 = $this->input->post('mobile2');
		$email = $this->input->post('email');
		$order_id = $this->input->post('order_id');										
		$data= array(
			'customername' => $name,
			'customeraddress' => $address,
			'customeremail' => $email,
			'customerphone' => $phone,
			'customermobile1' => $mobile1,
			'customermobile2' => $mobile2,
		
		);
		$customer_id = $this->specialitem_model->save_customer($data);
		$datas = array(
			'orderstatus' => 'confirmed',
			'customer_id' => $customer_id,
		);
		$this->specialitem_model->update_order_table($datas,$order_id); 
		redirect('/specialevent/payment');				
	}


	
	
		
	
	
}