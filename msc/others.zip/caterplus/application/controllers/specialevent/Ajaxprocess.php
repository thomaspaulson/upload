<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ajaxprocess extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		
	$this->load->library('functions');	
	}
	public function index()
	{
$currentuserid=($_POST["currentuserid"]);
$user_id = ($_POST["user_id"]);
//$user_id=$this->post("user_id");
$query=$this->db->query("select * from employee where user_id='$user_id' and employeeid NOT IN('$currentuserid')");
$result=$query->result_array();
$total = count($result);

if($total>0){ echo "0"; }
else{ echo "1"; }

}



}