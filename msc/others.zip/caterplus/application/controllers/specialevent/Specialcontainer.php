<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specialcontainer extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'manager') ){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
	}

	public function index($page=0){
        	//$data['containers'] = $this->special_container_model->select_container();

$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id',$comp_id);
$query = $this->db->get('special_container');
		$total = $query->num_rows(); 
	
		$array = $query->result_array();
		
		$data['containers'] = $array;
$this->load->library('pagination');
		
		$config['base_url'] = base_url()."/index.php/specialevent/specialcontainer/index/";
		$config['total_rows'] = $total;
		$config['per_page'] =30;
		$config['uri_segment'] = 4;
		$config['num_links'] = 2;
		//$config['page_query_string'] = TRUE;
		//$config['full_tag_open'] = '<a class ="number">';
		//$config['full_tag_close'] = '</a>';
		$config['first_link'] = '&laquo; First';
		//$config['first_tag_open'] = '<span>';
		//$config['first_tag_close'] = '</span>';
		$config['last_link'] = 'Last &raquo;';
		//$config['last_tag_open'] = '<span>';
		//$config['last_tag_close'] = '</span>';
		$config['next_link'] = 'Next &raquo;';
		$config['prev_link'] = '&laquo; Previous';
		$config['cur_tag_open'] = '<a class ="number current">';
		$config['cur_tag_close'] = '</a>';
		
		
		
		$this->pagination->initialize($config);
		$data['page'] = $page;
$this->db->where('comp_id',$comp_id);
		$this->db->where('special_cstatus','active');
$this->db->order_by('special_cid','desc');
		$query = $this->db->get('special_container', $config['per_page'], $page);
		$data['paages'] = $this->pagination->create_links();
		//print_r($data['paages']);
//exit();
		$array = $query->result_array();
		
		$data['packages'] = $array;
		$this->load->view('headermerged',$data);     
		$this->load->view('specialevent/specialcontainer/containerlist.php',$data);     
		//$this->load->view('footerform',$data);        
	}

	public function addcontainer(){

        	$this->load->view('specialevent/specialcontainer/addcontainer');     
        }
	
	public function insertcontainer()
	{
	      $this->special_container_model->insert_container($_POST);
              redirect('specialevent/specialcontainer/index');
	}
	
	public function  delete_container($slug=''){
 		$this->special_container_model->delete_container($slug);
 		$this->session->set_flashdata('message','Successfully Updated');
 		redirect('specialevent/specialcontainer/index');
        }
        
	public function  activate_container($slug=''){
 		$this->special_container_model->activate_container($slug);
 		$this->session->set_flashdata('message','Successfully Upated');
 		redirect('specialevent/specialcontainer/index');
        }        
       
	public function  edit_container($slug=''){
       		$this->load->library('functions');
        	$table_name='special_container';
        	$primary_key = 'special_cid';
        	$slug_column_name = 'special_cslug';
        	$id = $this->functions->get_id($slug,$table_name,$primary_key,$slug_column_name);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Container Doesnt Exists !');
        		redirect(base_url().'specialevent/specialcontainer', 'refresh');
        		exit();
        	}

        	$data['id'] = $id;
        	$data['containers'] = $this->special_container_model->get_container_details($id);
        	$this->load->view('newheader',$data);  
        	$this->load->view('specialevent/specialcontainer/edit_container',$data);  
        	$this->load->view('newfooter',$data);  
        }   
       
       public function edit_existing_container(){
	        $id = $this->input->post('id');
		$name = $this->input->post('special_cname');
		$price = $this->input->post('special_cprice');			        
		$desc = $this->input->post('special_cdesc');
		$data = array(
			'name' => $name,
			'price' =>$price,
			'desc' =>$desc,
			'id' => $id,

		);
		$result = $this->special_container_model->edit_container($data);	
		if($result = 1){
			redirect(base_url().'specialevent/specialcontainer', 'refresh');
		}       
       
       }    
function changestatus($cid=null){
				$query = $this->db->get_where('special_container', array('special_cid' => $cid));
				$array = $query->result_array();
				$status=($array[0]['special_cstatus']=="active")?"inactive":"active";  

		$data = array(
				   'special_cstatus' => $status
				);
			$this->db->update('special_container', $data, array('special_cid' => $cid));
			redirect("specialevent/specialcontainer");	
		}
	
}