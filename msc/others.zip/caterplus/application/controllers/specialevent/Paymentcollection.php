<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Paymentcollection extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'payment')||($this->session->userdata('type') == 'manager')||($this->session->userdata('type') == 'office')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
	$this->load->library('functions');	
	}
	public function index($orderslug,$custslug)
	{

//cust
$table_name='customer';
$primary_key_column='customerId';
$slug_column_name='customerslug';
$custid= $this->functions->get_id($custslug,$table_name,$primary_key_column,$slug_column_name);

//cust
//orderid
$table_name='specialorder';
$primary_key_column='orderid';
$slug_column_name='orderslug';
$orderid= $this->functions->get_id($orderslug,$table_name,$primary_key_column,$slug_column_name);
//orderid

$this->db->where('customerId',$custid); 
$query=$this->db->get('customer');
$custdetail=$query->result_array();
foreach($custdetail as $cdetail)
{
$data['custname']=$cdetail['customername'];
$data['custmob']=$cdetail['customermobile1'];
$data['address']=$cdetail['customeraddress'];
$data['email']=$cdetail['customeremail'];

}

$data['cusdetail']=$custdetail;
$data['custid']=$custid;
$data['orderid']=$orderid;
$data['orderslug']=$orderslug;
$totalamount=$this->db->query("select * from specialorder where orderid='$orderid'");

$tamount=$totalamount->result_array(); 
foreach($tamount as $ttamount)
{ $talltotal= $ttamount['totalamount'];   }

$query=$this->db->query("select * from specialeventpaymentrelation where orderid='$orderid' and balance<$talltotal");
$nums=$query->num_rows();
foreach ($query->result() as $row)
{
   $amt_paid=$row->paidamount;   
   $data['amt_paid']=$amt_paid;  
   $bal_amt=$row->balance;  
   $data['bal_amt']=$bal_amt;  
}
if($nums==0) {
$data['amt_paid']=0;
$data['bal_amt']=0;
}

    		$data['alltotal']=$talltotal;
    		
    		$this->load->view('paymentheader.php');
    		$this->load->view('specialevent/paymentcolection/collectpayment',$data);	
	}



public function collect()
	{
    		if(isset($_POST['donepayment']))
{ 

$this->payment_model ->insert_directpayment($_POST); 
$orderslug=$this->input->post('orderslug');
$emailcheck=$this->input->post('emailcheck');
$printcheck=$this->input->post('printcheck');

if($emailcheck)
{ //email both admin and customer
redirect('specialevent/email/orderconfirmemail/'.$orderslug);
} //email
else // mail to admin only
{ redirect('specialevent/email/orderconfirmemailadmin/'.$orderslug); }

}else
{ exit(); }
	}



public function collectbal()
	{
    		if(isset($_POST['donepayment']))
{ 
$this->payment_model ->insert_paymentbal($_POST);
$orderslug=$this->input->post('orderslug');
redirect('specialevent/printorder/index/'.$orderslug);
}else
{ exit(); }
	}




public function balancepay() //through order collection
	{

$orderid=$this->input->post('orderno');
$idds=$this->db->query("select * from specialorder where  orderid='$orderid' and payment_status='unpaid'");
$custidlist=$idds->result_array(); 
if(($custidlist)&&($orderid))
{

foreach($custidlist as $cust)
{ $custid= $cust['customer_id']; $orderslug=$cust['orderslug'];  }

$this->db->where('customerId',$custid); 
$query=$this->db->get('customer');
$custdetail=$query->result_array();
foreach($custdetail as $cdetail)
{
$data['custname']=$cdetail['customername'];
$data['custmob']=$cdetail['customermobile1'];
$data['address']=$cdetail['customeraddress'];
$data['email']=$cdetail['customeremail'];
}
$data['orderslug']=$orderslug;
$data['cusdetail']=$custdetail;
$data['custid']=$custid;
$data['orderid']=$orderid;

$totalamount=$this->db->query("select * from specialorder where  orderid='$orderid' and payment_status='unpaid'");
$tamount=$totalamount->result_array(); 
foreach($tamount as $ttamount)
{ $talltotal= $ttamount['totalamount'];   }

$balamount=$this->db->query("select sum(paidamount) as cbal from specialeventpaymentrelation where  orderid='$orderid'");
$amountbal=$balamount->result_array(); 
foreach($amountbal as $bal)
{ $balanceamt= $bal['cbal'];   } //already paid

if($balanceamt)
{ $data['alreadypaid']=$balanceamt; } else {  $data['alreadypaid']=0; $balanceamt=0; }

$data['currbal']=$talltotal-$balanceamt;

$query=$this->db->query("select * from specialeventpaymentrelation where orderid='$orderid' and balance<$talltotal");
$nums=$query->num_rows();
foreach ($query->result() as $row)
{
   $amt_paid=$row->paidamount;   
   $data['amt_paid']=$amt_paid; 
}
if($nums==0) {
$data['amt_paid']=0;

}

$data['alltotal']=$talltotal;
$this->load->view('paymentheader.php');
$this->load->view('specialevent/paymentcolection/balancepayment',$data);
}else{ redirect(base_url()); }
}




public function balancepayment()
	{
$data['orderlist']=$this->payment_model->select_orderforpayment();
$this->load->view('ordercollection_header.php');
$this->load->view('specialevent/paymentcolection/collectpaymentindex',$data);


}



public function homedeliverybalpay()
	{
$data['orderlist']=$this->payment_model->homedeliveryforpayment();
$this->load->view('ordercollection_header.php');
$this->load->view('specialevent/paymentcolection/collpayhomedelivery',$data);


}







	}