<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specialkitchen  extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'chef')||($this->session->userdata('type') == 'manager')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
		$this->load->library('functions');
	}

	public function test(){
		exit('test');
	}
	public function viewkitchen($msg='')
	{		
		//exit('dd');
		//$this->output->enable_profiler(TRUE);	
		$data['allitems'] = $this->supplier_model->getallcategories_allitems();

		$br_id=$this->session->userdata('branch_id');
		/***added commended***/
		$br_id=$this->session->userdata('branch_id');
		$date=date("Y-m-d");
		/***added***/
		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$start = $this->input->post('start');
			$end = $this->input->post('end');
			//$date = date('Y-m-d');
			$data['active'] = $start . $end;
			//$data['orders']= $this->kitchen_model->get_orders_between_timeslots($start,$end,$date);				
			//echo '<pre>';
			//print_r($data['orders']);
			//echo '</pre>';		
		}else{
			$start = 00;
			$end = 00;
			//$date = date('Y-m-d');
			$data['active'] = $start . $end;
			//$data['orders']= $this->kitchen_model->get_orders_between_timeslots(10,13,$date);						
			//$data['orders']= $this->kitchen_model->all_order($date);				
			//echo '<pre>';
			//print_r($data['orders']);
			//echo '</pre>';

		}
		
		$data['specialpackage'] = $this->package_model->all_packages();


		$data['cooked_items'] = $this->kitchen_model->cooked_items();
		$data['menus'] = $this->kitchen_model->get_all_menus();	
		
		$data['morning_orders']= $this->kitchen_model->get_orders_between_timeslots(10,13,$date);	
		$data['afternoon_orders']= $this->kitchen_model->get_orders_between_timeslots(13,16,$date);
		$data['evening_orders']= $this->kitchen_model->get_orders_between_timeslots(16,19,$date);
		$data['night_orders']= $this->kitchen_model->get_orders_between_timeslots(19,24,$date);
		$data['all_orders']= $this->kitchen_model->all_order($date);									
		$morning_id = $this->kitchen_model->insert_into_morning_table($data['allitems'],$date,$data['morning_orders']);
		$afternoon_id = $this->kitchen_model->insert_into_afternoon_table($data['allitems'],$date,$data['afternoon_orders']);
		$evening_id = $this->kitchen_model->insert_into_evening_table($data['allitems'],$date,$data['evening_orders']);
		$night_id = $this->kitchen_model->insert_into_night_table($data['allitems'],$date,$data['night_orders']);
		$all_id = $this->kitchen_model->insert_into_all_table($data['allitems'],$date,$data['all_orders']);
		$data['total_cooked_stocks'] = $this->kitchen_model->get_temperatures($date,'all');
																												

		if($data['active'] == 1013){
			$data['status_table_name']='morning';
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'morning');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'morning');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'morning');						
		}else if($data['active'] == 0000){
			$data['status_table_name']='all';				
			$data['started_items'] = $this->kitchen_model->get_all_started_items($date);			
			$data['completed_items'] = $this->kitchen_model->get_all_completed_items($date);
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'all');
			//$data['temperatures'] = $this->kitchen_model->get_temperatures_all($date);													
		}else if($data['active'] == 1316){
			$data['status_table_name']='afternoon';		
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'afternoon');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'afternoon');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'afternoon');
										
		}else if($data['active'] == 1619){
			$data['status_table_name']='evening';		
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'evening');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'evening');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'evening');								
		}else{
			$data['status_table_name']='night';		
			$data['cooking_status_items'] = $this->kitchen_model->get_cooking_status_items($date,'night');
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'night');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'night');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'night');								
		}						

		
			 		
		//echo '<pre>';
		//print_r($data['temperatures']);
		//echo '</pre>';
		//$this->load->view('headerkitchen');		
		$this->load->view('specialevent/specialkitchen/kitchen.php',$data); 	
	}
	
	public function timeslots($msg='')
	{	
		$data['msg'] = '';
		$this->load->view('specialevent/specialkitchen/timeslots.php',$data); 	
	}
	
	public function get_timeslots_ajax($x=''){
		$data['interval'] = $x;
		$this->load->view('specialevent/specialkitchen/timeslots_ajax',$data);
	}
	public function get_timeslot_orders_ajax($x=''){
		$explode = explode('-',$x);
		$start = $explode[0];
		$end = $explode[1];
		$data['allitems'] = $this->supplier_model->getallcategories_allitems();		
		$data['timeslot_orders']= $this->kitchen_model->get_orders_between_timeslots($start,$end);
		$this->load->view('specialevent/specialkitchen/timeslot_orders_ajax',$data);		

	}
	
	public function add_additional_ajax($x=''){
		$explode = explode('-',$x);
		$start = $explode[0];
		$end = $explode[1];
		$data['allitems'] = $this->supplier_model->getallcategories_allitems();		
		$data['timeslot_orders']= $this->kitchen_model->get_orders_between_timeslots($start,$end);
		$this->load->view('specialevent/specialkitchen/add_additional_ajax',$data);		

	}
	
	public function add_to_cook(){

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
		$this->output->enable_profiler();
		$items = $this->input->post('item');
		foreach($items as $item){
			$order_name = 'total_order_' . $item;
			$additional_name = 'add_additional_' . $item;
			$order = $this->input->post($order_name);
			$additional = $this->input->post($additional_name);
			$data = array('comp_id'=>$comp_id,'br_id'=> $br_id,
				'itemid' => $item,
				'total_order' => $order,
				'additional' => $additional,
				'total' => $order + $additional,
			);

			$insert_id = $this->kitchen_model->insert_to_cook($data);			
		}
		redirect('/specialevent/specialkitchen/viewkitchen');
	}
	
	public function auth_ajax($user_id='',$user_pin='',$status_table_name='',$item_id='',$status='',$temperatue='',$additional=''){
                $this->load->library('functions');
		if($status == 'started'){
			//$data['ingredients'] = $this->kitchen_model->get_item_ingredients($item_id); // hided for update only in order taking
			//$this->kitchen_model->raw_stock($data['ingredients'],$additional); //also pending if additional cooked,stock not decreases
		}
		$employee_id = $this->functions->auth($user_id,$user_pin);



		if($employee_id){
			//$date = date('Y-m-d');
/**safin added commended**/
$date="2015-07-17";
/**safin added**/
			$result = $this->kitchen_model->update_cooking_status($employee_id,$status_table_name,$item_id,$status,$date,$temperatue,$additional);
			if($result == 0){
				echo 'error';
			}else if($result == 1){
				echo 'success';
			}else{
				echo 'exists';
			}
		}else{
			echo $employee_id;
		}

	}
	
	
}	