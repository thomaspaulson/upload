<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Takeorder extends CI_Controller {

    function __construct() {
        parent::__construct();
               $this->load->library('functions');
    }

    public function index($orderslugg, $slug) { // w.r.  to new design 
        if (($orderslugg) && ($slug)) { // both hav param values
//cust
            $table_name = 'customer';
            $primary_key = 'customerId';
            $slug_column_name = 'customerslug';
            $custid = $this->functions->get_id($slug, $table_name, $primary_key, $slug_column_name);
//cust
//order
            $table_name = 'specialorder';
            $primary_key = 'orderid';
            $slug_column_name = 'orderslug';
            $orderid = $this->functions->get_id($orderslugg, $table_name, $primary_key, $slug_column_name);
//order slug

            if (($orderid) && ($custid)) {


                $this->db->where('customerId', $custid);
                $query = $this->db->get('customer');
                $custdetail = $query->result_array();
                foreach ($custdetail as $cdetail) {
                    $data['custname'] = $cdetail['customername'];
                    $data['custmob'] = $cdetail['customermobile1'];
                }

                $data['cusdetail'] = $custdetail;
                $data['orderid'] = $orderid;
                $data['custid'] = $custid;

                $data['menu'] = $this->specialitem_model->get_all_menu_active();
                $data['items'] = $this->specialitem_model->get_all_items_active();
                $data['packages'] = $this->specialitem_model->get_all_packages_active();
                $data['containers'] = $this->specialitem_model->get_all_containers_active();


                $this->load->view('neworderheader');
                $this->load->view('specialevent/specialorder/addneworder', $data);
//$this->load->view('neworderfooter');
            } else {
                redirect(base_url());
                exit();
            } //no custid or orderid
        } else {
            redirect(base_url());
            exit();
        } //no no both params
    }

    public function order() {
        $this->load->view('specialevent/specialorder/order', $data);
    }

    function select_item($id = '') {
        $data['item'] = $this->specialitem_model->select_item($id);
        $this->load->view('specialevent/specialorder/itemajax', $data);
    }

    public function select_item_unit($id = '') {
        $item_unit = $this->specialitem_model->select_item_unit($id);
        echo $item_unit;
    }

    public function savespecialorder() { // w.r. to new design
    
        $checkexist = 0;
        $contnum = 0;
        $orderid = $this->input->post("orderid");
        $custid = $this->input->post("custid");

        $currdate = date("Y/m/d");

        if (isset($_REQUEST['cancelorder'])) {
            redirect(base_url());
            exit();
        } elseif (isset($_REQUEST['holdorder'])) {
            $status = "hold";
        } elseif (isset($_REQUEST['confirmorder'])) {
            $status = "confirmed";
        } else {
            redirect(base_url());
            exit();
        }


        if ((isset($_REQUEST['confirmorder'])) || (isset($_REQUEST['holdorder']))) {
            $items = $this->specialitem_model->get_all_items();

            foreach ($items as $itemlist) {
                $itemid = $itemlist['itemid'];
                $package = $this->specialitem_model->get_all_packages();
                $getitemid = $this->input->post("itemid_" . $itemid);
                foreach ($package as $packagelist) {
                    $pkid = $packagelist['specialp_id'];
                    $getpackageid = $this->input->post("packageid_" . $itemid . "_" . $pkid);
                    $getpackagenos = $this->input->post("pkgnum_" . $itemid . "_" . $pkid);


                    if (($getpackagenos) && ($getpackageid) && ($getitemid)) { //if get all values
                        $checkexist = $checkexist + 1;


                        $query = $this->db->query("select * from Item where itemid='$getitemid'");
                        $itemarray = $query->result_array();
                        $query = $this->db->query("select * from specialpackage where specialp_id='$getpackageid'");
                        $packagearray = $query->result_array();
                        foreach ($itemarray as $itemar) {
                            $itemprice = $itemar['itemprice'];
                        }
                        foreach ($packagearray as $pkgar) {
                            $pkgqty = $pkgar['specialp_qty'];
                        }

                        $itemqty = $pkgqty * $getpackagenos;

                        $data['ingredients'] = $this->ingredientquantity_model->get_item_ingredients($getitemid); // update ingredient stock while taking order- line 1
                        $this->ingredientquantity_model->raw_stock($data['ingredients'], $itemqty); // added two lines only- line 2


                        $totprice = $itemqty * $itemprice;
                        $data2 = array(
                            'orderid' => $orderid,
                            'packageid' => $getpackageid,
                            'package_quantity' => $pkgqty,
                            'package_ordered_number' => $getpackagenos,
                            'base_price_of_item' => $itemprice,
                            'total_item' => $itemqty,
                            'total_price' => $totprice,
                            'itemid' => $getitemid,
                        );
/*safin adding comp id and br id static*/                 
$specialorder_update= array(
               'comp_id' => "60",
               'br_id' => "81",                
            );

$this->db->where('orderid', $orderid);
$this->db->update('specialorder', $specialorder_update); 
/*safin adding comp id and br id static*/


                        $this->db->insert('specialorderquantity', $data2);





                    }
                } // package list
            }// item list		

            $query = $this->db->query("select * from special_container where special_cstatus='active'");
            $containerarray = $query->result_array();
            foreach ($containerarray as $containerar) { // list all container to get post values
                $cid = $containerar['special_cid'];
                $getcid = $this->input->post("containerid_" . $cid);
                $getcnos = $this->input->post("containernos_" . $cid);

                if (($getcid) && ($getcnos)) { //get details of posted container
                    $query = $this->db->query("select * from special_container where special_cid='$getcid'");
                    $contnum = $contnum + 1;
                    $containdetail = $query->result_array();
                    foreach ($containdetail as $crlist) {
                        $conbasicprice = $crlist['special_cprice'];
                    }
                    $totconprice = $conbasicprice * $getcnos;


                    $condetailarray = array('order_id' => $orderid,
                        'container_id' => $getcid,
                        'container_quantity' => $getcnos,
                        'container_base_price' => $conbasicprice,
                        'container_total_price' => $totconprice,'comp_id'=>"60",'br_id'=>"81");
                    $this->db->insert('specialorder_container', $condetailarray);
                }// ends details of posted container if exists
            }// ends container list all
//get total amount of item and container
            $itemsum = 0;
            $query = $this->db->query("select sum(total_price) as ittsum from specialorderquantity where orderid='$orderid'");
            $sumt = $query->result_array();
            if ($sumt) {
                foreach ($sumt as $tsum) {
                    $itemsum = $tsum['ittsum'];
                }
            }




           $query = $this->db->query("select sum(container_total_price) as consum from specialorder_container where order_id='$orderid'");
            $sumc = $query->result_array();
            if ($sumc) {
                foreach ($sumc as $csum) {
                    $contsum = $csum['consum'];
                }
            } 

            $totalamount = $itemsum + $contsum;
            $this->db->query("update specialorder set totalamount='$totalamount',orderstatus='$status' where orderid='$orderid'");

/*safin adding comp id and br id static*/                 
$specialorder_update= array(
               'comp_id' => "60",
               'br_id' => "81",                
            );

$this->db->where('orderid', $orderid);
$this->db->update('specialorder', $specialorder_update); 
/*safin adding comp id and br id static*/

//get total amount,updated t main order table ended 

            $table_name = 'specialorder';
            $primary_key_column = 'orderid';
            $slug_column_name = 'orderslug';
            $orderslug = $this->functions->get_slug($orderid, $table_name, $primary_key_column, $slug_column_name);

            $table_name = 'customer';
            $primary_key_column = 'customerId';
            $slug_column_name = 'customerslug';
            $custslug = $this->functions->get_slug($custid, $table_name, $primary_key_column, $slug_column_name);

            if (($checkexist == 0) && ($contnum == 0)) { //redirect if no item or container
                redirect(base_url());
                exit();
            }



            redirect('specialevent/paymentcollection/index/' . $orderslug . '/' . $custslug);
        } // if confirm
    }

// function close

    public function getcollectiontime() { //create dummy order page background for get collection time
        $deliverydate = $this->input->post('deliverydate');
        $this->session->set_userdata('temprdate', $deliverydate);

//$this->load->view('specialevent/specialorder/takeorder',$data);     	
        $this->load->view('headermerged.php');
        $this->load->view('specialevent/specialorder/customer');
//no no both params
    }

// Not using now starts
    public function auth_ajax($user_id = '', $user_pin = '', $orderid = '') {
        $this->load->library('functions');
        $employee_id = $this->functions->auth($user_id, $user_pin);
        if ($employee_id) {

            $query = $this->db->query("update specialorder set employee_id='$employee_id' where orderid='$orderid'");

            $result = 1;


            if ($result == 0) {
                echo 'error';
            } else if ($result == 1) {
                echo 'success';
            }
        } else {
            echo $employee_id;
        }
    }

// Not using now ends
    /*

      public function edit_order($orderslug=''){ //old
      //order
      $table_name='specialorder';
      $primary_key = 'orderid';
      $slug_column_name='orderslug';
      $orderid= $this->functions->get_id($orderslug,$table_name,$primary_key,$slug_column_name);
      //order slug
      //details of order
      $order_detail_item=$this->specialorder_model->select_order($orderid);
      $data['orderitem']=$order_detail_item;
      $orderedcontainer=$this->specialorder_model->select_orderedcontainer($orderid);
      $data['ordercontainer']=$orderedcontainer;
      //details of order

      $data['orderslug']=$orderslug;
      if($order_detail_item||$orderedcontainer)
      {
      //$this->load->view('neworderheader');
      //$this->load->view('specialevent/specialorder/edit_order',$data);
      }
      else
      {redirect(base_url()); }
      }
     */














    public function newedit_order($orderslug = '') { //new
//order
        $table_name = 'specialorder';
        $primary_key = 'orderid';
        $slug_column_name = 'orderslug';
        $orderid = $this->functions->get_id($orderslug, $table_name, $primary_key, $slug_column_name);
//order slug

        $order_detail_item = $this->specialorder_model->select_order($orderid);
        $data['orderitem'] = $order_detail_item;

        $orderedcontainer = $this->specialorder_model->select_orderedcontainer($orderid);
        $data['ordercontainer'] = $orderedcontainer;
        $data['orderslug'] = $orderslug;

        if ($order_detail_item || $orderedcontainer) {
            $data['menu'] = $this->specialitem_model->get_all_menu_active();
            $data['items'] = $this->specialitem_model->get_all_items_active();
            $data['packages'] = $this->specialitem_model->get_all_packages_active();
            $data['containers'] = $this->specialitem_model->get_all_containers_active();

            $this->load->view('neworderheader');
            $this->load->view('specialevent/specialorder/newedit_order', $data);
        } else {
            redirect(base_url());
        }
    }

    public function updatespecialorder() { // w.r. to new design new
        $checkexist = 0;
        $contnum = 0;
        $orderid = $this->input->post("orderid");
        $custid = $this->input->post("custid");
        $orderslug = $this->input->post("orderslug");
        $currdate = date("Y/m/d");

        if (isset($_REQUEST['cancelorder'])) {
            redirect(base_url());
            exit();
        } elseif (isset($_REQUEST['holdorder'])) {
            $status = "hold";
        } elseif (isset($_REQUEST['confirmorder'])) {
            $status = "confirmed";
        } else {
            redirect(base_url());
            exit();
        }


        if ((isset($_REQUEST['confirmorder'])) || (isset($_REQUEST['holdorder']))) {
            $this->db->delete('specialorderquantity', array('orderid' => $orderid));  //first delete all item orders
            $this->db->delete('specialorder_container', array('order_id' => $orderid));
            $items = $this->specialitem_model->get_all_items();

            foreach ($items as $itemlist) {
                $itemid = $itemlist['itemid'];
                $package = $this->specialitem_model->get_all_packages();
                $getitemid = $this->input->post("itemid_" . $itemid);
                foreach ($package as $packagelist) {
                    $pkid = $packagelist['specialp_id'];
                    $getpackageid = $this->input->post("packageid_" . $itemid . "_" . $pkid);
                    $getpackagenos = $this->input->post("pkgnum_" . $itemid . "_" . $pkid);


                    if (($getpackagenos) && ($getpackageid) && ($getitemid)) { //if get all values
                        $checkexist = $checkexist + 1;


                        $query = $this->db->query("select * from Item where itemid='$getitemid'");
                        $itemarray = $query->result_array();
                        $query = $this->db->query("select * from specialpackage where specialp_id='$getpackageid'");
                        $packagearray = $query->result_array();
                        foreach ($itemarray as $itemar) {
                            $itemprice = $itemar['itemprice'];
                        }
                        foreach ($packagearray as $pkgar) {
                            $pkgqty = $pkgar['specialp_qty'];
                        }

                        $itemqty = $pkgqty * $getpackagenos;

//$data['ingredients'] = $this->ingredientquantity_model->get_item_ingredients($getitemid); // update ingredient stock while taking order- line 1
//$this->ingredientquantity_model->raw_stock($data['ingredients'],$itemqty); // added two lines only- line 2


                        $totprice = $itemqty * $itemprice;
                        $data2 = array(
                            'orderid' => $orderid,
                            'packageid' => $getpackageid,
                            'package_quantity' => $pkgqty,
                            'package_ordered_number' => $getpackagenos,
                            'base_price_of_item' => $itemprice,
                            'total_item' => $itemqty,
                            'total_price' => $totprice,
                            'itemid' => $getitemid,
                        );

                        $this->db->insert('specialorderquantity', $data2);
                    }
                } // package list
            }// item list		

            $query = $this->db->query("select * from special_container where special_cstatus='active'");
            $containerarray = $query->result_array();
            foreach ($containerarray as $containerar) { // list all container to get post values
                $cid = $containerar['special_cid'];
                $getcid = $this->input->post("containerid_" . $cid);
                $getcnos = $this->input->post("containernos_" . $cid);


                if (($getcid) && ($getcnos)) { //get details of posted container
                    $query = $this->db->query("select * from special_container where special_cid='$getcid'");
                    $contnum = $contnum + 1;
                    $containdetail = $query->result_array();
                    foreach ($containdetail as $crlist) {
                        $conbasicprice = $crlist['special_cprice'];
                    }
                    $totconprice = $conbasicprice * $getcnos;


                    $condetailarray = array('order_id' => $orderid,
                        'container_id' => $getcid,
                        'container_quantity' => $getcnos,
                        'container_base_price' => $conbasicprice,
                        'container_total_price' => $totconprice,);


                    $this->db->insert('specialorder_container', $condetailarray);
                }// ends details of posted container if exists
            }// ends container list all
//get total amount of item and container
            $itemsum = 0;
            $query = $this->db->query("select sum(total_price) as ittsum from specialorderquantity where orderid='$orderid'");
            $sumt = $query->result_array();
            if ($sumt) {
                foreach ($sumt as $tsum) {
                    $itemsum = $tsum['ittsum'];
                }
            }




            $query = $this->db->query("select sum(container_total_price) as consum from specialorder_container where order_id='$orderid'");
            $sumc = $query->result_array();
            if ($sumc) {
                foreach ($sumc as $csum) {
                    $contsum = $csum['consum'];
                }
            }

            $totalamount = $itemsum + $contsum;
            $this->db->query("update specialorder set totalamount='$totalamount' where orderid='$orderid'");

//get total amount,updated t main order table ended 



            $query = $this->db->query("select sum(paidamount) as totalpaid,custid as cust from specialeventpaymentrelation where orderid='$orderid'");
            $re = $query->result_array();
          
            $paidamount = 0;
            foreach ($re as $res) {
                $paidamount = $res['totalpaid'];
                $custid = $res['cust'];
            }

            $balance = $totalamount - $paidamount;
            if ($paidamount > $totalamount) {
                $this->db->query("update specialorder set payment_status='paid' where  orderid='$orderid'");
            }
            if ($paidamount < $totalamount) {
                $this->db->query("update specialorder set payment_status='unpaid' where  orderid='$orderid'");
            }
            $this->db->query("delete from specialeventpaymentrelation where orderid='$orderid'");

            $this->db->query("insert into specialeventpaymentrelation(custid,orderid,paidamount,balance,totalpay)
values('$custid','$orderid','$paidamount','$balance','$totalamount')");

            if ($checkexist > 0 || $contnum > 0) {
                redirect('specialevent/printorder/index/' . $orderslug);
            } else {
                redirect(base_url());
            }
        }
    }

// function close

    public function update_order($orderslug = '') { //old
//order
        $table_name = 'specialorder';
        $primary_key = 'orderid';
        $slug_column_name = 'orderslug';
        $orderid = $this->functions->get_id($orderslug, $table_name, $primary_key, $slug_column_name);
//order slug
        $this->db->query("delete from specialorderquantity where orderid='$orderid'");
        $this->db->query("delete from specialorder_container where order_id='$orderid'");

        $items = $this->specialitem_model->get_all_items();

        foreach ($items as $itemlist) {
            $itemid = $itemlist['itemid'];
            $package = $this->specialitem_model->get_all_packages();


            foreach ($package as $packagelist) {
                $pkid = $packagelist['specialp_id'];
                $getitemid = $this->input->post("item_" . $itemid . "_" . $pkid);
                $ordernum = $this->input->post("ordernum_" . $itemid . "_" . $pkid);

                $getpackagenos = $ordernum;

                if (($getpackagenos) && ($getitemid)) { //if get all values //$checkexist=$checkexist+1;
                    $getpackageid = $pkid;
                    $query = $this->db->query("select * from Item where itemid='$getitemid'");
                    $itemarray = $query->result_array();
                    $query = $this->db->query("select * from specialpackage where specialp_id='$pkid'");
                    $packagearray = $query->result_array();
                    foreach ($itemarray as $itemar) {
                        $itemprice = $itemar['itemprice'];
                    }
                    foreach ($packagearray as $pkgar) {
                        $pkgqty = $pkgar['specialp_qty'];
                    }

                    $itemqty = $pkgqty * $getpackagenos;
                    $totprice = $itemqty * $itemprice;
                    $data2 = array(
                        'orderid' => $orderid,
                        'packageid' => $getpackageid,
                        'package_quantity' => $pkgqty,
                        'package_ordered_number' => $getpackagenos,
                        'base_price_of_item' => $itemprice,
                        'total_item' => $itemqty,
                        'total_price' => $totprice,
                        'itemid' => $getitemid,
                    );


                    $this->db->insert('specialorderquantity', $data2);
                }
            } // package list
        }// item list




        $query = $this->db->query("select * from special_container where special_cstatus='active'");
        $containerarray = $query->result_array();
        foreach ($containerarray as $containerar) { // list all container to get post values
            $cid = $containerar['special_cid'];
            $getcid = $this->input->post("containerid_" . $cid);
            $getcnos = $this->input->post("containernos_" . $cid);

            if (($getcid) && ($getcnos)) { //get details of posted container
                $query = $this->db->query("select * from special_container where special_cid='$getcid'");
//$contnum=$contnum+1;
                $containdetail = $query->result_array();
                foreach ($containdetail as $crlist) {
                    $conbasicprice = $crlist['special_cprice'];
                }
                $totconprice = $conbasicprice * $getcnos;


                $condetailarray = array('order_id' => $orderid,
                    'container_id' => $getcid,
                    'container_quantity' => $getcnos,
                    'container_base_price' => $conbasicprice,
                    'container_total_price' => $totconprice,);




//needed to insert after delete

                $this->db->insert('specialorder_container', $condetailarray);
            }// ends details of posted container if exists
        }// ends container list all
//get total amount of item and container
        $itemsum = 0;
        $query = $this->db->query("select sum(total_price) as ittsum from specialorderquantity where orderid='$orderid'");
        $sumt = $query->result_array();
        if ($sumt) {
            foreach ($sumt as $tsum) {
                $itemsum = $tsum['ittsum'];
            }
        }




        $query = $this->db->query("select sum(container_total_price) as consum from specialorder_container where order_id='$orderid'");
        $sumc = $query->result_array();
        if ($sumc) {
            foreach ($sumc as $csum) {
                $contsum = $csum['consum'];
            }
        }

        $totalamount = $itemsum + $contsum;
        $this->db->query("update specialorder set totalamount='$totalamount' where orderid='$orderid'");

//get total amount,updated t main order table ended 



        $query = $this->db->query("select sum(paidamount) as totalpaid,custid as cust from specialeventpaymentrelation where orderid='$orderid'");
        $re = $query->result_array();
        $paidamount = 0;
        foreach ($re as $res) {
            $paidamount = $res['totalpaid'];
            $custid = $res['cust'];
        }

        $balance = $totalamount - $paidamount;
        if ($paidamount > $totalamount) {
            $this->db->query("update specialorder set payment_status='paid' where  orderid='$orderid'");
        }
        if ($paidamount < $totalamount) {
            $this->db->query("update specialorder set payment_status='unpaid' where  orderid='$orderid'");
        }
        $this->db->query("delete from specialeventpaymentrelation where orderid='$orderid'");

        $this->db->query("insert into specialeventpaymentrelation(custid,orderid,paidamount,balance,totalpay)
values('$custid','$orderid','$paidamount','$balance','$totalamount')");

        redirect('specialevent/printorder/index/' . $orderslug);
//redirect('specialevent/orderlist/index');
    }

//function
}

//class