<?php if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Items extends CI_Controller
{

    function __construct()
    {
        parent::__construct();
        if ($this->session->userdata('logged_in') !== 'yes') {
            redirect(base_url() . 'login', 'refresh');

        } else
            if ($this->session->userdata('logged_in') == 'yes') {
                if (($this->session->userdata('type') == 'admin') || ($this->session->userdata('type') ==
                    'manager')) {
                } else {
                    redirect(base_url() . 'admin_home', 'refresh');
                }

            }
        $this->load->model('ingredientquantity_model');
        $this->load->model('web_data_model');
        $this->load->library('form_validation');
    }

    function index()
    {


    }


    function listall($msg = '', $page = 0)
    {
        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');
        $data['msg'] = $msg;
        $data['search_term'] = '';
        $this->db->where('comp_id', $comp_id);
        $query = $this->db->get('Item');
        $total = $query->num_rows();
        $array = $query->result_array();
        $data['contents'] = $array;
        $this->load->library('pagination');

        $config['base_url'] = base_url() . "/index.php/item/listall/";
        $config['total_rows'] = $total;
        $config['per_page'] = 30;
        $config['uri_segment'] = 4;
        $config['num_links'] = 2;
        //$config['page_query_string'] = TRUE;
        //$config['full_tag_open'] = '<a class ="number">';
        //$config['full_tag_close'] = '</a>';
        $config['first_link'] = '&laquo; First';
        //$config['first_tag_open'] = '<span>';
        //$config['first_tag_close'] = '</span>';
        $config['last_link'] = 'Last &raquo;';
        //$config['last_tag_open'] = '<span>';
        //$config['last_tag_close'] = '</span>';
        $config['next_link'] = 'Next &raquo;';
        $config['prev_link'] = '&laquo; Previous';
        $config['cur_tag_open'] = '<a class ="number current">';
        $config['cur_tag_close'] = '</a>';


        $this->pagination->initialize($config);
        $data['page'] = $page;
        $this->db->where('comp_id', $comp_id);
        $this->db->order_by('itemid', 'desc');
        $query = $this->db->get('Item', $config['per_page'], $page);
        $data['paages'] = $this->pagination->create_links();
        //print_r($data['paages']);
        //exit();
        $array = $query->result_array();

        $data['contents'] = $array;
        $this->load->view('headermerged', $data);
        $this->load->view('item/item', $data);

    }
    public function delete_item($id)
    {
        $this->web_data_model->delete('itemid', $id, 'Item');
        $this->session->set_flashdata("message","The item deleted successfully");
           redirect('items/listall');
       
    }
    function search()
    {
        $data['msg'] = '';
        $search_term = $this->input->get('search');
        $data['search_term'] = $search_term;
        $data['contents'] = $this->search_model->search_item($search_term);
        $this->load->view('headermerged', $data);
        $this->load->view('item/item', $data);
        $this->load->view('footerform');
    }

    function get_search()
    {
        $data['msg'] = '';
        $search_term = $this->input->get('search_keyword');
        $data['search_term'] = $search_term;
        $data['contents'] = $this->search_model->search_items($search_term);
        $this->load->view('item/search_items', $data);
    }


    function addform($msg = '')
    {

        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');

        $data['packages'] = $this->ingredientquantity_model->get_activepackages();
        $data['items'] = $this->ingredientquantity_model->get_all_items();
        $data['units'] = $this->ingredientquantity_model->get_all_units();
        $data['ingredients'] = $this->ingredientquantity_model->get_active_ingredients();

        $this->db->where('comp_id', $comp_id);
        $query = $this->db->get('specialingredient');

        $array = $query->result_array();
        $data['specialingredient'] = $array;

        $query = $this->db->get('accompaniments');
        $array = $query->result_array();
        $data['accompaniments'] = $array;

        $this->db->where('comp_id', $comp_id);
        $query = $this->db->get('menutype');

        $array = $query->result_array();
        $data['menutype'] = $array;

        $this->load->view('newheader', $data);
        $this->load->view('item/additem', $data);

    }


    function insert()
    {

        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');

        extract($_POST);

        $item_packages = $this->input->post('item_packages');


        if ($item_packages) {
            $item_packages_id = implode(",", $item_packages);
        } else {
            $item_packages_id = 'NULL';
        }


        if ($this->input->post('included_specialevent') == 'yes') {
            $included_specialevent = 'yes';
        } else {
            $included_specialevent = 'no';
        }

        //$included_specialevent='yes';  //hard code for special event only

        if ($this->input->post('itemtemperaturecheck') == 'yes') {
            $temperature = 'yes';
            $temperature_value = $this->input->post('temperaturevalue');
        } else {
            $temperature = 'no';
            $temperature_value = 0;
        }
        $ingredientname = $this->input->post('ingredients');


        if ($ingredientname) {
            $ingrident = implode(",", $ingredientname);
        } else {
            $ingrident = 'NULL';
        }


        $menutype = $this->input->post('menutype');
        if ($menutype) {
            $this->db->select('menutypename');
            $this->db->where_in('menutypeid', $menutype);
            $query = $this->db->get('menutype');
            $menucat = $query->result_array();
            $data['menutype'] = $menucat;
            foreach ($menucat as $menucat) {
                $menucat_array[] = $menucat['menutypename'];
            }
            $menutype_names = implode(",", $menucat_array);
            $menu = implode(",", $menutype);
        } else {
            $menu = 'NULL';
        }
        $check_accompaniments = $this->input->post('check_accompaniments');

        if ($check_accompaniments == 'yes') {
            $accompaniments = $this->input->post('accompaniments');
            if ($accompaniments) {
                $accompani = implode(",", $accompaniments);
            } else {

                $accompani = 'NULL';
            }
        } else {
            //echo $check_accompaniments;
            $accompani = 'NULL';
        }
        $itemprice = $this->input->post('itemprice');
        $instructions = $this->input->post('instructions');
        $data = array(
            'comp_id' => $comp_id,
            'itemname' => ucwords($this->input->post('itemname')),
            'itemunits' => $this->input->post('itemunits'),
            'itemdescription' => trim($this->input->post('itemdescription')),
            'includedingredients' => $ingrident,
            'menutype' => $menu,
            'accompaniments' => $accompani,
            'itemtemperaturecheck' => $temperature,
            'temperature_value' => $temperature_value,
            'included_specialevent' => $included_specialevent,
            'itemprice' => $itemprice,
            'instructions' => $instructions,
            'item_packages' => $item_packages_id,
            );

        $ingredients = $this->input->post('ingredients');


        $item_qty = $this->input->post('itemqty');
        $item_unit = $this->input->post('itemunits');


        $this->db->insert('Item', $data);
        $insert_id = $this->db->insert_id();
        $item_id = $insert_id;

        //-----------------------------------------------
        //Image upload

        $allowedExts = array(
            "gif",
            "jpeg",
            "jpg",
            "png");
        $temp = explode(".", $_FILES["userfile"]["name"]);
        $extension = end($temp);
        $extension = strtolower($extension);

        if (in_array($extension, $allowedExts)) {
            move_uploaded_file($_FILES["userfile"]["tmp_name"], $_SERVER['DOCUMENT_ROOT'] .
                "/uploads/items/" . $item_id . '.' . $extension);
        }

        //end of image upload
        //-------------------------------------------------
        $data = array('item_image' => $item_id . '.' . $extension, );

        $this->db->where('itemid', $item_id);
        $this->db->update('Item', $data);

        if ($ingredients) {

            foreach ($ingredients as $ingredient) {
                $data = array(
                    'item_id' => $item_id,
                    'item_qty' => $item_qty,
                    'item_unit' => $item_unit,
                    'ing_id' => $ingredient,
                    'ing_qty' => $this->input->post('ing_qty_' . $ingredient),
                    'ing_unit' => $this->input->post('itemunits_' . $ingredient),
                    );
                $id = $this->ingredientquantity_model->insert($data);

            }


            redirect(base_url() . 'items/listall', 'refresh');
        } else {
            redirect(base_url() . 'items/listall', 'refresh');
        }

    }


    function updateform($ingid = null, $msg = '')
    {

        $comp_id = $this->session->userdata('comp_id');
        $br_id = $this->session->userdata('branch_id');
        $data['packages'] = $this->ingredientquantity_model->get_packages();
        $data['ingitem'] = $this->ingredientquantity_model->get_ing_item($ingid);
        $data['items'] = $this->ingredientquantity_model->get_all_items();
        $data['units'] = $this->ingredientquantity_model->get_all_units();
        $data['ingredients'] = $this->ingredientquantity_model->get_active_ingredients();
        //echo '<pre>';
        //print_r($data['ingitem']);
        //echo '</pre>';
        //exit();
        if (isset($ingredientname)) {
            $ingredient = implode(",", $ingredientname);
        } else {
            $ingredient = 'NULL';
        }
        $query = $this->db->get('specialingredient');
        $array = $query->result_array();
        $data['specialingredient'] = $array;
        $query = $this->db->get('accompaniments');
        $array = $query->result_array();
        $data['accompaniments'] = $array;

        $this->db->where('comp_id', $comp_id);
        $query = $this->db->get('menutype');
        $array = $query->result_array();
        $data['menutype'] = $array;
        if ($ingid != null) {
            $this->db->where('itemid', $ingid);
            $query = $this->db->get('Item');
            $array = $query->result_array();
            $data['data'] = $array[0];
        }
        $array = $query->result_array();
        $data['contents'] = $array;
        // $this->load->view('headerform');
        //$this->load->view('item/edititem',$data);
        $this->load->view('newheader');
        $this->load->view('item/edititem', $data);
    }

   	function update($msg=''){

		$item_packages = $this->input->post('item_packages');
		if($item_packages){	
			$item_packages_id = implode(",",$item_packages);
		}else{
			$item_packages_id = 'NULL';
		}
		

		extract($_POST);
		if($this->input->post('included_specialevent')=='yes'){
			$included_specialevent='yes';
		}else{
			$included_specialevent='no'; 
		}
$included_specialevent='yes';  //hard code for special event only
		
		$check_accompaniments = $this->input->post('check_accompaniments');
	
		if($check_accompaniments == 'yes'){
				
			$accompaniments=$this->input->post('accompaniments');
			if($accompaniments){
				$accompani=  implode(",",$accompaniments);
			}
			else{
			
			$accompani='NULL';
		}		
		}else{
			
			$accompani='NULL';
		}

		
		$menutype=$this->input->post('menutype');
		if(count($menutype)){
			$menu=  implode(",",$menutype);
		}else{
			$menu='NULL';
		}
		

		$itemprice=$this->input->post('itemprice');	
		if($this->input->post('itemtemperaturecheck')=='yes') {
			$temperature='yes'; $temperature_value= $this->input->post('temperaturevalue');
		}else{
			$temperature='no'; $temperature_value= 0;
		}

 		$this->db->where('itemid',$this->input->post('itemid'));
		$query = $this->db->get('Item');
		$array = $query->result_array();
		$data['data'] = $array[0];   					
		$data = array(
			'itemname' => strtolower($this->input->post('itemname')),		
			'itemunits' => $this->input->post('itemunits'),
		        'itemdescription' => $this->input->post('itemdescription'),
	                'itemtemperaturecheck' => $temperature,
	                'temperature_value'=>$temperature_value,
			'included_specialevent'=>$included_specialevent,
	                'itemprice' =>$this->input->post('itemprice'),
	                'menutype' => $menu,  
	                'accompaniments'=> $accompani,
	                'instructions' => $this->input->post('instructions'),
	                'item_packages' => $item_packages_id,
		);	
		$q = $this->db->query("select * from Item where itemname='".addslashes($this->input->post('itemname'))."' and itemid!='".$this->input->post('itemid')."'");		
		if($q->num_rows == 0){						
			$this->db->update('Item', $data, array('itemid' => $this->input->post('itemid')));
		
		

		
		//----------------------------------------------------
		//when editing item_ingredient table first delete all the data from the table for that item and insert new datas instead of updaing existing data
		$item_id = $this->input->post('itemid');
		$this->db->where('item_id', $item_id);
		$this->db->delete('item_ingredient'); 			
		//-----------------------------------------------------
		
		//post data for item_ingredient table
		$ingredients = $this->input->post('ingredients');
		$item_qty = $this->input->post('itemqty');
		$item_unit = $this->input->post('itemunits'); //read same as item unit
		
		//--------------------------------------------------
		
		if($ingredients ){
			foreach($ingredients as $ingredient){
				$data = array(
					'item_id' => $item_id,
					'item_qty' => $item_qty,
					'item_unit' => $item_unit,
					'ing_id' => $ingredient,
					'ing_qty' => $this->input->post('ing_qty_'.$ingredient),
					'ing_unit' => $this->input->post('itemunits_'.$ingredient),
				);

				$id = $this->ingredientquantity_model->insert($data);
			}

			//-----------------------------------------------
			//Image upload		
			if($_FILES["userfile"]["name"]){
				$allowedExts = array("gif", "jpeg", "jpg", "png");
				$temp = explode(".", $_FILES["userfile"]["name"]);
				$extension = end($temp);
				$extension = strtolower($extension );
				
				if (in_array($extension, $allowedExts)) {
				      move_uploaded_file($_FILES["userfile"]["tmp_name"],
				      $_SERVER['DOCUMENT_ROOT']."/uploads/items/" . $item_id.'.'.$extension);
				} 
		
				//end of image upload	
				//-------------------------------------------------
				$data = array(
					'item_image' => $item_id.'.'.$extension,
				);
				
				$this->db->where('itemid', $item_id);
				$this->db->update('Item', $data); 
			}

	
			redirect("items/listall/edited");
	
		}else{
			redirect(base_url().'items/listall', 'refresh');
		}						

		}else{						
		 	redirect("items/updateform/updated");
		}				
					
	}

    function delete($ingid = null)
    {
        $data = array('item_status' => 'inactive', );

        $this->db->where('itemid', $ingid);
        $this->db->update('Item', $data);
        redirect("items/listall/deleted");
    }

    function activate($ingid = null)
    {
        $data = array('item_status' => 'active', );

        $this->db->where('itemid', $ingid);
        $this->db->update('Item', $data);
        redirect("items/listall");
    }


    function changestatus($cid = null)
    {
        $query = $this->db->get_where('Item', array('itemid' => $cid));
        $array = $query->result_array();
        $status = ($array[0]['item_status'] == "active") ? "inactive" : "active";

        $data = array('item_status' => $status);
        $this->db->update('Item', $data, array('itemid' => $cid));
        redirect("items/listall/");
    }


}
