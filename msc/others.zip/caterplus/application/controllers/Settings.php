<?php
class Settings extends CI_Controller {

	function _construct()
	{
		parent::__construct();
 		  
		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}

		 

		
	}
	
	function index($msg=''){
$this->db->where('username','admin');
$query= $this->db->get('employee');
		$data['users'] = $query->row();
	 $data['msg'] = $msg;
	
	//print_r($data['users']);	
		$this->load->view('newheader',$data);
		$this->load->view('settings/editprofile',$data);
		$this->load->view('newfooter');
	}
	
	
	

		
	 function update($data='')
	 {
	 	extract($_POST);
    $this->db->where('employeeid',$id);
					$query = $this->db->get('employee');
					$array = $query->result_array();
					$data['data'] = $array[0];
					
			 		$gallery_image = $array[0]['staff_image']; 
			 				
if($_FILES["staff_image"]["name"]){
						$full_path = "uploads/staff/".$gallery_image;
						@unlink($full_path);
					
						$image = basename($_FILES['staff_image']['name']);
						$ext = end(explode('.', $image));
						$ext = strtolower($ext);
						$imagename = "admin_".time().'.'.$ext;
						
						move_uploaded_file($_FILES["staff_image"]["tmp_name"],  "uploads/staff/".$imagename);
						
						
					}else{$imagename = $gallery_image;} 
					
					
	 	$data = array(
'employeename'=>$employeename,
'email'=>$email,
'email2'=>$email2,
'employeeaddress' =>$employeeaddress,
'phn_ext' =>$phn_ext,
'employeephone'=>$employeephone,
'mobile1' =>$mobile1,
'mobile2' =>$mobile2,
'staff_image'=>$imagename,
'pin' =>$pin
);
	 	$this->db->update('employee', $data, array('employeeid' => $id));
	 	redirect('settings/index/edited');
 	} 
	function password($msg=''){
		
	 $this->db->where('username','admin');
$query= $this->db->get('employee');
		$data['users'] = $query->row();
	$data['msg'] = $msg;
	
		$this->load->view('newheader',$data);
		$this->load->view('settings/changepassword',$data);
		$this->load->view('newfooter');
	}
		
 function update_password()
	 {
	 	extract($_POST);
	 $id=$_POST['id'];
	  $result = $this->db->get_where('employee',array('password'=>md5($password)));
	  if($result->row())
	  {
	 	$data = array('password'=>md5($new_password));
		$this->db->update('employee',$data,array('employeeid'=>$id));
	 

	 	redirect('settings/password/edited');
	 	}
	 	else { redirect('settings/password/error');  }
	 	
 	}

	
}