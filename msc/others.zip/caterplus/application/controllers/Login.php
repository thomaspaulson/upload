<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

 	function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->model('mainlogin_model');
       		  	
       		
		if($this->session->userdata('logged_in') == 'yes'){ 
				redirect(base_url().'admin_home', 'refresh'); 			 
		   }
		   

    }

	public function index()
	{      

		$this->load->view('staff/staff_login.php');
	}
	
    public function staff_login(){
        

			$username=$this->input->post('username');
			$password=$this->input->post('password');
			$password = md5($password); 
			$result=$this->mainlogin_model->login($username,$password);
			if($result==0){ redirect(base_url()); }
			else{ foreach($result as $r){ $empid=$r['employeeid'];}
			$role=$this->getid_model->get_rolename($empid);
			$this->session->set_userdata('user_role',$role); 
			$this->session->set_userdata('type',$role); 
			$this->session->set_userdata('emp_id',$empid);
			
			if($role=='admin')
			{ 
				redirect('login/branch_login/', 'refresh');
				
			}
			else{  redirect('login/branch_login/', 'refresh');}
			}


    }	
        
        
        
    public function branch_login()
	{ 
		$empid=$this->session->userdata('emp_id');
		$compid=$this->getid_model->get_compid($empid);
		$this->session->set_userdata('comp_id',$compid); 
		$result['br_list']=$this->getid_model->get_branchlist_active($compid);
		$result['comp_name']=$this->getid_model->get_compname($compid);
		$this->session->set_userdata('comp_name',$result['comp_name']); 
		$this->session->set_userdata('branch_id','81');
$this->session->set_userdata('br_id','81');
$this->session->set_userdata('comp_id','60');
		$this->load->view('loginbranch',$result);
		$this->session->set_userdata('logged_in','yes');
		
		redirect('specialevent/customer/', 'refresh');
	 }    
        
        
        
  public function verify_branch()
{ 
$branchid=$this->input->post('branchid');
$branch_name=$this->getid_model->get_branchname($branchid);
$this->session->set_userdata('branch_name',$branch_name);
$this->session->set_userdata('branch_id',$branchid); 
$this->session->set_userdata('logged_in','yes');
redirect(base_url().'admin', 'refresh');	
//redirect(base_url().'admin/admin_dashboard/index'); 
 }      
        
        
        
        
        
        
        
        
        
        
        
        

        public function logout(){
        	$this->session->sess_destroy();
		redirect(base_url().'login', 'refresh');        	
        
        }         
	

	


        
        
      
           
	
		    
        
}