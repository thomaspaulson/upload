<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specialorder extends CI_Controller {

 	function __construct() {
       		parent::__construct();

		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		} 
       		$this->load->model('special_order_model');

    	}

	public function index()
	{
		$data['menus'] = $this->special_order_model->all_menus();
		echo '<pre>';
		print_r($data['menus']);
		echo '</pre>';
		$this->load->view('specialorder/add_special_order',$data);
	}
	
	public function add_package(){
	        $this->output->enable_profiler();
		$name = $this->input->post('name');
		$qty = $this->input->post('qty');			        
		$slug = random_slug(30);
		$data = array(
			'name' => $name,
			'qty' => $qty, 
			'slug' => $slug,
		
		);
		$result = $this->package_model->add_package($data);	
		if($result = 1){
			redirect(base_url().'specialpackage', 'refresh');
		}	
	
	
	}
	
	public function add_new_package(){
                $data['random_value'] =  random_slug(30);
        	$this->load->view('specialpackage/add_new_package.php',$data);
        }
        
        public function edit_package($slug=''){
        	$table_name='specialpackage';
        	$primary_key = 'specialp_id';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Package Doesnt Exists !');
        		redirect(base_url().'specialpackage', 'refresh');
        		exit();
        	}
        	$data['packages'] = $this->package_model->get_package_details($id);
        	$data['id'] = $id;
        	$this->load->view('specialpackage/edit_package',$data);        
        }
        
        
        
        public function edit_existing_package(){
	        $id = $this->input->post('id');
		$name = $this->input->post('name');
		$qty = $this->input->post('qty');		

		$data = array(
			'name' => $name,
			'id' => $id,
			'qty' => $qty,
		);
		$result = $this->package_model->edit_package($data);	
		if($result = 1){
			redirect(base_url().'specialpackage', 'refresh');
		}		       
        }        
        
        public function delete_package($slug=''){
        	$table_name='specialpackage';
        	$primary_key = 'specialp_id';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Package Doesnt Exists !');
        		redirect(base_url().'specialpackage', 'refresh');
        		exit();
        	}		        	
        	$result = $this->package_model->delete_package($id);
		if($result == 1){
			redirect(base_url().'specialpackage', 'refresh');
		}        
        }     

public function addneworder()
	{
		$this->load->view('neworderheader');
		$this->load->view('specialevent/specialorder/addneworder');
$this->load->view('neworderfooter');
	}




   
}