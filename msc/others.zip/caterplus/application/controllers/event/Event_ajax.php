<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_ajax extends KRUX_Controller {



	
	public function index($event_type_id='',$comp_id='')
	{

$result['subtype']=$this->getcomp_details_model->get_subeventtype($comp_id,$event_type_id); 
$this->load->view('event/subcategoryajax',$result); 
 }

public function event_task($event_task_tableid='',$event_id='')
	{

$query = $this->db->get_where('event_task', array('eventtask_id' => $event_task_tableid));
$array = $query->result_array();
$status=($array[0]['event_task_status']=="pending")?"completed":"pending"; 

$curr_status=$array[0]['event_task_status'];

$this->db->update('event_task', array(
'event_task_status' => $status
), array('eventtask_id' => $event_task_tableid));

echo $status;



 } //fntn close


public function auto_event_task($subtask_slug='',$event_id='')
	{

$query = $this->db->get_where('event_task', array('subtask_slug' => $subtask_slug,'event_id' => $event_id));

$array = $query->result_array();
$status=($array[0]['event_task_status']=="pending")?"completed":"completed"; //complete if already


$eventtask_id=$array[0]['eventtask_id'];

$this->db->update('event_task', array('event_task_status' => $status), array('subtask_slug' => $subtask_slug,'event_id' => $event_id));

$data=array('status'=>$status,'eventtask_id'=>$eventtask_id);

echo json_encode($data);




 } //fntn close




public function event_payschedule($selected_pay_id='',$event_id='',$fulltotal='')
	{

$row='';
$comp_id=$this->session->userdata('comp_id');
$query = $this->db->get_where('pay_schedule_detail', array('pay_schedule_id' => $selected_pay_id,'comp_id'=>$comp_id));


$result=$query->result_array();

foreach($result as $res)
{
$schedule_id=$res['pay_schedule_id'];
$first=$res['first'];
$second=$res['second'];
$third=$res['third'];
}
$symbol=$this->getid_model->getcurrency($comp_id);

$default_zero=$symbol.'0.00';


$this->db->where('event_id',$event_id);
$this->db->delete('event_pay_schedule'); //delete if exist any


$insert_schedule=array('event_id'=>$event_id,'schedule_id'=>$schedule_id,'first_temp'=>$first,'second_temp'=>$second,'third_temp'=>$third,'comp_id'=>$comp_id);

$this->db->insert('event_pay_schedule',$insert_schedule);


if($first)
{
$first_payment=$fulltotal*($first/100);

$first_payment=number_format((float)$first_payment, 2, '.', '');

$first_row='<div class="row_color2"><ul><li class="payment_part" id="first_percent">Part 1('.$first.'%)</li><li class="payment_part" id="first_price">'.$symbol .$first_payment.'</li><li class="payment_part"><input name="first_pay" id="first_pay" type="text" value="0.00" onblur="receivepayment(this.id)" class="payment_texfeild"></li><li class="payment_part" id="first_balance">'.$symbol .$first_payment.'</li><li class="payment_part"><a href="#"></a></li><li class="payment_part"></li><li class="payment_invoice"></li></ul></div>';
$row=$row.$first_row;
}
if($second)
{
$sec_payment=$fulltotal*($second/100);
$sec_payment=number_format((float)$sec_payment, 2, '.', '');

$second_row='<div class="row_color3"><ul><li class="payment_part" id="second_percent">Part 2('.$second.'%)</li><li class="payment_part" id="second_price">'.$symbol .$sec_payment.'</li><li class="payment_part"><input name="second_pay" id="second_pay" value="0.00" onblur="receivepayment(this.id)" type="text" class="payment2_texfeild"></li><li class="payment_part" id="second_balance">'.$symbol .$sec_payment.'</li><li class="payment_part"><a href="#"></a></li><li class="payment_part"></li><li class="payment_invoice"></li></ul></div>';
$row=$row.$second_row;
}

if($third)
{
$third_payment=$fulltotal*($third/100);
$third_payment=number_format((float)$third_payment, 2, '.', '');

$third_row='<div class="row_color2"><ul><li class="payment_part" id="third_percent">Part 3('.$third.'%)</li><li class="payment_part" id="third_price">'.$symbol .$third_payment.'</li><li class="payment_part"><input name="third_pay" id="third_pay" value="0.00" onblur="receivepayment(this.id)" type="text" class="payment_texfeild"></li><li class="payment_part" id="third_balance">'.$symbol .$third_payment.'</li><li class="payment_part"><a href="#"></a></li><li class="payment_part"></li><li class="payment_invoice"></li></ul></div>';
$row=$row.$third_row;
}

echo $row;

 } //fntn close





public function get_custlist($terms='')
	{

 $array= array();

$result=$this->getcomp_details_model->getcust_list_byterm($terms);

$p=0;
foreach($result as $row)
    {
    $p++;
    if($p==3){ $p=1;}
       
$customerId = $row['customerId'];
$customermobile1= $row['customermobile1'];
$customername= $row['customername'];
$customerphone= $row['customerphone'];


 // $array[] = $row['customername'];$row['customermobile1'];
  
  
  
 $array[]='<div class="event_customer_left_row'.$p.'"><div class="event_customer_left_row1_radio">
              <input name="cust_id"  value="'.$customerId.'" type="radio" class="radio_style">
             
</div>
<div class="event_customer_left_row1_name"><h1>'.$customername.'</h1></div>
<div class="event_customer_left_row1_phone"><h1>'.$customermobile1.'</h1></div>
<div class="event_customer_left_row1_phone"><h1>'.$customerphone.'</h1></div>
</div>';
  
  
  
  
  
    }

echo json_encode($array); 


}






} //class close








?>