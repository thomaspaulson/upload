<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_overview extends CI_Controller{

public $comp_id;
public $br_id; 

	function __construct()
	{
		parent::__construct();
 $this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');

		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'manager')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
       		
       		$this->load->library('form_validation');
       		$this->load->helper('custom_helper');		
       		$this->load->model('get_event_details');
       		$this->load->model('update_event'); 
       		$this->load->helper("file");

	}


public function event_list(){

$data['contents']=$this->event_model->get_event_list($this->comp_id,$this->br_id);

//print_r($data['contents']);
//echo $this->db->last_query();
$this->load->view('headermerged');
$this->load->view('event/event_list',$data);
}





public function view_event($eventidd='',$event_slug=''){  



$event_id=$this->event_model->get_event_id($eventidd,$event_slug);
if($event_id==0){ redirect(base_url()); exit(); } 


$resu=$this->get_event_details->event_customer($event_id);

foreach($resu as $r)
{ $cust_id=$r['cust_id']; }

$results=$this->get_event_details->get_event_detail_all($event_id);

foreach($results as $re)
{
$event_enq_type=$re['event_enq_type'];
$day_type=$re['eventday_type'];
$cater_type=$re['even_caterttype_name'];
$event_title=$re['event_title'];
$event_contact=$re['event_contactnum'];
$adult_nos=$re['adult'];
$child_nos=$re['children'];
$notes=$re['guest_notes'];
$event_date=$re['event_date'];
$event_start_time=$re['event_time'];
$venue_name=$re['event_location'];
$venue_detail=$re['event_location'];
$venue_address=$re['event_address'];
$venue_city=$re['event_town'];
$venue_state=$re['evet_state'];
$venue_country=$re['event_country'];
$event_type=$re['eventtypeb_id'];
$subevent_type=$re['eventtypestb_id'];
}
$detail['event_slug']=$event_slug;
$detail['cust_id']=$cust_id;
$detail['event_enq_type']=$event_enq_type;
$detail['day_type']=$day_type;
$detail['cater_type']=$cater_type;
$detail['event_title']=$event_title;
$detail['event_type']=$event_type;
$detail['subevent_type']=$subevent_type;
$detail['event_contact']=$event_contact;
$detail['adult_nos']=$adult_nos;
$detail['child_nos']=$child_nos;
$detail['notes']=$notes;
$detail['event_date']=$event_date;
$detail['event_start_time']=$event_start_time;
$detail['venue_name']=$venue_name;
$detail['venue_detail']=$venue_detail;
$detail['venue_address']=$venue_address;
$detail['venue_city']=$venue_city;
$detail['venue_state']=$venue_state;
$detail['venue_country']=$venue_country;


$detail['pay_schedule']=$this->event_model->get_payschedule(); 
$detail['currency']=$this->getid_model->getcurrency($this->comp_id); 



$detail['menu_types']=$this->event_model->get_menutypes($this->comp_id); 
$detail['get_agencylist']=$this->getcomp_details_model->get_agencylist($this->comp_id); 
$detail['pots_pans']=$this->getcomp_details_model->get_pots_pans(); 
$detail['comp_id']=$this->comp_id;

$detail['custdata']=$this->event_model->getcust_byid($cust_id);

$detail['venue_address']=$venue_address=$venue_address.' '.$venue_detail;
$event_date=changeto_dbformat($event_date);
$add_event=array('cust_id'=>$cust_id,'event_title'=>$event_title,'eventtypeb_id'=>$event_type,'eventtypestb_id'=>$subevent_type,
'eventday_type'=>$day_type,'event_contactnum'=>$event_contact,'even_caterttype_name'=>$cater_type,'event_enq_type'=>$event_enq_type
,'event_slug'=>$event_slug);


$detail['event_id']=$event_id;
$detail['tasklist']=$this->event_model->get_mast_tasklist($event_id); 
$detail['eventtypename']=$eventtypename=$this->getcomp_details_model->get_eventtype_name($this->comp_id,$event_type);
$detail['subevent_typename']=$eventtypename=$this->getcomp_details_model->get_subeventtype_name($this->comp_id,$subevent_type);
$detail['drivers']=$this->getcomp_details_model->get_alldrivers($this->comp_id,$this->br_id);
$detail['managers']=$this->getcomp_details_model->get_allmanagers($this->comp_id,$this->br_id); 
$detail['chefs']=$this->getcomp_details_model->get_allchefs($this->comp_id,$this->br_id);
	
	
        
        
/*read event inserted values**/

/***staff notes**/
$detail['event_chefnote']=$this->get_event_details->event_chefnote($event_id);//
$detail['event_manager_note']=$this->get_event_details->event_manager_note($event_id);//
$detail['event_drivernote']=$this->get_event_details->event_drivernote($event_id);//
/***staff notes**/

/**notes**/
$detail['event_commonnote']=$this->get_event_details->event_commonnote($event_id);//
/***/

/**menu name**/
$detail['event_menu']=$this->get_event_details->event_menu($event_id);
/**menu name**/


/***get_eventagency**/
$detail['get_eventagency']=$this->get_event_details->get_eventagency($event_id);
/***get_eventagency**/

/***task**/
$detail['event_task']=$this->get_event_details->event_task($event_id);
/***task**/

/**pots pans**/
$detail['event_pots_pans']=$this->get_event_details->event_pots_pans($event_id);
$detail['event_pot_price']=$this->get_event_details->event_pot_price($event_id);
/**pots pans**/

/**items menu**/
$detail['item_menu_relation']=$this->get_event_details->item_menu_relation($event_id);
$detail['event_menu_price']=$this->get_event_details->event_menu_price($event_id);
/**items menu**/

/**event payment**/
$detail['event_payment']=$this->get_event_details->event_payment($event_id);
$detail['event_pay_schedule']=$this->get_event_details->event_pay_schedule($event_id);
/**event payment**/

/**********/

$detail['row']= $this->get_event_details->get_paid_rows($event_id);


/***********/

$detail['get_paid_schedule']=$this->get_event_details->event_payment($event_id);


/*read event inserted values**/



	//$this->load->view('event/eventheader',$detail); 
$this->load->view('event/product_header',$detail); 
	$this->load->view('event/view_event'); 
	$this->load->view('admin/admin_footer'); 
        






}


public function edit_event_customer($eventidd="",$event_slug=""){


$event_id=$this->event_model->get_event_id($eventidd,$event_slug);
if($event_id==0){ echo "UNAUTHORIZED ENTRY"; exit(); }


$result['customer']=$this->get_event_details->event_customer($event_id);
$result['event_details']=$this->get_event_details->event_details($event_id);

$result['custlist']=$this->event_model->getcust_list();

$this->load->view('event/eventheader',$result); 
	 $this->load->view('event/edit_event1'); 
  //   $this->load->view('admin/admin_footer');







}


public function update_event_customer()
{

$event_id=$this->input->post("event_id"); 
$event_slug=$this->input->post("event_slug"); 
$result['enq_type']=$event_enq_type=$this->input->post('event_enq_type');
$result['day_type']=$day_type=$this->input->post('day_type');
$result['cater_type']=$cater_type=$this->input->post('cater_type');

$result['event_id']=$event_id;


if($this->input->post('new_cust_type')=='new_cust') 
{
$current_custid=$this->event_model->event_cust($_POST);
$data=array('cust_id'=>$current_custid);
$this->update_event->update_event_cust($data,$event_id);
$result['customerid']=$current_custid;
$result['custdata']=$this->event_model->getcust_byid($current_custid);
}
elseif($this->input->post('exist_cust_type')=='existing_cust') 
{
$current_custid=$this->input->post('customer_id');
$data=array('cust_id'=>$current_custid);
$this->update_event->update_event_cust($data,$event_id);
$result['customerid']=$current_custid;
$result['custdata']=$this->event_model->getcust_byid($current_custid);
}



$types_event=array('eventday_type'=>$day_type,'even_caterttype_name'=>$cater_type,'event_enq_type'=>$event_enq_type);
$this->update_event->update_event_catertypes($types_event,$event_id);


if(isset($_POST["continue"])) 
{ 
$result['typess']=$this->get_event_details->get_eventtype($event_id);
$result['eventguest']=$this->get_event_details->eventguest($event_id);
$result['customer']=$this->get_event_details->event_customer($event_id);
$result['event_details']=$this->get_event_details->event_details($event_id);
$compid=$this->session->userdata('comp_id');
$result['comp_name']=$this->getid_model->get_compname($compid);
$branchid=$this->session->userdata('branch_id');
$result['branch_name']=$this->getid_model->get_branchname($branchid);
$result['get_eventtype']=$this->getcomp_details_model->get_eventtype($compid);
		 $this->load->view('event/eventheader',$result); 
	 $this->load->view('event/edit_event2'); 
    // $this->load->view('admin/admin_footer');
     }
else
{

redirect("event/event_overview/event_list"); 
}

}




function update_event_details() //2
{

$event_id=$this->input->post('event_id');
$event_slug=random_string(50);

$detail['pay_schedule']=$this->event_model->get_payschedule(); 
$detail['currency']=$this->getid_model->getcurrency($this->comp_id); 
$detail['menu_types']=$this->event_model->get_menutypes($this->comp_id); 
$detail['get_agencylist']=$this->getcomp_details_model->get_agencylist($this->comp_id); 
$detail['pots_pans']=$this->getcomp_details_model->get_pots_pans(); 
$detail['comp_id']=$this->comp_id;
$detail['cust_id']=$cust_id=$this->input->post('customerid');
$detail['custdata']=$this->event_model->getcust_byid($cust_id);
$detail['event_enq_type']=$event_enq_type=$this->input->post('event_enq_type');
$detail['day_type']=$day_type=$this->input->post('day_type');
$detail['cater_type']=$cater_type=$this->input->post('cater_type');
$detail['event_title']=$event_title=$this->input->post('event_title');
$detail['event_type']=$event_type=$this->input->post('event_type'); //wedding
$detail['subevent_type']=$subevent_type=$this->input->post('subevent_type');
$detail['event_contact']=$event_contact=$this->input->post('event_contact');
$detail['adult_nos']=$adult_nos=$this->input->post('adult_nos');
$detail['child_nos']=$child_nos=$this->input->post('child_nos');
$detail['notes']=$notes=$this->input->post('notes');
$detail['event_date']=$event_date=$this->input->post('event_date');
$detail['event_start_time']=$event_start_time=$this->input->post('event_start_time');
$detail['venue_name']=$venue_name=$this->input->post('venue_name');
$detail['venue_detail']=$venue_detail=$this->input->post('venue_detail');
$detail['venue_address']=$venue_address=$this->input->post('venue_address');
$detail['venue_city']=$venue_city=$this->input->post('venue_city');
$detail['venue_state']=$venue_state=$this->input->post('venue_state');
$detail['venue_country']=$venue_country=$this->input->post('venue_country');
$detail['venue_address']=$venue_address=$venue_address.' '.$venue_detail;
$detail['event_slug']=$event_slug;
$event_date=changeto_dbformat($event_date);
$add_event=array('cust_id'=>$cust_id,'event_title'=>$event_title,'eventtypeb_id'=>$event_type,'eventtypestb_id'=>$subevent_type,
'eventday_type'=>$day_type,'event_contactnum'=>$event_contact,'even_caterttype_name'=>$cater_type,'event_enq_type'=>$event_enq_type
,'event_slug'=>$event_slug);
$this->event_model->update_event($add_event,$event_id); //update event
$addlocation=array('event_id'=>$event_id,'event_title'=>$event_title,'event_location'=>$venue_name,'event_address'=>$venue_address,
'event_town'=>$venue_city,'event_contactpersonph'=>$event_contact,'event_country'=>$venue_country,'evet_state'=>$venue_state);
$this->event_model->updatelocation($addlocation,$event_id); //update location
$addguest=array('event_id'=>$event_id,'event_date'=>$event_date,'event_time'=>$event_start_time,
'adult'=>$adult_nos,'children'=>$child_nos,'guest_notes'=>$notes);
$this->event_model->updateguest($addguest,$event_id); //update guest


if(isset($_POST["continue"])) 
{

$detail['event_id']=$event_id;
$detail['tasklist']=$this->event_model->get_mast_tasklist($event_id); 
$detail['eventtypename']=$eventtypename=$this->getcomp_details_model->get_eventtype_name($this->comp_id,$event_type);
$detail['subevent_typename']=$eventtypename=$this->getcomp_details_model->get_subeventtype_name($this->comp_id,$subevent_type);
$detail['drivers']=$this->getcomp_details_model->get_alldrivers($this->comp_id,$this->br_id);
$detail['managers']=$this->getcomp_details_model->get_allmanagers($this->comp_id,$this->br_id); 
$detail['chefs']=$this->getcomp_details_model->get_allchefs($this->comp_id,$this->br_id);
	
	
        
        
/*read event inserted values**/

/***staff notes**/
$detail['event_chefnote']=$this->get_event_details->event_chefnote($event_id);//
$detail['event_manager_note']=$this->get_event_details->event_manager_note($event_id);//
$detail['event_drivernote']=$this->get_event_details->event_drivernote($event_id);//
/***staff notes**/

/**notes**/
$detail['event_commonnote']=$this->get_event_details->event_commonnote($event_id);//
/***/

/**menu name**/
$detail['event_menu']=$this->get_event_details->event_menu($event_id);
/**menu name**/


/***get_eventagency**/
$detail['get_eventagency']=$this->get_event_details->get_eventagency($event_id);
/***get_eventagency**/

/***task**/
$detail['event_task']=$this->get_event_details->event_task($event_id);
/***task**/

/**pots pans**/
$detail['event_pots_pans']=$this->get_event_details->event_pots_pans($event_id);
$detail['event_pot_price']=$this->get_event_details->event_pot_price($event_id);
/**pots pans**/

/**items menu**/
$detail['item_menu_relation']=$this->get_event_details->item_menu_relation($event_id);
$detail['event_menu_price']=$this->get_event_details->event_menu_price($event_id);
/**items menu**/

/**event payment**/
$detail['event_payment']=$this->get_event_details->event_payment($event_id);
$detail['event_pay_schedule']=$this->get_event_details->event_pay_schedule($event_id);
/**event payment**/

/**********/

$detail['row']= $this->get_event_details->get_paid_rows($event_id);


/***********/

$detail['get_paid_schedule']=$this->get_event_details->event_payment($event_id);


/*read event inserted values**/



	$this->load->view('event/eventheader',$detail); 
	$this->load->view('event/edit_event3'); 
	//$this->load->view('admin/admin_footer'); 
        

} //else if ends
else
{ redirect("event/event_overview/event_list"); exit(); }


}



function save_edit_details() //3
{


$event_id=$this->input->post('event_id');
$event_slug=$this->input->post('event_slug');
$event_p_schedule=$this->event_model->get_event_payschedule($event_id); //take selected schedule before deleting

//print_r($event_p_schedule);

/****first delete already saved details*****/
$this->event_model->delete_for_edit($event_id);
/****first delete already saved details*****/

$new_menu_name=$this->input->post('new_menu_name'); //read menu name
$new_menu_name= preg_replace('!\s+!', ' ', $new_menu_name);


if($new_menu_name){}
else{ $new_menu_name="Menu -".$event_id; }



if((strlen($new_menu_name)==0)||(ctype_space($new_menu_name)))
{
$new_menu_name="Menu -".$event_id;
}



$menu_id=$this->event_model->create_menu($new_menu_name,$this->comp_id); //create new menu id
$menu_types=$this->event_model->get_menutypes($this->comp_id); 

$item_fulltotal=0;

foreach($menu_types as $type_menu){  //read item from post
$menu_id_id=$type_menu['menutypeid']; 
$menu_name=$type_menu['menutypename'];

/****item starts***/

$item_list=$this->event_model->get_items($this->comp_id,$menu_id_id); 
//print_r($item_list);
foreach($item_list as $items) 
{ 
$item_subprice=0;
$ittem_id=$items['itemid'];
$variab="textfield_".$ittem_id;
$item_value=$this->input->post($variab);
$item_unit=$items['itemunits'];
$item_price=$items['itemprice'];

if($item_value)
{ 
$item_subprice=$item_price*$item_value;
$item_fulltotal=$item_fulltotal+$item_subprice;
$item_menu_relation=array('item_id'=>$ittem_id,
'comp_menu_id'=>$menu_id,
'item_unit'=>$item_unit,
'item_nos'=>$item_value,
'comp_id'=>$this->comp_id,
'item_subprice'=>$item_subprice,);

$this->event_model->create_menu_item($item_menu_relation); 
}


} 
}  // read item ends

//save item total price to table event_menu_price

$data2=array('comp_id'=>$this->comp_id,
'menu_id'=>$menu_id,
'total_price'=>$item_fulltotal,
);

$this->event_model->totprice_menu_item($data2); //save item total price


/****item end***/

/****pots starts***/

$pots_pans=$this->getcomp_details_model->get_pots_pans(); 

$potgtotal=0;
 foreach($pots_pans as $ppp){  //read pots
 $tot_potprice=0;
 $potttid=$ppp['pp_id']; $temppot_deposit=$ppp['pp_deposit']; $temppot_price=$ppp['pp_price'];
 $pot_nos=$this->input->post('textfieldnos_'.$potttid); 
 $pot_rent_price=$this->input->post('textfieldrent_'.$potttid); 
 $pot_deposit=$this->input->post('textfielddeposit_'.$potttid);  
 
  if($pot_nos>0)
 {
 $tot_potprice=($pot_nos*$pot_rent_price)+$pot_deposit;
 $potgtotal=$potgtotal+$tot_potprice;
 $pots_array=array('pp_id'=>$potttid,'event_id'=>$event_id,'event_pp_nos'=>$pot_nos,'br_id'=>$this->br_id,
 'comp_id'=>$this->comp_id, 'pot_rent'=>$pot_rent_price,'pot_deposit'=>$pot_deposit,'pot_totalprice'=>$tot_potprice,);
 
$this->event_model->pots_event_relation($pots_array); //save pots and pans

 } 
 
 } //read end pots

$pots_price_gtotal_array=array('comp_id'=>$this->comp_id,'br_id'=>$this->br_id,'event_id'=>$event_id,'pot_total_price'=>$potgtotal);
$this->event_model->pots_totalprice($pots_price_gtotal_array); //save to event pot price g total



/****pots ends***/

/****common notes***/


$subj1=$this->input->post('subject1'); 
$notes1=$this->input->post('note1'); 
$subj2=$this->input->post('subject2'); 
$notes2=$this->input->post('note2'); 
$subj3=$this->input->post('subject3'); 
$notes3=$this->input->post('note3'); 
$subj4=$this->input->post('subject4'); 
$notes4=$this->input->post('note4'); 
$subj5=$this->input->post('subject5'); 
$notes5=$this->input->post('note5'); 
$subj6=$this->input->post('subject6'); 
$notes6=$this->input->post('note6'); 

$commnote1=array('common_subject'=>$subj1,'common_description'=>$notes1,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote2=array('common_subject'=>$subj2,'common_description'=>$notes2,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote3=array('common_subject'=>$subj3,'common_description'=>$notes3,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote4=array('common_subject'=>$subj4,'common_description'=>$notes4,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote5=array('common_subject'=>$subj5,'common_description'=>$notes5,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote6=array('common_subject'=>$subj6,'common_description'=>$notes6,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);



$this->event_model->insert_common_notes($commnote1); 
$this->event_model->insert_common_notes($commnote2); 
$this->event_model->insert_common_notes($commnote3); 
$this->event_model->insert_common_notes($commnote4); 
$this->event_model->insert_common_notes($commnote5); 
$this->event_model->insert_common_notes($commnote6); 
 
/****common notes ends***/


/**event menu relation*/

$event_menu=array('event_id'=>$event_id,'comp_menu_id'=>$menu_id);
$this->event_model->event_menu_relation($event_menu); 


/** event menu relation***/
/** event agency***/

$agency_notes=$this->input->post('agency_note'); 
$agency_id=$this->input->post('agency_id'); 
$agencynos_persons=$this->input->post('serve_staff');
$agency_insert=array('event_id'=>$event_id,'agency_id'=>$agency_id,'comp_id'=>$this->comp_id,'br_id'=>$this->br_id,'nos_persons'=>$agencynos_persons,'agency_notes'=>$agency_notes);

$this->event_model->event_agency($agency_insert); //save agency event relation
/** event agency***/

/** event driver***/
$driver_id=$this->input->post('driver_id');
$driverfrom=$this->input->post('driver_timefrom');
$driverto=$this->input->post('driver_timeto');
$drivernote=$this->input->post('driver_notes');
$driverdate=$this->input->post('driver_date');
$driverdate=changeto_dbformat($driverdate);
$driver_insert=array('event_id'=>$event_id,'comp_id'=>$this->comp_id,
'br_id'=>$this->br_id,'driver_description'=>$drivernote,'working_from'=>$driverfrom
,'working_to'=>$driverto,'working_date'=>$driverdate,'driver_id'=>$driver_id);

$this->event_model->event_drivernote($driver_insert);

/** event driver***/


/** event chef***/
$chef_id=$this->input->post('chef_id');
$cheffrom=$this->input->post('chef_timefrom');
$chefto=$this->input->post('chef_timeto');
$chefnote=$this->input->post('chef_notes');
$chefdate=$this->input->post('chef_date');
$chefdate=changeto_dbformat($chefdate);
$chef_insert=array('event_id'=>$event_id,'comp_id'=>$this->comp_id,
'br_id'=>$this->br_id,'chef_description'=>$chefnote,'working_from'=>$cheffrom
,'working_to'=>$chefto,'working_date'=>$chefdate,'chef_id'=>$chef_id);

$this->event_model->event_chefnote($chef_insert);

/** event chef***/

/** event manager***/
$manager_id=$this->input->post('manager_id');
$managerfrom=$this->input->post('manager_timefrom');
$managerto=$this->input->post('manager_timeto');
$managernote=$this->input->post('manager_notes');
$managerdate=$this->input->post('manager_date');
$managerdate=changeto_dbformat($managerdate);
$manager_insert=array('event_id'=>$event_id,'comp_id'=>$this->comp_id,
'br_id'=>$this->br_id,'manager_description'=>$managernote,'working_from'=>$managerfrom
,'working_to'=>$managerto,'working_date'=>$managerdate,'manager_id'=>$manager_id);

$this->event_model->event_manager($manager_insert);
/** event manager***/





/** event payment***/




foreach($event_p_schedule as $event_p_sched)  //event_pay_schedule which is used by event
{
$first_percent=$event_p_sched['first_temp'];
$second_percent=$event_p_sched['second_temp'];
$third_percent=$event_p_sched['third_temp'];
}






$first_pay=$this->input->post('first_pay');  //read post
$second_pay=$this->input->post('second_pay');
$third_pay=$this->input->post('third_pay');

$event_totprice=$potgtotal+$item_fulltotal; //grand total of event price
/*
echo $first_pay;
echo $second_pay;
echo $third_pay; */

if($first_pay){ //if first pay exists

$first_percent_amount_topay=($first_percent/100)*$event_totprice;
$first_bal=$first_percent_amount_topay-$first_pay;

$first_payment=array('event_id'=>$event_id,'event_paymode'=>'first','event_paytype'=>'cash',
'event_paypaid'=>$first_pay,'event_percentamount_topay'=>$first_percent_amount_topay,'br_id'=>$this->br_id,
'comp_id'=>$this->comp_id,'event_pay_balance'=>$first_bal,'event_grand_tot_price'=>$event_totprice,'percent'=>$first_percent);

$this->event_model->save_payment($first_payment); //insert payment
}

if($second_pay){

$second_percent_amount_topay=($second_percent/100)*$event_totprice;
$second_bal=$second_percent_amount_topay-$second_pay;


$second_payment=array('event_id'=>$event_id,'event_paymode'=>'second','event_paytype'=>'cash',
'event_paypaid'=>$second_pay,'event_percentamount_topay'=>$second_percent_amount_topay,'br_id'=>$this->br_id,
'comp_id'=>$this->comp_id,'event_pay_balance'=>$second_bal,'event_grand_tot_price'=>$event_totprice,'percent'=>$second_percent);

$this->event_model->save_payment($second_payment);

}

if($third_pay){

$third_percent_amount_topay=($third_percent/100)*$event_totprice;
$third_bal=$third_percent_amount_topay-$third_pay;


$third_payment=array('event_id'=>$event_id,'event_paymode'=>'third','event_paytype'=>'cash',
'event_paypaid'=>$third_pay,'event_percentamount_topay'=>$third_percent_amount_topay,'br_id'=>$this->br_id,
'comp_id'=>$this->comp_id,'event_pay_balance'=>$third_bal,'event_grand_tot_price'=>$event_totprice,'percent'=>$third_percent);

$this->event_model->save_payment($third_payment);

}


/** event payment***/


redirect("event/event_overview/view_event/".$event_id."/".$event_slug);



}


function remove_event($event_id='',$event_slug='')
{

$branch_id=$this->br_id;
$comp_id=$this->comp_id;

$this->db->where('event_slug',$event_slug);
$this->db->where('event_id',$event_id);
$query=$this->db->get('event');
$result=$query->result_array();

foreach($result as $res)
{ $event_idd=$res['event_id']; } //check event id valid

$this->db->where('branch_id',$branch_id);
$this->db->where('comp_id',$comp_id);
$this->db->where('event_id',$event_idd);
$query2=$this->db->get('event_branch');

if (($query2->num_rows() > 0)&&($event_idd==$event_id)) //to prevent url hack
{
$this->db->where('event_id',$event_id);
$this->db->delete('event_branch');

$this->db->where('event_id',$event_id);
$this->db->delete('event_chefnote');



$this->db->where('event_id',$event_id);
$this->db->delete('event_invoice');



$this->db->where('event_id',$event_id);
$this->db->delete('event_commonnote');

$this->db->where('event_id',$event_id);
$this->db->delete('eventguest');

$this->db->where('event_id',$event_id);
$this->db->delete('event');

$this->db->where('event_id',$event_id);
$this->db->delete('event_details');

$this->db->where('event_id',$event_id);
$this->db->delete('event_drivernote');

//delete invoice file pending


$this->db->where('event_id',$event_id);
$this->db->delete('event_payment');

$this->db->where('event_id',$event_id);
$this->db->delete('event_pay_schedule');


$this->db->where('event_id',$event_id);
$this->db->delete('event_pots_pans');

$this->db->where('event_id',$event_id);
$this->db->delete('event_pot_price');


$this->db->where('event_id',$event_id);
$this->db->delete('event_task');




redirect("event/event_overview/event_list");
}
 else{ redirect(base_url()); }









}




}	