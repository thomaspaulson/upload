<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_detail extends CI_Controller{

public $comp_id;
public $br_id; 

	function __construct()
	{
		parent::__construct();
 $this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');
 

		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'manager')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
       		$this->load->library('form_validation');
       		$this->load->helper('custom_helper');
       		$this->load->model('get_event_details');
       	
      	}
	
	public function search_event(){


$data['msg'] = '';
		$search_term = $this->input->get('search_keyword');
		$data['search_term'] = $search_term ;
		$data['contents'] = $this->get_event_details->get_events_search($search_term);
				
		$this->load->view('event/ajax_view_event',$data);	
	


}

}