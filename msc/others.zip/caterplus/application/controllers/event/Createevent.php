<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createevent extends CI_Controller{

public $comp_id;
public $br_id; 

	function __construct()
	{
		parent::__construct();
 $this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');
 
if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'manager')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
       		
       		$this->load->library('form_validation');
       		$this->load->helper('custom_helper');
       		$this->load->model('get_event_details');
       	
      	}
	
	public function index(){

$result['custlist']=$this->event_model->getcust_list();

$tot_cust_nos=count($result['custlist']);
$result['tot_cust_nos']=$tot_cust_nos;

		 $this->load->view('event/eventheader',$result); 
	 $this->load->view('event/create_event1'); 
   //  $this->load->view('admin/admin_footer');
	}

public function get_comp_curr()
{
$symbol=$this->getid_model->getcurrency($this->comp_id);
return $symbol;
}

public  function addevent(){ //2nd step
$current_custid=0;

if($this->input->post('new_cust_type')=='new_cust') 
{
$current_custid=$this->event_model->event_cust($_POST);
$result['customerid']=$current_custid;
$result['custdata']=$this->event_model->getcust_byid($current_custid);
}
elseif($this->input->post('exist_cust_type')=='existing_cust') 
{
$current_custid=$this->input->post('customer_id');
$result['customerid']=$current_custid;
$result['custdata']=$this->event_model->getcust_byid($current_custid);
}




$result['enq_type']=$this->input->post('event_enq_type');
$result['day_type']=$this->input->post('day_type');
$result['cater_type']=$this->input->post('cater_type');



$compid=$this->session->userdata('comp_id');
$result['comp_name']=$this->getid_model->get_compname($compid);
$branchid=$this->session->userdata('branch_id');
$result['branch_name']=$this->getid_model->get_branchname($branchid);
$result['get_eventtype']=$this->getcomp_details_model->get_eventtype($compid);


//print_r($_POST);
		 $this->load->view('event/eventheader',$result); 
	 $this->load->view('event/create_event2'); 
    // $this->load->view('admin/admin_footer');
	}

public  function finalizeevent(){

$comp_id=$this->comp_id;
$detail['get_defaultpay_schedule']=$get_defaultpay_schedule=$this->get_event_details->get_defaultpay_schedule($this->comp_id); 
$event_slug=random_string(50);

$detail['event_slug']=$event_slug; 
$detail['pay_schedule']=$this->event_model->get_payschedule(); 

$detail['currency']=$this->getid_model->getcurrency($this->comp_id); 
$detail['menu_types']=$this->event_model->get_menutypes($this->comp_id); 
$detail['get_agencylist']=$this->getcomp_details_model->get_agencylist($this->comp_id); 


$detail['pots_pans']=$this->getcomp_details_model->get_pots_pans(); 



$detail['comp_id']=$this->comp_id;
$detail['cust_id']=$cust_id=$this->input->post('customerid');
$detail['custdata']=$this->event_model->getcust_byid($cust_id);
$detail['event_enq_type']=$event_enq_type=$this->input->post('event_enq_type');
$detail['day_type']=$day_type=$this->input->post('day_type');
$detail['cater_type']=$cater_type=$this->input->post('cater_type');


$detail['event_title']=$event_title=$this->input->post('event_title');
$detail['event_type']=$event_type=$this->input->post('event_type'); //wedding
$detail['subevent_type']=$subevent_type=$this->input->post('subevent_type');

$detail['event_contact']=$event_contact=$this->input->post('event_contact');
$detail['adult_nos']=$adult_nos=$this->input->post('adult_nos');
$detail['child_nos']=$child_nos=$this->input->post('child_nos');

$detail['notes']=$notes=$this->input->post('notes');
$detail['event_date']=$event_date=$this->input->post('event_date');
$detail['event_start_time']=$event_start_time=$this->input->post('event_start_time');

$detail['venue_name']=$venue_name=$this->input->post('venue_name');
$detail['venue_detail']=$venue_detail=$this->input->post('venue_detail');
$detail['venue_address']=$venue_address=$this->input->post('venue_address');
$detail['venue_city']=$venue_city=$this->input->post('venue_city');
$detail['venue_state']=$venue_state=$this->input->post('venue_state');
$detail['venue_country']=$venue_country=$this->input->post('venue_country');

$detail['venue_address']=$venue_address=$venue_address.' '.$venue_detail;




$event_date=changeto_dbformat($event_date);
$add_event=array('cust_id'=>$cust_id,'event_title'=>$event_title,'eventtypeb_id'=>$event_type,'eventtypestb_id'=>$subevent_type,
'eventday_type'=>$day_type,'event_contactnum'=>$event_contact,'even_caterttype_name'=>$cater_type,'event_enq_type'=>$event_enq_type
,'event_slug'=>$event_slug);



$last_id=$this->event_model->add_event($add_event); //created event

$this->event_model->event_task_master($last_id); //create task master of event pending all


$addlocation=array('event_id'=>$last_id,'event_title'=>$event_title,'event_location'=>$venue_name,'event_address'=>$venue_address,
'event_town'=>$venue_city,'event_contactpersonph'=>$event_contact,'event_country'=>$venue_country,'evet_state'=>$venue_state);

$eventdetail_id=$this->event_model->addlocation($addlocation);

$addguest=array('event_id'=>$last_id,'eventd_id'=>$eventdetail_id,'event_date'=>$event_date,'event_time'=>$event_start_time,
'adult'=>$adult_nos,'children'=>$child_nos,'guest_notes'=>$notes);


$id=$this->event_model->addguest($addguest);

$detail['event_id']=$last_id;

/**insert default payment schedule to this event and get row html**/
$detail['row']=$this->get_event_details->get_default_row_pay_schedule($last_id); 
$detail['schedule_id']=$this->event_model->insert_dafault_as_initially($this->comp_id,$last_id);
/**insert default payment schedule to this event**/


$attatch_event_branch=array('event_id'=>$last_id,'comp_id'=>$this->comp_id,'branch_id'=>$this->br_id);
$ev_br_id=$this->event_model->attatch_event_branch($attatch_event_branch);

$detail['tasklist']=$this->event_model->get_mast_tasklist($last_id); 
$detail['eventtypename']=$eventtypename=$this->getcomp_details_model->get_eventtype_name($this->comp_id,$event_type);
$detail['subevent_typename']=$eventtypename=$this->getcomp_details_model->get_subeventtype_name($this->comp_id,$subevent_type);
$detail['drivers']=$this->getcomp_details_model->get_alldrivers($this->comp_id,$this->br_id);
$detail['managers']=$this->getcomp_details_model->get_allmanagers($this->comp_id,$this->br_id); 
$detail['chefs']=$this->getcomp_details_model->get_allchefs($this->comp_id,$this->br_id);
		 $this->load->view('event/eventheader',$detail); 
	 $this->load->view('event/create_event3'); 
    // $this->load->view('admin/admin_footer');
	}



public  function save_event(){

/***********/
	
       		


/*******/
$cust_id=$this->input->post('cust_id');
$event_slug=$this->input->post('event_slug');
$event_id=$this->input->post('event_id');

$new_menu_name=$this->input->post('new_menu_name'); //read menu name
$new_menu_name= preg_replace('!\s+!', ' ', $new_menu_name);

if($new_menu_name){}
else{ $new_menu_name="Menu -".$event_id; }

if((strlen($new_menu_name)==0)||(ctype_space($new_menu_name)))
{
$new_menu_name="Menu -".$event_id;
}

$ran_id=random_string(3);
$if_exists=$this->event_model->check_menu_name($new_menu_name,$event_id); //if any other exists 
if($if_exists=="1"){ 
$new_menu_name= preg_replace('/[0-9]+/', '', $new_menu_name);
$new_menu_name=$new_menu_name.$event_id.$ran_id; } //random slug needed





$menu_id=$this->event_model->create_menu($new_menu_name,$this->comp_id); //menu id
$menu_types=$this->event_model->get_menutypes($this->comp_id); 

$item_fulltotal=0;

foreach($menu_types as $type_menu){  //read item from post
$menu_id_id=$type_menu['menutypeid']; 
$menu_name=$type_menu['menutypename'];

/****item starts***/

$item_list=$this->event_model->get_items($this->comp_id,$menu_id_id); 
//print_r($item_list);
foreach($item_list as $items) 
{ 
$item_subprice=0;
$ittem_id=$items['itemid'];
$variab="textfield_".$ittem_id;
$item_value=$this->input->post($variab);
$item_unit=$items['itemunits'];
$item_price=$items['itemprice'];

if($item_value)
{ 
$item_subprice=$item_price*$item_value;
$item_fulltotal=$item_fulltotal+$item_subprice;
$item_menu_relation=array('item_id'=>$ittem_id,
'comp_menu_id'=>$menu_id,
'item_unit'=>$item_unit,
'item_nos'=>$item_value,
'comp_id'=>$this->comp_id,
'item_subprice'=>$item_subprice,);

$this->event_model->create_menu_item($item_menu_relation); 
}


} 
}  // read item ends

//save item total price to table event_menu_price

$data2=array('comp_id'=>$this->comp_id,
'menu_id'=>$menu_id,
'total_price'=>$item_fulltotal,
);

$this->event_model->totprice_menu_item($data2); //save item total price


/****item end***/

/****pots starts***/

$pots_pans=$this->getcomp_details_model->get_pots_pans(); 

$potgtotal=0;
 foreach($pots_pans as $ppp){  //read pots
 $tot_potprice=0;
 $potttid=$ppp['pp_id']; $temppot_deposit=$ppp['pp_deposit']; $temppot_price=$ppp['pp_price'];
 $pot_nos=$this->input->post('textfieldnos_'.$potttid); 
 $pot_rent_price=$this->input->post('textfieldrent_'.$potttid); 
 $pot_deposit=$this->input->post('textfielddeposit_'.$potttid);  
 
  if($pot_nos>0)
 {
 $tot_potprice=($pot_nos*$pot_rent_price)+$pot_deposit;
 $potgtotal=$potgtotal+$tot_potprice;
 $pots_array=array('pp_id'=>$potttid,'event_id'=>$event_id,'event_pp_nos'=>$pot_nos,'br_id'=>$this->br_id,
 'comp_id'=>$this->comp_id, 'pot_rent'=>$pot_rent_price,'pot_deposit'=>$pot_deposit,'pot_totalprice'=>$tot_potprice,);
 
$this->event_model->pots_event_relation($pots_array); //save pots and pans

 } 
 
 } //read end pots

$pots_price_gtotal_array=array('comp_id'=>$this->comp_id,'br_id'=>$this->br_id,'event_id'=>$event_id,'pot_total_price'=>$potgtotal);
$this->event_model->pots_totalprice($pots_price_gtotal_array); //save to event pot price g total



/****pots ends***/

/****common notes***/


$subj1=$this->input->post('subject1'); 
$notes1=$this->input->post('note1'); 
$subj2=$this->input->post('subject2'); 
$notes2=$this->input->post('note2'); 
$subj3=$this->input->post('subject3'); 
$notes3=$this->input->post('note3'); 
$subj4=$this->input->post('subject4'); 
$notes4=$this->input->post('note4'); 
$subj5=$this->input->post('subject5'); 
$notes5=$this->input->post('note5'); 
$subj6=$this->input->post('subject6'); 
$notes6=$this->input->post('note6'); 

$commnote1=array('common_subject'=>$subj1,'common_description'=>$notes1,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote2=array('common_subject'=>$subj2,'common_description'=>$notes2,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote3=array('common_subject'=>$subj3,'common_description'=>$notes3,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote4=array('common_subject'=>$subj4,'common_description'=>$notes4,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote5=array('common_subject'=>$subj5,'common_description'=>$notes5,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);
$commnote6=array('common_subject'=>$subj6,'common_description'=>$notes6,
'event_id'=>$event_id,'comp_id'=>$this->comp_id);



$this->event_model->insert_common_notes($commnote1); 
$this->event_model->insert_common_notes($commnote2); 
$this->event_model->insert_common_notes($commnote3); 
$this->event_model->insert_common_notes($commnote4); 
$this->event_model->insert_common_notes($commnote5); 
$this->event_model->insert_common_notes($commnote6); 
 
/****common notes ends***/


/**event menu relation*/

$event_menu=array('event_id'=>$event_id,'comp_menu_id'=>$menu_id);
$this->event_model->event_menu_relation($event_menu); 


/** event menu relation***/
/** event agency***/

$agency_notes=$this->input->post('agency_note'); 
$agency_id=$this->input->post('agency_id'); 
$agencynos_persons=$this->input->post('serve_staff');
$agency_insert=array('event_id'=>$event_id,'agency_id'=>$agency_id,'comp_id'=>$this->comp_id,
'br_id'=>$this->br_id,'nos_persons'=>$agencynos_persons,'agency_notes'=>$agency_notes);

$this->event_model->event_agency($agency_insert); //save agency event relation
/** event agency***/

/** event driver***/
$driver_id=$this->input->post('driver_id');
$driverfrom=$this->input->post('driver_timefrom');
$driverto=$this->input->post('driver_timeto');
$drivernote=$this->input->post('driver_notes');
$driverdate=$this->input->post('driver_date');
$driverdate=changeto_dbformat($driverdate);
$driver_insert=array('event_id'=>$event_id,'comp_id'=>$this->comp_id,
'br_id'=>$this->br_id,'driver_description'=>$drivernote,'working_from'=>$driverfrom
,'working_to'=>$driverto,'working_date'=>$driverdate,'driver_id'=>$driver_id);

$this->event_model->event_drivernote($driver_insert);

/** event driver***/


/** event chef***/
$chef_id=$this->input->post('chef_id');
$cheffrom=$this->input->post('chef_timefrom');
$chefto=$this->input->post('chef_timeto');
$chefnote=$this->input->post('chef_notes');
$chefdate=$this->input->post('chef_date');
$chefdate=changeto_dbformat($chefdate);
$chef_insert=array('event_id'=>$event_id,'comp_id'=>$this->comp_id,
'br_id'=>$this->br_id,'chef_description'=>$chefnote,'working_from'=>$cheffrom
,'working_to'=>$chefto,'working_date'=>$chefdate,'chef_id'=>$chef_id);

$this->event_model->event_chefnote($chef_insert);

/** event chef***/

/** event manager***/
$manager_id=$this->input->post('manager_id');
$managerfrom=$this->input->post('manager_timefrom');
$managerto=$this->input->post('manager_timeto');
$managernote=$this->input->post('manager_notes');
$managerdate=$this->input->post('manager_date');
$managerdate=changeto_dbformat($managerdate);
$manager_insert=array('event_id'=>$event_id,'comp_id'=>$this->comp_id,
'br_id'=>$this->br_id,'manager_description'=>$managernote,'working_from'=>$managerfrom
,'working_to'=>$managerto,'working_date'=>$managerdate,'manager_id'=>$manager_id);

$this->event_model->event_manager($manager_insert);
/** event manager***/





/** event payment***/


$event_p_schedule=$this->event_model->get_event_payschedule($event_id);
//print_r($event_p_schedule);

foreach($event_p_schedule as $event_p_sched)  //event_pay_schedule which is used by event
{
$first_percent=$event_p_sched['first_temp'];
$second_percent=$event_p_sched['second_temp'];
$third_percent=$event_p_sched['third_temp'];
}

//echo $first_percent;




$first_pay=$this->input->post('first_pay');  //read post
$second_pay=$this->input->post('second_pay');
$third_pay=$this->input->post('third_pay');

$event_totprice=$potgtotal+$item_fulltotal; //grand total of event price


if($first_pay){ //if first pay exists

$first_percent_amount_topay=($first_percent/100)*$event_totprice;
$first_bal=$first_percent_amount_topay-$first_pay;

$first_payment=array('event_id'=>$event_id,'event_paymode'=>'first','event_paytype'=>'cash',
'event_paypaid'=>$first_pay,'event_percentamount_topay'=>$first_percent_amount_topay,'br_id'=>$this->br_id,
'comp_id'=>$this->comp_id,'event_pay_balance'=>$first_bal,'event_grand_tot_price'=>$event_totprice,'percent'=>$first_percent);

$this->event_model->save_payment($first_payment); //insert payment
}

if($second_pay){

$second_percent_amount_topay=($second_percent/100)*$event_totprice;
$second_bal=$second_percent_amount_topay-$second_pay;


$second_payment=array('event_id'=>$event_id,'event_paymode'=>'second','event_paytype'=>'cash',
'event_paypaid'=>$second_pay,'event_percentamount_topay'=>$second_percent_amount_topay,'br_id'=>$this->br_id,
'comp_id'=>$this->comp_id,'event_pay_balance'=>$second_bal,'event_grand_tot_price'=>$event_totprice,'percent'=>$second_percent);

$this->event_model->save_payment($second_payment);

}

if($third_pay){

$third_percent_amount_topay=($third_percent/100)*$event_totprice;
$third_bal=$third_percent_amount_topay-$third_pay;


$third_payment=array('event_id'=>$event_id,'event_paymode'=>'third','event_paytype'=>'cash',
'event_paypaid'=>$third_pay,'event_percentamount_topay'=>$third_percent_amount_topay,'br_id'=>$this->br_id,
'comp_id'=>$this->comp_id,'event_pay_balance'=>$third_bal,'event_grand_tot_price'=>$event_totprice,'percent'=>$third_percent);

$this->event_model->save_payment($third_payment);

}


/** event payment***/


redirect("event/event_overview/view_event/".$event_id."/".$event_slug);

}








}	