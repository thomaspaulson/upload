<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Create_invoice extends CI_Controller{

public $comp_id;
public $br_id; 

	function __construct()
	{
		parent::__construct();
$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');

      		
       		$this->load->helper('custom_helper');
       		$this->load->model('get_event_details'); 
$this->load->model('event_model');
     	$this->load->helper('file');
     	     	
$this->load->helper('download');
      	}
	
	public function generate_invoice($event_id='',$inv_name=''){



$detail['currency']=$this->getid_model->getcurrency($this->comp_id); 


$detail['company_id']='60';

$detail['customer']=$this->get_event_details->event_customer($event_id);
$detail['event_details']=$this->get_event_details->event_details($event_id);

$detail['inv_name']=$inv_name;

$event_menu=$this->get_event_details->event_menu($event_id);

//print_r($event_menu);

$menu_price=0;
foreach($event_menu as $e_menu)
{
$menu_name=$e_menu['comp_menu_name'];
$menu_id=$e_menu['menu_id'];
$menu_price=$e_menu['total_price'];
}

$menu_price=number_format((float)$menu_price, 2, '.', '');


$detail['menu_price']=$menu_price;


$detail['menu_types']=$this->event_model->get_menutypes($this->comp_id); 





/**pots pans**/
$detail['event_pots_pans']=$this->get_event_details->event_pots_pans($event_id);
$event_pot_price=$this->get_event_details->event_pot_price($event_id);

$e_pot_total_price=0;
foreach($event_pot_price as $e_pot_price)
{
$e_pot_total_price=$e_pot_price['pot_total_price'];
}
$detail['e_pot_total_price']=number_format((float)$e_pot_total_price, 2, '.', '');

if($e_pot_total_price<0)
{
$e_pot_total_price=0;
}

/**pots pans**/

/**items menu**/
$detail['selected_items']=$this->get_event_details->item_selected_and_all($event_id,$menu_id);


$detail['item_menu_relation']=$this->get_event_details->item_menu_relation($event_id);
$detail['event_menu_price']=$this->get_event_details->event_menu_price($event_id);
/**items menu**/


/*create file*/

$filename=$inv_name.'.html';
$vPath = "invoice/html_file/";
$ViewData=$this->load->view('event/create_invoice',$detail,TRUE);
//mkdir($vPath);
write_file($vPath.$filename, $ViewData);

/*create file*/

$this->load->view('event/create_invoice',$detail);


//redirect('download_invoice/'.$ViewData.'/'.$filename);


}

public function create($eventidd='',$event_slug='')
{

$comp_id=$this->comp_id;

$event_id=$this->event_model->get_event_id($eventidd,$event_slug);
if($event_id==0){ echo "UNAUTHORIZED ENTRY"; exit(); }



$inv_name=$this->event_model->create_invoice_id($eventidd);

$filename_html=$inv_name.'.html';

$this->event_model->save_invoice_id($eventidd,$filename_html);

$html='';
$url=base_url().'event/create_invoice/generate_invoice/'.$eventidd.'/'.$inv_name;

redirect($url);
exit();

/*
$this->load->library('curl');
$html.= $this->curl->simple_get($url);					
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url); 
		curl_setopt ($curl, CURLOPT_RETURNTRANSFER, 1);				
		$html.= curl_exec($curl);
		curl_close ($curl); 
if ( ! write_file('invoice/html_file/'.$filename_html, $html))
{
     echo 'Unable to write the file';
}
else
{
      echo $html;
}

*/
}


public function download_invoice($ViewData='',$name='')
{

/*download*/

$data =$ViewData;
$name = $filename;
force_download($name, $data);

/*download*/


}

}