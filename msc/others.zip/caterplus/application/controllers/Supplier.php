<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Supplier extends CI_Controller {

 	function __construct() {
       		parent::__construct();
       		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		} 
       		$this->load->library('functions');       		
    	}

	public function index()
	{      
	        $data['suppliers'] = $this->supplier_model->select_supliers();	        
		$this->load->view('supplier/supplier.php',$data);
	}
	
        public function add_new_supplier(){
		$data['title'] = 'key';
        	$this->load->view('supplier/add_new_supplier.php',$data);
        }
        
        public function add_supplier(){
		$name = $this->input->post('name');
		$email = $this->input->post('email');			        
		$address = $this->input->post('address');
		$phn_ext= $this->input->post('phn_ext');
                $phone = $this->input->post('phone');
                $mobile1= $this->input->post('mobile1');
                $mobile2 = $this->input->post('mobile2');
		$slug = random_slug(30);
		$data = array(
			'name' => $name,
			'address' => $address,
			'phn_ext' => $phn_ext,
                        'phone' => $phone,
                        'mobile1' => $mobile1,
                        'mobile2' => $mobile2,
			'slug' => $slug,
			'email' => $email,
		
		);
		$result = $this->supplier_model->add_supplier($data);	
		if($result = 1){
			redirect(base_url().'supplier', 'refresh');
		}																
        }      
        
        public function delete_supplier($slug=''){
        	$table_name='supplier';
        	$primary_key = 'supplier_id';
        	$slug_column_name = 'supplier_slug';
        	$id = $this->functions->get_id($slug,$table_name,$primary_key,$slug_column_name);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Supplier Doesnt Exists !');
        		redirect(base_url().'supplier', 'refresh');
        		exit();
        	}		        	
        	$result = $this->supplier_model->delete_supplier($id);
		if($result == 1){
			redirect(base_url().'supplier', 'refresh');
		}        
        }        

	public function  edit_supplier($slug='')
       {
        	$table_name='supplier';
        	$primary_key = 'supplier_id';
        	$slug_column_name = 'supplier_slug';
        	$id = $this->functions->get_id($slug,$table_name,$primary_key,$slug_column_name);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Supplier Doesnt Exists !');
        		redirect(base_url().'supplier', 'refresh');
        		exit();
        	}

        	$data['id'] = $id;
        	$data['suppliers'] = $this->supplier_model->get_supplier_details($id);
        	$this->load->view('supplier/edit_supplier',$data);  
       }   
       
       public function edit_existing_supplier(){
	        $id = $this->input->post('id');
		$name = $this->input->post('name');
		$address= $this->input->post('address');			        
		$phn_ext= $this->input->post('phn_ext');
                $phone= $this->input->post('phone');
                $mobile1= $this->input->post('mobile1');
                $mobile2 = $this->input->post('mobile2');
		$email= $this->input->post('email');		
		$data = array(
			'name' => $name,
			'phn_ext' => $phn_ext,
                        'phone' => $phone,
                        'mobile1' => $mobile1,
                        'mobile2' => $mobile2,
			'email' =>$email,
			'id' => $id,
			'address' => $address,			

		);
		$result = $this->supplier_model->edit_supplier($data);	
		if($result = 1){
			redirect(base_url().'supplier', 'refresh');
		}       
       
       }                   	
	

        
        
        
   
           
	
		    
        
}