<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staff_role extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');
       		} 		
	}

	public function index()	{
		$this->load->model('staff_role_model');
		$data['role_data'] = $this->staff_role_model->display_role();
		$this->load->view('headerform',$data);
	        $this->load->view('staff_role/staffrole',$data);
		$this->load->view('footerform',$data);	
	}

	public function insert_role()
	{
		$this->load->model('staff_role_model');
		$this->staff_role_model->insert_role_db();
		redirect('staff_role/index'); 
	   	
	}
	
        public function deactive_rolestatus($roleslug)
	{
		$this->db->select('*');
		$this->db->from('staffrole');
		$this->db->where('roleslug', $roleslug);
		$query = $this->db->get();
		$result=$query->result_array();
		$role_id = $result[0]['roleid'];
		
		if($result[0]['rolestatus']=='active'){
			$status='inactive';
		}else{
			$status='active';
		}
		
		$this->load->model('staff_role_model');
		$this->staff_role_model->update_rolestatus($roleslug,$status);
		$this->staff_role_model->update_staff_status($role_id,$status);			       
		redirect('staff_role/index');
						
	}
	
        public function edit_role($roleslug)
	{
		$this->load->model('staff_role_model');
		$data['role_data'] = $this->staff_role_model->edit_role_model($roleslug);
		$this->load->view('headerform', $data);
		$this->load->view('staff_role/staffrole_edit', $data);
		$this->load->view('footerform', $data);						
	}
	
        public function save_role()
	{			
		$this->load->model('staff_role_model');
		$this->staff_role_model->update_role();
		redirect('staff_role/index');						
	}
	
}