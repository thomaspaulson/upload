<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Dashboard extends CI_Controller {
    function __construct() {
        parent::__construct();
        if($this->session->userdata('user_role')=='admin'){}
        else{
            redirect("admin_home");
        }
    }
    public function index() {
        $comp_id = $this->session->userdata('comp_id');
		$br_id = $this->session->userdata('branch_id');
        $this->load->database();
        /*$data['data']=$this->db->query("select count (*)  asd from morning,afternoon,evening,night where morning.item_id=(select Item.itemid from Item where Item.itemname='meat pulav')")->result_array();*/

		 /* $this->load->view('dashboard/home',$data);*/

		 // print "Hai";
          /*-------------------------------------------------*/

		/*$data['data']=$this->db->query("select count (*) from morning,afternoon,evening,night where morning.item_id=(select Item.itemid from Item where Item.itemname='meat pulav')")->result_array();*/

        
        /*$query = $this->db->query("select * from raw_stock rs,specialingredient si where si.ingredientid=rs.ingredient_id and rs.comp_id='$comp_id' and si.comp_id='$comp_id' and rs.br_id='$br_id'");*/
		
		$query = $this->db->query("select itm.itemname,
sum(soq.package_quantity*soq.package_ordered_number) as Qty,
(sum(soq.package_quantity*soq.package_ordered_number)*soq.base_price_of_item) as amount,soq.base_price_of_item,itm.itemunits 
from specialorderquantity soq
left join specialorder spo on soq.orderid=spo.orderid
left join Item itm on soq.itemid=itm.itemid 
where itm.comp_id=60 and itm.itemid=soq.itemid and spo.orderid=soq.orderid and spo.`orderstatus`='confirmed' group BY itm.itemid");
        
		$this->data['rawstock'] = $query->result();
        $query3 = $this->db->query("SELECT sum(container_total_price) as 'containeramount' FROM `specialorder_container`");
        $containeramount = $query3->result();
        $this->data['containeramount']=$containeramount[0]->containeramount;
        
		$query1 = $this->db->query("select sum(soq.package_quantity*soq.package_ordered_number) as Qty,ment.menutypename from specialorderquantity soq
left join specialorder spo on soq.orderid=spo.orderid
LEFT JOIN Item itm ON soq.itemid=itm.itemid
LEFT JOIN menutype ment ON itm.menutype=ment.menutypeid
where itm.comp_id=60 and itm.itemid=soq.itemid and spo.orderid=soq.orderid and spo.`orderstatus`='confirmed' group BY itm.menutype");
		$this->data['rawstock1'] = $query1->result();
		//print_r($query);
        /*print_r($data['temperatures']);
        echo '</pre>';*/
        
        //PENDING ORDERS
        $pendingorders=$this->db->select('count(*) as ccount')
                                ->from('specialorder')
                                ->where("collection_status",'pending',"=")
                                ->get();
        $pendingorders=$pendingorders->result();
        $this->data["pendingorders"]=$pendingorders[0]->ccount;
        //COLLECTED ORDERS
        $collectedorders=$this->db->select('count(*) as ccount')
                                ->from('specialorder')
                                ->where("collection_status",'collected','=')
                                ->get();
        $collectedorders=$collectedorders->result();
        $this->data["collectedorders"]=$collectedorders[0]->ccount;
        //TOTAL ORDER
        $totalorders=$this->db->select('count(*) as ccount')
                                ->from('specialorder')
                                ->get();
        $totalorders=$totalorders->result();
        $this->data["totalorders"]=$totalorders[0]->ccount;
        
        //PENDING PAYMENT
        $pendingpayment=$this->db->select('(sum(paidamount)-totalpay) as pendingpayment')
                                ->from('specialeventpaymentrelation')
                                ->where('year(time)',date('Y'),'=')
                                ->get();
        $pendingpayment=$pendingpayment->result();
        $this->data["pendingpayment"]=$pendingpayment[0]->pendingpayment;
        //TOTAL PAYMENT
        $totalpayment=$this->db->select('sum(totalamount) as totalamount')
                                ->from('specialorder')
                                ->where('year(ordereddate)',date('Y'),'=')
                                ->where('orderstatus','confirmed','=')
                                ->get();
        $totalpayment=$totalpayment->result();
        $this->data["totalpayment"]=$totalpayment[0]->totalamount;
        //ADVANCE PAYMENT
        $advancepayment=$this->data["totalpayment"]-$this->data["pendingpayment"];
        $this->data["advancepayment"]=$advancepayment;
        //PENDING ORDERS TO COOK
        
        //READY FOR DELIVERY


        //POTS & PANS STOCK


        //INGREDIENTS STOCK
        
        
        //chart data
        $chartdata=$this->db->query("SELECT itemid,itemname,itemunits,gettotalqty(itemid) as totalordered,getdeliveredqty(itemid) as delivered FROM `Item` WHERE item_status='active' and menutype in(55,56)");
        $chartdata=$chartdata->result();
        $sr=0;
        $this->data["items"]="";
        $this->data["totalordered"]="";
        $this->data["delivered"]="";
        $this->data["pending"]="";
        foreach($chartdata as $idata){
            if($sr==0){
                $this->data["items"].='"'.strtoupper($idata->itemname).'"';
                if($idata->totalordered==""){
                    $totalordered=0;
                    $this->data["totalordered"].="0";
                }
                else{
                    $totalordered=$idata->totalordered;
                    $this->data["totalordered"].=$idata->totalordered;
                }
                if($idata->delivered==""){
                    $delivered=0;
                    $this->data["delivered"].="0";
                }
                else{
                    $delivered=$idata->delivered;
                    $this->data["delivered"].=$idata->delivered;
                }
                $delivered=$totalordered-$delivered;
                $this->data["pending"]=$delivered;
            }
            else{
                $this->data["items"].=', "'.strtoupper($idata->itemname).'"';
                if($idata->totalordered==""){
                    $totalordered=0;
                    $this->data["totalordered"].=", 0";
                }
                else{
                    $totalordered=$idata->totalordered;
                    $this->data["totalordered"].=", ".$idata->totalordered;
                }
                if($idata->delivered==""){
                    $delivered=0;
                    $this->data["delivered"].=", 0";
                }
                else{
                    $delivered=$idata->delivered;
                    $this->data["delivered"].=", ".$idata->delivered;
                }
                $pending=$totalordered-$delivered;
                if($pending==""){
                    $this->data["pending"].=", 0";
                }
                else{
                    $this->data["pending"].=", ".$pending;
                }
            }
            $sr++;
        }
        //chart2 data
        $chartdata2=$this->db->query("SELECT itemid,itemname,itemunits,gettotalqty(itemid) as totalordered,getdeliveredqty(itemid) as delivered FROM `Item` WHERE item_status='active' and menutype in(57,58)");
        $chartdata2=$chartdata2->result();
        $sr=0;
        $this->data["items2"]="";
        $this->data["totalordered2"]="";
        $this->data["delivered2"]="";
        $this->data["pending2"]="";
        foreach($chartdata2 as $idata){
            if($sr==0){
                $this->data["items2"].='"'.strtoupper($idata->itemname).'"';
                if($idata->totalordered==""){
                    $totalordered=0;
                    $this->data["totalordered2"].="0";
                }
                else{
                    $totalordered=$idata->totalordered;
                    $this->data["totalordered2"].=$idata->totalordered;
                }
                if($idata->delivered==""){
                    $delivered=0;
                    $this->data["delivered2"].="0";
                }
                else{
                    $delivered=$idata->delivered;
                    $this->data["delivered2"].=$idata->delivered;
                }
                $delivered=$totalordered-$delivered;
                $this->data["pending2"]=$delivered;
            }
            else{
                $this->data["items2"].=', "'.strtoupper($idata->itemname).'"';
                if($idata->totalordered==""){
                    $totalordered=0;
                    $this->data["totalordered2"].=", 0";
                }
                else{
                    $totalordered=$idata->totalordered;
                    $this->data["totalordered2"].=", ".$idata->totalordered;
                }
                if($idata->delivered==""){
                    $delivered=0;
                    $this->data["delivered2"].=", 0";
                }
                else{
                    $delivered=$idata->delivered;
                    $this->data["delivered2"].=", ".$idata->delivered;
                }
                $pending=$totalordered-$delivered;
                if($pending==""){
                    $this->data["pending2"].=", 0";
                }
                else{
                    $this->data["pending2"].=", ".$pending;
                }
            }
            $sr++;
        }
        //chart3 data
        $chartdata2=$this->db->query("SELECT itemid,itemname,itemunits,gettotalqty(itemid) as totalordered,getdeliveredqty(itemid) as delivered FROM `Item` WHERE item_status='active' and menutype in(59,60)");
        $chartdata2=$chartdata2->result();
        $sr=0;
        $this->data["items3"]="";
        $this->data["totalordered3"]="";
        $this->data["delivered3"]="";
        $this->data["pending3"]="";
        foreach($chartdata2 as $idata){
            if($sr==0){
                $this->data["items3"].='"'.strtoupper($idata->itemname).'"';
                if($idata->totalordered==""){
                    $totalordered=0;
                    $this->data["totalordered3"].="0";
                }
                else{
                    $totalordered=$idata->totalordered;
                    $this->data["totalordered3"].=$idata->totalordered;
                }
                if($idata->delivered==""){
                    $delivered=0;
                    $this->data["delivered3"].="0";
                }
                else{
                    $delivered=$idata->delivered;
                    $this->data["delivered3"].=$idata->delivered;
                }
                $delivered=$totalordered-$delivered;
                $this->data["pending3"]=$delivered;
            }
            else{
                $this->data["items3"].=', "'.strtoupper($idata->itemname).'"';
                if($idata->totalordered==""){
                    $totalordered=0;
                    $this->data["totalordered3"].=", 0";
                }
                else{
                    $totalordered=$idata->totalordered;
                    $this->data["totalordered3"].=", ".$idata->totalordered;
                }
                if($idata->delivered==""){
                    $delivered=0;
                    $this->data["delivered3"].=", 0";
                }
                else{
                    $delivered=$idata->delivered;
                    $this->data["delivered3"].=", ".$idata->delivered;
                }
                $pending=$totalordered-$delivered;
                if($pending==""){
                    $this->data["pending3"].=", 0";
                }
                else{
                    $this->data["pending3"].=", ".$pending;
                }
            }
            $sr++;
        }
        $this->load->view('headermerged', $this->data);	
        $this->load->view('dashboard/home', $this->data);
    }
}