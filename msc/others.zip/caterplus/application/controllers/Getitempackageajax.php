<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Getitempackageajax extends CI_Controller {

 	function __construct() {
       		parent::__construct();

		}
public function packagelist()
{
$itid= $_POST['itid']; 
//$nextulid= $_POST['nextulid']; 
  //get item unit
  $query=$this->db->query("select itemunits from Item where itemid ='$itid'");
$result=$query->result_array();
foreach($result as $res){
$itemunits=$res['itemunits'];
}
  
  //get item unit
  


$query=$this->db->query("select item_packages from Item where itemid ='$itid'");
$result=$query->result_array();
foreach($result as $res){
$pkgid= explode(",", $res['item_packages']);
}

$lengt=count($pkgid);
$list=NULL;

if($lengt>0)
{ //no pkgid or no pkg check found
for($jj=0;$jj<$lengt;$jj++)
{

$pkid=$pkgid[$jj];
$query2=$this->db->query("select * from specialpackage where specialp_id='$pkid'");
$packagedetail=$query2->result_array();


foreach($packagedetail as $pdetail)
{  $pakageid=$pdetail['specialp_id'];  $pakageqty=$pdetail['specialp_qty'];

$passclassname="'sampleclass".$pakageid."'";

$list=$list.'<li class="slider-2bg"><a class="sampleclass'.$pakageid.'" rel="'.$itemunits.'" id="'.$pakageid.'" name="'.$pakageqty.'" onClick="selectpackage(this.id,this.name,'.$passclassname.',this.rel)"><p>'.$pakageqty.'</p></a></li>';
}

}

if($list==NULL)
{ echo 0; }
else
{
echo $list;
}


} //if no pkgid or no pkg ends
 else  //else not found pkg
 { echo 0;}










}













}