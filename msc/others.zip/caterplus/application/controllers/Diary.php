<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Diary extends CI_Controller{

public $comp_id;
public $br_id; 

	function __construct()
	{
		parent::__construct();
		$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');

		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'manager')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}		
       				
	}
	
	function index()
{
$data['eventslist'] = $this->diary_model->getallevents($this->comp_id,$this->br_id);
//print_r($data['eventslist']);
$this->load->view('diary/header',$data);		
		$this->load->view('diary/month',$data);	
$this->load->view('diary/footer');			
	 
	}
	
	function completed()
{

$data['eventslist'] = $this->diary_model->getcompleted_events($this->comp_id,$this->br_id);
//print_r($data['eventslist']);
$this->load->view('diary/header',$data);		
		$this->load->view('diary/completed');	
$this->load->view('diary/footer');	

}

function enquiry()
{
$data['eventslist'] = $this->diary_model->getenquiry_events($this->comp_id,$this->br_id);
//print_r($data['eventslist']);
$this->load->view('diary/header',$data);		
		$this->load->view('diary/enquiry');	
$this->load->view('diary/footer');	

}
function confirmed()
{
$data['eventslist'] = $this->diary_model->getconfirmed_events($this->comp_id,$this->br_id);
//print_r($data['eventslist']);
$this->load->view('diary/header',$data);		
		$this->load->view('diary/confirmed');	
$this->load->view('diary/footer');	

}

function provincial()
{
$data['eventslist'] = $this->diary_model->getprovincial_events($this->comp_id,$this->br_id);
//print_r($data['eventslist']);
$this->load->view('diary/header',$data);		
		$this->load->view('diary/cancel');	
$this->load->view('diary/footer');	

}

function listview()
{
$data['eventslist'] = $this->diary_model->getallevents($this->comp_id,$this->br_id);
//print_r($data['eventslist']);
$this->load->view('diary/header',$data);	
$this->load->view('diary/list');	
$this->load->view('diary/footer');	

}

	
}