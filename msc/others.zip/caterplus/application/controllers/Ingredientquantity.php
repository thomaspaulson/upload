<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ingredientquantity extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		 
       		$this->load->model('ingredientquantity_model');	
	}
	
	function index(){
		$data['items'] = $this->ingredientquantity_model->get_all_items();
		$data['items_ings'] = $this->ingredientquantity_model->get_all_items_ing();
		$this->load->view('ingredientquantity/ingredientquantity',$data);		
	}
	
	public function add_ingredient_quantity(){
		$data['items'] = $this->ingredientquantity_model->get_all_items();
		$data['units'] = $this->ingredientquantity_model->get_all_units();
		$data['ingredients'] = $this->ingredientquantity_model->get_all_ingredients();
		$this->load->view('ingredientquantity/add_ingredientquantity',$data);
	}
	
	public function insert_ingredientquantity(){
		$ingredients = $this->input->post('ingredients');
		$item_id = $this->input->post('item_id');
		$item_qty = $this->input->post('item_qty');
		$item_unit = $this->input->post('itemunits');				
		if($ingredients ){
			foreach($ingredients as $ingredient){
				$data = array(
					'item_id' => $item_id,
					'item_qty' => $item_qty,
					'item_unit' => $item_unit,
					'ing_id' => $ingredient,
					'ing_qty' => $this->input->post('ing_qty_'.$ingredient),
					'ing_unit' => $this->input->post('itemunits_'.$ingredient),
				);
				$id = $this->ingredientquantity_model->insert($data);
			}

			redirect(base_url().'ingredientquantity', 'refresh');
	
		}
	}	
		
	
public function addnew_ingredient()
{
//this->ingredientquantity_model->insert($data);
redirect('items/addform');
}
			
	
}