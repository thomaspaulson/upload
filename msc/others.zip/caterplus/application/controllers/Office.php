<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Office extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')||($this->session->userdata('type') == 'office')||($this->session->userdata('type') == 'manager')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}

		
	}

	public function index($msg=''){	
		//$this->output->enable_profiler(TRUE);	

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
		$data['allitems'] = $this->supplier_model->getallcategories_allitems();
$date="2016-07-05";

		if($_SERVER['REQUEST_METHOD'] == 'POST'){
			$start = $this->input->post('start');
			$end = $this->input->post('end');
			//$date = date('Y-m-d');
$date="2016-07-05";
			$data['active'] = $start . $end;
			//$data['orders']= $this->kitchen_model->get_orders_between_timeslots($start,$end,$date);				
			//echo '<pre>';
			//print_r($data['orders']);
			//echo '</pre>';		
		}else{
			$start = 00;
			$end = 00;
			//$date = date('Y-m-d');
			$data['active'] = $start . $end;
			//$data['orders']= $this->kitchen_model->get_orders_between_timeslots(10,13,$date);						
			//$data['orders']= $this->kitchen_model->all_order($date);				
			//echo '<pre>';
			//print_r($data['orders']);
			//echo '</pre>';

		}
		
		$data['specialpackage'] = $this->package_model->all_packages();


		$data['cooked_items'] = $this->kitchen_model->cooked_items();
		$data['menus'] = $this->kitchen_model->get_all_menus();	
		
		$data['morning_orders']= $this->kitchen_model->get_orders_between_timeslots(10,13,$date);	
		$data['afternoon_orders']= $this->kitchen_model->get_orders_between_timeslots(13,16,$date);
		$data['evening_orders']= $this->kitchen_model->get_orders_between_timeslots(16,19,$date);
		$data['night_orders']= $this->kitchen_model->get_orders_between_timeslots(19,24,$date);
		$data['all_orders']= $this->kitchen_model->all_order($date);									
		$morning_id = $this->kitchen_model->insert_into_morning_table($data['allitems'],$date,$data['morning_orders']);
		$afternoon_id = $this->kitchen_model->insert_into_afternoon_table($data['allitems'],$date,$data['afternoon_orders']);
		$evening_id = $this->kitchen_model->insert_into_evening_table($data['allitems'],$date,$data['evening_orders']);
		$night_id = $this->kitchen_model->insert_into_night_table($data['allitems'],$date,$data['night_orders']);
		$all_id = $this->kitchen_model->insert_into_all_table($data['allitems'],$date,$data['all_orders']);
		$data['total_cooked_stocks'] = $this->kitchen_model->get_temperatures($date,'all');
																												

		if($data['active'] == 1013){
			$data['status_table_name']='morning';
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'morning');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'morning');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'morning');						
		}else if($data['active'] == 0000){
			$data['status_table_name']='all';				
			$data['started_items'] = $this->kitchen_model->get_all_started_items($date);			
			$data['completed_items'] = $this->kitchen_model->get_all_completed_items($date);
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'all');
			//$data['temperatures'] = $this->kitchen_model->get_temperatures_all($date);													
		}else if($data['active'] == 1316){
			$data['status_table_name']='afternoon';		
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'afternoon');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'afternoon');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'afternoon');
										
		}else if($data['active'] == 1619){
			$data['status_table_name']='evening';		
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'evening');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'evening');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'evening');								
		}else{
			$data['status_table_name']='night';		
			$data['cooking_status_items'] = $this->kitchen_model->get_cooking_status_items($date,'night');
			$data['started_items'] = $this->kitchen_model->get_started_items($date,'night');
			$data['completed_items'] = $this->kitchen_model->get_completed_items($date,'night');
			$data['temperatures'] = $this->kitchen_model->get_temperatures($date,'night');								
		}						

		$query=$this->db->query("select * from raw_stock rs,specialingredient si where si.ingredientid=rs.ingredient_id and rs.comp_id='$comp_id' and 
si.comp_id='$comp_id' and rs.br_id='$br_id'");
$data['rawstock']=$query->result_array();
					
//print_r($data['rawstock']);
		//echo '<pre>';
		//print_r($data['temperatures']);
		//echo '</pre>';
		//$this->load->view('headerkitchen');		
		$this->load->view('office/office.php',$data); 	
	}
















}