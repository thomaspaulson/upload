<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


//include_once(APPPATH.'core/KRUX_Controller.php');


class Admin_dashboard extends KRUX_Controller {

 	function __construct() {
       		parent::__construct();
		 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		}else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
    	}

public function index()
{
//echo "dsfsdf";exit();
$compid=$this->session->userdata('comp_id');
$result['comp_name']=$this->getid_model->get_compname($compid);
$branchid=$this->session->userdata('branch_id');
$result['branch_name']=$this->getid_model->get_branchname($branchid);
$result['get_eventtype']=$this->getcomp_details_model->get_eventtype($compid);

$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/admin_dashboard.php');
$this->load->view('admin/admin_footer.php');
}
	
        
}