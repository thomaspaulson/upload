<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Settings extends KRUX_Controller {

 	function __construct() {
       		parent::__construct();
       		
$this->load->model('admin/admin_master_model');
		if($this->session->userdata('logged_in') != 'yes')
		{ redirect(base_url()); }
    	}

public function create_eventtype()
{
$this->admin_master_model->add_event_type($_POST);
redirect('admin/admin_dashboard/index'); 
}

public function create_subeventtype()
{
$this->admin_master_model->update_event_type($_POST);
redirect('admin/admin_dashboard/index'); 
}	


public function add_item()
{

$result['packages']=$this->get_mast_detail->get_package();
$result['ingredients']=$this->get_mast_detail->get_ingredient();
$result['units']=$this->get_mast_detail->get_basicunits();
$result['category']=$this->get_mast_detail->get_menutype();
$this->load->view('admin/admin_header.php');
$this->load->view('admin/add_item.php',$result);
$this->load->view('admin/admin_footer.php');
}

public function add_ingredient()
{
$this->load->view('admin/admin_header.php');
$this->load->view('admin/add_ingredient.php');
$this->load->view('admin/admin_footer.php');
}

public function create_ingredient()
{

$this->admin_master_model->add_ing($_POST);
redirect('admin/admin_dashboard/index'); 
}

public function edit_subeventtype($data)
{
extract($data);           
$this->admin_master_model->edit_subeventtype($data);
}


function add_package()
	{
$this->load->view('admin/admin_header.php');
$this->load->view('admin/add_package.php');
$this->load->view('admin/admin_footer.php');
}

function  create_package()
{
$this->admin_master_model->create_package($_POST);
redirect('admin/admin_dashboard/index'); 
}			
		

function add_container()
	{
$this->load->view('admin/admin_header.php');
$this->load->view('admin/add_containers.php');
$this->load->view('admin/admin_footer.php');
}

function  create_container()
{
$this->admin_master_model->create_containers($_POST);
redirect('admin/admin_dashboard/index'); 
}

function  add_menutypes()
{
$this->load->view('admin/admin_header.php');
$this->load->view('admin/add_menutypes.php');
$this->load->view('admin/admin_footer.php'); 
}


function  create_menutype()
{
$this->admin_master_model->create_menutype($_POST);
redirect('admin/admin_dashboard/index'); 
}

function  add_staff()
{
$this->load->view('admin/admin_header.php');
$this->load->view('admin/add_staff.php');
$this->load->view('admin/admin_footer.php'); 
}


function create_staff(){
        	$flag =  0;
        	
        	
        	
        	while($flag == 0){
        	        $pin = random_string('alnum', 4);
                	$pin_check = $this->getid_model->pin_check($pin);
                	if($pin_check == 0){
                		$flag = 1;
                		break;                	
                	}  	        	
        	}     
        	
        	$user_id = random_string(4);
        	
        	
        	
		$emp_name= $this->input->post('name');
		$emp_email= $this->input->post('email');
		//$email2 = $this->input->post('email');
		$emp_phone= $this->input->post('mobile1');
		//$mobile2 = $this->input->post('mobile2');							        
		$username = $this->input->post('username');
		$emp_address= $this->input->post('address');
                $phn_ext= $this->input->post('phn_ext');
		$phone = $this->input->post('phone');
                $mobile1= $this->input->post('mobile1');
               // $mobile2= $this->input->post('mobile2');
		$role = $this->input->post('role'); 
		$type = $this->input->post('type'); 
		$password = $this->input->post('password'); 
		
		$data = array(
			'emp_name' => $emp_name,
			'emp_phone'=> $emp_phone,
			'emp_address' => $emp_address,
                        'emp_email' => $emp_email,
				
		); 
		
		$lastid= $this->admin_master_model->add_staff($data);
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');




$data2 = array('emp_id' => $lastid,'emp_username' =>$username,
                        'emp_password' => md5($password),
                        'comp_id' => $comp_id,
			'br_id' => $br_id,
			'emp_PIN' => $pin,
			);

$this->admin_master_model->add_stafflogin($data2);


		//-----------------------------------------------
		//Image upload		

		$allowedExts = array("gif", "jpeg", "jpg", "png");
		$temp = explode(".", $_FILES["userfile"]["name"]);
		$extension = end($temp);
		$extension = strtolower($extension );
		
		if (in_array($extension, $allowedExts)) {
		      move_uploaded_file($_FILES["userfile"]["tmp_name"],
		      $_SERVER['DOCUMENT_ROOT']."/uploads/staff/" . $lastid.'.'.$extension);
		} 

		//end of image upload	
		//-------------------------------------------------	
		if($lastid){
			$data = array(
				'emp_img' => $lastid.'.'.$extension,
			);
			
			$this->db->where('emp_id', $lastid);
			$this->db->update('pdt_employee', $data);
			redirect('admin/admin_dashboard/index');
		}																
        } 




function insert_item()
	{


			
		extract($_POST);
		
		$item_packages = $this->input->post('item_packages'); 

		
		if($item_packages){	
			$item_packages_id = implode(",",$item_packages);
		}else{
			$item_packages_id = 'NULL';
		}




		
		if($this->input->post('included_specialevent')=='yes'){
			$included_specialevent='yes';
		}else{
			$included_specialevent='no'; 
		}
			
		

	 	if($this->input->post('itemtemperaturecheck')=='yes'){
			$temperature='yes'; $temperature_value= $this->input->post('temperaturevalue');
		}else{
			$temperature='no'; $temperature_value=0;
		}
		$ingredientname =$this->input->post('ingredients');
		
	
		if($ingredientname){
			$ingrident=  implode(",",$ingredientname);
		}else{
			$ingrident='NULL';
		}

		
		$menutype=$this->input->post('menutype'); 
		
		/*if($menutype)
		{ $menu=  implode(",",$menutype); } else { $menu=NULL;}*/
		
		
		
		
		$check_accompaniments = $this->input->post('check_accompaniments');
	
		if($check_accompaniments == 'yes'){		
			$accompaniments=$this->input->post('accompaniments');
			if($accompaniments){
				$accompani=  implode(",",$accompaniments);
			}
			else{
			
			$accompani='NULL';
		}			
		}else{
			
			$accompani='NULL';
		}
		$comp_id=$this->session->userdata('comp_id');
		$itemprice=$this->input->post('itemprice');
		$instructions=$this->input->post('instructions');		
		$data = array(
			'item_name' => ucwords($this->input->post('itemname')),		//
			'item_unit' =>$this->input->post('itemunits'),  //
		        'item_desc'=>trim($this->input->post('itemdescription')), //
			//'includedingredients' => $ingrident,
			//'menutype' => $menu,
			'comp_id' =>$comp_id,                      //
			'temperature_value' => $temperature,          //   
			'temperature_value'=>$temperature_value, //
			'item_specialevent'=>$included_specialevent, //
			'item_price' => $itemprice,  //
			'item_instructions' => $instructions, //
			'item_package' => $item_packages_id, //
		);
		
		$this->db->insert('item',$data); 							
		$insert_id = $this->db->insert_id();
		$item_id = $insert_id;	
		
		$ingredients = $this->input->post('ingredients');
		
		
		$item_qty = $this->input->post('itemqty');
		$item_unit = $this->input->post('itemunits');
		
		if($menutype){
		foreach($menutype as $menutypes)
		{
		$data2=array('item_id' => $item_id,'menutype_id'=>$menutypes,'comp_id'=>$comp_id);
		$this->db->insert('menutype_item',$data2); 							
		} }
		

//-----------------------------------------------
		//Image upload		
		
		$allowedExts = array("gif", "jpeg", "jpg", "png");
		$temp = explode(".", $_FILES["userfile"]["name"]);
		$extension = end($temp);
		$extension = strtolower($extension );
		
		if (in_array($extension, $allowedExts)) {
		      move_uploaded_file($_FILES["userfile"]["tmp_name"],
		      $_SERVER['DOCUMENT_ROOT']."/uploads/items/" . $item_id.'.'.$extension);
		} 

		//end of image upload	
		//-------------------------------------------------
		$data = array(
			'item_img' => $item_id.'.'.$extension,
		);
		
		$this->db->where('item_id', $item_id);
		$this->db->update('item', $data); 	
			
		if($ingredients){
		
			foreach($ingredients as $ingredient){
				$data = array(
					'item_id' => $item_id,
					'item_quantity' => $item_qty,
					'comp_id' => $comp_id,
					'ing_id' => $ingredient,
					'item_ing_qty' => $this->input->post('ing_qty_'.$ingredient),
					'item_ing_unit' => $this->input->post('itemunits_'.$ingredient),
				);
				$id = $this->admin_master_model->item_ing($data);
				
			}	
				
		
				
		}
		redirect(base_url());

	}





function  list_ingredients()
{
$result['ingredients']=$this->get_mast_detail->get_ingredient();
$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/list_ingredients.php');
$this->load->view('admin/admin_footer.php'); 
}



function  remove_ingredients($ran='',$ingid='')
{

$this->admin_master_model->remove_ing($ingid);
redirect('admin/settings/list_ingredients');
}

function  list_item()
{
$result['items']=$this->get_mast_detail->get_activeitems();
$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/list_item.php');
$this->load->view('admin/admin_footer.php'); 
}


function  remove_item($ran='',$itemid='')
{

$this->admin_master_model->remove_item($itemid);
redirect('admin/settings/list_item');
}

function  list_container()
{
$result['container']=$this->get_mast_detail->get_activecontainer();

$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/list_container.php');
$this->load->view('admin/admin_footer.php'); 
}

function  remove_container($ran='',$cid='')
{
$this->admin_master_model->remove_container($cid);
redirect('admin/settings/list_container');
}

function  list_packages()
{
$result['packages']=$this->get_mast_detail->get_package();
$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/list_packages.php');
$this->load->view('admin/admin_footer.php'); 
}



function  remove_packages($ran='',$pid='')
{
$this->admin_master_model->remove_packages($pid);
redirect('admin/settings/list_packages');
}


function list_menutypes()
{
$result['menutype']=$this->get_mast_detail->get_menutype();
$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/list_menutype.php');
$this->load->view('admin/admin_footer.php'); 
}


function  remove_menutype($ran='',$mid='')
{
$this->admin_master_model->remove_menutype($mid);
redirect('admin/settings/list_menutypes');
}

/*
function list_staff() //not using
{
$result['menutype']=$this->get_mast_detail->get_menutype();
$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/list_staff.php');
$this->load->view('admin/admin_footer.php'); 
} */


function list_staffrole()
{

$result['get_staff_subrole']=$this->get_mast_detail->get_staff_subrole();
$this->load->view('admin/admin_header.php',$result);
$this->load->view('admin/list_staffrole.php');
$this->load->view('admin/admin_footer.php'); 
}

function add_staffrole()
{
$result['staffrole']=$this->get_mast_detail->get_staffrole();
$this->load->view('admin/admin_header.php');
$this->load->view('admin/add_staffrole.php',$result);
$this->load->view('admin/admin_footer.php'); 
}


function insert_staffrole()
{
$this->admin_master_model->insert_staffrole($_POST);
redirect('admin/settings/list_staffrole'); 
}
     
function edit_staffrole($id='')
{
$result['sb_id']=$id;
$result['staffrole']=$this->get_mast_detail->get_staffrole();
$result['edit_staff_subrole']=$this->get_mast_detail->get_staff_subrole_byid($id);
$this->load->view('admin/admin_header.php');
$this->load->view('admin/edit_staffrole.php',$result);
$this->load->view('admin/admin_footer.php'); 
}
     


function update_staffrole()
{
$this->admin_master_model->update_staffrole($_POST);
redirect('admin/settings/list_staffrole');
}

function update_pots()
{
$this->admin_master_model->update_pots($_POST);
redirect('admin/settings/list_pots_pans');
}

   
function changestat_staff($id='')
{
$this->admin_master_model->change_status_staff($id);
redirect('admin/settings/list_staffrole');
}
   

     
function add_pots_pans()
{


$this->load->view('admin/admin_header.php');
$this->load->view('pots_and_pans/addpans.php');
$this->load->view('admin/admin_footer.php'); 
}

function insert_pots()
{
$this->admin_master_model->insert_pots($_POST);
redirect('admin/settings/list_pots_pans');
}


function list_pots_pans()
{
$comp_id=$this->session->userdata('comp_id');
$result['currency']=$this->getid_model->getcurrency($comp_id); 
$result['pots_list']=$this->admin_master_model->list_pots();


$this->load->view('admin/admin_header.php',$result);
$this->load->view('pots_and_pans/list_pots.php');
$this->load->view('admin/admin_footer.php'); 
}

function changestat_pots($id='')
{
$this->admin_master_model->changestat_pots($id);
redirect('admin/settings/list_pots_pans');
}

     
function edit_pots($id='')
{
$result['pp_id']=$id;
$result['potdetail']=$this->admin_master_model->list_potsby_id($id);

$this->load->view('admin/admin_header.php');
$this->load->view('pots_and_pans/edit_pots.php',$result);
$this->load->view('admin/admin_footer.php'); 
}


}