<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editprofile extends KRUX_Controller {

 	function __construct() {
       		parent::__construct(); 
$this->load->model('admin/adminprofile_model');	
       		if($this->session->userdata('logged_in') != 'yes')
		{ redirect(base_url()); }
    	}

public function edit()
{
$empid=$this->session->userdata('emp_id'); 
if($empid){ $result['data']=$this->adminprofile_model->get_admindetail($empid); $this->load->view('admin/edit_profile.php',$result); }
else{ redirect('logout/userlogout'); }
}

	
   public function update()
{

$password=$this->input->post('password');
if($password){$password=md5($password);} else{ $password=md5('admin0001');}

 $data = array(
               'emp_username' =>$this->input->post('username'),
               'emp_password' =>$password          ); 
           
$this->adminprofile_model->update_profile($data);
redirect('admin/admin_dashboard/index'); 
 
}
}