<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Accompaniments extends CI_Controller {

	function _construct()
	{
		parent::_construct();
		$this->load->helper('url');
		
	}
	
	function index(){
		
	 
	}
	
	
function listall($msg=''){
	 
	$data['msg'] =$msg;	
		
		
		$query = $this->db->get('accompaniments');
		$total = $query->num_rows(); 
	
		$array = $query->result_array();
		
		$data['contents'] = $array;

		$this->load->view('accompaniments/accompaniments',$data);
		
	}
	
	
	
	
	function addform($msg=''){ 
      
		$this->load->view('accompaniments/addaccompaniments');
		
	}


		
function insert(){

$data = array(
						   'accompanimentsname' => ucwords($this->input->post('accompanimentsname'))		
						  
					         
								);

					$this->db->insert('accompaniments',$data); 
						
			$insert_id = $this->db->insert_id();
			redirect("accompaniments/listall/added");

}
		
	

function updateform($id=null,$msg=''){
		
		if($id!=null){
		$this->db->where('accompanimentsid',$id);
		$query = $this->db->get('accompaniments');
		$array = $query->result_array();
		$data['data'] = $array[0];
		}

		$array = $query->result_array();
		$data['contents'] = $array;
		
		$this->load->view('accompaniments/editaccompaniments',$data);

	}
function update($msg=''){


		         $this->db->where('accompanimentsid',$this->input->post('accompanimentsid'));
					$query = $this->db->get('accompaniments');
					$array = $query->result_array();
					$data['data'] = $array[0];
					
				$data = array(
						  'accompanimentsname' => ucwords($this->input->post('accompanimentsname'))		
						 
								);

				$q = $this->db->query("select * from accompaniments where accompanimentsname='".addslashes($this->input->post('accompanimentsname'))."' and accompanimentsid!='".$this->input->post('accompanimentsid')."'");


				 if($q->num_rows == 0)
				 {
					
//print_r($data);
					$this->db->update('accompaniments', $data, array('accompanimentsid' => $this->input->post('accompanimentsid')));
					
					redirect("accompaniments/listall/edited");
				 }else{
					
				 	redirect("accompaniments/updateform/updated");
				 }				
				
	}
function delete($id=null){

			$this->db->delete('accompaniments', array('accompanimentsid' => $id)); 
			
			redirect("accompaniments/listall/deleted");	
		}
			
	
}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */