<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Logout extends CI_Controller {


	public function index()
	{      
        	$this->session->sess_destroy();

 $this->session->unset_userdata('logged_in');
 $this->session->unset_userdata('comp_id');
 $this->session->unset_userdata('emp_id');
 $this->session->unset_userdata('branch_id');
 $this->session->unset_userdata('user_role');
 $this->session->unset_userdata('comp_name');
 $this->session->unset_userdata('branch_name');
		redirect(base_url().'login', 'refresh');   
	}
	     
}