<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Saveingredient extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh'); 		     		
       		}
       		$this->load->model('ingredientquantity_model');
       		$this->load->library('form_validation');			
	}
	

function save(){
	
   $ingredient_name= $_POST['ingredient_name']; 
   $ingredient_price= $_POST['ingredient_price']; 
   $ingredientqty_type= $_POST['ingredientqty_type']; //unit
   $ingredient_stock= $_POST['ingredient_stock']; 
   $ingredient_reorderlevel=$_POST['ingredient_reorderlevel']; 
 
 if( (is_numeric($ingredient_stock)) && (is_numeric($ingredient_price)) && (is_numeric($ingredient_reorderlevel)))
  {
 
 $data = array(
				'ingredientname' => ucwords($ingredient_name),           
				'ingredientqtytype' => $ingredientqty_type,
				'ingredientprice' => $ingredient_price,
			);
			
			$this->db->insert('specialingredient',$data); 						
			$insert_id = $this->db->insert_id();
			
			 $datas = array(
    'current_stock' =>$ingredient_stock,
    'ingredient_id' =>$insert_id,
    'reorder_level' =>$ingredient_reorderlevel
    );
    $this->db->insert('raw_stock',$datas); 
			
 
   if($insert_id) { echo $insert_id; } else { echo "0"; }
	 
	} else { echo "0"; }
	
  }
}

  