<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staff extends CI_Controller {

 	function __construct() {
       		parent::__construct();
$this->load->helper('string');
 	 if($this->session->userdata('logged_in') !== 'yes'){
			redirect(base_url().'login', 'refresh');

       		} else if($this->session->userdata('logged_in') == 'yes'){
       			 if(($this->session->userdata('type') == 'admin')){}
                       else { redirect(base_url().'admin_home', 'refresh'); }			
       		
       		}
    	}

	public function index($page=0)
	{  


$data['search_term'] = '';	
$data['staffs'] = $this->staff_model->select_staffs();
$total =count($data['staffs']);
//print_r($total);
//print_r($data['staffs']);
$this->load->library('pagination');
		
		$config['base_url'] = base_url()."/index.php/staff/index/";
		$config['total_rows'] = $total;
		$config['per_page'] =20;
		$config['uri_segment'] = 4;
		$config['num_links'] = 2;
		//$config['page_query_string'] = TRUE;
		//$config['full_tag_open'] = '<a class ="number">';
		//$config['full_tag_close'] = '</a>';
		$config['first_link'] = '&laquo; First';
		//$config['first_tag_open'] = '<span>';
		//$config['first_tag_close'] = '</span>';
		$config['last_link'] = 'Last &raquo;';
		//$config['last_tag_open'] = '<span>';
		//$config['last_tag_close'] = '</span>';
		$config['next_link'] = 'Next &raquo;';
		$config['prev_link'] = '&laquo; Previous';
		$config['cur_tag_open'] = '<a class ="number current">';
		$config['cur_tag_close'] = '</a>';
		
		
		
		$this->pagination->initialize($config);
		$data['page'] = $page;
 $data['staffs'] = $this->staff_model->select_staffs( $config['per_page'], $page);
$data['paages'] = $this->pagination->create_links();
		//print_r($data['paages']);
//print_r($data['staffs']);
//exit();
              $this->load->view('headermerged',$data);
   		$this->load->view('staff/staff.php',$data);
		$this->load->view('footerform',$data);
	}
	

        
        public function edit_staff($slug=''){
        	$table_name='employee';
        	$primary_key = 'employeeid';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Employee Doesnt Exists !');
        		redirect(base_url().'staff', 'refresh');
        		exit();
        	}
$comp_id=$this->session->userdata('comp_id');
$data['branches']=$this->getid_model->get_branchlist_active($comp_id);
        	$data['staffs'] = $this->staff_model->get_staff_details($id);
        	$data['roles'] = $this->staff_model->select_roles();
        	$data['id'] = $id;
            //   $this->load->view('headerform',$data);
 $this->load->view('newheader',$data);
        	$this->load->view('staff/edit_staff',$data);  
              // $this->load->view('footerform',$data);   
$this->load->view('newfooter',$data);   
        }
        
        
        
        public function edit_existing_staff(){

	        $id = $this->input->post('id');
		$name = $this->input->post('name');
		$email = $this->input->post('email');	
                $email2 = $this->input->post('email2');			        
		$username = $this->input->post('username');
		$address = $this->input->post('address');
		$phn_ext= $this->input->post('phn_ext');
                $phone = $this->input->post('phone');
                $mobile1= $this->input->post('mobile1');
                $mobile2 = $this->input->post('mobile2');
		$role = $this->input->post('role');
		$type = $this->input->post('type'); $comp_id=$this->session->userdata('comp_id'); $branch_id=$this->input->post('branch_id'); 
$pin = $this->input->post('pin');
$user_id = $this->input->post('user_id');


		$data = array(
			'name' => $name,
			'username' =>$username,
			'address' => $address,
			'phn_ext' => $phn_ext,
                        'phone' => $phone,
                        'mobile1' => $mobile1,
                        'mobile2' => $mobile2,
			'role' => $role,
			'type' => $type,
			'id' => $id,
			'email' => $email,
                        'email2' => $email2,'pin' => $pin,'user_id' => $user_id,'br_id' => $branch_id,'comp_id'=>$comp_id,
		
		);
		$result = $this->staff_model->edit_staff($data);
				//-----------------------------------------------
			//Image upload		
			if($_FILES["userfile"]["name"]){
			$allowedExts = array("gif", "jpeg", "jpg", "png");
			$temp = explode(".", $_FILES["userfile"]["name"]);
			$extension = end($temp);
			$extension = strtolower($extension );
			
$idname=md5(uniqid(rand(), true));
			if (in_array($extension, $allowedExts)) {
			      move_uploaded_file($_FILES["userfile"]["tmp_name"],
			      $_SERVER['DOCUMENT_ROOT']."/uploads/staff/" . $idname.'.'.$extension);
			} 
	
			//end of image upload	
			//-------------------------------------------------	

				$data = array(
					'staff_image' => $idname.'.'.$extension,
				);
				
				$this->db->where('employeeid', $id);
				$this->db->update('employee', $data);
		
		
		
		}
	
		if($result){
			redirect(base_url().'staff', 'refresh');
		}		       
        }        
        
        public function delete_staff($slug=''){
        	$table_name='employee';
        	$primary_key = 'employeeid';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Employee Doesnt Exists !');
        		redirect(base_url().'staff', 'refresh');
        		exit();
        	}		        	
        	$result = $this->staff_model->delete_staff($id);
		if($result == 1){
			redirect(base_url().'staff', 'refresh');
		}        
        }  
        
        public function activate_staff($slug=''){
        	$table_name='employee';
        	$primary_key = 'employeeid';
        	$id = $this->staff_model->get_id($slug,$table_name,$primary_key);
        	if($id == 0){
        		$this->session->set_flashdata('message', 'Employee Doesnt Exists !');
        		redirect(base_url().'staff', 'refresh');
        		exit();
        	}		        	
        	$result = $this->staff_model->activate_staff($id);
		if($result == 1){
			redirect(base_url().'staff', 'refresh');
		}        
        }    

function changestatus($cid=null){
				$query = $this->db->get_where('employee', array('employeeid' => $cid));
				$array = $query->result_array();
				$status=($array[0]['current_status']=="active")?"inactive":"active";  

		$data = array(
				   'current_status' => $status
				);
			$this->db->update('employee', $data, array('employeeid' => $cid));
			redirect("staff");	
		}  
        
        public function add_new_staff(){
                $data['random_value'] =  random_string(4);
                $data['roles'] = $this->staff_model->select_roles();
$comp_id=$this->session->userdata('comp_id');
$data['branches']=$this->getid_model->get_branchlist_active($comp_id);
//print_r($data['roles']);

              //  $this->load->view('headerform',$data);
 $this->load->view('newheader',$data);
        	$this->load->view('staff/add_new_staff.php',$data);
            //  $this->load->view('footerform',$data);
 $this->load->view('newfooter',$data);
        }
        
        public function add_staff(){
        	$flag =  0;
        	
        	while($flag == 0){
        	        $pin = random_string(4);
                	$pin_check = $this->staff_model->pin_check($pin);
                	if($pin_check == 0){
                		$flag = 1;
                		break;                	
                	}  	        	
        	}     
        	
        	$user_id = random_string(4);
        	$comp_id=$this->session->userdata('comp_id');
		$name = $this->input->post('name');
		$email = $this->input->post('email');
		$email2 = $this->input->post('email2');
		$mobile1 = $this->input->post('mobile1');
		$mobile2 = $this->input->post('mobile2');							        
		$username = $this->input->post('username');
		$address = $this->input->post('address');
                $phn_ext= $this->input->post('phn_ext');
		$phone = $this->input->post('phone');
                $mobile1= $this->input->post('mobile1');
                $mobile2= $this->input->post('mobile2');
		$role = $this->input->post('role');
		$type = $this->input->post('type');
		$password = $this->input->post('password'); $branch_id=$this->input->post('branch_id'); 
		$slug = random_slug(30);
		$data = array(
			'name' => $name,
			'username' =>$username,
			'address' => $address,
                        'phn_ext' => $phn_ext,
			'phone' => $phone,
                        'mobile1' => $mobile1,
                        'mobile2' => $mobile2,
			'role' => $role,
			'type' => $type,
			'password' => $password,
			'pin' => $pin, 
			'slug' => $slug,
			'email' => $email,
                        'email2' => $email2,
                        'user_id' => $user_id,'br_id' => $branch_id,'comp_id'=>$comp_id,

		
		);
		$result = $this->staff_model->add_staff($data);
		//-----------------------------------------------
		//Image upload		

		$allowedExts = array("gif", "jpeg", "jpg", "png");
		$temp = explode(".", $_FILES["userfile"]["name"]);
		$extension = end($temp);
		$extension = strtolower($extension );
		
		if (in_array($extension, $allowedExts)) {
		      move_uploaded_file($_FILES["userfile"]["tmp_name"],
		      $_SERVER['DOCUMENT_ROOT']."/uploads/staff/" . $result .'.'.$extension);
		} 

		//end of image upload	
		//-------------------------------------------------	
		if($result){
			$data = array(
				'staff_image' => $result.'.'.$extension,
			);
			
			$this->db->where('employeeid', $result);
			$this->db->update('employee', $data);
			redirect(base_url().'staff', 'refresh');
		}																
        } 
        
        public function logout(){
        	$this->session->sess_destroy();
		redirect(base_url().'staff/login', 'refresh');        	
        
        }       
           
	
	function search(){
		$data['msg'] = '';
		$search_term = $this->input->get('search');
		$data['search_term'] = $search_term ;
		$data['contents'] = $this->search_model->search_staff($search_term);
		$this->load->view('headerform',$data);		
		$this->load->view('staff/staff',$data);
	}

	function searchstaff(){
		$data['msg'] = '';
		$search_term = $this->input->get('search_keyword');
		$data['search_term'] = $search_term ;
		$data['contents'] = $this->search_model->search_staffs($search_term);
		$this->load->view('staff/staff',$data);		
	}

function stafffetchdetailslist()
{
 $search_term = str_replace(' ', '',$this->input->post('employeename'));

// Use a model to retrieve the results.

        $data['staffs'] = $this->search_model->get_stafffdetailslist2($search_term);
        // Pass the results to the view.
       
       $data['paages']='';
//$this->load->view('headerform',$data);
$this->load->view('headermerged',$data);
		$this->load->view('staff/staff',$data);
		$this->load->view('footerform',$data);	
}
	
		
	
	public function get_search(){
		$data['msg'] = '';
		$search_term = $this->input->get('search_keyword');
		$data['search_term'] = $search_term ;
		$data['contents'] = $this->search_model->search_items($search_term);
		$this->load->view('staff/search_staff',$data);	
	}	    
        
}