<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Company extends KRUX_Controller {

 	function __construct() {
       		parent::__construct(); 
$this->load->model('superadmin/company_model');
       		if($this->session->userdata('superlogged_in') != 'yes')
		{redirect(base_url().'superadmin/super_login/index'); }
    	}



public function remove_company($compid='') //view
{       
$result['comp_logo']= $this->get_comp_logo($compid);
$result['detail']=$this->company_model->list_companynamebyid($compid);
$result['comp_name']=$this->company_model->get_companyname($compid); 
$result['comp_id']=$compid;

$this->load->view('superadmin/super_header.php',$result);
$this->load->view('superadmin/super_headermenu.php',$result);
$this->load->view('superadmin/remove_company.php');
$this->load->view('superadmin/super_footer.php');   

}	



public function profile_company($compid='')
{
$result['comp_logo']= $this->get_comp_logo($compid);
$result['detail']=$this->company_model->list_company($compid);
$result['comp_id']=$compid;
$this->load->view('superadmin/super_header.php',$result);
$this->load->view('superadmin/super_headermenu.php');
$this->load->view('superadmin/profile_company.php');
$this->load->view('superadmin/super_footer.php'); 

}

public function module_company($compid='')
{
$result['comp_logo']= $this->get_comp_logo($compid);
$result['detail']=$this->company_model->list_company($compid);
$result['comp_id']=$compid;
$this->load->view('superadmin/super_header.php',$result);
$this->load->view('superadmin/super_headermenu.php');
$this->load->view('superadmin/module_company.php');
$this->load->view('superadmin/super_footer.php'); 

}






public function delete_company($compid='') //permanent delete
{       
if($compid){ $this->company_model->delete_company($compid);  }
redirect('superadmin/company/remove_company/'.$compid);

}	

public function disable($compid='')
{          
if($compid){ $this->company_model->disable_company($compid);  }
redirect('superadmin/company/edit_company/'.$compid);
}


public  function add_branch($id='') //new branch
{  
$result['comp_logo']= $this->get_comp_logo($id);
$result['branches']=$this->company_model->get_branchlist($id);
$result['data']=$this->company_model->list_companyname();
$result['detail']=$this->company_model->list_companynamebyid($id);
foreach($result['detail'] as $det){  $result['comp_name']=$det['comp_name']; $result['comp_id']=$det['comp_id'];} 
$this->load->view('superadmin/super_header.php',$result);
$this->load->view('superadmin/super_headermenu.php',$result);
$this->load->view('superadmin/add_branch.php');
$this->load->view('superadmin/super_footer.php');
//$this->load->view('superadmin/br',$result);
}


public function create_branch()
{          
$data = array(
               'comp_id' =>$this->input->post('comp_id'),
               'br_address' =>$this->input->post('br_address'),
               'br_ph1' =>$this->input->post('br_ph1'),
               'br_email1' =>$this->input->post('br_email1'),
                'br_name' =>$this->input->post('br_name'),
            ); 


$this->company_model->create_branch($data);

redirect('superadmin/superadmin_dashboard/index');



}




public  function edit_company($id='') //to payment default
{  
$result['comp_logo']= $this->get_comp_logo($id);
$comp_name=$this->company_model->get_companyname($id); 
$result['detail']=$this->company_model->list_companynamebyid($id); 
 foreach($result['detail'] as $det){  $result['comp_name']=$det['comp_name']; $result['comp_id']=$det['comp_id'];} 

$result['pay']=$this->company_model->payment_detail($id);
$this->load->view('superadmin/super_header.php',$result);
$this->load->view('superadmin/super_headermenu.php',$result);
$this->load->view('superadmin/company_detail.php');
$this->load->view('superadmin/super_footer.php');
//$this->load->view('superadmin/detail',$result);
}


public  function newpay()
{  
$comp_id=$this->company_model->pay_new($_POST);
$result['detail']=$this->company_model->list_companynamebyid($comp_id);
redirect('superadmin/company/edit_company/'.$comp_id);
}


public  function licence($id='')
{ 
$result['comp_logo']= $this->get_comp_logo($id);
$result['comp_name']=$this->company_model->get_companyname($id); 
$result['comp_id']=$id;
$result['data']=$this->company_model->licence_detail($id);
$comp_name=$this->company_model->get_companyname($id); 
$this->load->view('superadmin/super_header.php',$result);
$this->load->view('superadmin/super_headermenu.php',$result);
$this->load->view('superadmin/licence_detail.php');
$this->load->view('superadmin/super_footer.php');


//$this->load->view('superadmin/licence_detail',$result);

}
public  function update_licence($id='')
{ 
$comp_id=$this->company_model->update_licence($_POST);
redirect('superadmin/company/licence/'.$comp_id);

}


public  function disable_branch($comp_id='',$br_id='') //post
{ 
$comp_id=$this->company_model->disable_branch($comp_id,$br_id);
redirect('superadmin/company/add_branch/'.$comp_id);
}



 
public  function disable_branches($comp_id='') //view
{ 

$result['data']=$this->company_model->get_branchlist($comp_id);
$this->load->view('superadmin/disable_branch',$result);

}


}