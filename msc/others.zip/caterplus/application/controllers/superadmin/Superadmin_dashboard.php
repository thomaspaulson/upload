<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Superadmin_dashboard extends KRUX_Controller {

 	function __construct() {
       		parent::__construct();
$this->load->model('superadmin/company_model');
		if($this->session->userdata('superlogged_in') != 'yes')
		{ redirect(base_url().'superadmin/super_login/index'); 
}
    	}

public function index()
{
$result['data']=$this->company_model->list_company();
$this->load->view('superadmin/super_header.php',$result);
$this->load->view('superadmin/dashboard.php');
$this->load->view('superadmin/super_footer.php');
//$this->load->view('superadmin/dash.php');
}
	
        
}