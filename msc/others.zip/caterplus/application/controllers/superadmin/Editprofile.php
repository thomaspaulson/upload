<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editprofile extends KRUX_Controller {

 	function __construct() {
       		parent::__construct(); 
$this->load->model('superadmin/editprofile_model');	

       		if($this->session->userdata('superlogged_in') != 'yes')
		{ redirect(base_url().'superadmin/super_login/index'); }
    	}

public function edit()
{
$result['data']=$this->editprofile_model->get_detail();
$this->load->view('superadmin/editprofile.php',$result);
}
	
   public function update()
{

$password=$this->input->post('password');
if($password){$password=md5($password);} else{ $password=md5('superadmin');}

 $data = array(
               'sa_fname' =>$this->input->post('fname'),
               'sa_lname' =>$this->input->post('lname'),
               'sa_email' =>$this->input->post('email'),
               'sa_mob' =>$this->input->post('mobile'),
                'sa_password' => $password
            ); 
           
$this->editprofile_model->update_profile($data);
redirect(base_url().'superadmin/superadmin_dashboard/index'); 
 
}
}