<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Superlogout extends CI_Controller {

function __construct() {
       		parent::__construct();
		
    	}


public function super_logout()
 {
 $this->session->unset_userdata('superlogged_in');
redirect(base_url().'superadmin/super_login/index');
 }

}