<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Super_login extends CI_Controller {

 	function __construct() {
       		parent::__construct();
$this->load->model('mainlogin_model');
		if($this->session->userdata('superlogged_in') == 'yes')
		{ redirect(base_url().'superadmin/superadmin_dashboard/index'); }
    	}

 	public function index()
{
$this->load->view('superadmin/superlogin');
}
		
    public function verify()
{ 
 
$username=$this->input->post('username');
$password=$this->input->post('password');
$password = md5($password); 
$result['data']=$this->mainlogin_model->superlogin($username,$password);
if($result['data']==0){ redirect('superadmin/super_login/index'); 
}
else{ $this->session->set_userdata('superlogged_in', 'yes'); 
redirect('superadmin/superadmin_dashboard/index');
 }

 }	   

 

 }	   