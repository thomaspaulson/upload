<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Addcaterer extends KRUX_Controller {

 	function __construct() {
       		parent::__construct(); 
$this->load->model('superadmin/createcompany_model');
$this->load->model('superadmin/company_model');
       		if($this->session->userdata('superlogged_in') != 'yes')
		{ redirect(base_url().'superadmin/super_login/index'); }
    	}

public function add()
{
$this->load->view('superadmin/super_header.php');
$this->load->view('superadmin/addcaterer.php');
$this->load->view('superadmin/super_footer.php');
//$this->load->view('superadmin/add.php');
}
	
   public function create()
{           
$comp_br_id['v']=$this->createcompany_model->createcompany($_POST);
foreach($comp_br_id as $get_ids)
{ $comp_id=$get_ids['comp_id']; $br_id=$get_ids['br_id']; }
$this->createcompany_model->create_master($comp_id,$br_id);
redirect(base_url().'superadmin/superadmin_dashboard/index'); 
 
}






}