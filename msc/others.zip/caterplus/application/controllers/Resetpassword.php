<?php
class Resetpassword extends CI_Controller
{
	function _construct()
	{
	
	}
	public function index($email='')
	{				
		
		$this->load->library('session');	
		
		
		$this->load->view('settings/resetpassword');
		$this->load->view('footerform');
			
		
		
		}
		function submit() {
	
		extract($_POST);
	$this->load->library('session');
		$this->load->library('functions');
	$password =	$this->functions->createPassword(5);
		$encripted_password = md5($password);
		$email = $this->input->post('email'); 	
	$data = array(
					      		     'password' => $encripted_password,
					      		     'email'   =>$email
							     
							     );
					$data = array('password'=>$encripted_password);
$this->db->update('employee',$data,array('email' => $this->input->post('email'),'status'=>'active'));
				
					
		
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->library('email');
		$email = $this->input->post('email'); 	
                
                 $query = $this->db->get_where('employee', array('email' => $email));
		$array = $query->result_array();
		
		//print_r($data['admin']);
		
		 if(!$array) {
			$this->session->set_flashdata('error', ' No Profile Exist');
 redirect('resetpassword'); } 
		//$name  = $this->input->post('name');	
		
			
				$config['protocol'] = 'mail';
				$config['mailtype'] = 'html';
				$config['mailpath'] = '';
				$config['charset'] = 'iso-8859-1';
				$config['crlf'] = '\r\n';
				$config['wordwrap'] = TRUE;
				$this->email->initialize($config);
				$baseurl = base_url();
				$this->email->from('caterplus.thephinixgroup.com');
				$this->email->to($this->input->post('email'));
			$this->email->subject('Forgot Password');
			
						$content_head	=	'<html>
									<head>
													<title>emailer</title>
													<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
													</head>
													<body bgcolor="#FFFFFF" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">
													<table width="600" cellpadding="0" cellspacing="0" border="0" align="center">
													<tr>
													<td align="left" valign="top">
													<img src="'.base_url().'extras/extra/images/caterplus_logo.png" alt="'.base_url().'" width="600" height="137" border="1px normal #000;"></td>
													</tr>
													<tr>
													<td width="600" align="left" valign="top"><table width="600" border="0" cellspacing="0" cellpadding="0">
													<tr>
													<td width="10" bgcolor="#EEEEEE">&nbsp;</td>
													<td style="font-family:Arial, Helvetica, sans-serif; font-size:13px; color:#666; padding: 0 10px;">';
						$content_tail 			=  '</td>
													<td width="10" bgcolor="#EEEEEE">&nbsp;</td>
													</tr>
													</table></td>
													</tr>
													<tr>
													<td align="left" valign="top">
													</td>
													</tr>
													<tr>
													<td align="left" valign="top" bgcolor="#666666" style="font-family:Arial, Helvetica, sans-serif; font-size:11px; color:#f2f2f2; padding:5px 10px;">&copy;'.date('Y').'. '.base_url().' . All Rights Reserved.
													</tr>
													</table>
													</body>
													</html>';
													
					$content = $content_head.'<p>Hi  <strong>Admin,</strong></p>';
						$content .= '<p></p>';
						$content .= 'Your Caterplus account new password is following'.' You can login and change your password:';
						$content .= '<p><table>';
						$content .= '<tr><td>Login here<td><td>'.$baseurl .'</td></tr>';
						$content .= '<tr><td>Email :<td><td>'.$email.'</td></tr>';
						$content .= '<tr><td>Your  Password<td><td>'.$password.'</td></tr>';
						$content .= '</table><p>';
						$content .= '<p>Thank you<br/>';
						
						$content .= base_url().'</p><br/>'.$content_tail;
						
						$this->email->message($content);
						$msg =  $this->email->send();
						$this->session->set_flashdata('status', 'Your password Sent to your mail');
						redirect("resetpassword");
						
			
	}
		
	
 }