<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Editprofile_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }


    function update_profile($data){   
    extract($data);
$this->db->where('sa_username', 'superadmin');
$this->db->update('pdt_superadmin', $data);
    }

function get_detail(){   
 
$this->db->where('sa_username', 'superadmin');
$query=$this->db->get('pdt_superadmin');
return $result=$query->result_array();
    }

}