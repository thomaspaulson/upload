<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Company_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }


public  function disable_company($comp_id='')
{  

$query = $this->db->get_where('pdt_company', array('comp_id' => $comp_id));
$array = $query->result_array();
$status=($array[0]['comp_status']=="active")?"inactive":"active"; 
$data = array(
'comp_status' => $status
);
$this->db->update('pdt_company', $data,  array('comp_id' => $comp_id));

}

public  function list_company()
{ 
 $this->db->where('perm_status','active');
$query = $this->db->get('pdt_company');
return $query->result_array();
}
public  function get_companyname($id='')
{ 
$this->db->select('comp_name');
$this->db->where('comp_id',$id);
$query = $this->db->get('pdt_company');
$comp_namearray=  $query->result_array();

foreach($comp_namearray as $cc)
{ $ccname=$cc['comp_name'];}

return $ccname;
}

public  function list_companynamebyid($id='')
{ 
$this->db->select('comp_name');
$this->db->select('comp_id');
$this->db->select('comp_status');
$this->db->where('comp_id',$id);
$query = $this->db->get('pdt_company');
return $query->result_array();
}

public  function list_companyname()
{ 
$this->db->select('comp_name');
$this->db->select('comp_id');
$query = $this->db->get('pdt_company');
return $query->result_array();
}

 public  function create_branch($data=''){  
$this->db->insert('pdt_branch', $data);  $br_id= $this->db->insert_id(); 
}


public  function get_largestpayid($comp_id='6'){  

$this->db->select_max('pay_id');
$this->db->where('comp_id',$comp_id);
$res1 = $this->db->get('pdt_payment');
 if ($res1->num_rows() > 0)
    { $res2 = $res1->result_array(); foreach($res2 as $rr){
        
        $result = $rr['pay_id']; }
}
else
{ $result='00xx5';}
return $result;
}


public  function create_receipt($comp_id=''){  
$ccname=$this->company_model->get_companyname($comp_id); //get company name 
$ccname= preg_replace('/\s+/', '', $ccname);
$large_id=$this->company_model->get_largestpayid($comp_id); 
$rr=random_string('numeric', 4);
$receipt_id=$comp_id.$ccname.$large_id.'-'.$rr;
return $receipt_id;
}





 public  function payment_detail($comp_id=''){  

$this->db->select('*');
$this->db->where('comp_id',$comp_id);
$query = $this->db->get('pdt_payment');
return $query->result_array();
}



 public  function pay_new($data=''){  

extract($data);
$comp_id=$this->input->post('comp_id');
$pay_totamount=$this->input->post('pay_totamount');
$newpay_paid=$this->input->post('newpay_paid');
$tot_bal=$this->input->post('tot_bal');
$new_bal=$tot_bal-$newpay_paid; 

$receipt_id=$this->company_model->create_receipt($comp_id);



$data=array('comp_id'=>$comp_id,'pay_totamount'=>$pay_totamount,'pay_paid'=>$newpay_paid,'pay_bal'=>$new_bal,'receipt_id'=>$receipt_id);

$this->db->where('comp_id',$comp_id);
$this->db->insert('pdt_payment',$data);
return $comp_id;
}




 public  function licence_detail($comp_id=''){  

$this->db->select('*');
$this->db->where('comp_id',$comp_id);
$query = $this->db->get('pdt_license');
return $query->result_array();
}

 public  function update_licence($data=''){  
extract($data);
$comp_id=$this->input->post('comp_id');
$lic_enddate=$this->input->post('enddate');
$lic_desc=$this->input->post('desc');

$data2=array('lic_enddate'=>$lic_enddate,'lic_desc'=>$lic_desc); 
$this->db->where('comp_id', $comp_id);
$this->db->update('pdt_license', $data2); 
return $comp_id;
}


public  function disable_branch($comp_id='',$br_id=''){  

$query = $this->db->get_where('pdt_branch', array('br_id' => $br_id,'comp_id' => $comp_id));
$array = $query->result_array();
$status=($array[0]['br_status']=="active")?"inactive":"active"; 
$data = array(
'br_status' => $status
);
$this->db->update('pdt_branch', $data, array('br_id' => $br_id,'comp_id' => $comp_id));
return $comp_id;
}




public  function delete_company($comp_id='') //permanent disable
{  

$query = $this->db->get_where('pdt_company', array('comp_id' => $comp_id));
$array = $query->result_array();
$status=($array[0]['perm_status']=="active")?"inactive":"active"; 
$data = array(
'perm_status' => $status
);
$this->db->update('perm_status', $data,  array('comp_id' => $comp_id));

}










function get_branchlist($comp_id='')
{
$this->db->select('*');
	$this->db->from('pdt_branch');
	$this->db->where('comp_id',$comp_id);	
        $query = $this->db->get();
        $result = $query->result_array(); 
        if(($result)){
        	return $branchlist=$result;
        }   
}



}