<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Createcompany_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }


  public  function createcompany($data=''){  
    extract($data);
    
   $company= array(
               'comp_name' =>$this->input->post('compname'),
               'comp_address' =>$this->input->post('compaddress'),
               'comp_ph1' =>$this->input->post('compcontact'),
               'comp_email1' =>$this->input->post('compemail')
               ); $this->db->insert('pdt_company', $company); //company added
    
   $comp_id= $this->db->insert_id();
   $license=array(  'comp_id' =>$comp_id,
   			 'lic_no' =>$this->input->post('complicnum'), 
              	 	'lic_startdate' =>$this->input->post('complicfrom'),
              		 'lic_enddate' =>$this->input->post('complicto'),
                ); $this->db->insert('pdt_license', $license);  //lisence added


//Image upload		
		
		$allowedExts = array("gif", "jpeg", "jpg", "png");
		$temp = explode(".", $_FILES["com_logo"]["name"]);
		$extension = end($temp);
		$extension = strtolower($extension );
		
		if (in_array($extension, $allowedExts)) {
	$ran=random_string('alnum',5); 
		$filename= $comp_id.'-'.$ran.'.'.$extension;

		      move_uploaded_file($_FILES["com_logo"]["tmp_name"],
		      $_SERVER['DOCUMENT_ROOT']."/uploads/company_logo/" . $filename);
		} 

		//end of image upload	
		//-------------------------------------------------
		$dataf = array(
			'comp_logo' => $filename,
		);

$this->db->where('comp_id', $comp_id);
$this->db->update('pdt_company', $dataf); 

///

    
   $branch= array( 'comp_id' =>$comp_id,
               'br_name' =>$this->input->post('brname'),
               'br_address' =>$this->input->post('braddress'),
               'br_email1' =>$this->input->post('bremail'),
               'br_ph1' =>$this->input->post('brcontact'),
                          );   $this->db->insert('pdt_branch', $branch);  $br_id= $this->db->insert_id(); //branch added
$receipt_id=$this->company_model->create_receipt($comp_id);//receipt                          

                          $pay_totamount=$this->input->post('totpay');
                          $pay_paid=$this->input->post('received');
                          $pay_bal=$pay_totamount- $pay_paid;                          
	$payment=array(  'comp_id' =>$comp_id,
			'pay_totamount' =>$pay_totamount,
			'pay_paid' =>$pay_paid,
			'pay_bal' =>$pay_bal,'pay_description'=> $this->input->post('pay_description'),'receipt_id'=>$receipt_id
                ); $this->db->insert('pdt_payment', $payment); //payment added
                
               $comp_email1= $this->input->post('compemail');
                $admin_employee=array(
			'emp_name' =>$comp_email1,
			'emp_phone' =>$comp_email1,
			'emp_address' =>$comp_email1,
			'emp_country' =>$comp_email1, 
			'emp_state' =>$comp_email1,
			'emp_email' =>$comp_email1, 
			  );$this->db->insert('pdt_employee', $admin_employee);  $emp_id= $this->db->insert_id(); //admin added
                
               $ad_password='admin'.$comp_id; $ad_password=md5($ad_password); $ad_pin=$emp_id.$emp_id.$emp_id.$emp_id.$emp_id.$emp_id;
                $login_employee=array(
			'emp_id' =>$emp_id,
			'emp_username' =>'admin'.$comp_id,
			'emp_password' =>$ad_password,
			'comp_id' =>$comp_id, 
			'br_id' =>$br_id,
			'emp_PIN' =>$ad_pin, 
			  );$this->db->insert('pdt_employeelogin', $login_employee); //admin login added
			  
			  
			  $roleid=$this->getid_model->get_roleid('admin');
			  $rolecode=$this->getid_model->get_rolecode('admin');
			  
		$pdt_mast_emprolereleation=array(
			'emp_id' =>$emp_id,
			'c_emprole_id' =>$roleid,
			'emprole_code' =>$rolecode,			
			  );$this->db->insert('pdt_mast_emprolereleation', $pdt_mast_emprolereleation);	  //role edded as admin
			  
		return  $compid_brid=array('comp_id' =>$comp_id,'br_id' =>$br_id);			 
                    }
                    
                    
public  function create_master($comp_id='',$br_id=''){                                        
                                    
                                              
                    $this->db->select('m_event_name as eventtypeb_name,m_event_color as eventtypeb_color');  $this->db->limit(1);    
                    $query = $this->db->get('pdt_mast_eventtype');
                    $wedding_eventtype=$query ->result_array(); //create samples event type
                    $wedding_eventtype[0]['comp_id']=$comp_id; 
                    $this->db->insert('eventtype_comp', $wedding_eventtype[0]); //insert sample event type
                    $eventtype_id= $this->db->insert_id();
                    
                    
                     $this->db->select('m_subevent_name as eventstb_name');$this->db->limit(1);
                    $query = $this->db->get('pdt_mast_subeventtype');
                    $wedding_subeventtype=$query ->result_array(); //create samples subevent type
                    $wedding_subeventtype[0]['comp_id']=$comp_id; 
                    $wedding_subeventtype[0]['eventtypeb_id']=$eventtype_id; 
                    $this->db->insert('eventsubtype_branch', $wedding_subeventtype[0]); //insert sample subevent type
                    
                 
                     $this->db->select('m_menutype_name as com_tmenu_name'); $this->db->limit(1);
                    $query = $this->db->get('pdt_mast_menutype');
                    $starter_subeventtype=$query ->result_array(); //create samples subevent type
                    $starter_subeventtype[0]['comp_id']=$comp_id; 
                    $this->db->insert('menutype_company', $starter_subeventtype[0]); //insert sample      
                    
                    
                    //direct insert only 



                                 
                    $ingredient=array(  'comp_id' =>$comp_id,
			'ing_name' =>'chicken',
			'ing_unit' =>'KG',
			'ing_price' =>'250.00','ing_reorder' =>'100');                                   
                       $this->db->insert('ingredient', $ingredient); //insert sample
                       
                       $emp_role=array(
                       array(  'comp_id' =>$comp_id,
			'c_emprole_name' =>'admin',
			'c_emprole_code' =>'xx111'
			), 
			array(  'comp_id' =>$comp_id,
			'c_emprole_name' =>'manager',
			'c_emprole_code' =>'xx222'
			) ,
			array(  'comp_id' =>$comp_id,
			'c_emprole_name' =>'driver',
			'c_emprole_code' =>'xx444'
			), 
			array(  'comp_id' =>$comp_id,
			'c_emprole_name' =>'chef',
			'c_emprole_code' =>'xx333'
			)
			);                               
                      $this->db->insert_batch('employee_role', $emp_role); 
                      
                       //direct insert only
                                 
                    $supplier=array(  'supp_email' =>'123@gmail.com',
			'supp_name' =>'Al-shamal Distributors',
			'supp_address' =>'Al-shamal Distributors 101/ KG building Isa Town Bahrain ',
			'supp_ph' =>'90 000 74580');                                   
                       $this->db->insert('supplier', $supplier);  $supp_id= $this->db->insert_id(); //insert sample
                       
                       $supplier_comp=array(  'comp_id' =>$comp_id,
			'br_id' =>$br_id,
			'supp_id' =>$supp_id,
			);                                   
                       $this->db->insert('supplier_company', $supplier_comp); //insert sample
                      
                     //direct insert only
                                 
                    $package=array(  'pkg_name' =>'Pack 1',
			'pkg_unit' =>'KG',
			'pkg_qty' =>'25',
			'comp_id' =>$comp_id);                                   
                       $this->db->insert('package', $package); 
                      
                     
                      
                       
}















}