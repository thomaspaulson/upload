<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Kitchen_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
    }
    
    function all_order($date){    
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('specialorder');
 $this->db->where('specialorder.comp_id',$comp_id);
 $this->db->where('specialorder.br_id',$br_id);
	$this->db->where('deliverydate',$date);
	$this->db->where('orderstatus','confirmed');			
	$this->db->join('specialorderquantity', 'specialorderquantity.orderid = specialorder.orderid');		
        $query = $this->db->get();
        return $query->result_array();        
    }
    
    function get_orders_between_timeslots($start,$end,$date){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('specialorder');
       $this->db->where('specialorder.comp_id',$comp_id);
$this->db->where('specialorder.br_id',$br_id);
	$this->db->where('HOUR(deliverytime) >=',$start);
	$this->db->where('HOUR(deliverytime) <',$end);
	$this->db->where('deliverydate',$date);	
	$this->db->where('orderstatus','confirmed');		
	$this->db->join('specialorderquantity', 'specialorderquantity.orderid = specialorder.orderid');		
        $query = $this->db->get();
        return $query->result_array(); 
    
    }
    
    function get_cooked_items($start,$end,$date,$table_name){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('specialorder');
 $this->db->where('specialorder.comp_id',$comp_id);
$this->db->where('specialorder.br_id',$br_id);
	$this->db->where('HOUR(deliverytime) >=',$start);
	$this->db->where('HOUR(deliverytime) <',$end);
	$this->db->where('collection_status','collected');
	$this->db->where('deliverydate',$date);	
	$this->db->where('status','completed');			
	$this->db->join('specialorderquantity', 'specialorderquantity.orderid = specialorder.orderid');
	$this->db->join($table_name,"specialorder.deliverydate = $table_name.date_current");		
        $query = $this->db->get();
        return $query->result_array(); 
    
    }
    
    function insert_into_morning_table($items,$date,$orders){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

    	$table_name = 'morning';    	    	     
    	if($items){
	      	foreach($items as $item){	      		      		      		      	
	      		$total_order_taken = 0;
    			$collected = 0;	      		
			if($orders){
				foreach($orders as $order){

						if($item['itemid'] == $order['itemid']){
							$total_order_taken = $total_order_taken + $order['total_item'] ;
							if($order['collection_status'] == 'collected'){
								$collected = $collected + $order['total_item'];
							}
						}

				}									
			}else{																		
				$total_order_taken = 0;
			}
			
	    		$result = $this->check_item_exists($item['itemid'],$date,$table_name);	    			    			    		
	    		if($result == 0){
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'item_id' => $item['itemid'],
	    				'date_current' => $date,
	    				'total_order_taken' => $total_order_taken,	    				
	    			);	        
	    			$this->db->set($data);
			        $this->db->insert('morning');			        			        
	    		}else{
	    		
				$this->db->select('*');
				$this->db->from($table_name);
				$this->db->where('item_id',$item['itemid']); $this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
				$this->db->where('date_current',$date);				
			        $query = $this->db->get();
			        $re =  $query->result_array();
			        
			        $to_or = $re[0]['total_order_taken'];
			        $co_st = $re[0]['cooked_stock'];
			        $status = $re[0]['status'];
			        
			        if($status == 'completed'){
				        if($to_or > $co_st){
				        	$status = 'not started';
				        }			        
			        }
	    		
	    		
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'total_order_taken' => $total_order_taken,
	    				'collected' => $collected,
	    				'status' => $status,	    				
	    			);
				$this->db->trans_start();	    				        
	    			$this->db->where('item_id',$item['itemid']);
	    			$this->db->where('date_current',$date);	    			
			        $this->db->update('morning',$data);
			        $this->db->trans_complete();	    		
	    		
	    		}	
	    	}  	
    	}

    
    }
    
    
    function insert_into_afternoon_table($items,$date,$orders){
    	$table_name = 'afternoon';   
    	 
    	$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
    	
    	if($items){
	      	foreach($items as $item){
	      	

	      	
	      		$total_order_taken = 0;
    			$collected = 0;	      		
			if($orders){
				foreach($orders as $order){

						if($item['itemid'] == $order['itemid']){
							$total_order_taken = $total_order_taken + $order['total_item'] ;
							if($order['collection_status'] == 'collected'){
								$collected = $collected + $order['total_item'];
							}
						}

				}									
			}else{																		
				$total_order_taken = 0;
			}
			
	    		$result = $this->check_item_exists($item['itemid'],$date,$table_name);
	    		if($result == 0){
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'item_id' => $item['itemid'],
	    				'date_current' => $date,
	    				'total_order_taken' => $total_order_taken,	    				
	    			);	        
	    			$this->db->set($data);
			        $this->db->insert('afternoon');			        			        
	    		}else{
	    			    		
				$this->db->select('*');
				$this->db->from($table_name); $this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
				$this->db->where('item_id',$item['itemid']);
				$this->db->where('date_current',$date);				
			        $query = $this->db->get();
			        $re =  $query->result_array();
			        
			        $to_or = $re[0]['total_order_taken'];
			        $co_st = $re[0]['cooked_stock'];
			        $status = $re[0]['status'];
			        
			        if($status == 'completed'){
				        if($to_or > $co_st){
				        	$status = 'not started';
				        }			        
			        }	    		
	    			    			    		
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'total_order_taken' => $total_order_taken,
	    				'collected' => $collected,
	    				'status' => $status,	    					    				
	    			);
	    			$this->db->trans_start();	        
	    			$this->db->where('item_id',$item['itemid']);
	    			$this->db->where('date_current',$date);	    			
			        $this->db->update('afternoon',$data);
			        $this->db->trans_complete();	    		
	    		
	    		}	
	    	}  	
    	}

    
    }
    
    function insert_into_evening_table($items,$date,$orders){

	$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
    	$table_name = 'evening';    
    	
     	
    	
    	if($items){
	      	foreach($items as $item){
	      		      	
	      	
	      		$total_order_taken = 0;
    			$collected = 0;	      		
			if($orders){
				foreach($orders as $order){

						if($item['itemid'] == $order['itemid']){
							$total_order_taken = $total_order_taken + $order['total_item'] ;
							if($order['collection_status'] == 'collected'){
								$collected = $collected + $order['total_item'];
							}
						}

				}									
			}else{																		
				$total_order_taken = 0;
			}
			
	    		$result = $this->check_item_exists($item['itemid'],$date,$table_name);
	    		if($result == 0){
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'item_id' => $item['itemid'],
	    				'date_current' => $date,
	    				'total_order_taken' => $total_order_taken,	    				
	    			);	        
	    			$this->db->set($data);
			        $this->db->insert('evening');			        			        
	    		}else{	
	    		
				$this->db->select('*');
				$this->db->from($table_name);
				$this->db->where('item_id',$item['itemid']);$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
				$this->db->where('date_current',$date);				
			        $query = $this->db->get();
			        $re =  $query->result_array();
			        
			        $to_or = $re[0]['total_order_taken'];
			        $co_st = $re[0]['cooked_stock'];
			        $status = $re[0]['status'];
			        
			        if($status == 'completed'){
				        if($to_or > $co_st){
				        	$status = 'not started';
				        }			        
			        }	    		
	    		    			
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'total_order_taken' => $total_order_taken,
	    				'collected' => $collected,	
	    				'status' => $status,	    				    				
	    			);
	    			$this->db->trans_start();	        
	    			$this->db->where('item_id',$item['itemid']);
	    			$this->db->where('date_current',$date);	    			
			        $this->db->update('evening',$data);
			        $this->db->trans_complete();	    		
	    		
	    		}	
	    	}  	
    	}

    
    }
    
    function insert_into_night_table($items,$date,$orders){
    	$table_name = 'night';    
    	$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
     	
    	
    	if($items){
	      	foreach($items as $item){
	      	
	      	
	      	
	      		$total_order_taken = 0;
	      		$collected = 0;
			if($orders){
				foreach($orders as $order){

						if($item['itemid'] == $order['itemid']){
							$total_order_taken = $total_order_taken + $order['total_item'] ;
							if($order['collection_status'] == 'collected'){
								$collected = $collected + $order['total_item'];
							}
						}

				}									
			}else{																		
				$total_order_taken = 0;
			}
			
	    		$result = $this->check_item_exists($item['itemid'],$date,$table_name);
	    		if($result == 0){
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'item_id' => $item['itemid'],
	    				'date_current' => $date,
	    				'total_order_taken' => $total_order_taken,
	    			);	        
	    			$this->db->set($data);
			        $this->db->insert('night');			        			        
	    		}else{
	    		
				$this->db->select('*');
				$this->db->from($table_name);
				$this->db->where('item_id',$item['itemid']);$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
				$this->db->where('date_current',$date);				
			        $query = $this->db->get();
			        $re =  $query->result_array();
			        
			        $to_or = $re[0]['total_order_taken'];
			        $co_st = $re[0]['cooked_stock'];
			        $status = $re[0]['status'];
			        
			        if($status == 'completed'){
				        if($to_or > $co_st){
				        	$status = 'not started';
				        }			        
			        }	    		
	    		
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'total_order_taken' => $total_order_taken,
	    				'collected' => $collected,
	    				'status' => $status,	    				
	    			);
	    			$this->db->trans_start();	        
	    			$this->db->where('item_id',$item['itemid']);
	    			$this->db->where('date_current',$date);	    			
			        $this->db->update('night',$data);
			        $this->db->trans_complete();	    		
	    		
	    		}	
	    	}  	
    	}

    
    }          
    
    
    function insert_into_all_table($items,$date,$orders){   

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');     
    	$table_name = 'all';    	    	     
    	if($items){
	      	foreach($items as $item){	      		      		      		      	
	      		$total_order_taken = 0;
    			$collected = 0;	      		
			if($orders){

				foreach($orders as $order){

					if($item['itemid'] == $order['itemid']){			
						$total_order_taken = $total_order_taken + $order['total_item'] ;						
						if($order['collection_status'] == 'collected'){
							$collected = $collected + $order['total_item'];
						}
					}

				}									
			}else{																		
				$total_order_taken = 0;
			}
			
	    		$result = $this->check_item_exists($item['itemid'],$date,$table_name);	

	    		    			    			    		
	    		if($result == 0){	    		
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'item_id' => $item['itemid'],
	    				'date_current' => $date,
	    				'total_order_taken' => $total_order_taken,	    				
	    			);	        
	    			$this->db->set($data);
			        $this->db->insert('all');			        			        
	    		}else{	    		
				$this->db->select('*');
				$this->db->from($table_name);
				$this->db->where('item_id',$item['itemid']);$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
				$this->db->where('date_current',$date);				
			        $query = $this->db->get();
			        $re =  $query->result_array();
			        
			        $to_or = $re[0]['total_order_taken'];
			        $co_st = $re[0]['cooked_stock'];
			        $status = $re[0]['status'];
			        
			        if($status == 'completed'){
				        if($to_or > $co_st){
				        	$status = 'not started';
				        }			        
			        }
	    		
	    		
	    			$data = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	    				'total_order_taken' => $total_order_taken,
	    				'collected' => $collected,
	    				'status' => $status,	    				
	    			);
	    			$this->db->trans_start();	        
	    			$this->db->where('item_id',$item['itemid']);
	    			$this->db->where('date_current',$date);	    			
			        $this->db->update('all',$data);	
			        $this->db->trans_complete();    		
	    		
	    		}	
	    	}
 	
    	}

    
    }      
    
    function check_item_exists($item_id,$date,$table_name){

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
        $this->db->select('*');
	$this->db->from($table_name);
	$this->db->where('item_id',$item_id);
$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);

	$this->db->where('date_current',$date);				
        $packages = $this->db->get();
        return $packages->num_rows();    
    }
    
    function get_cooking_status_items($date,$table_name){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
        $this->db->select('*');
	$this->db->from($table_name);
$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
	$this->db->where('date_current',$date);				
        $packages = $this->db->get();
        return $packages->result_array();          
    }
    
    function get_started_items($date,$table_name){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
        $this->db->select('*');
	$this->db->from($table_name);
$this->db->where('br_id',$br_id); $this->db->where($table_name.'.comp_id',$comp_id);
	$this->db->where('date_current',$date);
	$this->db->where('status','started');
	$this->db->join('Item', "item_id=itemid");						
        $packages = $this->db->get();
        return $packages->result_array();          
    } 
    
    function get_completed_items($date,$table_name){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
        $this->db->select('*');
	$this->db->from($table_name);
$this->db->where('br_id',$br_id); $this->db->where($table_name.'.comp_id',$comp_id);
	$this->db->where('date_current',$date);
	$this->db->where('status','completed');
	$this->db->join('Item', "item_id=itemid");						
        $packages = $this->db->get();
        return $packages->result_array();          
    }  
    
    function get_temperatures($date,$table_name){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
        $this->db->select('*');
	$this->db->from($table_name);
$this->db->where('br_id',$br_id); $this->db->where($table_name.'.comp_id',$comp_id);
	$this->db->where('date_current',$date);
	$this->db->join('Item', "item_id=itemid");						
        $packages = $this->db->get();
        return $packages->result_array();        
    }
    
    function get_temperatures_all($date){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
    	$all = array();
    
        $this->db->select('*');
	$this->db->from('morning');
$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
	$this->db->where('date_current',$date);	
	$this->db->join('Item', "item_id=itemid");							
        $packages = $this->db->get();
        $mornings = $packages->result_array();
        
        foreach($mornings as $morning){
        	$all[] = $morning;
        }
        
        $comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
        $this->db->select('*');
	$this->db->from('evening');
$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
	$this->db->where('date_current',$date);
	$this->db->join('Item', "item_id=itemid");							
        $packages = $this->db->get();
        $evenings = $packages->result_array(); 
        
        foreach($evenings as $evening){
        	$all[] = $evening;
        }        
        
        
        $this->db->select('*');
	$this->db->from('afternoon');
$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
	$this->db->where('date_current',$date);		
	$this->db->join('Item', "item_id=itemid");						
        $packages = $this->db->get();
        $afternoons = $packages->result_array();
        
        foreach($afternoons as $afternoon){
        	$all[] = $afternoon;
        }  
        
        $this->db->select('*');
	$this->db->from('night');
$this->db->where('br_id',$br_id); $this->db->where('comp_id',$comp_id);
	$this->db->where('date_current',$date);		
	$this->db->join('Item', "item_id=itemid");						
        $packages = $this->db->get();
        $nights = $packages->result_array();
        
        foreach($nights as $night){
        	$all[] = $night;
        }          
        
        return $all;        
    }
    
      
    
    
    function get_all_started_items($date){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
    
        $this->db->select('*');
	$this->db->from('all');
$this->db->where('br_id',$br_id); $this->db->where('all.comp_id',$comp_id);
	$this->db->where('date_current',$date);
	$this->db->where('status','started');
	$this->db->join('Item', "item_id=itemid");						
        $packages = $this->db->get();
        return $packages->result_array();
		                     
  
    } 
    
    
    
    
    function get_all_completed_items($date){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
    
        $this->db->select('*');
	$this->db->from('all');
$this->db->where('br_id',$br_id); $this->db->where('all.comp_id',$comp_id);
	$this->db->where('date_current',$date);
	$this->db->where('status','completed');
	$this->db->join('Item', "item_id=itemid");						
        $packages = $this->db->get();
        return $packages->result_array();     
                
  
    }                   
              
    
    function all_packages(){

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('specialpackage');
$this->db->where('comp_id',$comp_id);
	$this->db->where('current_status','active');			
        $packages = $this->db->get();
        return $packages->result_array();
    }
    
    function get_all_menus(){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('menutype');
$this->db->where('comp_id',$comp_id);
	$this->db->where('menu_status','active');				
        $packages = $this->db->get();
        return $packages->result_array();        
    }
    
    function cooked_items(){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 
        $this->db->select('*');
	$this->db->from('cooked_stock');			
        $packages = $this->db->get();
        return $packages->result_array();
    }
    
    function add_package($array){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id'); 

	        $package = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	        	'specialp_name' => $array['name'], 
	        	'specialp_qty' => $array['qty'],
	        );
	        $this->db->set($package);
	        $this->db->insert('specialpackage');
	        $package_id = $this->db->insert_id();

 
        if($package_id){
        	//insert slug into special package table after inserting package  details on registration
	        
	        $slug = array(
	        	'slug' => $array['slug'].'_'. $package_id , 
	        );

		$this->db->where('specialp_id', $package_id);
		$this->db->update('specialpackage', $slug);		        
	        return 1;
        }    
    
    
    }
    
    function delete_package($id){
    	$data = array(
               'current_status' => 'inactive',
        );
	$this->db->where('specialp_id', $id);
	$this->db->update('specialpackage', $data);
	return 1;
    }
    
    function get_package_details($id){
        $this->db->select('*');
	$this->db->from('specialpackage');
	$this->db->where('specialp_id',$id);	
        $query = $this->db->get();
        return $query->result_array();    
    }        

    function edit_package($array){
        $package = array(
        	'specialp_name' => $array['name'],
        	'specialp_qty' => $array['qty']
        );
	$this->db->where('specialp_id', $array['id']);
	$this->db->update('specialpackage', $package);
	return 1;
 
    } 
    

    function insert_to_cook($data){
        $this->db->set($data);
        $this->db->insert('to_cook');
        return $this->db->insert_id();      
    }

    function update_cooking_status($employee_id,$status_table_name,$item_id,$status,$date,$temperatue,$additional){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

    	if($status == 'started'){
    	
    	        $this->db->select('*');
		$this->db->from('all');
		$this->db->where('date_current', $date);$this->db->where('comp_id', $comp_id);$this->db->where('br_id', $br_id);
		$this->db->where('item_id', $item_id);	
	        $query = $this->db->get();
	        $result =  $query->result_array();
    		$add = $result[0]['additional'];
    		$add = $add + $additional;
    		$start_date_time = date("Y-m-d H:i:s");
    		
	        $all_data = array('comp_id'=>$comp_id,'br_id'=> $br_id,
	        	'start_id' => $employee_id,
	        	'add_id' => $employee_id,	        	
	        	'status' => $status,
	        	'additional' => $add,
	        	'session' => $status_table_name,
	        	'start_date_time' => $start_date_time,	        	
	        );     	
	        
		$this->db->where('date_current', $date);

		$this->db->where('item_id', $item_id);	
		$this->db->update('all', $all_data);	        	
    		    		    	
    	
	        $data = array('comp_id'=>$comp_id,'br_id'=> $br_id,
	        	'start_id' => $employee_id,
	        	'add_id' => $employee_id,	        	
	        	'status' => $status,
	        	'additional' => $additional,
	        	'start_date_time' => $start_date_time,	        		        	
	        );    
	        

			        	   	
    	}else if($status == 'completed'){
    	
    	        $this->db->select('*');
		$this->db->from('all');
		$this->db->where('date_current', $date);
$this->db->where('comp_id', $comp_id);$this->db->where('br_id', $br_id);
		$this->db->where('item_id', $item_id);	
	        $query = $this->db->get();
	        $result =  $query->result_array();
    		$additional = $result[0]['additional'];
    		$total_order_taken = $result[0]['total_order_taken'];
    		$cooked_stock = $result[0]['cooked_stock'];
    		    		
    		$cooked_stock = ($cooked_stock) + $additional;
    		$end_date_time = date("Y-m-d H:i:s");
    		
	        $all_data = array('comp_id'=>$comp_id,'br_id'=> $br_id,
	        	'end_id' => $employee_id,
	        	'status' => $status,
	        	'temperatue' => $temperatue,
	        	'temp_id' => $employee_id,
	        	'cooked_stock'	=> $cooked_stock,
	        	'additional' => 0,
	        	'end_date_time' => $end_date_time,        		        	
	        );  
	        
		$this->db->where('date_current', $date);
		$this->db->where('item_id', $item_id);	
		$this->db->update('all', $all_data);	           	
    	
    	
    	
    	        $this->db->select('*');
		$this->db->from($status_table_name);
		$this->db->where('date_current', $date);
$this->db->where('comp_id', $comp_id);$this->db->where('br_id', $br_id);
		$this->db->where('item_id', $item_id);	
	        $query = $this->db->get();
	        $result =  $query->result_array();
    		$additional = $result[0]['additional'];
    		$total_order_taken = $result[0]['total_order_taken'];
    		$cooked_stock = $result[0]['cooked_stock'];
    		    		
    		$cooked_stock = ($cooked_stock) + $additional;
    		
	        $data = array('comp_id'=>$comp_id,'br_id'=> $br_id,
	        	'end_id' => $employee_id,
	        	'status' => $status,
	        	'temperatue' => $temperatue,
	        	'temp_id' => $employee_id,
	        	'cooked_stock'	=> $cooked_stock,
	        	'additional' => 0, 
	        	'end_date_time' => $end_date_time,	        	       		        	
	        ); 


	            	    	
    	}else if($status == 'additional'){
	        $data = array(
	        	'add_id' => $employee_id,
	        	'additional' => $additional,
	        );     	    	
    	}else{
	        $data = array(
	        	'temp_id' => $employee_id,
	        	'temperatue' => $temperatue,
	        );     	
    	}

	    	

	$this->db->where('date_current', $date);
	$this->db->where('item_id', $item_id);	
	if($this->db->update($status_table_name, $data)){
		return 1;
	}else{
		return 0;	
	}
   
    
    }
    
    
    function get_item_ingredients($item_id){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('item_ingredient');
$this->db->where('comp_id', $comp_id);$this->db->where('br_id', $br_id);
	$this->db->where('item_id',$item_id);			
        $packages = $this->db->get();
        return $packages->result_array();         
    }	
    
    function raw_stock($ingredients,$additional){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
    	foreach($ingredients as $ingredient){
	        $this->db->select('*');
		$this->db->from('raw_stock');
		$this->db->where('ingredient_id',$ingredient['ing_id']);	
$this->db->where('comp_id', $comp_id);$this->db->where('br_id', $br_id);		
	        $query = $this->db->get();
	        $result = $query->result_array();
	        if($result){
		        $current_stock = $result[0]['current_stock'];
		        $item_qty = $ingredient['item_qty'];		        
		        if($item_qty != 0){
		         $num = ($additional / $item_qty);
                        }else{
                         $num = $additional;
                        }
		        $ing_qty =  $ingredient['ing_qty'];
		        $ing_unit = $ingredient['ing_unit']; 
		        $tot_ing = $num * $ing_qty;
			//assume items in stock stored in units like (KG,L etc)
		        if($ing_unit == 'G'){
		        	$tot_ing = ($tot_ing/1000);
		        }else if($ing_unit == 'MG'){
		        	$tot_ing = ($tot_ing/1000000);
		        }	
		        $balance = $current_stock - $tot_ing;	                
		        $data = array(
		        	'current_stock' => $balance,	        
		        );     	
			$this->db->where('ingredient_id', $ingredient['ing_id']);
			$this->db->update('raw_stock', $data);	        
	        
	        }

            	    	
    	}            
    }


	 
		
	
	


		
}