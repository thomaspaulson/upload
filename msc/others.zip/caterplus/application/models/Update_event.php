<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Update_event extends CI_Model {

public $comp_id;
public $br_id; 
	function __construct(){
		parent::__construct();    
$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');  
 $this->load->helper('string');  
	}
	
function update_event_cust($data='',$event_id=''){

$this->db->where('event_id',$event_id);
$this->db->update('event',$data);

}


function update_event_catertypes($data='',$event_id='')
{
$this->db->where('event_id',$event_id);
$this->db->update('event',$data);
}





}