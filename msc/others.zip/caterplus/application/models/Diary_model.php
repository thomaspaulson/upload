<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Diary_model extends CI_Model {
	
	
	public $comp_id;
public $br_id; 
	function __construct(){
		parent::__construct();    
$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');  
 $this->load->helper('string');  
	}

function getallevents($comp_id='',$br_id='')
{
$this->db->order_by('event.event_id','desc');

$this->db->where('event_branch.branch_id',$br_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->select("*");
$this->db->from("event_branch");
$this->db->join("event","event.event_id=event_branch.event_id");
$this->db->join("eventguest","eventguest.event_id=event.event_id");
$this->db->join("customer","customer.customerId=event.cust_id");
$query=$this->db->get();
return $query->result_array();


}


function getenquiry_events($comp_id='',$br_id='')
{
$this->db->order_by('event.event_id','desc');
$this->db->where(array('event_enq_type'=>'Enquiry'));

$this->db->where('event_branch.branch_id',$br_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->select("*");
$this->db->from("event_branch");
$this->db->join("event","event.event_id=event_branch.event_id");
$this->db->join("eventguest","eventguest.event_id=event.event_id");
$this->db->join("customer","customer.customerId=event.cust_id");
$query=$this->db->get();
return $query->result_array();


}

function getprovincial_events($comp_id='',$br_id='')
{
$this->db->order_by('event.event_id','desc');
$this->db->where(array('event_enq_type'=>'Provisional'));

$this->db->where('event_branch.branch_id',$br_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->select("*");
$this->db->from("event_branch");
$this->db->join("event","event.event_id=event_branch.event_id");
$this->db->join("eventguest","eventguest.event_id=event.event_id");
$this->db->join("customer","customer.customerId=event.cust_id");
$query=$this->db->get();
return $query->result_array();


}

function getcompleted_events($comp_id='',$br_id='')
{
$this->db->order_by('event.event_id','desc');
$this->db->where(array('event_enq_type'=>'Completed'));

$this->db->where('event_branch.branch_id',$br_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->select("*");
$this->db->from("event_branch");
$this->db->join("event","event.event_id=event_branch.event_id");
$this->db->join("eventguest","eventguest.event_id=event.event_id");
$this->db->join("customer","customer.customerId=event.cust_id");
$query=$this->db->get();
return $query->result_array();


}

function getconfirmed_events($comp_id='',$br_id='')
{
$this->db->order_by('event.event_id','desc');
$this->db->where(array('event_enq_type'=>'Confirm'));

$this->db->where('event_branch.branch_id',$br_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->select("*");
$this->db->from("event_branch");
$this->db->join("event","event.event_id=event_branch.event_id");
$this->db->join("eventguest","eventguest.event_id=event.event_id");
$this->db->join("customer","customer.customerId=event.cust_id");
$query=$this->db->get();
return $query->result_array();


}
}