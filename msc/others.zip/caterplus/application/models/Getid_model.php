<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Getid_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
       
    }
     protected static $userrole_code; 
     protected static $company_name;
        protected static $userrolename; 
        protected static $user_roleid;
         protected static $emp_compid;
        protected static $emp_br_name; 
        protected static $branchlist; 

function get_id($table_name,$primary_key,$column_name,$column_value){
        $this->db->select($primary_key);
	$this->db->from($table_name);
	$this->db->where($column_name,$column_value);	
        $query = $this->db->get();
        $result = $query->result_array();
        if(($result)){
        	return $result[0][$primary_key];
        }  
    }


function get_comp_logo($comp_id='')
{
$this->db->select('comp_logo');
	$this->db->from('pdt_company');
	$this->db->where('comp_id',$comp_id);	
        $query = $this->db->get();
        $result = $query->result_array();
        if(($result)){
        	return $comp_logo=$result[0]['comp_logo'];
        }  


}



function get_roleid($rolename='')
{
$this->db->select('emprole_id');
	$this->db->from('pdt_mast_emprole');
	$this->db->where('emprole_name',$rolename);	
        $query = $this->db->get();
        $result = $query->result_array();
        if(($result)){
        	return $user_roleid=$result[0]['emprole_id'];
        }  


}
function get_rolecode($rolename='')
{
$this->db->select('emprole_code');
	$this->db->from('pdt_mast_emprole');
	$this->db->where('emprole_name',$rolename);	
        $query = $this->db->get();
        $result = $query->result_array();
        if(($result)){
        	return $userrole_code=$result[0]['emprole_code'];
        }   
}


function get_rolename($empid=''){
        $this->db->select('roleid');
	$this->db->from('employee');
	$this->db->where('employeeid',$empid);	
	$query = $this->db->get();$result = $query->result_array();  
	foreach($result as $rr)
	{ $roleid=$rr['roleid'];}
	
	$this->db->select('rolename');
	$this->db->from('staffrole');
	$this->db->where('roleid',$roleid);	
        $query2 = $this->db->get();
        $result2 = $query2->result_array(); foreach($result2 as $rr2)
	{ $rolename=$rr2['rolename'];} return $userrolename=$rolename;
			
}

function get_rolenameold($empid=''){
        $this->db->select('c_emprole_id');
	$this->db->from('pdt_mast_emprolereleation');
	$this->db->where('emp_id',$empid);	
	$query = $this->db->get();$result = $query->result_array();  
	foreach($result as $rr)
	{ $roleid=$rr['c_emprole_id'];}
	
	$this->db->select('emprole_name');
	$this->db->from('pdt_mast_emprole');
	$this->db->where('emprole_id',$roleid);	
        $query2 = $this->db->get();
        $result2 = $query2->result_array(); foreach($result2 as $rr2)
	{ $rolename=$rr2['emprole_name'];} return $userrolename=$rolename;
			
}


function get_compid($empid='')
{
$this->db->select('comp_id');
	$this->db->from('employee');
	$this->db->where('employeeid',$empid);	
        $query = $this->db->get();
        $result = $query->result_array();
          if($result){
        	return $emp_compid=$result[0]['comp_id'];
        }  
}
function get_compname($comp_id='')
{
$this->db->select('*');
	$this->db->from('pdt_company');
	$this->db->where('comp_id',$comp_id);	
        $query = $this->db->get();
        $result = $query->result_array();
          if($result){
        	return $company_name=$result[0]['comp_name'];
        }  
}

function get_branchname($br_id='')
{
$this->db->select('br_name');
	$this->db->from('pdt_branch');
	$this->db->where('br_id',$br_id);	
        $query = $this->db->get();
        $result = $query->result_array(); 
        if(($result)){
        	return $emp_br_name=$result[0]['br_name'];
        }   
}


function get_branchlist($comp_id='')
{
$this->db->select('*');
	$this->db->from('pdt_branch');
	$this->db->where('comp_id',$comp_id);	
        $query = $this->db->get();
        $result = $query->result_array(); 
        if(($result)){
        	return $branchlist=$result;
        }   
}

function get_branchlist_active($comp_id='')
{
$this->db->select('*');
	$this->db->from('pdt_branch');
	$this->db->where('comp_id',$comp_id);	$this->db->where('br_status','active');	
        $query = $this->db->get();
        $result = $query->result_array(); 
        if(($result)){
        	return $branchlist=$result;
        }   
}



function pin_check($pin=''){    	
        $this->db->select('*');
	$this->db->from('pdt_employeelogin');
	$this->db->where("emp_PIN", $pin);		
        $employees = $this->db->get();
        if($employees->num_rows() > 0){
		return 1;
        }else{
        	return 0;
        }
    
    }



function getcurrency($comp_id=''){ 
   
$this->db->select('currrency_symbol');
	$this->db->from('pdt_currency_list');
	$this->db->where("comp_currency.comp_id", $comp_id);	
	$this->db->join("comp_currency","comp_currency.currencylist_id=pdt_currency_list.currencylist_id");	
        $currency= $this->db->get(); $currency_array=$currency->result_array();
        if($currency->num_rows() > 0){
        foreach($currency_array as $curr)
        {       $symbol= $curr['currrency_symbol'];       
        }
		return $symbol;
        }else{
        	return "£";
        }


}


}