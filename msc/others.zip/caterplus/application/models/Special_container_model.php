<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Special_container_model extends CI_Model {
	function __construct(){
        	parent::__construct();        
	}

	function  select_container()
	{
		$this->db->select('*');
		$this->db->from('special_container');
		$employees = $this->db->get();
		return $employees->result_array();
	}

	function  insert_container($array)
	{	$comp_id=$this->session->userdata('comp_id');
                
		$name=$this->input->post('cname');
		$desc=$this->input->post('cdesc');
		$price=$this->input->post('cprice');
		$container= array('comp_id' => $comp_id, 
		        	'special_cname' => $name, 
	        	'special_cprice' => $price,
	        	'special_cdesc' => $desc,
	        	
	        );
	        $this->db->set($container);
	        $this->db->insert('special_container');
	        $container_id= $this->db->insert_id();
	        
		$slug = random_slug(30);
		$array=array('slug' => $slug);
	 	if($container_id){
	        	//insert slug into container table after inserting
		        
		        $slug = array(
		        	'special_cslug' => $array['slug'].'_'. $container_id, 
		        );
				
			$this->db->where('special_cid', $container_id);
			$this->db->update('special_container', $slug);		     
		}
	}

	function  delete_container($slug=''){
		$this->db->query("update special_container set special_cstatus='inactive' where special_cslug='$slug'");
	}
	
	function  activate_container($slug=''){
		$this->db->query("update special_container set special_cstatus='active' where special_cslug='$slug'");
	}	
	
	
	function get_container_details($id){
		$this->db->select('*');
		$this->db->from('special_container');
		$this->db->where('special_cid',$id);	
		$query = $this->db->get();
		return $query->result_array();    
	}	
	
	function edit_container($array){
	        $container = array(
	        	'special_cname' => $array['name'],
	        	'special_cprice' => $array['price'],  
	        	'special_cdesc' => $array['desc'],
	        );
	
		$this->db->where('special_cid', $array['id']);
		$this->db->update('special_container', $container);
		return 1;
	
	} 	



}
	