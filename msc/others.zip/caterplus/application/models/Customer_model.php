<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer_model extends CI_Model {

	function __construct(){
		parent::__construct();        
	}
	
	function search_items($search_item){
		$terms = explode(' ', $search_item);	
		foreach($terms as $term){
		  $this->db->or_like('customername', $term);
		}
		return $this->db->get('customer')->result_array();
	
	}
	
	function search_order_by_order_id($search_item){
		$terms = explode(' ', $search_item);	
		$this->db->select('*');
		$this->db->from('specialorder');
		$this->db->join('customer','customer.customerId=specialorder.customer_id');
		foreach($terms as $term){
		  $this->db->or_like('orderid', $term);
		}		
		return $this->db->get()->result_array();	
	}
	
	function one_order_by_order_id($search_item){	
		$this->db->select('*');
		$this->db->from('specialorder');
		$this->db->join('customer','customer.customerId=specialorder.customer_id');
		$this->db->like('orderid', $search_item);	
		return $this->db->get()->result_array();	
	}		
	
	function search_items_by_number($search_item){
		$terms = explode(' ', $search_item);	
		foreach($terms as $term){
		  $this->db->or_like('customermobile1', $term);
		}
		return $this->db->get('customer')->result_array();
	
	}
	
	function one_search_item($search_item){	
		$this->db->like('customername', $search_item);		
		return $this->db->get('customer')->result_array();
	
	}
	
	function one_search_item_by_number($search_item){	
		$this->db->like('customermobile1', $search_item);		
		return $this->db->get('customer')->result_array();
	
	}		
  

}