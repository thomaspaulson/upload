<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ordercollection_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
    }
    
    function select_order($orderid){
 $query=$this->db->query("select * from specialorder spo,specialorderquantity spoq,customer cu,Item itm where (spo.orderid=spoq.orderid) and  (spoq.itemid=itm.itemid) and  (spo.orderid='$orderid') and (spo.customer_id=cu.customerId)");
        return $query->result_array();
    }
    

function select_order_uncollected($orderid){
 $query=$this->db->query("select * from specialorder spo,specialorderquantity spoq,customer cu,Item itm where (spo.orderid=spoq.orderid) and  (spoq.itemid=itm.itemid) and  (spo.orderid='$orderid') and (spo.customer_id=cu.customerId) and (spo.collection_status='pending')");
        return $query->result_array();
    }

 function select_orderedcontainer($orderid){        
$query=$this->db->query("select * from special_container spc,specialorder_container soc,specialorder spo,customer cu where (soc.order_id='$orderid')  and (soc.container_id=spc.special_cid) and (spo.customer_id=cu.customerId) and (spo.orderid='$orderid')");
return $query->result_array();
}

function select_orderedcontainer_uncollected($orderid){        
$query=$this->db->query("select * from special_container spc,specialorder_container soc,specialorder spo,customer cu where (soc.order_id='$orderid')  and (soc.container_id=spc.special_cid) and (spo.customer_id=cu.customerId) and (spo.orderid='$orderid') and (spo.collection_status='pending')");
return $query->result_array();
}


 
function select_orderforcollection(){
 $query=$this->db->query("select * from specialorder spo,customer cu where (spo.customer_id=cu.customerId) and (spo.collection_status='pending') and (spo.totalamount>0)");
        return $query->result_array();
    }
    

function getorderforcollection(){

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

 $query=$this->db->query("select * from specialorder spo,customer cu where (spo.customer_id=cu.customerId) and (spo.collection_status='pending') and (spo.payment_status='paid ') and (spo.totalamount>0) and  (spo.comp_id='$comp_id') and (spo.br_id='$br_id')");
        return $query->result_array();
    }



}