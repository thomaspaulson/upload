<?php
class Web_data_model extends CI_Model {
    function __construct() {
        parent::__construct();
        $this->load->database();
    }

    public function insert($table, $data) {
        $query = $this->db->insert($table, $data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }
    public function view_all($table) {
        $this->db->select('*');
        $this->db->from($table);
        $view = $this->db->get();
        if ($view->num_rows() > 0) {
            return $view->result_array();
        }
    }
    public function delete($field,$value,$table) {
        $this->db->where($field, $value);
        $this->db->delete($table);
    }

     public function view_all_condition($table, $field, $value) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $value);
        $view = $this->db->get();

        if ($view->num_rows() > 0) {
            return $view->result_array();
        }
    }
}