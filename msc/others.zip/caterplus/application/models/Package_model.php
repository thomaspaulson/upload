<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Package_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
    }
    
    function all_packages(){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('specialpackage');	
$this->db->where('comp_id',$comp_id);		
        $packages = $this->db->get();
        return $packages->result_array();
    }
    
    function add_package($array){
	        $package = array('comp_id' => $array['comp_id'],
	        	'specialp_name' => $array['name'], 
	        	'specialp_qty' => $array['qty'],
	        );
	        $this->db->set($package);
	        $this->db->insert('specialpackage');
	        $package_id = $this->db->insert_id();

 
        if($package_id){
        	//insert slug into special package table after inserting package  details on registration
	        
	        $slug = array(
	        	'slug' => $array['slug'].'_'. $package_id , 
	        );

		$this->db->where('specialp_id', $package_id);
		$this->db->update('specialpackage', $slug);		        
	        return 1;
        }    
    
    
    }
    
    function delete_package($id){
    	$data = array(
               'current_status' => 'inactive',
        );
	$this->db->where('specialp_id', $id);
	$this->db->update('specialpackage', $data);
	return 1;
    }
    
    function activate_package($id){
    	$data = array(
               'current_status' => 'active',
        );
	$this->db->where('specialp_id', $id);
	$this->db->update('specialpackage', $data);
	return 1;
    }    
    
    function get_package_details($id){
        $this->db->select('*');
	$this->db->from('specialpackage');
	$this->db->where('specialp_id',$id);	
        $query = $this->db->get();
        return $query->result_array();    
    }        

    function edit_package($array){
	        $package = array(
	        	'specialp_name' => $array['name'],
	        	'specialp_qty' => $array['qty']
	        );
		$this->db->where('specialp_id', $array['id']);
		$this->db->update('specialpackage', $package);
		return 1;
 
    } 


	 
		
	
	


		
}