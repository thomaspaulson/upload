<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Supplier_model extends CI_Model {
    
    function __construct()
    {
        parent::__construct();
        
    }


    function select_supliers(){
        $this->db->select('*');
	$this->db->from('supplier');
	$this->db->where('supplier_current_status','active');
	$this->db->order_by("supplier_name", "asc");		
        $supplier = $this->db->get();
        return $supplier->result_array();
    }


    
    function add_supplier($array){
	        $supplier = array(
	        	'supplier_name' => $array['name'], 
	        	'supplier_address' => $array['address'],
	        	'phn_ext' => $array['phn_ext'],
	        	'supplier_phone'=>$array['phone'],
                        'mobile1'=>$array['mobile1'],
                        'mobile2'=>$array['mobile2'],
	        	'supplier_email' => $array['email'],
	        );
	        $this->db->set($supplier);
	        $this->db->insert('supplier');
	        $supplier_id = $this->db->insert_id();

 
        if($supplier_id){
        	//insert slug into supplier table after inserting supplier details on registration
	        
	        $slug = array(
	        	'supplier_slug' => $array['slug'].'_'. $supplier_id , 
	        );

		$this->db->where('supplier_id', $supplier_id);
		$this->db->update('supplier', $slug);
	        return 1;
        }
    }
    
    function delete_supplier($id){
    	$data = array(
               'supplier_current_status' => 'inactive',
        );
	$this->db->where('supplier_id', $id);
	$this->db->update('supplier', $data);
	return 1;
    }
    
    function edit_supplier($array){
	        $supplier = array(
	        	'supplier_name' => $array['name'],
	        	'supplier_address' => $array['address'],
	        	'phn_ext'=>$array['phn_ext'],
                        'supplier_phone'=>$array['phone'],
                        'mobile1'=>$array['mobile1'],
                        'mobile2'=>$array['mobile2'],
	        	'supplier_email' => $array['email'],
	        );

		$this->db->where('supplier_id', $array['id']);
		$this->db->update('supplier', $supplier);
		return 1;
 
    }    

    function get_supplier_details($id){
        $this->db->select('*');
	$this->db->from('supplier');
	$this->db->where('supplier_id',$id);	
        $supplier= $this->db->get();
        return $supplier->result_array();    
    }    
         
 function getallcategories_allitems(){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

        $this->db->select('*');
	$this->db->from('Item');
$this->db->where('comp_id',$comp_id);
	$this->db->order_by("itemname", "asc");
	$this->db->where('included_specialevent', "yes");
	$this->db->where('item_status', "active");
        $query= $this->db->get();
        return $query->result_array();
    }    

		
}