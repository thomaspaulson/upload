<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specialitem_model extends CI_Model {

	function __construct(){
		parent::__construct();        
	}

	function get_all_items(){ 
		return $this->db->get('Item')->result_array();
	}
	
	function get_all_packages(){ 
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
		$this->db->where('current_status','active');
		$this->db->order_by('specialp_name','asc');
		return $this->db->get('specialpackage')->result_array();
	}
	
	
	function get_all_containers(){ 
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
		$this->db->where('special_cstatus','active');
		$this->db->order_by('special_cname','asc');
		return $this->db->get('special_container')->result_array();
	}
	
	function get_all_menu(){ 
		return $this->db->get('menutype')->result_array();
	}

//for order page

function get_all_menu_active(){ 
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
$this->db->where('menu_status', 'active'); 
return $this->db->get('menutype')->result_array();
	}

function get_all_items_active(){ 

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id', $comp_id); 


$this->db->where('item_status', 'active'); 

		return $this->db->get('Item')->result_array();
	}
function get_all_packages_active(){ 

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id', $comp_id); 

$this->db->where('current_status','active');
		$this->db->order_by('specialp_name','asc');
		return $this->db->get('specialpackage')->result_array();
	}

function get_all_containers_active(){ 
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id', $comp_id); 

		$this->db->where('special_cstatus','active');
		$this->db->order_by('special_cname','asc');
		return $this->db->get('special_container')->result_array();
	}


//for order page

	public function select_item($id=''){
		//$id is menu type id
		$menu_ids = array();
		$items_array = array();
		
		
		//first select all the itesms from item table, navigate through it and explode mentu type and check if it contains the //menutype id then //put that entire row in an array $items_array

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
		$this->db->select('*');

		$this->db->from('Item'); $this->db->where('item_status', 'active'); 
		$query = $this->db->get();
		$items =  $query->result_array();
		foreach($items as $item){
			$ids = explode(',',$item['menutype']);
			if(in_array($id,$ids)){
				$items_array[] = $item;
			}
		}	
		return $items_array;
	}
	
	public function select_item_unit($id=''){
		//$id is item id
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
		$this->db->select('*');
		$this->db->from('Item');
		$this->db->where('itemid',$id);
		$query = $this->db->get();
		$items =  $query->result_array();
		if($items){
			return $items[0]['itemunits'];		
		}else{
			return 'kg';	
		}	
	}
	
	public function insert_order($data){
		$this->db->insert('specialorder',$data);
		return $this->db->insert_id();
	}
	
	function get_item_base_price($item_id){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
		$this->db->select('*');
		$this->db->from('Item');
		$this->db->where('itemid',$item_id);
		$query = $this->db->get();
		$items =  $query->result_array();
		if($items){
			return $items[0]['itemprice'];		
		}else{
			return 0;	
		}	
	
	}
	
	function insert_specialorderquantity($data){
		$this->db->insert('specialorderquantity',$data);
		return $this->db->insert_id();	
	}
	
	function get_container_base_price($container_id){
		$this->db->where('special_cid',$container_id);
		$result = $this->db->get('special_container')->result_array();
		return $result[0]['special_cprice'];		
	}
	
	function insert_specialorder_container($data){
		$this->db->insert('specialorder_container',$data);
		return $this->db->insert_id();		
	}
	
	function save_customer($data){
		$this->db->insert('customer',$data);
		return $this->db->insert_id();		
	}
	
	function update_order_table($data,$order_id){
		$this->db->where('orderid', $order_id);	
		$this->db->update('specialorder',$data);
	}
function save_order_table($datas){

		$this->db->insert('specialorder',$datas);
$order_id=$this->db->insert_id();
		

//order slug
$order_slug=random_slug(5);
$order_slug=$order_slug."-".$order_id;
$order_slug=$order_slug.random_slug(5);
//order slug ends
$data=array('orderslug'=>$order_slug);
$this->db->where('orderid', $order_id);	
$this->db->update('specialorder',$data);



return $order_slug;

	}
	
	function get_unpaid_orders(){
		$this->output->enable_profiler();
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
$this->db->where('br_id',$br_id);
		$this->db->where('payment_status','unpaid');
		return 	$this->db->get('specialorder')->result_array();
	}
	
}