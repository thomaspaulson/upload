<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Specialorder_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
    }
    
    

	  	//created for updation for order edit 
 function select_order($orderid){
 $query=$this->db->query("select * from specialorder spo,specialorderquantity spoq,customer cu,Item itm where (spo.orderid=spoq.orderid) and  (spoq.itemid=itm.itemid) and  (spo.orderid='$orderid') and (spo.customer_id=cu.customerId) and (spo.collection_status='pending')");
        return $query->result_array();
    }
    

 function select_orderedcontainer($orderid){        
$query=$this->db->query("select * from special_container spc,specialorder_container soc,specialorder spo,customer cu where (soc.order_id='$orderid')  and (soc.container_id=spc.special_cid) and (spo.customer_id=cu.customerId) and (spo.orderid='$orderid') and (spo.collection_status='pending')");
return $query->result_array();
}

//created for updation for order edit ends



function ordernum_timeslot($deliverydate='',$timeslot='')
{ 
$deliverydate= date("Y-m-d", strtotime($deliverydate));

list($timefrom, $timeto) = explode('-', $timeslot);
//$query=$this->db->query("select * from specialorder where (orderstatus='confirmed') and (deliverytime >= CAST('$timefrom' AS time)) and (deliverytime < CAST('$timeto' AS time)) and (deliverydate='$deliverydate')"); 

$query = $this->db->query("select * from specialorder where (orderstatus='confirmed') and (deliverytime >= CAST('$timefrom' AS time)) and (deliverytime < CAST('$timeto' AS time))");// and (date(ordereddate)='$deliverydate')");
$nums=$query->num_rows();
return $nums;
}



function demos()
{
return "sdfs";}






		
}