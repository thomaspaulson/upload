<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_master_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
   
//       $this->load->helper('string');  
    }



function add_event_type($data=''){    
extract($data); 
$comp_id=$this->session->userdata('comp_id');
$insertvalues=array( 'eventtypeb_name' =>$this->input->post('event_name'),
               'comp_id' =>$comp_id,
               'eventtypeb_color' =>'#'.$this->input->post('event_color'),
              );
 

$this->db->where('comp_id', $comp_id);
$this->db->insert('eventtype_comp', $insertvalues);


    }
    
    
function update_event_type($data=''){    
extract($data); 
$comp_id=$this->session->userdata('comp_id');
$insertvalues=array( 'eventstb_name' =>$this->input->post('subtype_name'),
               'comp_id' =>$comp_id,
               'eventtypeb_id' =>$this->input->post('type_id'),
              );
 
$this->db->insert('eventsubtype_branch', $insertvalues);

    }    
    
    
     
function add_ing($data=''){    
  $comp_id=$this->session->userdata('comp_id');
$insertvalues=array( 'ing_name' =>$this->input->post('ingredientname'),
               'comp_id' =>$comp_id,
               'ing_unit' =>$this->input->post('ingredientqtytype'),
               'ing_price' =>$this->input->post('ingredientprice'),
               'ing_reorder' =>$this->input->post('reorderlevel'),
               'ing_desc' =>$this->input->post('ingredientdescription'),
               'curr_stock' =>$this->input->post('currquantity'),
              );
 
$this->db->insert('ingredient', $insertvalues);

    }       
    



function edit_subeventtype($data=''){    
extract($data); 
$data2= array(
               'eventstb_id' =>$this->input->post('eventstb_id'),
               'subtype_name' =>$this->input->post('subtype_name'),        ); 
 
$this->db->insert('eventsubtype_branch', $data2);

    }    



function create_package($data=''){    
extract($data); 
  $comp_id=$this->session->userdata('comp_id');
$data2= array(
               'pkg_name' =>$this->input->post('pkg_name'),
               'pkg_qty' =>$this->input->post('pkg_qty'),  'comp_id' =>$comp_id,         ); 
 
$this->db->insert('package', $data2);

    }    



function create_containers($data=''){    
extract($data); 
  $comp_id=$this->session->userdata('comp_id');
$data2= array(
               'pdt_con_name' =>$this->input->post('cont_name'),
               'pdt_con_price' =>$this->input->post('cont_price'),  'comp_id' =>$comp_id,         ); 
 
$this->db->insert('pdt_containers', $data2);

    } 


function create_menutype($data=''){    
extract($data); 
  $comp_id=$this->session->userdata('comp_id');
$data2= array(
               'com_tmenu_name' =>$this->input->post('type_name'),
              'comp_id' =>$comp_id,         ); 
 
$this->db->insert('menutype_company', $data2);

    } 



    
     
function add_staff($data=''){   
  
$this->db->insert('pdt_employee', $data);
return $lastid=$this->db->insert_id();

    }       
    


function add_stafflogin($data=''){   
  
$this->db->insert('pdt_employeelogin', $data);

    }       
    

function item_ing($data=''){   
  
$this->db->insert('item_ing', $data);

    }

function remove_ing($ing_id=''){   //logical disable  
$comp_id=$this->session->userdata('comp_id');
$data = array('ing_status' => 'inactive',);
$this->db->where('ing_id', $ing_id);
$this->db->where('comp_id', $comp_id);
$this->db->update('ingredient', $data); 

    }

function remove_item($item_id=''){   //logical disable  
$comp_id=$this->session->userdata('comp_id');
$data = array('item_status' => 'inactive',);
$this->db->where('item_id', $item_id);
$this->db->where('comp_id', $comp_id);
$this->db->update('item', $data); 

    }





function remove_container($con_id=''){   //logical disable  
$comp_id=$this->session->userdata('comp_id');
$data = array('pdt_con_status' => 'inactive',);
$this->db->where('pdt_conid', $con_id);
$this->db->where('comp_id', $comp_id);
$this->db->update('pdt_containers', $data); 

    }






function remove_packages($pkid=''){   //logical disable  
$comp_id=$this->session->userdata('comp_id');
$data = array('pkg_status' => 'inactive',);
$this->db->where('pkg_id', $pkid);
$this->db->where('comp_id', $comp_id);
$this->db->update('package', $data); 

    }

function remove_menutype($mid=''){   // logical disable
$comp_id=$this->session->userdata('comp_id');
$data = array('com_tmenu_status' => 'inactive',);
$this->db->where('com_tmenu_id', $mid);
$this->db->where('comp_id', $comp_id);
$this->db->update('menutype_company', $data); 

    }


function insert_staffrole($data=''){   
  extract($data);
$comp_id=$this->session->userdata('comp_id');
$c_emprole_code=$comp_id.random_string('alnum',10); 


$insertvalues=array( 'role_id' =>$this->input->post('staffrole'),
               'subrole_name' =>$this->input->post('sub_emp_role'),
              'comp_id' =>$comp_id,
              );
 


$this->db->insert('role_subrole', $insertvalues);


    }       
    


function remove_staffrole(){   
$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $comp_id);
$this->db->where_not_in('c_emprole_name','admin');
$query= $this->db->get('employee_role');
return $query->result_array();
}


function update_staffrole($data=''){   

extract($data);
$comp_id=$this->session->userdata('comp_id');
$c_emprole_code=$comp_id.random_string('alnum',10); 
$sbid=$this->input->post('subrole_id');

$insertvalues=array( 'role_id' =>$this->input->post('staffrole'),
               'subrole_name' =>$this->input->post('sub_emp_role'),
              'comp_id' =>$comp_id,
              );
 


$this->db->where('role_subrole_id', $sbid);
$this->db->update('role_subrole', $insertvalues); 




}



function change_status_staff($role_subrole_id='')
{
$query = $this->db->get_where('role_subrole', array('role_subrole_id' => $role_subrole_id));
$array = $query->result_array();
$status=($array[0]['subrole_status']=="active")?"inactive":"active"; 


$this->db->update('role_subrole', array(
'subrole_status' => $status
), array('role_subrole_id' => $role_subrole_id));
	


}



function list_pots()
{
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

$this->db->where('comp_id', $comp_id);
$this->db->where('br_id', $br_id);
$query= $this->db->get('pots_pans');

return $query->result_array();

}



function list_potsby_id($id='')
{
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

$this->db->where('comp_id', $comp_id);
$this->db->where('br_id', $br_id);
$this->db->where('pp_id', $id);
$query= $this->db->get('pots_pans');

return $query->result_array();

}

function insert_pots($data='')
{
 extract($data);
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');


$insertvalues=array( 'pp_name' =>$this->input->post('pot_name'),
               'pp_deposit' =>$this->input->post('pot_deposit'),
'pp_size ' =>$this->input->post('pot_size'),
'pp_price ' =>$this->input->post('pot_price'),
'pp_nos' =>$this->input->post('pot_stock'),

              'comp_id' =>$comp_id,'br_id' =>$br_id,
              );
 


$this->db->insert('pots_pans', $insertvalues);

}



function update_pots($data=''){   

 extract($data);
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');


$insertvalues=array( 'pp_name' =>$this->input->post('pot_name'),
               'pp_deposit' =>$this->input->post('pot_deposit'),
'pp_size ' =>$this->input->post('pot_size'),
'pp_price ' =>$this->input->post('pot_price'),
'pp_nos' =>$this->input->post('pot_stock'),

              'comp_id' =>$comp_id,'br_id' =>$br_id,
              );
 
$id=$this->input->post('pp_id');
$this->db->where('pp_id', $id);

$this->db->update('pots_pans', $insertvalues);
}












function changestat_pots($pp_id='')
{
$query = $this->db->get_where('pots_pans', array('pp_id' => $pp_id));
$array = $query->result_array();
$status=($array[0]['pp_status']=="active")?"inactive":"active"; 


$this->db->update('pots_pans', array(
'pp_status' => $status
), array('pp_id' => $pp_id));
	


}




}