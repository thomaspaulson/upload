<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Adminprofile_model  extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }



function get_admindetail($emp_id=''){   
   
$this->db->where('emp_id', $emp_id);
$query=$this->db->get('pdt_employeelogin');
return $result=$query->result_array();
    }

function update_profile($data){   
    extract($data);
$emp_id=$this->session->userdata('emp_id');
$this->db->where('emp_id', $emp_id);
$this->db->update('pdt_employeelogin', $data);
    }
}