<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Get_event_details extends CI_Model {

public $comp_id;
public $br_id; 
	function __construct(){
		parent::__construct();    
$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');  
 $this->load->helper('string');  
	}
	
function event_customer($event_id='')
{
$this->db->select("*");
$this->db->from("customer");
$this->db->where('event.event_id',$event_id);
$this->db->join("event","customer.customerId=event.cust_id");
$query=$this->db->get();
return $query->result_array();
}




function event_details($event_id='')
{
$this->db->select("*");
$this->db->from("event_details");
$this->db->where('event_id',$event_id);
$query=$this->db->get();
return $query->result_array();
}

function eventguest($event_id='')
{
$this->db->select("*");
$this->db->from("eventguest");
$this->db->where('event_id',$event_id);
$query=$this->db->get();
return $query->result_array();
}


function event_chefnote($event_id='')
{
$this->db->select("*");
$this->db->from("event_chefnote");
$this->db->where('event_chefnote.event_id',$event_id);
$this->db->join("employee","employee.employeeid=event_chefnote.chef_id"); 
$this->db->join("staffrole","staffrole.roleid=employee.roleid");
$this->db->where("staffrole.role_code","xxx333");
$query=$this->db->get();
return $query->result_array();
}

function event_commonnote($event_id='')
{
$this->db->select("*");
$this->db->from("event_commonnote");
$this->db->where("event_commonnote.event_id",$event_id);
$query=$this->db->get();
return $query->result_array();
}


function event_manager_note($event_id='')
{
$this->db->select("*");
$this->db->from("event_manager_note");
$this->db->where('event_manager_note.event_id',$event_id);
$this->db->join("employee","employee.employeeid=event_manager_note.manager_id"); 
$this->db->join("staffrole","staffrole.roleid=employee.roleid");
$this->db->where("staffrole.role_code","xxx222");
$query=$this->db->get();
return $query->result_array();
}


function event_drivernote($event_id='')
{
$this->db->select("*");
$this->db->from("event_drivernote");
$this->db->where('event_drivernote.event_id',$event_id);
$this->db->join("employee","employee.employeeid=event_drivernote.driver_id"); 
$this->db->join("staffrole","staffrole.roleid=employee.roleid");
$this->db->where("staffrole.role_code","xxx444");
$query=$this->db->get();
return $query->result_array();
}


function event_invoice($event_id='')
{
$this->db->select("*");
$this->db->from("event_invoice");
$this->db->where('event_id',$event_id);
$query=$this->db->get();
return $query->result_array();
}



function event_menu($event_id='')
{
$this->db->select("*");
$this->db->from("event_menu");
$this->db->where('event_menu.event_id',$event_id);
$this->db->join("company_menu","company_menu.comp_menu_id=event_menu.comp_menu_id");

$this->db->join("event_menu_price","event_menu_price.menu_id=company_menu.comp_menu_id");
$query=$this->db->get();
return $query->result_array();
}



function event_menu_price($event_id='')
{
$this->db->select("*");
$this->db->from("event_menu");
$this->db->where('event_menu.event_id',$event_id);
$this->db->join("event_menu_price","event_menu.comp_menu_id=event_menu_price.menu_id");


$query=$this->db->get();
return $query->result_array();
}

function event_payment($event_id='')
{
$this->db->select("*");
$this->db->from("event_payment");
$this->db->where('event_id',$event_id);
$this->db->order_by("event_paymode", "asc"); 
$query=$this->db->get();
return $query->result_array();
}




function event_pay_schedule($event_id='')
{
$this->db->select("*");
$this->db->from("event_pay_schedule");
$this->db->where('event_id',$event_id);
$query=$this->db->get();
return $query->result_array();
}

function event_pots_pans($event_id='')
{
$this->db->select("*");
$this->db->from("event_pots_pans");
$this->db->where('event_pots_pans.event_id',$event_id);
$this->db->join("pots_pans","pots_pans.pp_id=event_pots_pans.pp_id");
$query=$this->db->get();
return $query->result_array();
}

function event_pot_price($event_id='')
{
$this->db->select("*");
$this->db->from("event_pot_price");
$this->db->where('event_id',$event_id);
$query=$this->db->get();
return $query->result_array();
}



function event_task($event_id='')
{
$this->db->select("*");
$this->db->from("event_task");
$this->db->where('event_id',$event_id);
$query=$this->db->get();
return $query->result_array();
}

function get_eventtype($event_id='')
{

$this->db->select("event.eventtypeb_id");
$this->db->select("event.eventtypestb_id");

$this->db->select("eventtype_comp.eventtypeb_name");

$this->db->select("eventsubtype_branch.eventstb_name");

$this->db->from("event");
$this->db->where("event.event_id",$event_id);
$this->db->join("eventtype_comp","event.eventtypeb_id=eventtype_comp.eventtypeb_id");
$this->db->join("eventsubtype_branch","eventsubtype_branch.eventstb_id=event.eventtypestb_id");
$query=$this->db->get();
return $query->result_array();


}

function get_eventagency($event_id='')
{

$this->db->select("*");
$this->db->from("event_agency");
$this->db->where("event_agency.event_id",$event_id);
$this->db->join("comp_staffagency","comp_staffagency.agency_id=event_agency.agency_id"); 
$query=$this->db->get();
return $query->result_array();
}




function item_menu_relation($event_id='')
{
$this->db->select("*");
$this->db->from("item_menu_relation");
$this->db->join("event_menu","item_menu_relation.comp_menu_id=event_menu.comp_menu_id"); 
$this->db->where('event_menu.event_id',$event_id);
$query=$this->db->get();
return $query->result_array();
}



function item_selected_and_all($event_id='',$comp_menu_id='')
{

$this->db->select("*");
$this->db->from("item_menu_relation");
$this->db->join("event_menu","item_menu_relation.comp_menu_id=event_menu.comp_menu_id"); 
$this->db->join("Item","Item.itemid=item_menu_relation.item_id"); 
$this->db->where("event_menu.event_id",$event_id);
$this->db->where("event_menu.comp_menu_id",$comp_menu_id);
$query=$this->db->get();
return $query->result_array();
}


function get_defaultpay_schedule($comp_id=''){

$this->db->select('*');
$this->db->from('pay_schedule_detail');
$this->db->where('default','true');
$this->db->where('comp_id',$comp_id);
$query=$this->db->get();
return $query->result_array();
}


function get_default_row_pay_schedule($event_id='')
{
$last_id=$event_id;
$comp_id=$this->comp_id;


/***create html append  same as ajax**/
$get_defaultpay_schedule=$this->get_event_details->get_defaultpay_schedule($this->comp_id);

foreach($get_defaultpay_schedule as $res)
{
$schedule_id=$res['pay_schedule_id'];
$first=$res['first'];
$second=$res['second'];
$third=$res['third'];
}

$symbol=$this->getid_model->getcurrency($comp_id);
$default_zero=$symbol.'0.00';
$fulltotal=0;
$row='';
if($first)
{
$first_payment=$fulltotal*($first/100);

$first_payment=number_format((float)$first_payment, 2, '.', '');

$first_row='<div class="row_color2"><ul><li class="payment_part" id="first_percent">Part 1('.$first.'%)</li><li class="payment_part" id="first_price">'.$symbol .$first_payment.'</li><li class="payment_part"><input name="first_pay" id="first_pay" type="text" value="0.00" onblur="receivepayment(this.id)" class="payment_texfeild"></li><li class="payment_part" id="first_balance">'.$symbol .$first_payment.'</li><li class="payment_part"><a href="#"></a></li><li class="payment_part"></li><li class="payment_invoice"></li></ul></div>';
$row=$row.$first_row;
}
if($second)
{
$sec_payment=$fulltotal*($second/100);
$sec_payment=number_format((float)$sec_payment, 2, '.', '');

$second_row='<div class="row_color3"><ul><li class="payment_part" id="second_percent">Part 2('.$second.'%)</li><li class="payment_part" id="second_price">'.$symbol .$sec_payment.'</li><li class="payment_part"><input name="second_pay" id="second_pay" value="0.00" onblur="receivepayment(this.id)" type="text" class="payment2_texfeild"></li><li class="payment_part" id="second_balance">'.$symbol .$sec_payment.'</li><li class="payment_part"><a href="#"></a></li><li class="payment_part"></li><li class="payment_invoice"></li></ul></div>';
$row=$row.$second_row;
}

if($third)
{
$third_payment=$fulltotal*($third/100);
$third_payment=number_format((float)$third_payment, 2, '.', '');

$third_row='<div class="row_color2"><ul><li class="payment_part" id="third_percent">Part 3('.$third.'%)</li><li class="payment_part" id="third_price">'.$symbol .$third_payment.'</li><li class="payment_part"><input name="third_pay" id="third_pay" value="0.00" onblur="receivepayment(this.id)" type="text" class="payment_texfeild"></li><li class="payment_part" id="third_balance">'.$symbol .$third_payment.'</li><li class="payment_part"><a href="#"></a></li><li class="payment_part"></li><li class="payment_invoice"></li></ul></div>';
$row=$row.$third_row;
}

return $row;
/***create html append **/
}


function get_paid_rows($event_id="")
{

$last_id=$event_id;
$comp_id=$this->comp_id;
$symbol=$this->getid_model->getcurrency($comp_id);
$get_paid_schedule=$this->get_event_details->event_payment($event_id);

$default_zero=$symbol.'0.00';
$row='';
$i=1; $j=0;
foreach($get_paid_schedule as $res)
{ $j++; $i++; if($i==4){ $i=2; }
$event_paymode=$res['event_paymode'];
$event_paypaid=$res['event_paypaid'];
$event_paypaid=number_format((float)$event_paypaid, 2, '.', '');
$event_pay_balance=$res['event_pay_balance'];
$event_pay_balance=number_format((float)$event_pay_balance, 2, '.', '');
$event_percentamount_topay=$res['event_percentamount_topay']; 
$event_percentamount_topay=number_format((float)$event_percentamount_topay, 2, '.', ''); 
$event_grand_tot_price=$res['event_grand_tot_price'];
$percentage=$res['percent'];


$rows='<div class="row_color'.$i.'"><ul><li class="payment_part" id="'.$event_paymode.'_percent">Part '.$j.'('.$percentage.'%)</li><li class="payment_part" id="'.$event_paymode.'_price">'.$symbol .$event_percentamount_topay.'</li><li class="payment_part"><input name="'.$event_paymode.'_pay" id="'.$event_paymode.'_pay" type="text" value="'.$event_paypaid.'" onblur="receivepayment(this.id)" class="payment_texfeild"></li><li class="payment_part" id="'.$event_paymode.'_balance">'.$symbol .$event_pay_balance.'</li><li class="payment_part"><a href="#"></a></li><li class="payment_part"></li><li class="payment_invoice"></li></ul></div>';
$row=$row.$rows;

}
return $row;

}

function get_event_detail_all($event_id="")
{

$this->db->select("*");
$this->db->from("event");
$this->db->where("event.event_id",$event_id);
$this->db->join("event_details","event_details.event_id=event.event_id");
$this->db->join("eventguest","eventguest.event_id=event.event_id");
$query=$this->db->get();
return $query->result_array();

}




function get_events_search($search_item="")
{

$terms = explode(' ', $search_item);	
		$this->db->select('*');
		$this->db->from('event');
				foreach($terms as $term){
		  $this->db->or_like('event_id', $term);
		}		
		return $this->db->get()->result_array();	

}


}