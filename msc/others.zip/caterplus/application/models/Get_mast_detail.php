<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Get_mast_detail extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }



function get_menutype(){     //starters

$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $comp_id);
$this->db->where('com_tmenu_status', 'active');
$query= $this->db->get('menutype_company');
return $query->result_array();

    }
  
function get_basicunits(){  
$this->db->where('unit_status', 'active');
$query= $this->db->get('pdt_mast_units');
return $query->result_array();
}
    

function get_staff_subrole()
{
$comp_id=$this->session->userdata('comp_id');

$this->db->select('*');
$this->db->from('staffrole');

$this->db->join('role_subrole','staffrole.roleid=role_subrole.role_id');

$this->db->where('role_subrole.comp_id',$comp_id);
//$this->db->where('role_subrole.subrole_status','active');
 $query= $this->db->get();
return $query->result_array();

}

function get_staff_subrole_byid($id='')
{
$comp_id=$this->session->userdata('comp_id');

$this->db->select('*');
$this->db->from('staffrole');

$this->db->join('role_subrole','staffrole.roleid=role_subrole.role_id');

$this->db->where('role_subrole.comp_id',$comp_id);
//$this->db->where('role_subrole.subrole_status','active');

$this->db->where('role_subrole.role_subrole_id',$id);
 $query= $this->db->get();
return $query->result_array();

}




function get_ingredient()
{
$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $comp_id);
$this->db->where('ing_status', 'active');
$query= $this->db->get('ingredient');
return $query->result_array();
}

function get_package()
{
$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $comp_id);
$this->db->where('pkg_status', 'active');
$query= $this->db->get('package');
return $query->result_array();
}



function get_activeitems(){   
$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $comp_id);
$this->db->where('item_status', 'active');
$query= $this->db->get('item');
return $query->result_array();
}




function get_activecontainer(){  
$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $comp_id);
$this->db->where('pdt_con_status', 'active');
$query= $this->db->get('pdt_containers');
return $query->result_array();
}


function get_staffrole(){   // use speecial event table
$comp_id=$this->session->userdata('comp_id');
$this->db->where('comp_id', $comp_id);
$this->db->where_not_in('rolename','admin');
$query= $this->db->get('staffrole');
return $query->result_array();
}












}