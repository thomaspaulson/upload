<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Staff_role_model extends CI_Model {

   function __construct()
   {
       parent::__construct();
   } 
   function insert_role_db()
   {
      $role_name = $this->input->post('role_name');
      $role_description = $this->input->post('role_description');
      $roleslug = random_slug(30);
      $rolestatus="active";
      $data = array(
                     'rolename' =>  $role_name,
		     'roledescription' => $role_description,
                     'rolestatus' =>$rolestatus,
                     'roleslug' => $roleslug,
		   );
     $this->db->insert('staffrole', $data);
	       
   }
   
   function update_rolestatus($roleslug,$status)
   {
       $query=$this->db->query("UPDATE `staffrole` SET `rolestatus`='$status' WHERE `roleslug`='$roleslug'");
      
   }
   
   function update_staff_status($role_id,$status)
   {
       	$data = array(
       		'current_status' => $status,
       	); 
       	      	   
	if($status == 'active'){
		$this->db->where('roleid',$role_id);		
		$this->db->where('current_status_copy','active'); 
		$this->db->update('employee',$data);
	}else{
		$this->db->where('roleid',$role_id);	
		$this->db->update('employee',$data);			
	}
      
   }      
   
   function edit_role_model($roleslug)
   {
        $this->db->select('*');
        $this->db->from('staffrole');
	$this->db->where('roleslug', $roleslug);
        $query = $this->db->get();
        return $result = $query->result_array();
      
   }  
   function update_role()
   {
        $roleslug= $this->input->post('roleslug');
	$rolename= $this->input->post('role_name');
	$roledescription= $this->input->post('role_description');
        $query=$this->db->query("UPDATE staffrole SET rolename ='$rolename',roledescription='$roledescription' WHERE roleslug='$roleslug'");
      
   }  
   function display_role()
   {
      $query=$this->db->query("SELECT * FROM staffrole where rolename!='Admin' AND rolename!='admin'");
      return $result =$query->result_array();
      
   } 
	
	
}