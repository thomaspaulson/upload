<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Getcomp_details_model extends CI_Model {
public $comp_id;
public $br_id; 
	  function __construct()
    {
        parent::__construct();
$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');
        
    }

function getcust_list_byterm($term='')
{
if (is_numeric ($term)) 
{

$this->db->select("*");
$this->db->from("customer"); 
$this->db->where('comp_id',$this->comp_id);
$this->db->where('br_id',$this->br_id);
$this->db->where('customerstatus','active');
$this->db->like('customermobile1',$term);
//$this->db->or_like('customerphone',$term); 
$query=$this->db->get();
return $query->result_array();
}
else if(ctype_alpha($term))
{
$this->db->select("*");
$this->db->from("customer"); 
$this->db->where('comp_id',$this->comp_id);
$this->db->where('br_id',$this->br_id);
$this->db->where('customerstatus','active');
$this->db->like('customername', $term); 
$query=$this->db->get();
return $query->result_array();
}
else //empty
{

$this->db->select('customername');
$this->db->select('customerphone');
$this->db->select('customermobile1');
$this->db->select('customermobile2');
$this->db->select('customerId');
$this->db->where('comp_id',$this->comp_id);
$this->db->where('br_id',$this->br_id);
$this->db->where('customerstatus','active');
                $this->db->order_by('customerId','desc');
		$query = $this->db->get('customer');
		$total = $query->num_rows(); 
	
	return	$array = $query->result_array();
}
}


function get_eventtype($comp_id=''){    //only event
$this->db->select('*');
$this->db->from('eventtype_comp');
$this->db->where('comp_id', $comp_id);
$this->db->where('eventtypeb_status', 'active');
$query=$this->db->get();
return $query->result_array();
    }
    
  function get_subeventtype($comp_id='',$ev_typeid=''){    //only sub
 $this->db->select('*'); 
$this->db->from('eventsubtype_branch');
$this->db->where('eventsubtype_branch.comp_id', $comp_id);
$this->db->join('eventtype_comp', 'eventtype_comp.eventtypeb_id= eventsubtype_branch.eventtypeb_id');
$this->db->where('eventsubtype_branch.eventtypeb_status','active');
$this->db->where('eventsubtype_branch.eventtypeb_id',$ev_typeid);
$eve_subevent= $this->db->get();
return $eve_subevent->result_array();
    }  
    
    
    
    
    
   function get_event_subevent($comp_id=''){ //both
        $this->db->select('*'); 
	$this->db->from('eventtype_comp');
	$this->db->where('eventtype_comp.comp_id',$comp_id);
	$this->db->join('eventsubtype_branch', 'eventtype_comp.eventtypeb_id= eventsubtype_branch.eventtypeb_id');
	$this->db->where('eventtype_comp.eventtypeb_status','active');
	$this->db->where('eventsubtype_branch.eventtypeb_status','active');
	$eve_subevent= $this->db->get();
	
        return $eve_subevent->result_array();    
    } 
    
    


  
   function get_agencylist($comp_id=''){ //both
        $this->db->select('*'); 
	$this->db->from('comp_staffagency');
	$this->db->where('comp_id',$comp_id);
	
	$agencylist= $this->db->get();
	
        return $agencylist->result_array();    
    } 
    



function get_pots_pans($comp_id='',$br_id=''){ //both
        $this->db->select('*'); 
	$this->db->from('pots_pans');
	$this->db->where('comp_id',$this->comp_id);
$this->db->where('br_id',$this->br_id);
$this->db->where('pp_status','active');
	
	$pp_list= $this->db->get();
	
        return $pp_list->result_array();    
    } 
    
    
     
   function get_eventtype_name($comp_id='',$typeid=''){ //both
        $this->db->select('eventtypeb_name'); 
	$this->db->from('eventtype_comp');
	$this->db->where('comp_id',$comp_id);
	$this->db->where('eventtypeb_id',$typeid);
		$eventtypes= $this->db->get();
	
      $eventtype=$eventtypes->result_array();    
      foreach($eventtype as $sub)
      { $evnttype= $sub['eventtypeb_name'];      } return $evnttype;
    } 
    
    
     function get_subeventtype_name($comp_id='',$subtypeid=''){ //both
        $this->db->select('eventstb_name'); 
	$this->db->from('eventsubtype_branch');
	$this->db->where('comp_id',$comp_id);
	$this->db->where('eventstb_id',$subtypeid);
		$eventtypes= $this->db->get();
	
      $eventtype=$eventtypes->result_array();    
      foreach($eventtype as $sub)
      { $evntstype= $sub['eventstb_name'];      } return $evntstype;
    } 
    
    
    
     function get_alldrivers($comp_id='',$br_id=''){ 
     
        $this->db->select('employee.employeename'); $this->db->select('employee.employeeid'); $this->db->select('staffrole.rolename'); 
	$this->db->from('employee');
	$this->db->where('employee.current_status','active');
	$this->db->where('employee.comp_id',$comp_id);$this->db->where('employee.br_id',$br_id); 
	$this->db->where('staffrole.comp_id',$comp_id);
	$this->db->where('staffrole.rolename','driver'); 
           $this->db->join('staffrole','staffrole.roleid=employee.roleid');


	
      $eve_subevent= $this->db->get();
      return  $eve_subevent->result_array();
     
    } 
    
    
  function get_allmanagers($comp_id='',$br_id=''){ 
     
        $this->db->select('employee.employeename'); $this->db->select('employee.employeeid'); $this->db->select('staffrole.rolename'); 
	$this->db->from('employee');
	$this->db->where('employee.current_status','active');
	$this->db->where('employee.comp_id',$comp_id);$this->db->where('employee.br_id',$br_id); 
	$this->db->where('staffrole.comp_id',$comp_id);
	$this->db->where('staffrole.rolename','manager'); 
           $this->db->join('staffrole','staffrole.roleid=employee.roleid');


	
      $eve_subevent= $this->db->get();
      return  $eve_subevent->result_array();
     
    }  
    
    
    function get_allchefs($comp_id='',$br_id=''){ 
     
        $this->db->select('employee.employeename'); $this->db->select('employee.employeeid'); $this->db->select('staffrole.rolename'); 
	$this->db->from('employee');
	$this->db->where('employee.current_status','active');
	$this->db->where('employee.comp_id',$comp_id);$this->db->where('employee.br_id',$br_id); 
	$this->db->where('staffrole.comp_id',$comp_id);
	$this->db->where('staffrole.rolename','chef'); 
           $this->db->join('staffrole','staffrole.roleid=employee.roleid');


	
      $eve_subevent= $this->db->get();
      return  $eve_subevent->result_array();
     
    }  
    
    

}