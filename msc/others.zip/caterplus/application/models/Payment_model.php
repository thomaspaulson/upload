<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Payment_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }

function  insert_payment($data)
{
extract($data);
$bal=$this->input->post('hiddenbalance');
 $detail= array(
	        	'custid' =>$this->input->post('custid'), 
	        	'orderid' => $this->input->post('orderid'),
	        	'totalpay' => $this->input->post('initialtotal'),
	        	'balance'=>$this->input->post('hiddenbalance'),
	        	'paidamount'=>$this->input->post('hiddenpaid'),
'paymenttype'=>$this->input->post('hiddencashtype'),
'employeeid'=>48
                        
	        );


	        $this->db->set($detail);
	        $this->db->insert('specialeventpaymentrelation'); 

if($bal==0){
$query=$this->db->query("update specialorder set payment_status='paid' where orderid='$orderid'");
}


}



function  insert_directpayment($data)
{
extract($data);
$bal=$this->input->post('hiddenbalance');
$homedelivery=$this->input->post('homedelivery');
if($homedelivery!='yes')
{ $homedelivery='no'; } 


 $comp_id=$this->session->userdata('comp_id');
 $br_id=$this->session->userdata('branch_id');

 $detail= array(        'comp_id' =>$comp_id,'br_id' =>$br_id,   
	        	'custid' =>$this->input->post('custid'), 
	        	'orderid' => $this->input->post('orderid'),
	        	'totalpay' => $this->input->post('initialtotal'),
	        	'balance'=>$this->input->post('hiddenbalance'),
	        	'paidamount'=>$this->input->post('hiddenpaid'),
'paymenttype'=>$this->input->post('hiddencashtype'),
'employeeid'=>48
                        
	        );


	        $this->db->set($detail);
	        $this->db->insert('specialeventpaymentrelation'); 

$query=$this->db->query("update specialorder set home_delivery='$homedelivery' where orderid='$orderid'");

if($bal==0){
$query=$this->db->query("update specialorder set payment_status='paid' where orderid='$orderid'");
}


}




function  insert_paymentbal($data)
{
extract($data);
$bal=$this->input->post('hiddenbalance');
 $detail= array(
	        	'custid' =>$this->input->post('custid'), 
	        	'orderid' => $this->input->post('orderid'),
	        	'totalpay' => $this->input->post('initialtotal'),
	        	'balance'=>$this->input->post('hiddenbalance'),
	        	'paidamount'=>$this->input->post('hiddenpaid'),
'paymenttype'=>$this->input->post('hiddencashtype'),
'employeeid'=>48
                        
	        );



	        $this->db->set($detail);
	        $this->db->insert('specialeventpaymentrelation'); 

if($bal==0){
$query=$this->db->query("update specialorder set payment_status='paid' where orderid='$orderid'");
}

}




function homedeliveryforpayment(){
// $query=$this->db->query("select * from specialorder spo,customer cu where (spo.customer_id=cu.customerId) and (spo.payment_status='unpaid') and (spo.totalamount>0) and //(spo.home_delivery='yes')");

$query=$this->db->query("select * from specialorder spo,customer cu where (spo.customer_id=cu.customerId) and (spo.home_delivery='yes')");

        return $query->result_array();
    }
    









function select_orderforpayment(){

$comp_id=$this->session->userdata('comp_id');
 $br_id=$this->session->userdata('branch_id');

 $query=$this->db->query("select * from specialorder spo,customer cu where (spo.customer_id=cu.customerId) and (spo.payment_status='unpaid') and (spo.totalamount>0) and (spo.comp_id='$comp_id') and (spo.br_id='$br_id')");
        return $query->result_array();
    }


function get_balpay($orderid=''){

//$query=$this->db->query("select sum(paidamount) as paidamount,totalpay as tpay from specialeventpaymentrelation where orderid='$orderid'");
$query=$this->db->query("select balance as tpay from specialeventpaymentrelation where orderid='$orderid' ORDER BY paymentid DESC LIMIT 1");
$res=$query->result_array();
foreach($res as $result)
{ $totalpay=$result['tpay'];}
$nums=$query->num_rows();
if($nums==0)
$balpay=0;
//$balpay=$totalpay-$paid;
else
$balpay=$totalpay;
//$balpay= number_format($balpay, 2);
$balpay= number_format((float)$balpay, 2, '.', '');
return $balpay;
}


function get_paidamount($orderid=''){

//$query=$this->db->query("select sum(paidamount) as paidamount,totalpay as tpay from specialeventpaymentrelation where orderid='$orderid'");
$query=$this->db->query("select paidamount as paidamount from specialeventpaymentrelation where orderid='$orderid' ORDER BY paymentid DESC LIMIT 1");

$res=$query->result_array();
foreach($res as $result)
{ $paid=$result['paidamount'];}


//$paid= number_format($paid, 2);
$balpay= number_format((float)$paid, 2, '.', '');
return $paid;
}



}