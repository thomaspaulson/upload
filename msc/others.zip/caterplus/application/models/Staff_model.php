<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Staff_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }


    function select_staffs(){
$br_id= $this->session->userdata('branch_id');
$comp_id=$this->session->userdata('comp_id');

        $this->db->select('*');
	$this->db->from('employee');
$this->db->where('employee.br_id',$br_id);
$this->db->where('employee.comp_id',$comp_id);
	$this->db->order_by("rolename", "asc");		
	$this->db->join('staffrole', 'employee.roleid = staffrole.roleid');
        $employees = $this->db->get();
        return $employees->result_array();
    }


	function select_customer($custid){	
		$this->db->select('*');
		$this->db->from('customer');
		$this->db->where('customerId',$custid);
	        $customers = $this->db->get();
	        return $customers->result_array();
	}

function get_adminname()
{
 $this->db->select('employeename');
$this->db->where('username','admin');
$query= $this->db->get('employee');
$result = $query->row();
		return $result->employeename;
}
 /*   function login($array){
	$this->db->select('*');
	$this->db->from('employee');
	$this->db->where('username',$array['username']);	
	$this->db->where('password',$array['password']);     
	$query = $this->db->get();
	if($query->num_rows() > 0){
		$result = $query->result_array();
		if($result[0]['roleid'] == 1){
			$this->session->set_userdata('user_id',$result[0]['employeeid']);
			$this->session->set_userdata('logged_in','yes');			
			$this->session->set_userdata('type','cook');			
			return 'cook';
		}else if($result[0]['roleid'] == 2){
			$this->session->set_userdata('user_id',$result[0]['employeeid']);
			$this->session->set_userdata('logged_in','yes');			
			$this->session->set_userdata('type','admin');			
			return 'admin';
		}else{
			$this->session->sess_destroy();
			return 'else';
		}
	}else{
		$this->session->sess_destroy();	
		return 'else';
	}

    }*/
    
    function pin_check($pin){    	
        $this->db->select('*');
	$this->db->from('login');
	$this->db->where("pin", $pin);		
        $employees = $this->db->get();
        if($employees->num_rows() > 0){
		return 1;
        }else{
        	return 0;
        }
    
    }
    
    function add_staff($array){
$br_id= $this->session->userdata('branch_id');
$comp_id=$this->session->userdata('comp_id');

	        $employee = array('comp_id'=>$comp_id,'br_id'=>$br_id,
	        	'employeename' => $array['name'], 
	        	'username' => $array['username'],
	        	'employeeaddress' => $array['address'],
	        	'roleid'=>$array['role'],
	        	'status'=>$array['type'],
                        'phn_ext' => $array['phn_ext'],
	        	'employeephone'=>$array['phone'],
                        'mobile1'=>$array['mobile1'],
                        'mobile2'=>$array['mobile2'],
	        	'email' => $array['email'],
                        'email2' => $array['email2']
	        );
	        $this->db->set($employee);
	        $this->db->insert('employee');
	        $employee_id = $this->db->insert_id();
	        
	        $user_id = $array['user_id'] . $employee_id; 

 
        if($employee_id){
        	//insert slug into employee table after inserting employee details on registration
	        
	        $slug = array(
	        	'slug' => $array['slug'].'_'. $employee_id , 
	        );

		$this->db->where('employeeid', $employee_id);
		$this->db->update('employee', $slug);
		        
	        $login = array(
	        	'password' => md5($array['password']), 
	        	'pin' => $array['pin'],
	        	'user_id' =>  $user_id, 
	        );
	        

		$this->db->where('employeeid', $employee_id);
		$this->db->update('employee', $login);
	        
	        return $employee_id ;
        }
    } 
    
    function edit_staff($array){
	        $employee = array(
	        	'employeename' => $array['name'],
	        	'username' => $array['username'],  
	        	'employeeaddress' => $array['address'],
	        	'roleid'=>$array['role'],
	        	'status'=>$array['type'],
	        	'phn_ext'=>$array['phn_ext'],
                        'employeephone'=>$array['phone'],
                        'mobile1'=>$array['mobile1'],
                        'mobile2'=>$array['mobile2'],
	        	'email' => $array['email'],
                        'email2' => $array['email2'],
'pin' => $array['pin'],
'user_id' => $array['user_id'],
	        );

		$this->db->where('employeeid', $array['id']);
		$this->db->update('employee', $employee);
		return 1;
 
    }        
    
    function delete_staff($id){
    	$data = array(
               'current_status' => 'inactive',
               'current_status_copy' => 'inactive',
        );
	$this->db->where('employeeid', $id);
	$this->db->update('employee', $data);
	return 1;
    }
    
    
    function activate_staff($id){
    	$data = array(
               'current_status' => 'active',
               'current_status_copy' => 'active',               
        );
	$this->db->where('employeeid', $id);
	$this->db->update('employee', $data);
	return 1;
    }
    
    function get_staff_details($id){
        $this->db->select('*');
	$this->db->from('employee');
	$this->db->where('employeeid',$id);	
	$this->db->join('staffrole', 'employee.roleid = staffrole.roleid');
	//$this->db->join('login', 'employee.employeeid = login.employeeid');	
        $employees = $this->db->get();
        return $employees->result_array();    
    }
    
    function select_roles(){
    	$this->db->order_by("rolename", "asc");
    	$this->db->where("rolestatus", "active");
        $employees = $this->db->get('staffrole');
        return $employees->result_array();    
    }
    
    
    function get_id($slug,$table_name,$primary_key){
        $this->db->select('*');
	$this->db->from($table_name);
	$this->db->where('slug',$slug);	
        $query = $this->db->get();
        $result = $query->result_array();
        if(count($result)){
        	return $result[0][$primary_key];
        }else{
        	return 0;
        }    
    }
	 
		
	
	


		
}