<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Event_model extends CI_Model {

public $comp_id;
public $br_id; 
	function __construct(){
		parent::__construct();    
$this->comp_id=$this->session->userdata('comp_id');
 $this->br_id=$this->session->userdata('branch_id');  
 $this->load->helper('string');  
	}
	
function getcust_list(){

$this->db->select('customername');
$this->db->select('customerphone');
$this->db->select('customermobile1');
$this->db->select('customermobile2');
$this->db->select('customerId');
$this->db->where('comp_id',$this->comp_id);
$this->db->where('br_id',$this->br_id);
$this->db->where('customerstatus','active');
                $this->db->order_by('customerId','desc');
		$query = $this->db->get('customer');
		$total = $query->num_rows(); 
	
	return	$array = $query->result_array();
		
		}




function event_cust($data=''){
extract($data);

$customername=$this->input->post('custname');
$customeraddress=$this->input->post('custaddress');
$customeremail=$this->input->post('custemail');
$customerphone=$this->input->post('custphone');
$customermobile1=$this->input->post('custmob');
$data=array('customername'=>$customername,'customeraddress'=>$customeraddress,
'customeremail'=>$customeremail,'customerphone'=>$customerphone,'customermobile1'=>$customermobile1,'comp_id'=>$this->comp_id,'br_id'=>$this->br_id);
$this->db->insert('customer',$data);


$id=$this->db->insert_id();

$customerslug=$id.random_string(10);;
$customerslg = array(
               'customerslug' => $customerslug,              
            );

$this->db->where('customerId', $id);
$this->db->update('customer', $customerslg ); 


return $id;

}

function getcust_byid($customerId=''){

$this->db->select('customername');
$this->db->select('customerphone');
$this->db->select('customermobile1');
$this->db->select('customermobile2');
$this->db->select('customerId');
$this->db->where('customerId',$customerId);
$this->db->where('comp_id',$this->comp_id);
$this->db->where('br_id',$this->br_id);
$this->db->where('customerstatus','active');

		$query = $this->db->get('customer');
		
	
	return	$array = $query->result_array();
		
		}






function add_event($data=''){

$this->db->insert('event',$data);

return $this->db->insert_id();


}



function addlocation($data=''){

$this->db->insert('event_details',$data);

return  $this->db->insert_id();


}



function addguest($data=''){

$this->db->insert('eventguest',$data);

return $this->db->insert_id();


}



function attatch_event_branch($data=''){

$this->db->insert('event_branch',$data);

return $this->db->insert_id();


}




function get_items($comp_id='',$menutypeid=''){ 

$this->db->where('item_status','active');
$this->db->where('comp_id',$comp_id);
$this->db->where('menutype',$menutypeid);
$query=$this->db->get('Item');

		return $query->result_array(); 


}





function get_menutypes($comp_id=''){

$this->db->where('menu_status','active');
$this->db->where('comp_id',$this->comp_id);
		$query = $this->db->get('menutype');
		return $query->result_array(); 

}

function get_mast_tasklist($event_id=''){
$this->db->where('event_id',$event_id);
		$query = $this->db->get('event_task');
		return $query->result_array(); 


}



function create_menu($menu_name='',$comp_id=''){
$data=array('comp_id'=>$comp_id,'comp_menu_name'=>$menu_name);  //insert menu name
$this->db->insert('company_menu',$data);
return $this->db->insert_id();

}

function create_menu_item($data=''){
$this->db->insert('item_menu_relation',$data); // add menu and item
}


function totprice_menu_item($data=''){        //total menu price
$this->db->insert('event_menu_price',$data);
}



function insert_common_notes($data=''){      // common notes
$this->db->insert('event_commonnote',$data);
}


function event_menu_relation($data=''){               //menu and event relation
$this->db->insert('event_menu',$data);
}


function pots_event_relation($data=''){               //pots- event relation
$this->db->insert('event_pots_pans',$data);
}


function pots_totalprice($data=''){               //pots-tot price
$this->db->insert('event_pot_price',$data);
}

function event_drivernote($data=''){               //event_drivernote
$this->db->insert('event_drivernote',$data);
}

function event_manager($data=''){               //event_manager_note
$this->db->insert('event_manager_note',$data);
}

function event_chefnote($data=''){               //event_chefnote
$this->db->insert('event_chefnote',$data);
}

function event_agency($data=''){               //event_agency
$this->db->insert('event_agency',$data);
}

function event_task_master($event_id=''){    //create task master

$this->db->select("*");
$this->db->from("pdt_mast_subtask");
$query=$this->db->get();
$result=$query->result_array();

foreach($result as $rr)
{
$insert=array('task_id'=>$rr['m_task_id'],'subtask_id'=>$rr['m_subtask_id'],'subtask_name'=>$rr['m_subtask_name'],
'event_id'=>$event_id,'br_id'=>$this->br_id,'comp_id'=>$this->comp_id,'subtask_slug'=>$rr['m_subtask_slug']);

$this->db->insert('event_task',$insert);
}

}

function get_payschedule()
{

$this->db->where('comp_id',$this->comp_id);
$this->db->select("*");
$this->db->from("pay_schedule_detail");
$query=$this->db->get();
return $query->result_array();
}

function save_payment($data='')
{
$this->db->insert('event_payment',$data);
}


function get_event_payschedule($event_id='')
{

$this->db->where('event_id',$event_id);
$this->db->select("*");
$this->db->from("event_pay_schedule");
$query=$this->db->get();
return $query->result_array();
}

function get_event_id($event_id='',$event_slug='')
{

$event_idd=0;
$this->db->where('event_id',$event_id);
$this->db->where('event_slug',$event_slug);
$this->db->select("event_id");
$this->db->from("event");
$query=$this->db->get();
$res= $query->result_array();
foreach($res as $rest)
{ $event_idd=$rest['event_id'];}

if($event_idd){ return $event_idd; } else { return 0 ; }

}


function get_event_list($comp_id='',$br_id='')
{

$this->db->order_by('event.event_id','desc');

$this->db->where('event_branch.branch_id',$br_id);
$this->db->where('event_branch.comp_id',$comp_id);
$this->db->select("*");
$this->db->from("event_branch");
$this->db->join("event","event.event_id=event_branch.event_id");
$this->db->join("customer","customer.customerId=event.cust_id");
$query=$this->db->get();
return $query->result_array();

}


function update_event($data='',$event_id='')
{

$this->db->where('event_id',$event_id);
$this->db->update('event',$data);


}


function updatelocation($data='',$event_id=''){

$this->db->where('event_id',$event_id);
$this->db->update('event_details',$data);

}


function updateguest($data='',$event_id=''){

$this->db->where('event_id',$event_id);
$this->db->update('eventguest',$data);

}



function insert_dafault_as_initially($comp_id='',$event_id=''){

$this->db->select('*');
$this->db->from('pay_schedule_detail');
$this->db->where('default','true');
$this->db->where('comp_id',$comp_id);
$query=$this->db->get();
$result=$query->result_array();

foreach($result as $res)
{
$schedule_id=$res['pay_schedule_id'];
$first=$res['first'];
$second=$res['second'];
$third=$res['third'];
}
$this->db->where('event_id',$event_id);
$this->db->delete('event_pay_schedule'); //delete if exist any

$insert_schedule=array('event_id'=>$event_id,'schedule_id'=>$schedule_id,'first_temp'=>$first,'second_temp'=>$second,'third_temp'=>$third,'comp_id'=>$comp_id);
$this->db->insert('event_pay_schedule',$insert_schedule);
return $schedule_id;

}


function check_menu_name($new_menu_name='',$event_id='')
{
$event_idd= array($event_id);

$this->db->select("*");
$this->db->from("company_menu");
$this->db->like("company_menu.comp_menu_name",$new_menu_name);
$this->db->where("company_menu.comp_id",$this->comp_id);
$this->db->join("event_menu","event_menu.comp_menu_id=company_menu.comp_menu_id");
$this->db->where_not_in("event_menu.event_id", $event_idd);
$query=$this->db->get();
if($query->num_rows() > 0)
{ return "1"; } 
else { return "0";}


}


function delete_for_edit($event_id='')
{
$this->db->where('event_id',$event_id);
$this->db->delete('event_pots_pans'); //remove pots

$this->db->where('event_id',$event_id);
$this->db->delete('event_pot_price'); //remove pot price


$this->db->where('event_id',$event_id);
$this->db->delete('event_commonnote'); //remove notes

$this->db->where('event_id',$event_id);
$this->db->delete('event_menu'); //remove menu vs event relation

$this->db->where('event_id',$event_id);
$this->db->delete('event_agency'); //remove menu vs event relation

$this->db->where('event_id',$event_id);
$this->db->delete('event_drivernote'); //remove menu vs event relation

$this->db->where('event_id',$event_id);
$this->db->delete('event_chefnote'); //remove menu vs event relation


$this->db->where('event_id',$event_id);
$this->db->delete('event_manager_note'); //remove menu vs event relation


$this->db->where('event_id',$event_id);
$this->db->delete('event_payment'); //remove menu vs event relation


}



function create_invoice_id($event_id='')
{
$this->db->select('*');
$this->db->from('event_invoice');
$this->db->where('event_id',$event_id);

$query=$this->db->get();
$count_rows=$query->num_rows();

$count_rows=$count_rows+1;
$len=strlen($count_rows);

if($len<4)
{
$count_rows='000'.$count_rows;
}

$inv_name='invoice-'.$count_rows;

return $inv_name;

}






function save_invoice_id($event_id='',$file_name=''){
$data=array('event_inv_filename'=>$file_name,'event_id'=>$event_id,
'event_inv_date'=>'');
$this->db->insert('event_invoice',$data);

}









}