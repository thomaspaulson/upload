<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mainlogin_model extends CI_Model {

	  function __construct()
    {
        parent::__construct();
        
    }


    function superlogin($username,$password){ //super admin login
      $this->db->select('*');
	$this->db->from('pdt_superadmin');
	$this->db->where('sa_username',$username);	 $this->db->where('sa_password',$password);
        $query = $this->db->get();
        $result = $query->result_array();
        if(count($result)){
        	return $result;
        }else{
        	return 0;
        }    
    }
/*
function loginold($username,$password){ // admin login caterer
      $this->db->select('*');
	$this->db->from('pdt_employeelogin');
	$this->db->where('emp_username',$username);
	$this->db->where('emp_password',$password);	
	$this->db->where('emp_status','active');
	 $query = $this->db->get();
	 $result = $query->result_array();
        if(count($result)){
        	return $result;
        }else{
        	return 0;
        }  
    }*/







function login($username,$password){ // admin login caterer
      $this->db->select('*');
	$this->db->from('employee');
	$this->db->where('username',$username);
	$this->db->where('password',$password);	
	$this->db->where('current_status','active');
	 $query = $this->db->get();
	 $result = $query->result_array();
        if(count($result)){
        	return $result;
        }else{
        	return 0;
        }  
    }













}