<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Special_order_model extends CI_Model {

    function __construct()
    {
        parent::__construct();
        
    }
    
    function all_menus(){
        $this->db->select('*');
	$this->db->from('menutype');
	$this->db->order_by('menutypename','asc');
	$this->db->where('menu_status','active');			
        $packages = $this->db->get();
        return $packages->result_array();
    }
    
    function add_package($array){
	        $package = array(
	        	'specialp_name' => $array['name'], 
	        	'specialp_qty' => $array['qty'],
	        );
	        $this->db->set($package);
	        $this->db->insert('specialpackage');
	        $package_id = $this->db->insert_id();

 
        if($package_id){
        	//insert slug into special package table after inserting package  details on registration
	        
	        $slug = array(
	        	'slug' => $array['slug'].'_'. $package_id , 
	        );

		$this->db->where('specialp_id', $package_id);
		$this->db->update('specialpackage', $slug);		        
	        return 1;
        }    
    
    
    }
    
    function delete_package($id){
    	$data = array(
               'current_status' => 'inactive',
        );
	$this->db->where('specialp_id', $id);
	$this->db->update('specialpackage', $data);
	return 1;
    }
    
    function get_package_details($id){
        $this->db->select('*');
	$this->db->from('specialpackage');
	$this->db->where('specialp_id',$id);	
        $query = $this->db->get();
        return $query->result_array();    
    }        

    function edit_package($array){
	        $package = array(
	        	'specialp_name' => $array['name'],
	        	'specialp_qty' => $array['qty']
	        );
		$this->db->where('specialp_id', $array['id']);
		$this->db->update('specialpackage', $package);
		return 1;
 
    } 


	  	
 function select_order($orderid){
 $query=$this->db->query("select * from specialorder spo,specialorderquantity spoq,customer cu,Item itm where (spo.orderid=spoq.orderid) and  (spoq.itemid=itm.itemid) and  (spo.orderid='$orderid') and (spo.customer_id=cu.customerId)");
        return $query->result_array();
    }
    

 function select_orderedcontainer($orderid){        
$query=$this->db->query("select * from special_container spc,specialorder_container soc,specialorder spo,customer cu where (soc.order_id='$orderid')  and (soc.container_id=spc.special_cid) and (spo.customer_id=cu.customerId) and (spo.orderid='$orderid')");
return $query->result_array();
}

    
		
}