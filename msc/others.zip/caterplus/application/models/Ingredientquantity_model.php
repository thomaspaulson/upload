<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Ingredientquantity_model extends CI_Model {

    function __construct(){
        parent::__construct();        
    }
    
    function get_all_items(){ 
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id',$comp_id);
	return $this->db->get('Item')->result_array();
    }
    
    function get_all_units(){
    	$this->db->order_by('unit_name','asc');
    	return $this->db->get('units')->result_array();
    }
    
    function get_all_ingredients(){
    	$this->db->order_by('ingredientname','asc');
    	return $this->db->get('specialingredient')->result_array();
    }    
    
function get_active_ingredients(){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

$this->db->where('comp_id',$comp_id);
 $this->db->where('ing_status', 'active'); 
    	$this->db->order_by('ingredientname','asc');
    	return $this->db->get('specialingredient')->result_array();
    }   
    function get_all_items_ing(){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');


        $this->db->select('*');
	$this->db->from('Item');
$this->db->where('comp_id',$comp_id);
	$this->db->order_by("itemname", "asc");		
	$this->db->join('item_ingredient', 'item_ingredient.item_id= Item.itemid');
	$this->db->join('specialingredient', 'specialingredient.ingredientid= item_ingredient.ing_id');
        $query= $this->db->get();
        return $query->result_array();
    }
    
    function get_packages(){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
$this->db->where('comp_id', $comp_id); 
$this->db->where('current_status', 'active'); 
    	return $this->db->get('specialpackage')->result_array();		
    }    
    
 function get_activepackages(){ 

$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');

$this->db->where('current_status', 'active'); 
$this->db->where('comp_id', $comp_id); 
    	return $this->db->get('specialpackage')->result_array();		
    } 


    function get_ing_item($item_id){
$comp_id=$this->session->userdata('comp_id');
$br_id=$this->session->userdata('branch_id');
        $this->db->select('*');
	$this->db->from('Item');
$this->db->where("Item.comp_id", $comp_id); 
	$this->db->order_by("itemname", "asc");	
	$this->db->where("itemid", $item_id);			
	$this->db->join('item_ingredient', 'item_ingredient.item_id= Item.itemid');
	$this->db->join('specialingredient', 'specialingredient.ingredientid= item_ingredient.ing_id');
        $query= $this->db->get();
        $result = $query->result_array();
        if($result){
        	return $result;
        }else{
        	return 0;
        }
    }
    
    function insert($data){
		$datas = array(
			'item_id' => $data['item_id'],
			'item_qty' => $data['item_qty'],
			'item_unit' => $data['item_unit'],
			'ing_id' => $data['ing_id'],
			'ing_qty' => $data['ing_qty'],
			'ing_unit' => $data['ing_unit'],
		);
	        $this->db->set($datas);
	        $this->db->insert('item_ingredient');
	        $insert_id = $this->db->insert_id();
    		return $insert_id;
    }
    



   function get_item_ingredients($item_id){
        $this->db->select('*');
	$this->db->from('item_ingredient');
	$this->db->where('item_id',$item_id);			
        $packages = $this->db->get();
        return $packages->result_array();         
    }	
    
    function raw_stock($ingredients,$additional){
    	foreach($ingredients as $ingredient){
	        $this->db->select('*');
		$this->db->from('raw_stock');
		$this->db->where('ingredient_id',$ingredient['ing_id']);			
	        $query = $this->db->get();
	        $result = $query->result_array();
	        if($result){
		        $current_stock = $result[0]['current_stock'];
		        $item_qty = $ingredient['item_qty'];		        
		        if($item_qty != 0){
		         $num = ($additional / $item_qty);
                        }else{
                         $num = $additional;
                        }
		        $ing_qty =  $ingredient['ing_qty'];
		        $ing_unit = $ingredient['ing_unit']; 
		        $tot_ing = $num * $ing_qty;
			//assume items in stock stored in units like (KG,L etc)
		        if($ing_unit == 'G'){
		        	$tot_ing = ($tot_ing/1000);
		        }else if($ing_unit == 'MG'){
		        	$tot_ing = ($tot_ing/1000000);
		        }	
		        $balance = $current_stock - $tot_ing;	                
		        $data = array(
		        	'current_stock' => $balance,	        
		        );     	
			$this->db->where('ingredient_id', $ingredient['ing_id']);
			$this->db->update('raw_stock', $data);	        
	        
	        }

            	    	
    	}            
    }




	  function restore_raw_stock($ingredients,$additional){
    	foreach($ingredients as $ingredient){
	        $this->db->select('*');
		$this->db->from('raw_stock');
		$this->db->where('ingredient_id',$ingredient['ing_id']);			
	        $query = $this->db->get();
	        $result = $query->result_array();
	        if($result){
		        $current_stock = $result[0]['current_stock'];
		        $item_qty = $ingredient['item_qty'];		        
		        if($item_qty != 0){
		         $num = ($additional / $item_qty);
                        }else{
                         $num = $additional;
                        }
		        $ing_qty =  $ingredient['ing_qty'];
		        $ing_unit = $ingredient['ing_unit']; 
		        $tot_ing = $num * $ing_qty;
			//assume items in stock stored in units like (KG,L etc)
		        if($ing_unit == 'G'){
		        	$tot_ing = ($tot_ing/1000);
		        }else if($ing_unit == 'MG'){
		        	$tot_ing = ($tot_ing/1000000);
		        }	
		        $balance = $current_stock +$tot_ing;	                
		        $data = array(
		        	'current_stock' => $balance,	        
		        );     	
			$this->db->where('ingredient_id', $ingredient['ing_id']);
			$this->db->update('raw_stock', $data);	        
	        
	        }

            	    	
    	}            
    } 
		
	





	 
		
	
	


		
}