<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


         function random_string($length) {
    		$key = '';
    		$array= array();
    		$keys = array_merge(range(0, 9), $array);

	    	for ($i = 0; $i < $length; $i++) {
	       		$key .= $keys[array_rand($keys)];
	    	}
    		return $key;
	} 
	
	 function random_slug($length) {
    		$key = '';
    		$array= array();
    		$keys = array_merge(range(0, 9), range('a','z'));

	    	for ($i = 0; $i < $length; $i++) {
	       		$key .= $keys[array_rand($keys)];
	    	}
    		return $key;
	}
	
	function remove_extra_white_spaces($string) {
		return preg_replace( '/\s+/', ' ', $string);
	}	



function changeto_dbformat($date_input) {
		$date_input= str_replace('/', '-', $date_input);
$date_input= date('Y-m-d', strtotime($date_input));
return $date_input;
	}