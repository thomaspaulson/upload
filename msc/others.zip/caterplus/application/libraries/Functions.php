<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Functions extends CI_Model{



	function get_id($slug,$table_name,$primary_key,$slug_column_name){
		$this->db->select('*');
		$this->db->from($table_name);
		$this->db->where($slug_column_name,$slug);	
		$query = $this->db->get();
		$result = $query->result_array();
		if(count($result)){
			return $result[0][$primary_key];
		}else{
			return 0;
		}    
	}

  
   	function get_slug($id,$table_name,$primary_key_column,$slug_column_name){
		$this->db->select('*');
		$this->db->from($table_name);
		$this->db->where($primary_key_column,$id);	
		$query = $this->db->get();
		$result = $query->result_array();
		if(count($result)){
			return $result[0][$slug_column_name];
		}else{
			return "Invalid";
		}   			
	}
	
	function auth($user_id,$user_pin){
		$this->db->select('*');
		$this->db->from('employee');
		$this->db->where('pin',$user_pin);
		$this->db->where('user_id',$user_id);
		$this->db->where('current_status','active');					
		$query = $this->db->get();
		$result = $query->result_array();
		if(count($result)){
			return $result[0]['employeeid'];
		}else{
			return 0;
		}  	
	
	}
	
function createPassword($length) {
		$chars = "234567890abcdefghijkmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$i = 0;
		$password = "";
		while ($i <= $length) {
			$password .= $chars{mt_rand(0,strlen($chars))};
			$i++;
		}
		return $password;
	}

	

function createmail($orderslug)
{


//orderid
$table_name='specialorder';
$primary_key_column='orderid';
$slug_column_name='orderslug';
$orderid= $this->functions->get_id($orderslug,$table_name,$primary_key_column,$slug_column_name);
//orderid

$query=$this->db->query("select * from employee e,staffrole sr where e.roleid =sr.roleid and sr.rolename='Admin'");
$result=$query->result_array();
foreach($result as $res)
{ $adminmail=$res['email'];  } 

$order_detail_item=$this->ordercollection_model->select_order($orderid);
$orderedcontainer=$this->ordercollection_model->select_orderedcontainer($orderid);


if($order_detail_item){
foreach($order_detail_item as $list)
{
$custname=$list['customername'];
$custaddress=$list['customeraddress'];
$custmob=$list['customermobile1'];
$grandtotal=$list['totalamount'];
$customeremail=$list['customeremail'];
}}


if($orderedcontainer){
foreach($orderedcontainer as $clist)
{ 
$custname=$clist['customername'];
$custaddress=$clist['customeraddress'];
$custmob=$clist['customermobile1'];
$grandtotal=$clist['totalamount'];
$customeremail=$clist['customeremail'];
}}







													
					$content = '<p>Hi  <strong>,</strong></p>';
						
						$content .= 'Successfully Ordered dishes from '.base_url().' ';
$content .= '<p>Order Id : #'.$orderid.'</p>';
$content .= '<p>Grand Total Price : £  '.$grandtotal.'</p>';
$content .= '<p>Customer Name : '.$custname.'</p>';
$content .= '<p>Customer Address : '.$custaddress.'</p>';
$content .= '<p>Customer Mob : '.$custmob.'</p>';




						$content .= '<p><table><th>Item</th><th>Quantity</th>
<th>Unit price</th><th>Total price</th>';
						
if($order_detail_item){

foreach($order_detail_item as $list)
{ $itemname=$list['itemname']; $itemquantity=$list['total_item']; $unitprice=$list['base_price_of_item']; 
$totalprice=$list['total_price']; 
$content .= '<tr><td>'.$itemname.'<td><td>'.$itemquantity.'</td><td>'.$unitprice.'</td><td>'.$totalprice.'</td></tr>';
						

}}
if($orderedcontainer){

foreach($orderedcontainer as $clist)
{ $contname=$clist['special_cname']; $conquantity=$clist['container_quantity']; $conprice=$clist['container_base_price']; 
$contotalprice=$clist['container_total_price'];

$content .= '<tr><td>'.$contname.'<td><td>'.$conquantity.'</td><td>'.$conprice.'</td><td>'.$contotalprice.'</td></tr>';
						

}}


					
						$content .= '</table><p>';
						$content .= '<p>Thank you<br/>';
						
	$array['content']=$content;
$array['adminmail']=$adminmail;		
$array['customeremail']=$customeremail;
	
return $array;
}

	
	
	
}

?>