<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class Company extends CI_Model {

    public function get()
    {
    }
}
