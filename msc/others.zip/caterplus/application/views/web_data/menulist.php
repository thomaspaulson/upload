<table border='1'>
<thead>
<th>sl no</th>
<th>Menu</th>
<th>Item Unit</th>
<th>Item Price</th>
<th>Package</th>
</thead>
<tbody>
<?php
$i= 1;

foreach($contents as $value)
{
?>
<tr>
<td><?= $i ?></td>
<td><?= $value['itemname']?> </td>
<td> <?= $value['itemunits'] ?></td>
<td><?= $value['itemprice']?></td>
<td><?= $value['item_packages']?></td>
</tr>
<?php 
$i++;
}?>
</tbody>
</table>
