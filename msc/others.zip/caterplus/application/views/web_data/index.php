<table>
<thead>
<th>sl no</th>
<th>Customer Name</th>
<th>sl no</th>
<th>Mobile no</th>
</thead>
<tbody>
<?php
$i= 1;
foreach($view as $rr)
{
?>
<tr>
<td><?= $i ?></td>
<td><?= $rr['customername']?> </td>
<td> <?= $i ?></td>
<td><?= $rr['customermobile1']?></td>
</tr>
<?php 
$i++;
}?>
</tbody>
</table>
