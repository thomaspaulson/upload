<html>
	<body>
	<h1>Kitchen</h1>
<a href="<?php echo base_url();?>logout">Logout</a> / <a href="<?php echo base_url();?>staff">Staffs</a> / <a href="<?php echo base_url();?>kitchen">Kitchen</a> / <a href="<?php echo base_url();?>items/listall">Items</a> / <a href="<?php echo base_url();?>specialevent/specialcontainer">Containers</a> / <a href="<?php echo base_url();?>supplier">Suplliers</a>
	</body>
<html>