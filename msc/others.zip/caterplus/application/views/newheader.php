<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Iqbal Catering</title>
<link href="<?php echo base_url() ?>extras/new/css/style.css" rel="stylesheet" type="text/css">
<link href='<?php echo base_url() ?>extras/new/css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url() ?>extras/new/css/fullcalendar.print.css' rel='stylesheet' media='print' />
<link media="screen" rel="stylesheet" href="<?php echo base_url() ?>extras/new/css/colorbox.css" />
<link media="screen" rel="stylesheet" href="<?php echo base_url() ?>extras/extra/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/validationEngine.jquery.css">

<script src="<?php echo base_url() ?>extras/new/js/html5.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine-en.js"></script>
<link href="<?php echo base_url() ?>extras/new/css/jquery-ui.css" rel="stylesheet" type="text/css">


<script type="text/javascript">

jQuery(document).ready(function ($) {
 jQuery("#add-items").validationEngine();
});
  
</script>

</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="<?php echo base_url();?>admin"><img src="<?php echo base_url() ?>extras/new/images/logo.png" alt=""></a></div>
<div class="header_right">
    <ul>
  
      <li> <a href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/kitchen.png" alt="">
      <h6>Kitchen</h6>
      </a> </li>
      
      <li> <a href="<?php echo base_url();?>items/listall" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/item.png" alt="">
      <h6>Items</h6>
      </a> </li>
      
      <li>  <a href="<?php echo base_url();?>specialevent/paymentcollection/balancepayment" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/payment.png" alt="">
      <h6>Payment</h6>
      </a> </li>
      
      <li> <a href="<?php echo base_url();?>settings"  class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/settings.png" alt="">
      <h6>Settings</h6>
      </a> </li>
      
      <li> <a href="#"  id="showmorebutton" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/more.png" alt="">
      <h6>More </h6>
      </a> 
      <ul class="showmore">
            <li><a href="<?php echo base_url();?>specialevent/customer/listcustomer/"><img src="<?php echo base_url() ?>extras/new/images/customers.png" alt="" title="CUSTOMERS">  </a></li>
            <li><a href="<?php echo base_url();?>specialingredients/listall"><img src="<?php echo base_url() ?>extras/new/images/ingredients.png" alt="" title="INGREDIENTS"></a></li>
            <li><a href="<?php echo base_url();?>menu/listall"><img src="<?php echo base_url() ?>extras/new/images/menu-type.png" alt="" title="MENU TYPE"></a></li>
            <li class="more-drop"><a href="<?php echo base_url();?>specialevent/orderlist"><img src="<?php echo base_url() ?>extras/new/images/manage-order.png" alt="" title="MANAGE ORDER"></a></li>
           
             <li class="more-drop"><a href="<?php echo base_url();?>staff"><img src="<?php echo base_url() ?>extras/new/images/staff.png" alt="" title="STAFF"></a></li>
              <li class="more-drop"><a href="<?php echo base_url();?>office"><img src="<?php echo base_url() ?>extras/new/images/office.png" alt="" title="OFFICE"></a></li>
               <li><a href="<?php echo base_url();?>specialevent/specialcontainer"><img src="<?php echo base_url() ?>extras/new/images/containers.png" alt="" title="CONTAINERS"></a></li>
                <li><a href="<?php echo base_url();?>specialpackage"><img src="<?php echo base_url() ?>extras/new/images/packages.png" alt="" title="PACKAGES"></a></li>
               
          </ul>
      </li>
      
      <li> <a href="<?php echo base_url();?>admin">
      <div class="user_box">
        <div class="user">
          <div class="icon"> </div>
          <div class="user_name">
             <?php $pobj = new staff_model(); ?>
<?php $bal = $pobj->get_adminname();  ?>
            <p><?php echo $bal; ?></p>
          
          </div>
          <h6>Admin</h6>
        </div>
      </div>
      </a> </li>
      
      <li> <a href="<?php echo base_url();?>logout" class="logout"><img src="<?php echo base_url() ?>extras/new/images/logout.png" alt="">
      <h6>Logout</h6>
      </a></li>
    
    </ul>
    
      </div>
<script>
$("#showmorebutton").click(function(){                
               if (!$('.showmore:visible').length)
  {         $(".showmore").fadeIn();    }
  else{ $(".showmore").fadeOut(); }
       
               });
               </script>
</header>