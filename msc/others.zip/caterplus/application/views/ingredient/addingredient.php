<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>INGREDIENT</h1></div>
<div class="master-left">
<form class="validate" id="add-items" action="<?php echo base_url();?>specialingredients/insert" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
         
         <!---->
         <div class="master-left-1">
           <div class="master-name">Ingredient Name:: *</div>         
<div class="master-select">
<input name="ingredientname" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="ingredientname">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Description: </div>         
<div class="master-select">
<input name="ingredientdescription" id="ingredientdescription" type="text" class="master-textfeild">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Ingredient Quantity Unit: *</div>         
<div class="master-select">
<select name="ingredientqtytype" class="required-1 validate[required]" id="ingredientqtytype">
           <?php
			foreach($units as $unit){
				if($data['ingredientqtytype'] != $unit['unit_name']){
			?>
			<option value="<?php echo $unit['unit_name'];  ?>"><?php echo ucfirst($unit['unit_name']);  ?></option>							
			<?php
				}
			}
			?>
</select>
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Ingredient Price: *</div>         
<div class="master-select">
<input name="ingredientprice" id="ingredientprice" type="text" class="master-textfeild validate[required,custom[number]]">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Current Stock: *</div>         
<div class="master-select">
<input name="currquantity" type="text" class="master-textfeild validate[required,custom[number]]" id="currquantity">
          </div>
          </div>
          
         
         
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Re-Order Level: *</div>         
<div class="master-select">
  <input name="reorderlevel" type="text" class="master-textfeild validate[required,custom[number]]" id="reorderlevel">
</div>
          </div>
          
         
        <input class="master-submit" type="submit" name="subscribe" value="" /> 
</form>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->

