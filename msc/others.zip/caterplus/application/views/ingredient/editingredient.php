<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>INGREDIENT</h1></div>
<div class="master-left">
<form class="validate" id="add-items" action="<?php echo base_url();?>specialingredients/update" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
         
         <!---->
         <div class="master-left-1">
           <div class="master-name">Ingredient Name:: *</div>         
<div class="master-select">
<input name="ingredientname" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="ingredientname" value="<?php echo $data['ingredientname'] ;?>">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Description: </div>         
<div class="master-select">
<input name="ingredientdescription" id="ingredientdescription" type="text" class="master-textfeild" value="<?php echo $data['ingredientdescription']; ?>">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Ingredient Quantity Unit: *</div>         
<div class="master-select">
<select name="ingredientqtytype" class="validate[required]" id="required-1">
			<option value="<?php echo $data['ingredientqtytype'];  ?>"><?php echo ucfirst($data['ingredientqtytype']);  ?></option>
			<?php
			foreach($units as $unit){
				if($data['ingredientqtytype'] != $unit['unit_name']){
			?>
			<option value="<?php echo $unit['unit_name'];  ?>"><?php echo ucfirst($unit['unit_name']);  ?></option>							
			<?php
				}
			}
			?>
</select>
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Ingredient Price: *</div>         
<div class="master-select">
<input name="ingredientprice" id="ingredientprice" type="text" class="master-textfeild validate[required,custom[number]]" value="<?php echo $data['ingredientprice'] ;?>">
          </div>
          </div>
          <?php foreach($cont as $ct){ ?>
           <!---->
         <div class="master-left-1">
           <div class="master-name">Current Stock: *</div>         
<div class="master-select">
<input name="currstock" type="text" class="master-textfeild validate[required,custom[number]]" id="currstock" value="<?php echo $ct['current_stock'] ;?>">
          </div>
          </div>
          
         
         
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Re-Order Level: *</div>         
<div class="master-select">
  <input name="reorderlevel" type="text" class="master-textfeild validate[required,custom[number]]" id="reorderlevel" value="<?php echo $ct['reorder_level'] ;?>" >
</div>
          </div>
     <?php } ?>     
        <input type="hidden" name="ingredientid" value="<?php echo $data['ingredientid']?>"/> 
        <input class="master-submit" type="submit" name="subscribe" value="" /> 
</form>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
