<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>EDIT STAFF</h1></div>
<div class="msprogrm-main">
<?php
		foreach($staffs as $staff){
		?>
<form class="validate" id="add-items" action="<?php echo base_url(); ?>staff/edit_existing_staff" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
<div class="msprogrm-left">


         <div class="master-left-1">
           <div class="master-name">Employee Name *</div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="name" value="<?php echo $staff['employeename'];  ?>">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Username: *</div>         
<div class="master-select">
<input name="username" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="username" value="<?php echo $staff['username'];  ?>">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Email: *</div>         
<div class="master-select">
<input name="email" type="text" class="master-textfeild validate[required,custom[email]]" id="email" value="<?php echo $staff['email'];  ?>">

          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Email 2: </div>         
<div class="master-select">
<input name="email2" type="text" class="master-textfeild" id="email2" value="<?php echo $staff['email2'];  ?>">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Address: </div>         
<div class="master-select">
<input name="address" type="text" class="master-textfeild validate[required]" id="address" value="<?php echo $staff['employeeaddress'];  ?>">
          </div>
          </div>
          <!---->
  <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile: *</div>         
<div class="master-select">
<input name="mobile1" type="text" class="master-textfeild validate[required,custom[phone]]" id="mobile1" value="<?php echo $staff['mobile1'];  ?>">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile 2: </div>         
<div class="master-select">
<input name="mobile2" type="text" class="master-textfeild " id="mobile2" value="<?php echo $staff['mobile2'];  ?>">
          </div>
          </div>
          <!---->


</div>
<div class="msprogrm-right">
 
       
         <div class="master-left-1">
           <div class="master-name">Ext: </div>         
<div class="master-select">
  <input id="phn_ext" type="text" name="phn_ext" class="master-textfeild" value="<?php echo $staff['phn_ext'];  ?>">
</div>
          </div>
           <!---->
 <div class="master-left-1">
           <div class="master-name">Landline Number: </div>         
<div class="master-select">
  <input id="phone" type="text" name="phone" class="master-textfeild" value="<?php echo $staff['employeephone'];  ?>">
</div>
          </div>
           <!---->
<!----><div class="master-left-1">
           <div class="master-name">Select Role: *</div>         
<div class="master-select">
<select class="required" id="required-1" name="role">
<option value="<?php echo $staff['roleid'];  ?>"><?php echo ucfirst($staff['rolename']);  ?></option>
					<?php
					foreach($roles as $role){
						if($role['rolename'] != 'Admin'){
							if($staff['rolename'] != $role['rolename']){
					?>
					<option value="<?php echo $role['roleid'];  ?>"><?php echo ucfirst($role['rolename']);  ?></option>				
					
					<?php
							}
						}
					}
					?>		

</select>
          </div>
          </div>
          

         <!---->
<div class="master-left-1">
           <div class="master-name">Select Type: *</div>         
<div class="master-select">
<select class="required" id="required-1" name="type">
	<?php
						if($staff['rolename'] == 'permanent'){
						
					?>
					<option value="permanent">Permanent</option>
					<option value="temporary">Temporary</option>
					<?php
						}else{
					?>
					<option value="temporary">Temporary</option>
					<option value="permanent">Permanent</option>
					<?php
						}
					?>				
</select>
          </div>
          </div>
          <!---->
<div class="master-left-1">
           <div class="master-name">Select Branch: *</div>         
<div class="master-select">
<select class="required-1" id="branch_id" name="branch_id">

<?php
					foreach($branches as $bran){
						
				?>
					<option value="<?php echo $bran['br_id']; ?>" 


<?php if($staff['br_id']==$bran['br_id']){ echo "selected";   } ?> >
<?php echo ucfirst($bran['br_name']);  ?></option>
				<?php
						
					}
				?>		

</select>
          </div>
          </div>
          

         <!---->

         <!---->

  <div class="master-left-1">
           <div class="master-name">Pin: </div>         
<div class="master-select">
  <input  type="text" name="pin" class="master-textfeild validate[required,custom[integer],minSize[4]]" id="pin" value="<?php echo $staff['pin'];  ?>">
</div>
          </div>
           <!---->
 <div class="master-left-1">
           <div class="master-name">User ID: </div>         
<div class="master-select">
  <input name="user_id" type="text"  class="master-textfeild validate[required,custom[integer],minSize[4]]" id="user_id" value="<?php echo $staff['user_id'];  ?>">
</div>
          </div><span id="errmsg" style="color:red;"></span>
           <!---->
         <div class="master-left-1">
           <div class="master-name">Select Image : *</div>         
<div class="master-select">
<input name="userfile" id="userfile" type="file" class="form_field_browsestyle">
<img src="<?php echo base_url(),'uploads/staff/',$staff['staff_image']; ?>" width="75" height="75">

          </div>
          </div>
       <input type="hidden" name="id" value="<?php echo $id; ?>"/>  
        <input class="master-submit" type="submit" name="subscribe" value="" /> 

</div>
          
        
</form>
<?php
		}
		?>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			

$("#user_id").blur(function() {
       //gets the value of the field
       var user_id = $("#user_id").val();
      var currentuserid=<?php echo $id; ?>;

       //here would be a good place to check if it is a valid email before posting to your db

       //displays a loader while it is checking the database
       //$("#emailError").html('');

       //here is where you send the desired data to the PHP file using ajax
var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

if(user_id)
{
       $.post("<?php echo base_url().'specialevent/ajaxprocess/index'; ?>", {user_id:user_id,currentuserid:currentuserid},
           function(result) {
         
               if(result == 1) {
                                   //the email is available
                   $("#errmsg").html("Available");
               }
               else {
                   //the email is not available
                   $('#user_id').val('');
                   $("#errmsg").html("Not available");
               }
           });
}
    });

         });


                       </script>