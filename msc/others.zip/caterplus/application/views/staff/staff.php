 
                
                 <!--   <script type="text/javascript">
                    	$(document).ready (function(){
							$('#sadvance').click (function(){
								$('.hide_serch').slideToggle()
							});
						});
                    </script> -->
                </div>
                </div>
        </header>
        <div class="container">
                <div class="row custemor_dtls ">
                	<div class="col-md-12">
                     <script type="text/javascript" src="<?php echo base_url()?>extras/mergeddesign/js/cycle.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
			$('.slider_wrap').cycle({ 
				fx:     'scrollHorz', 
				speed:  1000, 
				timeout: 5000,
				 timeout: 0,
				slideExpr:".slider",
				pager: ".pager233",
				 next: ".nxt0", 
				 prev:  ".prv0",
				
			});			
	});
</script>
                    <ul>
                    	<li class="main_header"><p>Staff Details</p>
<div class="row search_cus newstyleedited" >
                	<div class="col-md-12">

                    	<form action="<?php echo base_url();?>staff/stafffetchdetailslist" method="post" id="customemailfetch" name="customemailfetch"> 
                        	 <input type="text" placeholder="User Id / Name" name="employeename" id="employeename" autocomplete="off" value="" class="validate[required,custom[phone]]" required>
                            <input name="" type="submit" value="Search Staff"> 

<a href="<?php echo base_url();?>staff/add_new_staff" id="sadvance">New Staff</a>
 <ul class="results" id="results">
                           <!-- <a href="#" id="sadvance"> Advanced search</a>
                            <div class="clearfix"></div>
                            <div class="hide_serch"><input type="text" placeholder="Name">
                            <input type="text" placeholder="Last Name">
                            <input name="" type="submit" value="Search customer"> -->
                            </div>
                        </form>
                    </div>
                     <?php if(count($staffs)>15){?>  
                        	<div class="pag_nav">
                            	<a href="#"  class="prv0"><img src="<?php echo base_url()?>extras/mergeddesign/images/prev_p.png" width="29" height="31"></a>
                                <a href="#" class="nxt0"><img src="<?php echo base_url()?>extras/mergeddesign/images/nxtp.png" width="29" height="31"></a>
                            </div>
                            <?php } ?>
                      </li>
                      </ul>
                      <div class="slider_wrap wr">

<?php if(count($staffs)<15){?>  


 <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="name_fld">Name</li>
                                <li class="other_fld">Image</li> 
 <li class="other_fld">Phone</li>       
 <li class="other_fld">Email</li>                                    
                                <li class="other_fld">Actions</li>
                            </ul>
                      </li> 
                      
                       <?php $i=0;foreach($staffs as $value){ 
                      
                       $i++;if($i%2==0){$v=2;}else{$v=1;}  ?>
                       <?php    ?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>

                            	<li class="name_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><?php echo $value['employeename'];?></a></li>
                                <li class="other_fld"><img src="<?php echo base_url(),'uploads/staff/',$value['staff_image']; ?>" width="75" height="75"></li>
 <li class="other_fld"><?php echo $value['mobile1']; ?></li>
 <li class="other_fld"><?php echo $value['email']; ?></li>
                      <li class="other_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>staff/changestatus/<?php echo $value['employeeid'];?>" >
								                  
 <?php if ($value['current_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                               
                            </ul>
                      </li>
                   
                      
                  
                    <?php } ?>
                                            
                    </ul>

<?php }  else { ?>



                     <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="name_fld">Name</li>
                                <li class="other_fld">Image</li> 
 <li class="other_fld">Phone</li>       
 <li class="other_fld">Email</li>                                    
                                <li class="other_fld">Actions</li>
                            </ul>
                      </li> 
                      
                       <?php $i=0;foreach($staffs as $value){ 
                       if($value['rolename'] !== 'Admin'){
                       $i++;if($i%2==0){$v=2;}else{$v=1;}  if($i<=15){?>
                       <?php    ?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>

                            	<li class="name_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><?php echo $value['employeename'];?></a></li>
                                <li class="other_fld"><img src="<?php echo base_url(),'uploads/staff/',$value['staff_image']; ?>" width="75" height="75"></li>
 <li class="other_fld"><?php echo $value['mobile1']; ?></li>
 <li class="other_fld"><?php echo $value['email']; ?></li>
                      <li class="other_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>staff/changestatus/<?php echo $value['employeeid'];?>" >
								                  
 <?php if ($value['current_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                               
                            </ul>
                      </li>
                   
                      
                  
                    <?php }} }?>
                                            
                    </ul>

                  <ul class="slider wr">
                      	<li class="sub_header">
                      		<ul>
                            	<li class="name_fld">Name</li>
                                <li class="other_fld">Image</li>   
<li class="other_fld">Phone</li>       
 <li class="other_fld">Email</li>                                       
                                <li class="other_fld">Actions</li>
                            </ul>
                      </li>
                     <?php $i=0;  foreach($staffs  as $value){ 
                      if($value['rolename'] !== 'Admin'){
                     $i++;if($i%2==0){$v=2;}else{$v=1;}   if($i>30){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<ul>

                            	<li class="name_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><?php echo $value['employeename'];?></a></li>
                                <li class="other_fld"><img src="<?php echo base_url(),'uploads/staff/',$value['staff_image']; ?>" width="75" height="75"></li>
<li class="other_fld"><?php echo $value['mobile1']; ?></li>
 <li class="other_fld"><?php echo $value['email']; ?></li>
                      <li class="other_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>staff/changestatus/<?php echo $value['employeeid'];?>" >
								                  
 <?php if ($value['current_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                               
                            </ul>
                      </li>
                      
                  
                    <?php }} }?>
                    </ul>
  <ul class="slider wr">
                      	<li class="sub_header">
                      		<ul>
                            	<li class="name_fld">Name</li>
                                <li class="other_fld">Image</li>   
<li class="other_fld">Phone</li>       
 <li class="other_fld">Email</li>                                       
                                <li class="other_fld">Actions</li>
                            </ul>
                      </li>
                     <?php $i=0;  foreach($staffs  as $value){ 
                      if($value['rolename'] !== 'Admin'){
                     $i++;if($i%2==0){$v=2;}else{$v=1;}   if($i>45){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<ul>

                            	<li class="name_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><?php echo $value['employeename'];?></a></li>
                                <li class="other_fld"><img src="<?php echo base_url(),'uploads/staff/',$value['staff_image']; ?>" width="75" height="75"></li>
<li class="other_fld"><?php echo $value['mobile1']; ?></li>
 <li class="other_fld"><?php echo $value['email']; ?></li>
                      <li class="other_fld"><a href="<?php echo base_url(); ?>staff/edit_staff/<?php echo $value['slug']; ?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>staff/changestatus/<?php echo $value['employeeid'];?>" >
								                  
 <?php if ($value['current_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                               
                            </ul>
                      </li>
                      
                  
                    <?php }} }?>
                    </ul>
<?php } ?>
                    </div>
                    </div>
                </div>
                <footer>
                 <ul>
                 	
                    <li>
                    	<a href="<?php echo base_url();?>">Cancel</a>
                    </li>
                    
                    <li>
                    	<a href="<?php echo base_url();?>staff/add_new_staff">New</a>
                    </li>
                   
                 </ul>
                 </footer>
          </div>  
</body>
</html>