<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Iqbal Catering</title>
<link href="<?php echo base_url();?>extras/new/css/style.css" rel="stylesheet" type="text/css">
<link href='<?php echo base_url();?>extras/new/css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url();?>extras/new/css/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src="<?php echo base_url();?>extras/new/js/html5.js"></script>
<script src="<?php echo base_url();?>extras/new/js/jquery-1.10.2.js"></script>
<!--======= Calendar =======-->
<link href="<?php echo base_url();?>extras/new/css/jquery-ui.css" rel="stylesheet" type="text/css">

<!--======= Calendar end =========-->
<!--====== touch support =====-->
<script src="<?php echo base_url();?>extras/new/js/jquery.ui.touch-punch.js"></script>
<script>$('#widget').draggable();</script>
<!--====== touch support end =====-->

</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="#"><img src="<?php echo base_url();?>extras/new/images/logo.png" alt=""></a></div>
    
  </div>
</header>
<!--========= content ===============-->
<div class="wrapper"> 
<div class="login_wrap">
<div class="login-main">
<div class="login-main-left">
<div class="login-main-lefttop">
<a href=""><img src="<?php echo base_url();?>extras/new/images/caterplus-logo.png"></a>
</div>
<div class="login-main-leftbottom">
This is a user- friendly software specially designed to manage all your catering based events with attractive screen 
displays and effective features.This software provides important
 features such as kitchen and office management, order management, payment management, staff management and other facilities.
</div>
</div>
<div class="login-main-right">

<div class="login-main-righbottom">
<img src="<?php echo base_url();?>extras/new/images/loadingAnimation.gif">
</div>
<div class="login-main-righttop">

<div class="login_box">
          <div class="left_box">
<form action="<?php echo base_url(); ?>login/staff_login" method="post">
            <div class="hd">
              <h1>Login</h1>
            </div>

            <div class="left_from">
              <div class="col">
                <p>Username :
                  <input name="username" id="username" type="text" class="user_name">
                </p>
              </div>
              <div class="col">
                <p>Password :</p>
                <input name="password" id="password" type="password" class="password">
              </div>
              <div class="bottom_row">
                <div class="col2">
                 </div>
                <div class="col3">
                  <a></a>
                </div>
              </div>
            </div>
          </div>
          <input name="submit" type="submit" class="go" value="go">
</form>
          <div class="clear"></div>
        </div>
</div>

</div>
</div>





</div>

  <div class="clear"></div>
</div>
<!--========= content end ===============-->

</body>
</html>