<?php
if($order_detail_item){
foreach($order_detail_item as $list)
{
$custid=$list['customerId'];
$custname=$list['customername'];
$custaddress=$list['customeraddress'];
$custmob=$list['customermobile1'];
$grandtotal=$list['totalamount'];
$customeremail=$list['customeremail'];
$orderdate=$list['ordereddate'];
$deliverydate=$list['deliverydate'];
$deliverytime=$list['deliverytime'];

}}


if($orderedcontainer){
foreach($orderedcontainer as $clist)
{ 
$custid=$clist['customerId'];
$custname=$clist['customername'];
$custaddress=$clist['customeraddress'];
$custmob=$clist['customermobile1'];
$grandtotal=$clist['totalamount'];
$customeremail=$clist['customeremail'];
$orderdate=$clist['ordereddate'];
$deliverydate=$clist['deliverydate'];
$deliverytime=$clist['deliverytime'];
}}
						
?>







<!doctype html>
<html>
  <head>
  <meta charset="utf-8">
  <title>Cater Plus</title>
  <link rel="shortcut icon" href="favicon.png">
  <!--common style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>extras/print/css/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>extras/print/css/view_port.css">
  <!--font css style-->
  

  <!--bootsrap css style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url()?>extras/print/css/bootstrap.css">

  <!-- bootstrap js -->


<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>extras/print/css/elastislide.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>extras/print/css/custom.css" />
		


  <!-- tab and slide js -->
  <link type="text/css" rel="stylesheet" href="<?php echo base_url()?>extras/print/css/easy-responsive-tabs.css" />
 
<!--  <script type="text/javascript" src="js/jquery-1.10.2.min.js"></script>-->
 

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lte IE 8]>

<link rel="stylesheet" type="text/css" href="<?php echo base_url()?>extras/print/css/ie8-and-down.css" />
<![endif]-->

<link href='http://fonts.googleapis.com/css?family=Muli' rel='stylesheet' type='text/css'>

  </head>
  <body>
<div id="top_wrapper">
    <div class="container">
    <div class="row">
    	<div class="float-right">
            <div class=" col-md-3 col-sm-3" id="print_button">
            <input type="button" class="print_order" title="Print Order" onClick="window.print()">
          </div>
    
    <div class=" col-md-3 col-sm-3" id="print_button">
           <a href="<?php echo base_url()?>specialevent/customer/showcust/<?php echo $custid; ?>"><img src="<?php echo base_url()?>extras/images/neworder.png"  title="New Order from Same Customer"></a>
          </div>
          
    <div class=" col-md-3 col-sm-3" id="print_button">
           <a href="<?php echo base_url()?>specialevent/customer"><img src="<?php echo base_url()?>extras/images/order-icon.png"  title="New Order"></a>
          </div>
    
            <div class="col-md-3 col-sm-3" id="print_button">
          
     <a href="<?php echo base_url()?>specialevent/paymentcollection/balancepayment"><img src="<?php echo base_url()?>extras/print/images/homelast.png"  title="Home"></a>
          </div>
      	</div>
      </div>
  </div>
  </div>
<div id="content_wrapper">
    <div class="container ">
    	<div class="kitchen_heading wr">
        <div class="row">

        </div>
        </div>
        <div class="row bill_print">
        	<div class="col-md-12">
            	<div class="print_wrap ">

                <ul class="table_header">
               <li> <p style="font-size:93px; margin-bottom:-35px;margin-top:-11px; text-align:center;"><?php echo $orderid;?></p></br>
               
               <p style="text-align:center;">
                   Mr./Mrs. <?php echo $custname;?></br>
                    Mob No    : <?php echo $custmob;?></br>
                    Order Date: <?php echo date("d-m-Y", strtotime($orderdate));?></br>
                    Coll. Date: <?php echo date("d-m-Y", strtotime($deliverydate));?><?php echo ' '.$deliverytime;?></br>
               </p>
                    
                    </li>
                               </ul>
                <ul class="table_header">
                	<li class="item">Item</li>
                    <li class="qty">Qty</li>
                    <li class="price">Price</li>
                </ul>
<?php
 if($order_detail_item){
foreach($order_detail_item as $list)
{   
$itemunits=$list['itemunits'];
$itemname=$list['itemname']; $itemquantity=$list['total_item']; $unitprice=$list['base_price_of_item']; 
$totalprice=$list['total_price'];  ?>



                	<ul><li class="item"><?php echo $itemname;?></li>
                    <li class="qty"><?php echo $itemquantity." ".$itemunits;?></li>
                    <li class="price"><?php echo '£ '.number_format((float)$totalprice, 2, '.', '');?></li> 
                </ul>

<?php }} if($orderedcontainer){

foreach($orderedcontainer as $clist)
{ $contname=$clist['special_cname']; $conquantity=$clist['container_quantity']; $conprice=$clist['container_base_price']; 
$contotalprice=$clist['container_total_price']; ?>


                <ul>
                	<li class="item"><?php echo $contname;?></li>
                    <li class="qty"><?php echo $conquantity. ' Nos';?></li>
                    <li class="price"><?php echo '£ '.number_format((float)$contotalprice, 2, '.', '');?></li> 
                </ul>
                
<?php }} ?>
<ul  class="table_header">
  <li class="item"></li>              	
<li class="qty">Total Amount</li>
                    
                    <li class="price"><?php echo '£ '.number_format((float)$grandtotal, 2, '.', '');?></li>
                </ul>
<ul  class="table_header">
  <li class="item"></li>              	
<li class="qty">Paid Amount</li>
                    
                    <li class="price"><?php echo '£ '.number_format((float)$paidamount, 2, '.', '');?></li>
                </ul>
<ul  class="table_header">
  <li class="item"></li>              	
<li class="qty">Balance Amount</li>
                    
                    <li class="price"><?php echo '£ '.$balpay;?></li>
                </ul>
<ul class="table_header">
               <li align="center"><p style="text-align:center; font-weight:bold;">Iqbal Catering<br> Mansfield works
6a-8a Mansfield Road,Bradford BD8 7LY<br>01274 786687,01274 495963</p></li>
                               </ul>
<ul class="table_header">
               <li align="center"> <p style="text-align:center; margin-top:15px; font-size:40px;"><strong>EID MUBARAK</strong></p></li>
                               </ul>

                </div>
            </div>
        </div>
        </div>
    </div>



        
</body>
</html>