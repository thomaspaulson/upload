<option value=" ">Select Item</option>
<?php
	foreach($item as $item){
?>
<option value="<?php echo $item['itemid'];?>"><?php echo $item['itemname'];?></option>;
<?php 
	} 
?>




