<!-- Dummy Page for creating delivery time-->



<body>
<div id="top_wrapper">
    <div class="container">
    <div class="row">
        <div class=" col-md-3 col-sm-3">
        <div class="caterplus_logo"> <img src="<?php echo base_url();?>extras/images/caterplus_logo.png" alt="Cater Plus"> </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_sett_ord">
            <div class="top_settings"> <a href="#"><img src="<?php echo base_url();?>extras/images/top_settings.png" title="" alt="Cater Plus"></a> </div>
            <div class="top_order"> Order No : <?php echo $orderid;?></div>
          </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_dropdown">
         <!--   <select class="top_dropdown_style">
            <option>--Select--</option>
          </select> -->
          </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_search">
          <!--  <form action="#" method="post">
            <input name="" type="text" class="search_01"   />
            <button class="btn" title="Submit"></button>
          </form> -->
          </div>
      </div>
      </div>
  </div>
  </div>
<div id="content_wrapper">
    <div class="container">
    <div class="row content_bg">
        <div class="col-md-12">
        <div class="customerorder_frame">
            <div class="customername_orderframe">
            <div class="customername_orderframe_back"> <a href="#"><img src="<?php echo base_url();?>extras/images/customer_image.png" alt="cater plus"></a> </div>
            <div class="customername_orderno"> <a href="#"><?php echo $custname; ?></a> </div>
            <div class="customer_plus">
                <input type="button" class="customer_plus_btn" title="add here">
              </div>
          </div>
            <div class="clearfix"></div>
            
            
            
            
            
          
            <div class="customer_filling_frame">
              <div class="customer_over">
            <div class="customer_filling">
                <div class="customer_filling_top_title">
                <div class="customer_name">Name</div>
                <div class="customer_pkg">Qty<br/> <span class="kg"> </span></div>
                <div class="customer_qty">Nos</div>
                <div class="customer_totalqty">Total Qty<br/><span  
                class="kg"></span></div>
                 <div class="customer_unit">Unit Price<br/><span  
                class="kg"></span></div>
                <div class="customer_total">Total Price<br/><span  
                class="kg"></span></div>
              </div>
                
                <form>
                
              <div id="appendsection"></div>

              </div>
              </div>

            <div class="customer_filling_result">
              <!--  <div class="sub_total">Sub Total   :   $385</div> -->
               <!-- <div class="total">SubTotal <span class="total_color"> :   $385</span></div> -->
              </div>
            <div class="customer_filling_result">
            <!--    <div class="sub_total">Discount    :   $30</div> -->
                <div class="total"></div>
              </div>
            <div class="customer_filling_result">
            <!--    <div class="sub_total">Tax              :   $10</div> -->
                <div class="total" >Grand Total :£ <span class="balncetotal_color" id="displaygrandtotal">00.00</span></div>
              </div>
            
              
              
              
            <div class="clearfix"></div>
            <div class="customer_btm_btn">

<input type="hidden" name="orderid" value="<?php echo $orderid;?>" id="orderid"/>
<input type="hidden" name="custid" value="<?php echo $custid;?>" id="custid"/>


                <input type="submit" class="cancel_order" value="Cancel Order" title="Cancel Order" name="cancelorder">
<!--                <input type="submit" class="cancel_order" value="Hold Order" title="Hold Order"  name="holdorder"> -->
                <input type="submit" class="send_order" value="Confirm Order" title="Send Order"  name="confirmorder">
 </form>
              </div>
              
             <!------>
            <div class="clearfix"></div>
            <div class="five_buttons_frame">
                <!-- <div class="add_extra_items_frame">
                <input type="button" class="add_extra_items" alt="add extra items">
                <span class="five_btn_txt">Add <br>
                  Extra Item</span> </div>
                <div class="add_extra_items_frame">
                <input type="button" class="amount_order" title="Amount Order">
                <span class="five_btn_txt">Amount <br>
                  Order</span> </div>
                <div class="add_extra_items_frame">
                <input type="button" class="track_order" title="Track Order">
                <span class="five_btn_txt">Track <br>
                  Order</span> </div>  
<div class="add_extra_items_frame">
                <input type="button" class="pay" title="Pay">
                <span class="five_btn_txt">Pay <br>
                  </span> </div>-->
               <!-- <div class="add_extra_items_frame">
                <input type="button" class="print_order" title="Print Order">
                <span class="five_btn_txt">Print Order</span> </div>-->
                
              </div>
          </div>
      
          
          </div>
          
          
          
          
          
          
          
          
          
          
        <div class="bookyour_order_frame">
            <div class="bookyour_order">Select Dishes </div>
            <div class="booking_frame">
            <div class="booking_slide">
                <div class="left_green_textframe">
                <div class="left_green_text1">Menu</div>
              </div>
                <div class="demo"> 
                




                <!--Horizontal Tab-->
                <div id="horizontalTab">
                    <ul class="resp-tabs-list">
<?php if($menu){
$menucount=count($menu);
foreach($menu as $menulist){?>
                    <li><?php echo $menulist['menutypename'];?></li>
                    
<?php }
} ?>
                  </ul>


                    
              <div class="resp-tabs-container">
                             
                           <?php  if($menu){ $i=0;                        
                             foreach($menu as $itemmenu)
                             { $menuid=$itemmenu['menutypeid']; ?>
                             <div>
                             
				<ul id="<?php echo 'carousel'.$i;?>" class="elastislide-list">
				
			<?php	$data['item'] = $this->specialitem_model->select_item($menuid);
			
				
				foreach($data['item'] as $itemlist)
				{  $itemid=$itemlist['itemid']; $itemname=$itemlist['itemname'];  
				$itembasicp=$itemlist['itemprice'];  ?>
				 
				 <li>
				 <a href="#"><img src="<?php echo base_url();?>uploads/items/<?php echo $itemlist['item_image'];?>"
				  alt="<?php echo $itembasicp; ?>" 
				 name="<?php echo $itemname; ?>" id="<?php echo $itemid; ?>" onclick="selectitem(this.id,this.name,this.alt)"/><?php echo $itemname; ?></a></li>
				 
			<?php	 } ?>
				    
				</ul>                 
                            </div>
                           <?php  } }?>
                            
                            
		            
                  </div>
                  <!--close container resp-tabs-container-->
                  </div>
                  </div>
                  <div class="list_line"></div>
              </div>
              
              
                <div class="clearfix"></div>
                
                <div class="left_green_textframe">
                <div class="left_green_text2">Packs</div>
              </div>
              
              
                <div class="container_frame">
                <ul id="carousel101" class="elastislide-list">
					
                   <?php if($packages) { foreach($packages as $plist){ $pakageid=$plist['specialp_id']; 
                   $pakageqty=$plist['specialp_qty']; ?>
                    <li><a class="container_bg" href="#" id="<?php echo $pakageid; ?>" 
                    name="<?php echo $pakageqty; ?>" onclick="selectpackage(this.id,this.name)" >
                     <span class="pack_inner_text1">
                    <?php echo $plist['specialp_qty'];?></span> <span class="pack_inner_rate"></span> </a></li>
                    <?php } } ?>
				</ul> 
                
                <br>

                     <div class="list_line"></div>
                      <div class="clearfix"></div>
              </div>

                <div class="clearfix"></div>
                
                <div class="left_green_textframe">
                <div class="left_green_text2">Container</div>
              </div>
              
                <div class="container_frame">
                <ul id="carousel102" class="elastislide-list">
                 <?php if($containers) { foreach($containers as $clist){
 $conid=$clist['special_cid'];
 $conprice=$clist['special_cprice']; 
 $conname=$clist['special_cname']; ?>
		<li><a class="container_bg" href="#" rel="<?php echo $conname;?>" 
id="<?php echo $conid;?>" name=<?php echo $conprice;?>
 onclick="selectcontainer(this.id,this.name,this.rel)"> <span class="pack_inner_text1"><?php echo $clist['special_cname'];?>
		</span> <span class="pack_inner_rate"><?php echo '$'.$clist['special_cprice'];?></span> </a></li>
		 <?php } } ?>			
				</ul>
                
                
                
                
                
                
                <br>

                     <div class="list_line"></div>
              </div>
                <div class="clearfix"></div>
             <!--    <div class="left_green_textframe">
                <div class="left_green_text2"></div>
              </div>
               <div class="container_frame">
                <ul id="carousel104" class="elastislide-list">
					<li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
					<li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
                    <li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
                    <li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
                    <li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
				</ul>
              </div>-->
              
              </div>
          </div>
          </div>
      </div>
      </div>
  </div>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 


		<script type="text/javascript" src="<?php echo base_url();?>extras/js/jquerypp.custom.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>extras/js/jquery.elastislide.js"></script>
		<script type="text/javascript">
			var mmenu=<?php echo $menucount;?>;
			for(var i=0;i<mmenu;i++){
			        $( '#carousel'+i).elastislide();				
				} 

				$( '#carousel102' ).elastislide();
				$( '#carousel101' ).elastislide();
				$( '#carousel104' ).elastislide();
			
		</script>
		















<!--pop up -->
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
 <link type="text/css" rel="stylesheet" href="<?php echo base_url();?>extras/css/easy-responsive-tabs.css" />
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/newstyle.css">
 <div class="popupWrap2a popup2">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
     <!-- tab and slide js -->
 
<!-- tab and slide js end -->
<div class="col-lg-12 col-md-7 collection_time column" >
                    <!--<h4>Collection time</h4>-->
                        
			<div class="wr">
            <div class="tabbable" id="tabs-84203">
				<ul class="nav nav-tabs">
					<li class="active">
						<a href="#panel-1" data-toggle="tab" id="panel-12">
                       <img src="<?php echo base_url()?>extras/images/mng_icon.png">
                         <span>Morning</span></a>
					</li>
					<li>
						<a href="#panel-2" data-toggle="tab" id="panel-23">
                       <img src="<?php echo base_url()?>extras/images/Sun.png">
                         <span>After noon</span></a>
					</li>
                    <li>
						<a href="#panel-3" data-toggle="tab" id="panel-34">
                       <img src="<?php echo base_url()?>extras/images/sun_low.png">
                         <span>Evening</span></a>
					</li>
                    <li>
						<a href="#panel-4" data-toggle="tab" id="panel-45">
                       <img src="<?php echo base_url()?>extras/images/cm.png">
                         <span>Night</span></a>
					</li>

				</ul><input type="date" name="dsf" />
				<div class="tab-content custom_tab">
					<div class="tab-pane active" id="panel-1">
						<div class="time_wrap ">
                        	<div class="time_inner">
                            	<ul>
                                    <li><span class="left_time">10.00 - 10.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">10.30 - 11.00</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">11.00 - 11.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li class="active"><span class="left_time">11.30 - 12.00</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
<li><span class="left_time">12.30 - 13.00</span>
                                    <span class="right_order">10   Orders</span></li>
<li><span class="left_time">13.00 - 13.30</span>
                                    <span class="right_order">10   Orders</span></li>
<li><span class="left_time">13.30 - 14.00</span>
                                    <span class="right_order">10   Orders</span></li>

                                </ul>
                            </div>
                        </div>
					</div>
					<div class="tab-pane" id="panel-2">
						<div class="time_wrap time_wrap2"><div class="time_inner">
                            	<ul>
                                	<li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li class="active"><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                </ul>
                            </div></div>
					</div>
                    <div class="tab-pane" id="panel-3">
						<div class="time_wrap time_wrap3"><div class="time_inner">
                            	<ul>
                                	<li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li class="active"><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                </ul>
                            </div></div>
					</div>
                    <div class="tab-pane" id="panel-4">
						<div class="time_wrap time_wrap4"><div class="time_inner">
                            	<ul>
                                	<li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li class="active"><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                    <li><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order">10   Orders</span></li>
                                </ul>
                            </div></div>
					</div>
                    
				</div>
			</div></div>
			<input name="" type="submit" value="Select Menu">		
                    </div>
  
    </div>
    </div>   
<!--pop up -->



 <script type="text/javascript">

		$(document).ready(function() {


				$(".popup2").show(300);





}); 
		</script>



<script type="text/javascript">
$(document).ready (function(){
$('.time_inner li').click(function() {
$('.time_inner li').removeClass('active');
$(this).addClass('active');
});
});
</script>









</body>
</html>