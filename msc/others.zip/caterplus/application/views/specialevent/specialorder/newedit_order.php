<?php 
//print_r($orderitem);
//print_r($ordercontainer);

$orderid='';
$custname='';
$mobile='';
$email='';
$address='';
$orderdate='';
$deliverydate='';
$deliverytime='';
$pstatus='';
$totalamount='';
$collection_status='';



if(($orderitem)||($ordercontainer)){ 
foreach($orderitem as $itlist) { 
$custid=$itlist['customer_id'];
$orderid=$itlist['orderid'];
$custname=$itlist['customername'];
$mobile=$itlist['customermobile1'];
$email=$itlist['customeremail'];
$address=$itlist['customeraddress'];
$orderdate=$itlist['ordereddate'];
$deliverydate=$itlist['deliverydate'];
$deliverytime=$itlist['deliverytime'];
$pstatus=$itlist['payment_status'];
$totalamount=$itlist['totalamount'];
$collection_status=$itlist['collection_status'];
$orderslug=$itlist['orderslug'];
/*$balamount=$itlist['']; */
}
foreach($ordercontainer as $citlist) { 
$custid=$citlist['customer_id'];
$orderid=$citlist['orderid'];
$custname=$citlist['customername'];
$mobile=$citlist['customermobile1'];
$email=$citlist['customeremail'];
$address=$citlist['customeraddress'];
$orderdate=$citlist['ordereddate'];
$deliverydate=$citlist['deliverydate'];
$deliverytime=$citlist['deliverytime'];
$pstatus=$citlist['payment_status'];
$totalamount=$citlist['totalamount'];
$collection_status=$citlist['collection_status'];
$orderslug=$citlist['orderslug'];
/*$balamount=$itlist['']; */
}
}  if($menu){
$menucount=count($menu); } ?>
<script>
$(document).ready(function(){

<?php
for($i=1;$i<=$menucount;$i++){ ?>

 



	$(".tab_0<?php echo $i; ?>").click(function(){
    $(".tab_cont_0<?php echo $i; ?>").show(); 
    
    
    
    
    <?php
   $x=0;
for($v=1;$v<=$menucount;$v++)	{ $x=$x+1; $tt=($x*3)-1; if($v==$i) { continue; } ?>
     $(".tab_cont_0<?php echo $v; ?>").hide();
$(".tab_0<?php echo $v; ?>").removeClass("active");	
 
 
 
 nextulidi="flexiselDemo<?php echo $tt; ?>"; // when select next tab remove all pkg list (x*3)-1
 $('#'+nextulidi).empty(); 	  

 
    <?php } ?>
  $(this).addClass("active");
});

<?php } ?>
});
</script>
<!--tab end-->

<!--li active-->
<script type="text/javascript">
                    	$(document).ready (function(){
							$('.hidedish li').click(function() {
   $('.hidedish li').removeClass('menu-active');
	 $('.slider-2bg').removeClass('menu-active');
    $(this).addClass('menu-active');
});

	$('.slider-2bg').click(function() { 
   $('.slider-2bg').removeClass('menu-active');
	
    $(this).addClass('menu-active');
});			

$('.hidecontainer li').click(function() {
   $('.hidecontainer li').removeClass('menu-active');
	
    $(this).addClass('menu-active');
});		


		});
                    </script>


<!--li active end-->

</head>

<body class="bg_image">

<!--========= content ===============-->
<div class="wrapper">
  <div class="slider-tab-hd">
    <div class="slider-tab-hdleft"> Select Dishes</div>
    <div class="slider-tab-hdright">
      <div class="slider-tab-user"><?php echo $custname; ?></div>
      <div class="slider-tab-order">Order No: <?php echo  $orderid;?></div>
    </div>
  </div>
  <div class="superadmin-add-tab">
    <div class="tab">
      <div class="tab_menu">
        <ul>
    <?php if($menu){
$menucount=count($menu);
$i=1;
foreach($menu as $menulist){ 
//color tab
if($i==6){ $tcolor1='FA610B'; }
if($i>5){
if($tcolor1=='fff') { $tcolor1='FA610B';} 
$x=rand(1000,20000)+rand(1386,20011)+5589; $dec=hexdec($tcolor1)+$x;  $tcolor1=dechex($dec);
 }
//color tab ends
 
if($i==1){ ?> 
<li class="tab_0<?php echo $i; ?> active">
<?php echo $menulist['menutypename'];?></li>
<?php } else { ?>

                    <li class="tab_0<?php echo $i; ?>" style=""><?php echo $menulist['menutypename'];?></li> 
                    
<?php } $i++; }
} ?>
       
          
        </ul>
      </div>
      
      
      
      <?php if($menu){
$menucount=count($menu);
$i=0; $j=0;
foreach($menu as $itemmenu){ 

$menuid=$itemmenu['menutypeid']; ?>
      
      <div class="tab_content tab_cont_0<?php echo ++$j;?>" >
      
     


        <ul id="flexiselDemo<?php echo ++$i;?>" class="hidedish">
        
    <?php	$data['item'] = $this->specialitem_model->select_item($menuid);
			
				
				foreach($data['item'] as $itemlist)
				{  $itemid=$itemlist['itemid']; $itemname=$itemlist['itemname'];  
				$itembasicp=$itemlist['itemprice'];  ?>
				
          <li >
          <input type="hidden" name="price" id="price"/>
				 <input type="hidden" name="name" id="name"/>
				 <input type="hidden" name="id" id="id"/>
				 <input type="hidden" name="grandt" id="grandt" value="<?php echo $totalamount;?>"/>
				 <input type="hidden" name="containid" id="containid"/>
				 <input type="hidden" name="containprice" id="containprice"/>
				 
				<img src="<?php echo base_url();?>uploads/items/<?php echo $itemlist['item_image'];?>"
				  alt="<?php echo $itembasicp; ?>" 
				 name="<?php echo $itemname; ?>" id="<?php echo $itemid; ?>" 
				 onClick="selectitem(this.id,this.name,this.alt,<?php echo $i; ?>)" width="105" height="82"  /> <?php echo $itemname; ?></li>
            <?php	 } ?>
            
        </ul>
        <div class="clearout"></div>
        <div class="tab-cont-2">
        
          <ul id="flexiselDemo<?php echo ++$i;?>" class="hidepack">
          
         <?php if($packages) { foreach($packages as $cpack){?>
<li class="slider-3bg"></li>          
        <?php } } ?>      



          </ul>
        </div>
        <div class="clearout"></div>
         <div class="tab-cont-2">
        <ul id="flexiselDemo<?php echo ++$i;?>" class="hidecontainer">
        
       <?php if($containers) { foreach($containers as $clist){
 $conid=$clist['special_cid'];
 $conprice=$clist['special_cprice']; 
 $conname=$clist['special_cname']; ?>       
        
        
        
          <li class="slider-3bg">
          
          
            <a class="container_bg" href="#" rel="<?php echo $conname;?>" 
id="<?php echo $conid;?>" name=<?php echo $conprice;?>
 onclick="selectcontainer(this.id,this.name,this.rel)"><p><?php echo $clist['special_cname'];?> <br>
              <?php echo '£'.$clist['special_cprice'];?></p></a>
          </li>
          
      <?php } } ?>	
        </ul>
        </div>
      </div>
      
      <?php } } ?>
      
      
      
      
      
      
      
      
      
      
      <div class="select_menu_button"><a href="#"><img src="<?php echo base_url()?>extras/new/images/menu.png"></a></div>
      <div class="select_packs_button"><a href="#"><img src="<?php echo base_url()?>extras/new/images/packs.png"></a></div>
      <div class="select_container_button"><a href="#"><img src="<?php echo base_url()?>extras/new/images/container.png"></a></div>
    </div>
    <div class="order-summery">
      <div class="order-summeryhd">Order Summary</div>
      <div class="order-summery-cont">
        <div class="order-summery-conthd">
        
        
        
   <table cellpadding="0" cellspacing="0" border="0" width="100%">
            <tr>
              <td class="order-name"><h1>Name</h1></td>
              <td class="order-pkgqty"><h1>Pkg Qty</h1>
                <p>(kg/lb/pcs)</p></td>
              <td class="order-pkgnbr"><h1>Pkg Nos</h1></td>
              <td class="order-pkgqty"><h1>Total Qty </h1>
                <p>( kg/pcs)</p></td>
              <td class="order-pkgqty"><h1>Unit Price (£)</h1></td>
              <td class="order-pkgqty"><h1>Total Price (£)</h1></td>
              <td class="order-pkgqty"></td>
            </tr>
          </table>     
        </div>
        
        
        
        
         <form name="orderform" id="orderform" action="<?php echo base_url()?>specialevent/takeorder/updatespecialorder" method="post">
         <input type="hidden" name="orderid" value="<?php echo $orderid;?>" id="orderid"/>
<input type="hidden" name="custid" value="<?php echo $custid;?>" id="custid"/>
 <input type="hidden" name="orderslug" value="<?php echo $orderslug;?>" id="orderslug"/>
          
        
        <div class="order-summery-main" id="appendsection"> <!--main div--> 
          
          <?php if($orderitem){ foreach($orderitem as $itemlist) {   $itembprice=$itemlist['itemprice']; $total_item=$itemlist['total_item'];
 $itemid=$itemlist['itemid']; $packageid=$itemlist['packageid']; $packqty= $itemlist['package_quantity']; $itmunit=$itemlist['itemunits'];
 $package_ordered_number=$itemlist['package_ordered_number']; $total_price=$itemlist['total_price']; $uniqqid=$itemid.'_'.$packageid; 
 $itmname=$itemlist['itemname'];?>
          <!--repeating div-->  
          <div class="order-summery-container" id="displayrow<?php echo $uniqqid; ?>"><table cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td class="order-name" id="displayitemname<?php echo $uniqqid; ?>"><?php echo $itmname; ?> </td><td class="itemunits" id="displaypkgqty<?php echo $uniqqid; ?>"><?php echo $packqty;?></td><td class="itemunits" id="unittype"><?php echo $itmunit; ?></td><td class="order-pkgnbr"><div class="pkg-main"><input type="button" class="pkg-plus" title="add here" onclick="addf(this.id)" id="button_pkgnum_<?php echo $uniqqid; ?>"><input type="hidden" class="customer_text-area" name="packageid_<?php echo $uniqqid; ?>" id="packageid_<?php echo $uniqqid; ?>" value="<?php echo $packageid;?>"><input type="hidden" class="customer_text-area" name="itemid_<?php echo $itemid; ?>" id="itemid_<?php echo $itemid; ?>" value="<?php echo $itemid; ?>"><input type="text" onblur="textinsert(this.id,'<?php echo $uniqqid; ?>')" class="customer_text-area" title="textfield" id="pkgnum_<?php echo $uniqqid; ?>" value="<?php echo $package_ordered_number;?>" name="pkgnum_<?php echo $uniqqid; ?>"><input type="button" class="pkg-mins" title="remove here" onclick="minusf(this.id)" id="button_pkgnum_<?php echo $uniqqid; ?>"></div></td><td class="order-pkgqty" id="displaytotalqty<?php echo $uniqqid; ?>"><?php echo $total_item;?></td><td class="order-pkgqty" id="displayunitprice<?php echo $uniqqid; ?>"><?php echo $itembprice;?></td><td class="order-pkgqty" id="displaytotalprice<?php echo $uniqqid; ?>"><?php echo $total_price;?></td><td><a><img src="<?php echo base_url();?>extras/new/images/remove-button.png" class="remove-button" onclick="removitem('displayrow<?php echo $uniqqid; ?>','displaytotalprice<?php echo $uniqqid; ?>')"></a></td></tr></tbody></table></div>         
          <!--repeating div end-->
          <?php } }?>
          
          <?php if($ordercontainer){ foreach($ordercontainer as $conlist) {        // var uniqid="container_"+contid+"_"+contprice; 
   $contprice= $conlist['container_base_price'];      $con_name= $conlist['special_cname']; $con_id=$conlist['container_id'];   
   $cont_uniq=$con_id.'_'.$contprice; $con_tprice= $conlist['container_total_price'] ?>    
         <div class="order-summery-container" id="displayrowcontainer_<?php echo $cont_uniq;?>"><table cellpadding="0" cellspacing="0" border="0" width="100%"><tbody><tr><td class="order-name" id="displayname_container_<?php echo $cont_uniq;?>"><?php echo $con_name.'  Container';?></td><td class="order-pkgqty" id="displaycontainer_<?php echo $cont_uniq;?>"></td><td class="order-pkgnbr"><div class="pkg-main"><input type="button" class="pkg-plus" title="add here" onclick="addfcontainer(this.id)" id="button_containernos_<?php echo $con_id;?>"><input type="hidden" class="customer_text-area" name="containerid_<?php echo $con_id;?>" id="containerid_<?php echo $con_id;?>" value="<?php echo $con_id;?>"><input type="text" class="customer_text-area" title="textfield" readonly id="containernos_<?php echo $con_id;?>" value="<?php echo $conlist['container_quantity']; ?>" name="containernos_<?php echo $con_id;?>"><input type="button" class="pkg-mins" title="remove here" onclick="minuscontainerf(this.id)" id="button_containernos_<?php echo $con_id;?>"></div></td><td id="displays<?php echo $con_id;?>" class="order-pkgqty"></td><td id="displayprice_<?php echo $con_id;?>" class="order-pkgqty"><?php echo $contprice;?></td><td class="order-pkgqty" id="displaytotalprice<?php echo $con_id;?>"><?php echo $con_tprice;?></td><td><a><img src="<?php echo base_url();?>extras/new/images/remove-button.png" class="remove-button" onclick="removitem('displayrowcontainer_<?php echo $cont_uniq;?>','displaytotalprice<?php echo $con_id;?>')"></a></td></tr></tbody></table></div>
          
          <?php 
          } 
         }
         ?>
          
          
        </div> <!--main div end-->
        <div class="order-totalmain"> <a href="#">
          <div><input type="submit" class="order-cancel" value="Cancel Edit" title="Cancel Order" name="cancelorder"
 id="ordercancel" onclick="this.style.visibility='hidden'; orderconfirm.style.visibility='hidden';"> </div>
          </a> <a href="#">
          <div><input type="submit" class="order-confirm" value="Confirm Edit" title="Send Order"  name="confirmorder" id="orderconfirm" onclick="this.style.visibility='hidden'; ordercancel.style.visibility='hidden';" />  </div>
          </a>
          <div class="order-total">Grand Total :<span style="color:red;">£ </span> <span id="displaygrandtotal"><?php echo $totalamount;?></span></div>
        </div>
        
       
        </form>
        
        
        
        
        
      </div>
    </div>
  </div>
  <div class="clear"></div>
  

</div>
<div class="clear"></div>
<!--========= content end ===============-->


<script type="text/javascript">

$(document).ready(function(){
<?php $totslider=3*$menucount;
for($tslider=1;$tslider<=$totslider;$tslider++)
{ ?>

    $("#flexiselDemo<?php echo $tslider; ?>").flexisel( { clone:false });
	
	<?php } ?>
       
});
</script> 
<script type="text/javascript">
	Element.cleanWhitespace('content');
	init();
</script>


<!--addorder script starts-->




<script type="text/javascript">
		 	
		
		function selectitem(itid,itname,itprice,currentparenti)
		{
			
		nexti=currentparenti+1; 
		nextulid="flexiselDemo"+nexti; //to append via ajax to this id
		$('#'+nextulid).empty(); //remove current packages for appending next packages
		
   
  var dataString = 'itid='+itid+'&nextulid='+nextulid;
 
 $('#name').val(itname);
		$('#price').val(itprice);
		$('#id').val(itid);
		
	doAjax(dataString,nextulid);	//pass values to get response
		
		}
		
		
		
	
		
		
		
	function doAjax(dataString,nextulid) {
	
base_ajaxurl='<?php echo base_url()?>';
		 $.ajax({
    type:'POST',
    data:dataString,
    url:base_ajaxurl+'getitempackageajax/packagelist',
    success:function(data) {
    if(data!=0)
    {
    
  $('#'+nextulid).append(data);
        
      }
      else { alert("No package Found for This Dish or Communication Error.");}
    }
  });
	
	}		
		

		
		function selectpackage(pid,pqty,classnam,pkgunit)
		{
		
		
		
   $('.slider-2bg').removeClass('menu-active');
	
    $('.'+classnam).addClass('slider-2bg menu-active');
			

		
		itemid=$('#id').val();
		itemprice=$('#price').val();
		itemname=$('#name').val();


if(itemid)
{}else{ alert("please select an item"); exit;}

var uniid=itemid+"_"+pid;



if ($('#displayrow'+uniid).length > 0) { 


}
else{
var remrowid ='displayrow'+uniid;
var remdisptotal='displaytotalprice'+uniid;


var torow="<div class='order-summery-container' id='displayrow"+uniid+"'><table cellpadding='0' cellspacing='0' border='0' width='100%'><tr><td class='order-name' id='displayitemname"+uniid+"'></td><td class='itemunits' id='displaypkgqty"+uniid+"'></td><td class='itemunits' id='unittype'>"+pkgunit+"</td><td class='order-pkgnbr'><div class='pkg-main'><input type='button' class='pkg-plus' title='add here' onclick='addf(this.id)' id='button_pkgnum_"+uniid+"'><input type='hidden' class='customer_text-area' name='packageid_"+uniid+"' id='packageid_"+uniid+"' value='"+pid+"'/><input type='hidden' class='customer_text-area' name='itemid_"+itemid+"' id='itemid_"+itemid+"' value='"+itemid+"'/><input type='text' onblur=textinsert(this.id,"+ "'" + uniid+ "'" + ") class='customer_text-area' title='textfield' id='pkgnum_"+uniid+"' value='1' name='pkgnum_"+uniid+"'><input type='button' class='pkg-mins' title='remove here' onclick='minusf(this.id)' id='button_pkgnum_"+uniid+"'></div></td><td class='order-pkgqty' id='displaytotalqty"+uniid+"'></td><td class='order-pkgqty' id='displayunitprice"+uniid+"'></td><td class='order-pkgqty' id='displaytotalprice"+uniid+"'></td><td><a ><img src='<?php echo base_url()?>extras/new/images/remove-button.png' class='remove-button' onclick=removitem("+ "'" + remrowid+ "'" +","+ "'" + remdisptotal + "'" + ")></a></td></tr></table></div> ";





$('#appendsection').append(torow);
$('#displayitemname'+uniid).html(itemname);
$('#displaypkgqty'+uniid).html(pqty);


//scroller focus down
//var objDiv = document.getElementById("forscroller");
//objDiv.scrollTop = objDiv.scrollHeight;
//scroller focus down






//calc pkg and pkg nos
numpackage=$('#pkgnum_'+uniid).val();
calctotalqty=numpackage*pqty;


//calc ends
$('#displaytotalqty'+uniid).html(calctotalqty);
//calc unit price and total kg
calctotalprice=calctotalqty*itemprice;

//newupdation
calctotalprice=parseFloat(calctotalprice).toFixed(2);
//new updation ended

$('#displayunitprice'+uniid).html(itemprice);
$('#displaytotalprice'+uniid).html(calctotalprice);
//calc ends



var tempttl=($('#grandt').val());
var calctotalprice= parseFloat(calctotalprice);
var tempt=parseFloat(tempttl);

var gtotal=calctotalprice+tempt; // calculate grand total


//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended

$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display

}
		
		} //select package ends



function selectcontainer(contid,contprice,contname)
{

var uniqid="container_"+contid+"_"+contprice;

if ($('#displayrow'+uniqid).length > 0) { 

   
}
else{

var remrowid ='displayrow'+uniqid;
var remdisptotal='displaytotalprice'+contid;

var to2row="<div class='order-summery-container' id='displayrow"+uniqid+"'><table cellpadding='0' cellspacing='0' border='0' width='100%'><tr><td class='order-name' id='displayname_"+uniqid+"'></td><td class='order-pkgqty' id='display"+uniqid+"'></td><td class='order-pkgnbr'><div class='pkg-main'><input type='button' class='pkg-plus' title='add here' onclick='addfcontainer(this.id)' id='button_containernos_"+contid+"'><input type='hidden' class='customer_text-area' name='containerid_"+contid+"' id='containerid_"+contid+"' value='"+contid+"'/><input type='text'  class='customer_text-area' title='textfield' id='containernos_"+contid+"' value='1' name='containernos_"+contid+"' readonly><input type='button' class='pkg-mins' title='remove here' onclick='minuscontainerf(this.id)' id='button_containernos_"+contid+"'></div></td><td id='displays"+contid+"' class='order-pkgqty'></td><td id='displayprice_"+contid+"' class='order-pkgqty'></td><td class='order-pkgqty' id='displaytotalprice"+contid+"'></td><td><a><img src='<?php echo base_url()?>extras/new/images/remove-button.png' class='remove-button' onclick=removitem("+ "'" + remrowid+ "'" +","+ "'" + remdisptotal + "'" + ")></a></td></tr></table></div> ";







$('#appendsection').append(to2row);





//scroller focus down
//var objDiv = document.getElementById("forscroller");
//objDiv.scrollTop = objDiv.scrollHeight;
//scroller focus down





contname=contname+" Container";
$('#displayname_'+uniqid).html(contname);//show con name
$('#displayprice_'+contid).html(contprice);//show con price
numcon=$('#containernos_'+contid).val();

contotal=contprice*numcon;
//newupdation
contotal=parseFloat(contotal).toFixed(2);
//new updation ended


$('#displaytotalprice'+contid).html(contotal);//show sub total price


var tempttl=($('#grandt').val()); // get grand total from temp
var tempt=parseFloat(tempttl); //convert to float
var contotal= parseFloat(contotal);//convert to float sub total
var currgrandtotal=tempt+contotal; // grand total



//newupdation
currgrandtotal=parseFloat(currgrandtotal).toFixed(2);
//new updation ended
$('#grandt').val(currgrandtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(currgrandtotal); //put grand total value display

}
} //select container ends
</script>


<script>
//spinner starts
	function minusf(input) {
		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                if(parsedval==0)
                 {}
                 else{
                 newval=parsedval-1;
                 document.getElementById(inputid).value=newval;

//spinner ends

uniids=input.replace('button_pkgnum_','');



//calc pkg and pkg nos
numpackage=$('#pkgnum_'+uniids).val();

pqty=document.getElementById('displaypkgqty'+uniids).innerHTML;
var pqty=parseFloat(pqty);
calctotalqty=numpackage*pqty;
//calc ends
$('#displaytotalqty'+uniids).html(calctotalqty);

//calc unit price and total kg
itemprice=document.getElementById('displayunitprice'+uniids).innerHTML;
itemprice=parseFloat(itemprice);
calctotalprice=calctotalqty*itemprice;

//newupdation
calctotalprice=parseFloat(calctotalprice).toFixed(2);
//new updation ended

//$('#displayunitprice'+uniids).html(itemprice);
$('#displaytotalprice'+uniids).html(calctotalprice);
//calc ends

unittotal=pqty*itemprice; //subtract price of 1 qty
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
var gtotal=tempt-unittotal; 



//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended

$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display


 }

}
	
</script>
<script type='text/javascript'>
	function addf(input) {
               //spinnr
		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                 newval=parsedval+1;
                 document.getElementById(inputid).value=newval;
                //spinner
      uniids=input.replace('button_pkgnum_','');



//calc pkg and pkg nos
numpackage=$('#pkgnum_'+uniids).val();
pqty=document.getElementById('displaypkgqty'+uniids).innerHTML;
pqty=parseFloat(pqty);
nowvalue=document.getElementById('displaytotalprice'+uniids).innerHTML;
nowvalue=parseFloat(nowvalue);
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);

var gtotal=tempt-nowvalue; // set total saved value as minus this,adding total code down 



//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended

$('#grandt').val(gtotal);

calctotalqty=numpackage*pqty;
//calc ends
$('#displaytotalqty'+uniids).html(calctotalqty);
//calc unit price and total kg
itemprice=document.getElementById('displayunitprice'+uniids).innerHTML;
itemprice=parseFloat(itemprice);
calctotalprice=calctotalqty*itemprice;

//newupdation
calctotalprice=parseFloat(calctotalprice).toFixed(2);
//new updation ended

//$('#displayunitprice'+uniids).html(itemprice);
$('#displaytotalprice'+uniids).html(calctotalprice);
//calc ends


var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
var calctotalprice= parseFloat(calctotalprice);


var gtotal=calctotalprice+tempt; // calculate grand total



//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended

$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display
        }
	
</script>



<script>

function addfcontainer(input)
{
//spinnr

		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                 newval=parsedval+1;
                 document.getElementById(inputid).value=newval;
                //spinner

//calc subtotal
contaid=input.replace('button_containernos_','');
contqty=document.getElementById('displayprice_'+contaid).innerHTML;
contqty=parseInt(contqty);
var nowrowtotal=newval*contqty;
//calc subtotal

//subtract curr. price with total
currtotalrow=document.getElementById('displaytotalprice'+contaid).innerHTML;
currtotalrow= parseFloat(currtotalrow);
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
tempt=tempt-currtotalrow;
//subtract curr. price with total

$('#displaytotalprice'+contaid).html(nowrowtotal); //show sub total
var nowrowtotal= parseFloat(nowrowtotal);

var gtotal=nowrowtotal+tempt; // calculate grand total



//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended

$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display

}

</script>



<script type='text/javascript'>
	function minuscontainerf(input) {
		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                if(parsedval==0)
                 {}
                 else{
                 newval=parsedval-1;
                 document.getElementById(inputid).value=newval;


//calc subtotal
contaid=input.replace('button_containernos_','');
contqty=document.getElementById('displayprice_'+contaid).innerHTML;
contqty=parseInt(contqty);
var nowrowtotal=newval*contqty;
//calc subtotal

//subtract curr. price with total
currtotalrow=document.getElementById('displaytotalprice'+contaid).innerHTML;
currtotalrow= parseFloat(currtotalrow);
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
tempt=tempt-currtotalrow;
//subtract curr. price with total

$('#displaytotalprice'+contaid).html(nowrowtotal); //show sub total
var nowrowtotal= parseFloat(nowrowtotal);

var gtotal=nowrowtotal+tempt; // calculate grand total



//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended
$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display

                        }
                   }


</script>



<script>

function removitem(rowid,totalid)
{

var remtotal=document.getElementById(totalid).innerHTML;
remtotal=parseFloat(remtotal); //current total of rem item
var tempttl=($('#grandt').val()); //y hidden value gtotal
var tempt=parseFloat(tempttl);

var gtotal=tempt-remtotal;
gtotal=parseFloat(gtotal).toFixed(2);
$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display

$("#"+rowid).remove();
}



</script>

<script> //for type num in box

function textinsert(textboxid,uniid)
{

enteredvalue=document.getElementById(textboxid).value;
if ((isNaN(enteredvalue)==true)||(enteredvalue=='')) //if char
{
document.getElementById(textboxid).value=0;
}

              
                nosvalue=textboxid.value;
                 parsedval=parseInt(nosvalue);
                 
                
              
      uniids=uniid;



//calc pkg and pkg nos
numpackage=$('#pkgnum_'+uniids).val();
numpackage= Math.round(numpackage); document.getElementById(textboxid).value=numpackage; //rounded and set value if decimal found
pqty=document.getElementById('displaypkgqty'+uniids).innerHTML;
pqty=parseFloat(pqty);
nowvalue=document.getElementById('displaytotalprice'+uniids).innerHTML;
nowvalue=parseFloat(nowvalue);
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);

var gtotal=tempt-nowvalue; // set total saved value as minus this,adding total code down 



//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended

$('#grandt').val(gtotal);

calctotalqty=numpackage*pqty;
//calc ends
$('#displaytotalqty'+uniids).html(calctotalqty);
//calc unit price and total kg
itemprice=document.getElementById('displayunitprice'+uniids).innerHTML;
itemprice=parseFloat(itemprice);
calctotalprice=calctotalqty*itemprice;

//newupdation
calctotalprice=parseFloat(calctotalprice).toFixed(2);
//new updation ended

//$('#displayunitprice'+uniids).html(itemprice);
$('#displaytotalprice'+uniids).html(calctotalprice);
//calc ends


var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
var calctotalprice= parseFloat(calctotalprice);


var gtotal=calctotalprice+tempt; // calculate grand total



//newupdation
gtotal=parseFloat(gtotal).toFixed(2);
//new updation ended

$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display






}


</script>








<!--add order sripts ends-->