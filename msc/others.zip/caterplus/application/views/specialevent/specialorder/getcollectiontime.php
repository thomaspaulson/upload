<!-- Dummy Page for creating delivery time-->


<body>
<div id="top_wrapper">
    <div class="container">
    <div class="row">
        <div class=" col-md-3 col-sm-3">
        <div class="caterplus_logo"> <img src="<?php echo base_url();?>extras/images/caterplus_logo.png" alt="Cater Plus"> </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_sett_ord">
            <div class="top_settings"> <a href="#"><img src="<?php echo base_url();?>extras/images/top_settings.png" title="" alt="Cater Plus"></a> </div>
            <div class="top_order"> Order No : <?php echo $orderid;?></div>
          </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_dropdown">
         <!--   <select class="top_dropdown_style">
            <option>--Select--</option>
          </select> -->
          </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_search">
          <!--  <form action="#" method="post">
            <input name="" type="text" class="search_01"   />
            <button class="btn" title="Submit"></button>
          </form> -->
          </div>
      </div>
      </div>
  </div>
  </div>
<div id="content_wrapper">
    <div class="container">
    <div class="row content_bg">
        <div class="col-md-12">
        <div class="customerorder_frame">
            <div class="customername_orderframe">
            <div class="customername_orderframe_back"> <a href="#"><img src="<?php echo base_url();?>extras/images/customer_image.png" alt="cater plus"></a> </div>
            <div class="customername_orderno"> <a href="#"><?php echo $custname; ?></a> </div>
            <div class="customer_plus">
                <input type="button" class="customer_plus_btn" title="add here">
              </div>
          </div>
            <div class="clearfix"></div>
            
            
            
            
            
          
            <div class="customer_filling_frame">
              <div class="customer_over">
            <div class="customer_filling">
                <div class="customer_filling_top_title">
                <div class="customer_name">Name</div>
                <div class="customer_pkg">Qty<br/> <span class="kg"> </span></div>
                <div class="customer_qty">Nos</div>
                <div class="customer_totalqty">Total Qty<br/><span  
                class="kg"></span></div>
                 <div class="customer_unit">Unit Price<br/><span  
                class="kg"></span></div>
                <div class="customer_total">Total Price<br/><span  
                class="kg"></span></div>
              </div>
                
                <form>
                
              <div id="appendsection"></div>

              </div>
              </div>

            <div class="customer_filling_result">
              <!--  <div class="sub_total">Sub Total   :   $385</div> -->
               <!-- <div class="total">SubTotal <span class="total_color"> :   $385</span></div> -->
              </div>
            <div class="customer_filling_result">
            <!--    <div class="sub_total">Discount    :   $30</div> -->
                <div class="total"></div>
              </div>
            <div class="customer_filling_result">
            <!--    <div class="sub_total">Tax              :   $10</div> -->
                <div class="total" >Grand Total :£ <span class="balncetotal_color" id="displaygrandtotal">00.00</span></div>
              </div>
            
              
              
              
            <div class="clearfix"></div>
            <div class="customer_btm_btn">

<input type="hidden" name="orderid" value="<?php echo $orderid;?>" id="orderid"/>
<input type="hidden" name="custid" value="<?php echo $custid;?>" id="custid"/>


                <input type="submit" class="cancel_order" value="Cancel Order" title="Cancel Order" name="cancelorder">
<!--                <input type="submit" class="cancel_order" value="Hold Order" title="Hold Order"  name="holdorder"> -->
                <input type="submit" class="send_order" value="Confirm Order" title="Send Order"  name="confirmorder">
 </form>
              </div>
              
             <!------>
            <div class="clearfix"></div>
            <div class="five_buttons_frame">
                <!-- <div class="add_extra_items_frame">
                <input type="button" class="add_extra_items" alt="add extra items">
                <span class="five_btn_txt">Add <br>
                  Extra Item</span> </div>
                <div class="add_extra_items_frame">
                <input type="button" class="amount_order" title="Amount Order">
                <span class="five_btn_txt">Amount <br>
                  Order</span> </div>
                <div class="add_extra_items_frame">
                <input type="button" class="track_order" title="Track Order">
                <span class="five_btn_txt">Track <br>
                  Order</span> </div>  
<div class="add_extra_items_frame">
                <input type="button" class="pay" title="Pay">
                <span class="five_btn_txt">Pay <br>
                  </span> </div>-->
               <!-- <div class="add_extra_items_frame">
                <input type="button" class="print_order" title="Print Order">
                <span class="five_btn_txt">Print Order</span> </div>-->
                
              </div>
          </div>
      
          
          </div>
          
          
          
          
          
          
          
          
          
          
        <div class="bookyour_order_frame">
            <div class="bookyour_order">Select Dishes </div>
            <div class="booking_frame">
            <div class="booking_slide">
                <div class="left_green_textframe">
                <div class="left_green_text1">Menu</div>
              </div>
                <div class="demo"> 
                




                <!--Horizontal Tab-->
                <div id="horizontalTab">
                    <ul class="resp-tabs-list">
<?php if($menu){
$menucount=count($menu);
foreach($menu as $menulist){?>
                    <li><?php echo $menulist['menutypename'];?></li>
                    
<?php }
} ?>
                  </ul>


                    
              <div class="resp-tabs-container">
                             
                           <?php  if($menu){ $i=0;                        
                             foreach($menu as $itemmenu)
                             { $menuid=$itemmenu['menutypeid']; ?>
                             <div>
                             
				<ul id="<?php echo 'carousel'.$i;?>" class="elastislide-list">
				
			<?php	$data['item'] = $this->specialitem_model->select_item($menuid);
			
				
				foreach($data['item'] as $itemlist)
				{  $itemid=$itemlist['itemid']; $itemname=$itemlist['itemname'];  
				$itembasicp=$itemlist['itemprice'];  ?>
				 
				 <li>
				 <a href="#"><img src="<?php echo base_url();?>uploads/items/<?php echo $itemlist['item_image'];?>"
				  alt="<?php echo $itembasicp; ?>" 
				 name="<?php echo $itemname; ?>" id="<?php echo $itemid; ?>" onclick="selectitem(this.id,this.name,this.alt)"/><?php echo $itemname; ?></a></li>
				 
			<?php	 } ?>
				    
				</ul>                 
                            </div>
                           <?php  } }?>
                            
                            
		            
                  </div>
                  <!--close container resp-tabs-container-->
                  </div>
                  </div>
                  <div class="list_line"></div>
              </div>
              
              
                <div class="clearfix"></div>
                
                <div class="left_green_textframe">
                <div class="left_green_text2">Packs</div>
              </div>
              
              
                <div class="container_frame">
                <ul id="carousel101" class="elastislide-list">
					
                   <?php if($packages) { foreach($packages as $plist){ $pakageid=$plist['specialp_id']; 
                   $pakageqty=$plist['specialp_qty']; ?>
                    <li><a class="container_bg" href="#" id="<?php echo $pakageid; ?>" 
                    name="<?php echo $pakageqty; ?>" onclick="selectpackage(this.id,this.name)" >
                     <span class="pack_inner_text1">
                    <?php echo $plist['specialp_qty'];?></span> <span class="pack_inner_rate"></span> </a></li>
                    <?php } } ?>
				</ul> 
                
                <br>

                     <div class="list_line"></div>
                      <div class="clearfix"></div>
              </div>

                <div class="clearfix"></div>
                
                <div class="left_green_textframe">
                <div class="left_green_text2">Container</div>
              </div>
              
                <div class="container_frame">
                <ul id="carousel102" class="elastislide-list">
                 <?php if($containers) { foreach($containers as $clist){
 $conid=$clist['special_cid'];
 $conprice=$clist['special_cprice']; 
 $conname=$clist['special_cname']; ?>
		<li><a class="container_bg" href="#" rel="<?php echo $conname;?>" 
id="<?php echo $conid;?>" name=<?php echo $conprice;?>
 onclick="selectcontainer(this.id,this.name,this.rel)"> <span class="pack_inner_text1"><?php echo $clist['special_cname'];?>
		</span> <span class="pack_inner_rate"><?php echo '$'.$clist['special_cprice'];?></span> </a></li>
		 <?php } } ?>			
				</ul>
                
                
                
                
                
                
                <br>

                     <div class="list_line"></div>
              </div>
                <div class="clearfix"></div>
             <!--    <div class="left_green_textframe">
                <div class="left_green_text2"></div>
              </div>
               <div class="container_frame">
                <ul id="carousel104" class="elastislide-list">
					<li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
					<li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
                    <li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
                    <li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
                    <li><a class="container_bg" href="#"> <span class="pack_inner_text1">SAMPLE</span> <span class="pack_inner_rate">$10.00</span> </a></li>
				</ul>
              </div>-->
              
              </div>
          </div>
          </div>
      </div>
      </div>
  </div>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 


		<script type="text/javascript" src="<?php echo base_url();?>extras/js/jquerypp.custom.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>extras/js/jquery.elastislide.js"></script>
		<script type="text/javascript">
			var mmenu=<?php echo $menucount;?>;
			for(var i=0;i<mmenu;i++){
			        $( '#carousel'+i).elastislide();				
				} 

				$( '#carousel102' ).elastislide();
				$( '#carousel101' ).elastislide();
				$( '#carousel104' ).elastislide();
			
		</script>
		
		
		<script type="text/javascript">
		 	
		
		function selectitem(itid,itname,itprice)
		{
		$('#name').val(itname);
		$('#price').val(itprice);
		$('#id').val(itid);
		}
		function selectpackage(pid,pqty)
		{
		itemid=$('#id').val();
		itemprice=$('#price').val();
		itemname=$('#name').val();

if(itemid)
{}else{ alert("please select an item"); exit;}

var uniid=itemid+"_"+pid;



if ($('#displayrow'+uniid).length > 0) { 
   alert("Already Selected");
}
else{
var torow= "<div class='customer_filling_btm_title' id='displayrow"+uniid+"'><div class='customer_name_result' id='displayitemname"+uniid+"'></div><div class='customer_pkg_result' id='displaypkgqty"+uniid+"'></div><div class='customer_qty_result'><input type='button' class='customer_add_btn' title='add here' onclick='addf(this.id)' id='button_pkgnum_"+uniid+"'><br><input type='hidden' class='customer_text-area' name='packageid_"+uniid+"' id='packageid_"+uniid+"' value='"+pid+"'/><input type='hidden' class='customer_text-area' name='itemid_"+itemid+"' id='itemid_"+itemid+"' value='"+itemid+"'/><input type='text' class='customer_text-area' title='textfield' id='pkgnum_"+uniid+"' value='5' name='pkgnum_"+uniid+"' readonly><br><input type='button' class='customer_minus_btn' title='remove here' onclick='minusf(this.id)' id='button_pkgnum_"+uniid+"'></div><div class='customer_Unit_result' id='displaytotalqty"+uniid+"'></div><div class='customer_total_result' id='displayunitprice"+uniid+"'></div><div class='customer_total_result' id='displaytotalprice"+uniid+"'></div></div>";

$('#appendsection').append(torow);
$('#displayitemname'+uniid).html(itemname);
$('#displaypkgqty'+uniid).html(pqty);

//calc pkg and pkg nos
numpackage=$('#pkgnum_'+uniid).val();
calctotalqty=numpackage*pqty;
//calc ends
$('#displaytotalqty'+uniid).html(calctotalqty);
//calc unit price and total kg
calctotalprice=calctotalqty*itemprice;
$('#displayunitprice'+uniid).html(itemprice);
$('#displaytotalprice'+uniid).html(calctotalprice);
//calc ends


var tempttl=($('#grandt').val());
var calctotalprice= parseFloat(calctotalprice);
var tempt=parseFloat(tempttl);

var gtotal=calctotalprice+tempt; // calculate grand total

$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display

}
		
		} //select package ends



function selectcontainer(contid,contprice,contname)
{

var uniqid="container_"+contid+"_"+contprice;

if ($('#displayrow'+uniqid).length > 0) { 
   alert("Already Selected");
}
else{
var to2row= "<div class='customer_filling_btm_title' id='displayrow"+uniqid+"'><div class='customer_name_result' id='displayname_"+uniqid+"'></div><div class='customer_pkg_result' id='display"+uniqid+"'></div><div class='customer_qty_result'><input type='button' class='customer_add_btn' title='add here' onclick='addfcontainer(this.id)' id='button_containernos_"+contid+"'><br><input type='hidden' class='customer_text-area' name='containerid_"+contid+"' id='containerid_"+contid+"' value='"+contid+"'/><input type='text' class='customer_text-area' title='textfield' id='containernos_"+contid+"' value='1' name='containernos_"+contid+"' readonly><br><input type='button' class='customer_minus_btn' title='remove here' onclick='minuscontainerf(this.id)' id='button_containernos_"+contid+"'></div><div class='customer_Unit_result' id='displays"+contid+"'></div><div class='customer_total_result' id='displayprice_"+contid+"'></div><div class='customer_total_result' id='displaytotalprice"+contid+"'></div></div>";

$('#appendsection').append(to2row);

contname=contname+" Container";
$('#displayname_'+uniqid).html(contname);//show con name
$('#displayprice_'+contid).html(contprice);//show con price
numcon=$('#containernos_'+contid).val();

contotal=contprice*numcon;
$('#displaytotalprice'+contid).html(contotal);//show sub total price


var tempttl=($('#grandt').val()); // get grand total from temp
var tempt=parseFloat(tempttl); //convert to float
var contotal= parseFloat(contotal);//convert to float sub total
var currgrandtotal=tempt+contotal; // grand total


$('#grandt').val(currgrandtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(currgrandtotal); //put grand total value display

}
} //select container ends
</script>


<script>
//spinner starts
	function minusf(input) {
		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                if(parsedval==0)
                 {}
                 else{
                 newval=parsedval-1;
                 document.getElementById(inputid).value=newval;

//spinner ends

uniids=input.replace('button_pkgnum_','');



//calc pkg and pkg nos
numpackage=$('#pkgnum_'+uniids).val();

pqty=document.getElementById('displaypkgqty'+uniids).innerHTML;
var pqty=parseFloat(pqty);
calctotalqty=numpackage*pqty;
//calc ends
$('#displaytotalqty'+uniids).html(calctotalqty);

//calc unit price and total kg
itemprice=document.getElementById('displayunitprice'+uniids).innerHTML;
itemprice=parseFloat(itemprice);
calctotalprice=calctotalqty*itemprice;
//$('#displayunitprice'+uniids).html(itemprice);
$('#displaytotalprice'+uniids).html(calctotalprice);
//calc ends

unittotal=pqty*itemprice; //subtract price of 1 qty
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
var gtotal=tempt-unittotal; 
$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display


 }

}
	
</script>
<script type='text/javascript'>
	function addf(input) {
               //spinnr
		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                 newval=parsedval+1;
                 document.getElementById(inputid).value=newval;
                //spinner
      uniids=input.replace('button_pkgnum_','');



//calc pkg and pkg nos
numpackage=$('#pkgnum_'+uniids).val();
pqty=document.getElementById('displaypkgqty'+uniids).innerHTML;
pqty=parseFloat(pqty);
nowvalue=document.getElementById('displaytotalprice'+uniids).innerHTML;
nowvalue=parseFloat(nowvalue);
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);

var gtotal=tempt-nowvalue; // set total saved value as minus this,adding total code down 
$('#grandt').val(gtotal);

calctotalqty=numpackage*pqty;
//calc ends
$('#displaytotalqty'+uniids).html(calctotalqty);
//calc unit price and total kg
itemprice=document.getElementById('displayunitprice'+uniids).innerHTML;
itemprice=parseFloat(itemprice);
calctotalprice=calctotalqty*itemprice;
//$('#displayunitprice'+uniids).html(itemprice);
$('#displaytotalprice'+uniids).html(calctotalprice);
//calc ends


var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
var calctotalprice= parseFloat(calctotalprice);


var gtotal=calctotalprice+tempt; // calculate grand total

$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display
        }
	
</script>



<script>

function addfcontainer(input)
{
//spinnr

		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                 newval=parsedval+1;
                 document.getElementById(inputid).value=newval;
                //spinner

//calc subtotal
contaid=input.replace('button_containernos_','');
contqty=document.getElementById('displayprice_'+contaid).innerHTML;
contqty=parseInt(contqty);
var nowrowtotal=newval*contqty;
//calc subtotal

//subtract curr. price with total
currtotalrow=document.getElementById('displaytotalprice'+contaid).innerHTML;
currtotalrow= parseFloat(currtotalrow);
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
tempt=tempt-currtotalrow;
//subtract curr. price with total

$('#displaytotalprice'+contaid).html(nowrowtotal); //show sub total
var nowrowtotal= parseFloat(nowrowtotal);

var gtotal=nowrowtotal+tempt; // calculate grand total
$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display

}

</script>



<script type='text/javascript'>
	function minuscontainerf(input) {
		inputid=input.replace('button_','');
                var s = document.getElementById(inputid);
                nosvalue=s.value;
                 parsedval=parseInt(nosvalue);
                if(parsedval==0)
                 {}
                 else{
                 newval=parsedval-1;
                 document.getElementById(inputid).value=newval;


//calc subtotal
contaid=input.replace('button_containernos_','');
contqty=document.getElementById('displayprice_'+contaid).innerHTML;
contqty=parseInt(contqty);
var nowrowtotal=newval*contqty;
//calc subtotal

//subtract curr. price with total
currtotalrow=document.getElementById('displaytotalprice'+contaid).innerHTML;
currtotalrow= parseFloat(currtotalrow);
var tempttl=($('#grandt').val());
var tempt=parseFloat(tempttl);
tempt=tempt-currtotalrow;
//subtract curr. price with total

$('#displaytotalprice'+contaid).html(nowrowtotal); //show sub total
var nowrowtotal= parseFloat(nowrowtotal);

var gtotal=nowrowtotal+tempt; // calculate grand total
$('#grandt').val(gtotal); //granttotal save temp var to hidden 
$('#displaygrandtotal').html(gtotal); //put grand total value display

                        }
                   }


</script>

<?php 

$colldate=$this->session->userdata('colldate');
if($colldate){}else{ $colldate=date('Y-m-d');}  ?>



<!--pop up -->
 <div class="popupWrap2a popup2">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <form action="" method="post" name="collectiontime" id="collectiontime"> <!-- needded to check order nos-->
 <label>Colection Time </label></br>
<select name="timeslot">
<option value="10:00:00-10:30:00">10:00-10:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'10:00:00-10:30:00'); ?> Orders</option>
<option value="10:30:00-11:00:00">10:30-11:00
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'10:30:00-11:00:00'); ?> Orders </option>
<option value="11:00:00-11:30:00">11:00-11:30
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'11:00:00-11:30:00'); ?> Orders</option>
<option value="11:30:00-12:00:00">11:30-12:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'11:30:00-12:00:00'); ?> Orders</option>
<option value="12:00:00-12:30:00">12:00-12:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'12:00:00-12:30:00'); ?> Orders</option>
<option value="12:30:00-13:00:00">12:30-13:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'12:30:00-13:00:00'); ?> Orders</option>
<option value="13:00:00-13:30:00">13:00-13:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'13:00:00-13:30:00'); ?> Orders</option>
<option value="13:30:00-14:00:00">13:30-14:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'13:30:00-14:00:00'); ?> Orders</option>
<option value="14:00:00-14:30:00">14:00-14:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'14:00:00-14:30:00'); ?> Orders</option>
<option value="14:30:00-15:00:00">14:30-15:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'14:30:00-15:00:00'); ?> Orders</option>
<option value="15:00:00-15.30:00">15:00-15:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'15:00:00-15:30:00'); ?> Orders</option>
<option value="15:30:00-16:00:00">15:30-16:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'15:30:00-16:00:00'); ?> Orders</option>
<option value="16:00:00-16:30:00">16:00-16:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'16:00:00-16:30:00'); ?> Orders</option>
<option value="16:30:00-17:00:00">16:30-17:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'16:30:00-17:00:00'); ?> Orders</option>
<option value="17:00:00-17:30:00">17:00-17:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'17:00:00-17:30:00'); ?> Orders</option>
<option value="17:30:00-18:00:00">17:30-18:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'17:30:00-18:00:00'); ?> Orders</option>
<option value="18:00:00-18.30:00">18:00-18:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'18:00:00-18.30:00'); ?> Orders</option>
<option value="18:30:00-19:00:00">18:30-19:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'18:30:00-19:00:00'); ?> Orders</option>
<option value="19:00:00-19:30:00">19:00-19:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'19:00:00-19:30:00'); ?> Orders</option>
<option value="19:30:00-20:00:00">19:30-20:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'19:30:00-20:00:00'); ?> Orders</option>
<option value="20:00:00-20:30:00">20:00-20:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'20:00:00-20:30:00'); ?> Orders</option>
<option value="20:30:00-21:00:00">20:30-21:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'20:30:00-21:00:00'); ?> Orders</option>
<option value="22:30:00-23:00:00">22:30-23:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'22:30:00-23:00:00'); ?> Orders</option>
<option value="23:00:00-23:30:00">23:00-23:30 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'23:00:00-23:30:00'); ?> Orders</option>
<option value="23:30:00-23:58:00">23:30-01:00 
<?php echo $this->specialorder_model->ordernum_timeslot($colldate,'23:30:00-23:58:00'); ?> Orders</option>
</select>
<input type="text" id="datepicker" name="dateslot" onchange="myFunction()" value="<?php echo $colldate; ?>"/>
      <input name="confirmtime" type="submit" value="Confirm" >
      </p>
      </form>
      <!-->
<link rel="stylesheet" href="//code.jquery.com/ui/1.11.0/themes/smoothness/jquery-ui.css">
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.0/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">
<!-->
    	
  <!--<a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>-->
    </div>
    </div>   
<!--pop up -->



 <script type="text/javascript">

		$(document).ready(function() {


				$(".popup2").show(300);


<?php    if($currtemdate=$this->session->userdata('temprdate')) { ?>
var currentDate ="<?php echo $currtemdate; ?>" ;
<?php } else { ?>  
var currentDate = new Date();  
<?php } ?>

var pickerOpts = {dateFormat:"yy-mm-dd"};  
$("#datepicker").datepicker(pickerOpts);


}); 
		</script>



<script>
function myFunction()
{
var dateslot= document.getElementById('dateslot');
document.getElementById("collectiontime").submit();
}


</script>









</body>
</html>