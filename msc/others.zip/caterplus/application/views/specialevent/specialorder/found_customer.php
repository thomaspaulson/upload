<script type="text/javascript">
/*
jQuery(document).ready(function ($) {
  $("#customemailfetch").validationEngine();
 }); */
</script>
<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">

 
 <div class="col-md-3 col-sm-4">
 <div class="listing_title"><span class="listing_title_capital"><a href="<?php echo base_url();?>specialevent/customer"><img src="<?php echo base_url();?>extras/extra/images/customer-list.png"/></a></span> </div>
</div>

  

<div class="col-md-6 col-sm-4">
<section class="main">
	 <form class="search-item" id="customemailfetch" name="customemailfetch" method="post" action="<?php echo base_url();?>specialevent/customer/customerfetchdetails" >
		 <input type="text" placeholder="Mobile Number / Name" name="customemail" id="customemail" autocomplete="off" value="<?php echo $search_term;  ?>" >
		 <ul class="results" id="results">

		 </ul>
		
	 </form>
</section>

</div>
    
  <div class="col-md-3 col-sm-3">
 <div class="listing_title"><a href="<?php echo base_url();?>specialevent/customer/new_customer"><span class="listing_title_capital"><img src="<?php echo base_url();?>extras/extra/images/add-customer.png"/></span> </a></div>
</div>
 <!---->
    
  
    
   <div class="list_line"></div> 
   
   <div class="list_table-1">
	<div class="list_title">
    <div class="listall-image">Name</div>
    <div class="listall-itemname">Email	</div>
    <div class="listall-item-action">Mobile</div>
    
    </div>
<div class="list_table_result_frame">
	<?php foreach($contents as $value){?>
<div class="list_table_result_row1">
<div class="listall-image" style="border-bottom:solid 1px #dedbdb;"><a href="<?php echo base_url()?>specialevent/customer/showcust/<?php echo $value['customerId'];?>"><?php echo $value['customername'];?></a></div>
<div class="listall-itemname"><a href="<?php echo base_url()?>specialevent/customer/showcust/<?php echo $value['customerId'];?>"><?php echo $value['customeremail']?></a></div>
<div  class="listall-item-action">
<a href="<?php echo base_url()?>specialevent/customer/showcust/<?php echo $value['customerId'];?>"><?php echo $value['customermobile1']?></a>
</div>
</div>
<?php } ?>


</div>
<!-- <div class="pagination">
<?php if($paages){ echo $paages; } ?>
</div> -->

</div>


<script>
	var base_url = "<?php echo base_url(); ?>";	
</script>

<script>
	$("#customemail").keyup(function(){
		var search_key = $("#customemail").val();
		$("#results").css("visibility", "visible");
		if(search_key != ''){
			$.ajax({
		                type: "GET",
		                url: base_url + "specialevent/customer/get_search",
		                data: {
		                    'search_keyword' : search_key
		                },
		                success: function(msg){
					 $('#results').html(msg);
		                }
	           	 });		
		}else{
        		$('#results').css("visibility", "hidden");		
		}				

	});

	$( "#search" ).focus(function() {
		$("#results").css("visibility", "visible");		
	});


</script>

<script>
$(document).mouseup(function (e)
{
    var container = $(".main");
    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        $('#results').css("visibility", "hidden");
    }
});
</script>