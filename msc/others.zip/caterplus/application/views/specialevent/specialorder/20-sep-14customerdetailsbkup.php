<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">
<div class="col-md-3 col-sm-3">
 <div class="listing_title"> <img src="<?php echo base_url();?>extras/extra/images/add-customer.png"/></div>
</div>


<!--<div class="col-md-3 col-sm-3">
<section class="main">
                                          <form class="search-item" id="customemailfetch" method="post" action="<?php echo base_url();?>specialevent/customer/customerfetchdetails" >
		 <input type="text" placeholder="Customer Email" name="customemail" id="customemail" autocomplete="off" value="">
		<ul class="results" >
			 <li><a href="">Search Result #1<br /><span>Description...</span></a></li>
			 <li><a href="">Search Result #2<br /><span>Description...</span></a></li>
	 		<li><a href="">Search Result #3<br /><span>Description...</span></a></li>
         	<li><a href="">Search Result #4</a></li>
		 </ul>
	 </form>
</section>

</div>-->
    

    
   <div class="list_line"></div> 


<div class="list_table1">

<div class="listtable-white">

<form class="validate" id="add-items" action="<?php echo base_url();?>specialevent/customer/updatecustomer" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
<?php
        // List up all results.
        foreach ($results as $val)
        {
         
    ?>
<div class="mc-field-group"><label for="mce-LNAME">Customer Name: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="name" class="required validate[required,custom[onlyLetterSp]]" id="required-1" value="<?php echo $val['customername'];?>"/>

</div>

<div class="mc-field-group"><label for="mce-EMAIL">Address: <span class="asterisk"></span><br />
</label><br />
 <textarea name="address" id="txtenq" cols="" rows="" class="area"><?php echo $val['customeraddress'];?></textarea></div>

<div class="mc-field-group">
<div class="ext">
<label for="mce-LNAME">Ext: <br />
</label><br />
<input class="required" id="required-1" type="text" name="customerphoneext" value="<?php echo $val['customerphoneext'];?>" />
</div>
<div class="landnum">
<label for="mce-LNAME">Landline Number: <br />
</label><br />
<input class="required" id="phone" type="text" name="phone" value="<?php echo $val['customerphone'];?>" />
</div>
</div>
<div class="clear" id="mce-responses">
<input class="button" id="mc-embedded-subscribe" type="submit" name="subscribe" value="Proceed To Order" /></div>
<div class="mc-field-group"><label for="mce-LNAME">Mobile: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="mobile1" class="required " id="mobile1" value="<?php echo $val['customermobile1'];?>" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">Mobile2: <br />
</label><br />
<input type="text" name="mobile2" class="required" id="mobile2" value="<?php echo $val['customermobile2'];?>" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">Primary Email: <br />
</label><br />
<input type="text" name="email" class="required" id="email" value="<?php echo $val['customeremail'];?>"/>
</div>
<div class="mc-field-group"><label for="mce-LNAME">Email2: <br />
</label><br />
<input type="text" name="email2" class="required" id="email2" value="<?php echo $val['customeremail2'];?>"/>
</div>
<div class="mc-field-group"><label for="mce-LNAME">Country: <span class="asterisk"></span><br />
</label><br />
<input type="text" name="country" class="required" id="country" value="<?php echo $val['country'];?>"/>
</div>
<div class="mc-field-group"><label for="mce-LNAME">State: <span class="asterisk"></span><br />
</label><br />
<input type="text" name="state" class="required" id="state" value="<?php echo $val['state'];?>"/>
</div>
<div class="mc-field-group"><label for="mce-LNAME">City: <span class="asterisk"></span><br />
</label><br />
<input type="text" name="city" class="required" id="city" value="<?php echo $val['city'];?>"/>
</div>

<div class="mc-field-group"><label for="mce-LNAME">Pincode: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="pincode" class="required" id="pincode" value="<?php echo $val['pincode'];?>"/>
</div>
<div class="clear" id="mce-responses"></div>
<div class="clear"><input type="hidden" name="customerId" id="custid" value="<?php echo $val['customerId'];?>"/>

<input class="button" id="mc-embedded-subscribe" type="submit" name="subscribe" value="Submit" /></div>

<?php } ?>
</form>
</div>
 </div>

<script>
	var base_url = "http://caterplus.thephinixgroup.com/";
	$("#customemailfetch").keyup(function(){
		var custemail = $("#customemail").val();
//alert(custemail);
		$.ajax({
	                type: "POST",
	                url: base_url + "customer/customerfetchdetails",
	                data: {
	                    'search_keyword' : search_key
	                },
	                success: function(msg){
				$('#results').html(msg);
	                }
           	 });
	});
	
</script>