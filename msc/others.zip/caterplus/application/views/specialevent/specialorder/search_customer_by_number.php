<?php
	foreach($contents as $content){
	$key_words= explode(' ',$content['customermobile1']);
	$key_words = implode('+',$key_words);
?>
	 <li><a  href="<?php echo base_url(),'specialevent/customer/search?search=',$key_words; ?>"><?php echo $content['customermobile1']?></span></a></li>
<?php
	}
?>