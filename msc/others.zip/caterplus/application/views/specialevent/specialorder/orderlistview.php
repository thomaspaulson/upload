 
                
                 <!--   <script type="text/javascript">
                    	$(document).ready (function(){
							$('#sadvance').click (function(){
								$('.hide_serch').slideToggle()
							});
						});
                    </script> -->
                </div>
                </div>
        </header>
        <div class="container">
                <div class="row custemor_dtls ">
                	<div class="col-md-12">
                     <script type="text/javascript" src="<?php echo base_url()?>extras/mergeddesign/js/cycle.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
			$('.slider_wrap').cycle({ 
				fx:     'scrollHorz', 
				speed:  1000, 
				timeout: 5000,
				 timeout: 0,
				slideExpr:".slider",
				pager: ".pager233",
				 next: ".nxt0", 
				 prev:  ".prv0",
				
			});			
	});
</script>
                    <ul>
                    	<li class="main_header"><p>Order List</p>
<div class="row search_cus newstyleedited" >
                	<div class="col-md-12">

                    	 <form class="search-item" id="customemailfetch" method="post" action="<?php echo base_url()?>specialevent/orderlist/searchorder" >

                        	 <input type="text" placeholder="Order no" name="orderno" id="orderno" autocomplete="off" value="" required>

                            <ul class="resultsajaxdrop" id="resultsajaxdrop">

		 </ul>	
 
<a href="<?php echo base_url();?>specialevent/customer" id="sadvance">New Order</a>
 <ul class="results" id="results">                           
                            </div>
                        </form>


<div style="float: left;width: 200px;position: absolute;margin-left: 35%;">
<form class=" " id=" " method="post" action="<?php echo base_url()?>specialevent/orderlist/searchorderbymobno" >                	 
<input type="text" placeholder="mob no" name="mob_no" id="mob_no" autocomplete="off" value="" required>                          
                        </form>
</div>







                    </div>
                 <?php if(count($contents)>10){?>         	<div class="pag_nav">
                            	<a href="#"  class="prv0"><img src="<?php echo base_url()?>extras/mergeddesign/images/prev_p.png" width="29" height="31"></a>
                                <a href="#" class="nxt0"><img src="<?php echo base_url()?>extras/mergeddesign/images/nxtp.png" width="29" height="31"></a>
                            </div>
<?php } ?>
                      </li>
                      </ul>
                      <div class="slider_wrap wr">

<?php if(count($contents)<10){?>  

 <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="order_fld">Order Id</li>
                                <li class="orderother_fld">Customer</li>                              
                                <li class="orderother_fld">Mobile</li>  
                                 <li class="orderother_fld">Total Amount</li>
                                <li class="orderother_fld">Balance Amount</li>
                               <li class="orderother_fld">Payment Status</li>
<li class="orderother_fld">Collection Status</li>
<li class="orderother_fld">Action</li>

                            </ul>
                      </li> 
                      
                       <?php $i=0;foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}  ?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="order_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php $oid=$value['orderid']; echo $oid=$value['orderid'];?></a></li>
                                <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['customername']?></a></li>
 <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['customermobile1']?></a></li>
                     <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php $tval=$value['totalamount']; echo '£ '.number_format((float)$tval, 2, '.', ''); ?></a></li>
<?php $bal = $this->payment_model->get_balpay($oid); ?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo '£ '.$bal;?></a></li>       
     
     <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php if(($bal<$tval)&&($bal>0)){ echo 'Partial'; } else{ echo $value['payment_status']; } ?></a></li>  
<?php $cstatus=$value['collection_status'];?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['collection_status']?></a></li>  
<?php $cstatus=$value['collection_status']; if($cstatus=='pending') { ?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/> |</a>
<a onclick="return window.confirm('Do you really want to cancel this Order?')" href="<?php echo base_url()?>specialevent/orderlist/cancelorder/<?php echo $value['orderslug']?>"><img src="<?php echo base_url();?>extras/new/images/close-button.png"/></a></li>  <?php } ?>                           
                            </ul>
                      </li>
                      
                  
                    <?php } ?>
                                            
                    </ul>


<?php } else { ?>







                     <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="order_fld">Order Id</li>
                                <li class="orderother_fld">Customer</li>                              
                                <li class="orderother_fld">Mobile</li>  
                                 <li class="orderother_fld">Total Amount</li>
                                <li class="orderother_fld">Balance Amount</li>
                               <li class="orderother_fld">Payment Status</li>
<li class="orderother_fld">Collection Status</li>
<li class="orderother_fld">Action</li>

                            </ul>
                      </li> 
                      
                       <?php $i=0;foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}  if($i<=10){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="order_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php $oid=$value['orderid']; echo $oid=$value['orderid'];?></a></li>
                                <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['customername']?></a></li>
 <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['customermobile1']?></a></li>
                     <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php $tval=$value['totalamount']; echo '£ '.number_format((float)$tval, 2, '.', ''); ?></a></li>
<?php $bal = $this->payment_model->get_balpay($oid); ?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo '£ '.$bal;?></a></li>       
     
     <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php if(($bal<$tval)&&($bal>0)){ echo 'Partial'; } else{ echo $value['payment_status']; } ?></a></li>  
<?php $cstatus=$value['collection_status'];?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['collection_status']?></a></li>  
<?php $cstatus=$value['collection_status']; if($cstatus=='pending') { ?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/> |</a>
<a onclick="return window.confirm('Do you really want to cancel this Order?')" href="<?php echo base_url()?>specialevent/orderlist/cancelorder/<?php echo $value['orderslug']?>"><img src="<?php echo base_url();?>extras/new/images/close-button.png"/></a></li>  <?php } ?>                           
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                                            
                    </ul>

                  <ul class="slider wr">
                      	<li class="sub_header">
                      		<ul>
                            	<li class="order_fld">Order Id</li>
                                <li class="orderother_fld">Customer</li>                              
                                <li class="orderother_fld">Mobile</li>  
                                 <li class="orderother_fld">Total Amount</li>
                                <li class="orderother_fld">Balance Amount</li>
                               <li class="orderother_fld">Payment Status</li>
<li class="orderother_fld">Collection Status</li>
<li class="orderother_fld">Action</li>
                            </ul>
                      </li>
                     <?php $i=0;  foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}   if($i>10){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="order_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php $oid=$value['orderid']; echo $oid=$value['orderid'];?></a></li>
                                <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['customername']?></a></li>
 <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['customermobile1']?></a></li>
                     <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php $tval=$value['totalamount']; echo '£ '.number_format((float)$tval, 2, '.', ''); ?></a></li>
<?php $bal = $this->payment_model->get_balpay($oid); ?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo '£ '.$bal;?></a></li>       
     
     <li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php if(($bal<$tval)&&($bal>0)){ echo 'Partial'; } else{ echo $value['payment_status']; } ?></a></li>  
<?php $cstatus=$value['collection_status'];?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><?php echo $value['collection_status']?></a></li>  
<?php $cstatus=$value['collection_status']; if($cstatus=='pending') { ?>
<li class="orderother_fld"><a href="<?php echo base_url()?>specialevent/takeorder/newedit_order/<?php echo $value['orderslug']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/> |</a>
<a onclick="return window.confirm('Do you really want to cancel this Order?')" href="<?php echo base_url()?>specialevent/orderlist/cancelorder/<?php echo $value['orderslug']?>"><img src="<?php echo base_url();?>extras/new/images/close-button.png"/></a></li>  <?php } ?>                                     
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                    </ul>
<?php } ?>
                    </div>
                    </div>
                </div>
                <footer>
                 <ul>
                 	
                    <li>
                    	<a href="<?php echo base_url();?>">Cancel</a>
                    </li>
                    
                    <li>
                    	<a href="<?php echo base_url();?>specialevent/customer">New</a>
                    </li>
                   
                 </ul>
                 </footer>
          </div>  
<script>
	var base_url = "<?php echo base_url(); ?>";	
</script>

<script>
	$("#orderno").keyup(function(){
		var search_key = $("#orderno").val();
		$("#resultsajaxdrop").css("visibility", "visible");				
		if(search_key != ''){
			$.ajax({
		                type: "GET",
		                url: base_url + "specialevent/orderlist/get_search",
		                data: {
		                    'search_keyword' : search_key
		                },
		                success: function(msg){
					 $('#resultsajaxdrop').html(msg);
		                }
	           	 });		
		}else{
        		$('#resultsajaxdrop').css("visibility", "hidden");		
		}
	});

	$( "#search" ).focus(function() {
		$("#resultsajaxdrop").css("visibility", "visible");		
	});


</script>

<script>
$(document).mouseup(function (e)
{
    var container = $(".main");
    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        $('#resultsajaxdrop').css("visibility", "hidden");
    }
});
</script>
</body>
</html>