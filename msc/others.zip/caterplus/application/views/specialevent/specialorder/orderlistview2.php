<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">

 
 <div class="col-md-3 col-sm-3">
 <div class="listing_title"><span class="listing_title_capital"><a href="<?php echo base_url()?>specialevent/orderlist/index">ORDER LIST</a></span> </div>
</div>

  

<div class="col-md-3 col-sm-3">
<section class="main">
	 <form class="search-item" id="customemailfetch" method="post" action="<?php echo base_url()?>specialevent/orderlist/searchorder" >
 Search Order
		 <input type="text" placeholder="Order no" name="orderno" id="orderno" autocomplete="off" value="">
		
	 </form>
</section>

</div>
    
  <div class="col-md-3 col-sm-3">
 <div class="listing_title"><a href="<?php echo base_url();?>specialevent/customer"><span class="listing_title_capital">New Order</span> </a></div> 
</div>
 <!---->
    
  
    
   <div class="list_line"></div> 
   
   <div class="list_table-1">
	<div class="list_title">
    <div class="listall-orderid">Order Id</div>
    <div class="listall-customername">Customer	</div>
    <div class="listall-customermobile">Mobile Num</div>
 <div class="listall-customerpayment">Total Amount</div>
    <div class="listall-customerpaymentstatus">Payment Status</div>
    <div class="listall-customercollectionstatus ">Collection Status</div>
<div class="listall-item-orderaction">Action</div>
    
    </div>
<div class="list_table_result_frame">
	<?php foreach($contents as $value){ ?>

<div class="list_table_result_row1">

<div class="listall-orderid"  ><a class="orderpopup" ><?php echo $value['orderid'];?></a></div>
 <div class="listall-customername"><a href=""><?php echo $value['customername']?></a></div>
<div class="listall-customermobile"><a href=""><?php echo $value['customermobile1']?></a></div>
<div class="listall-customerpayment"><a href=""><?php echo $value['totalamount']?></a></div>
<div class="listall-customerpaymentstatus"><a href=""><?php echo $value['payment_status']?></a></div>
<div class="listall-customercollectionstatus"><a href=""><?php echo $value['collection_status']?></a></div>
<div  class="listall-item-orderaction">
<a href="<?php echo base_url()?>specialevent/orderlist/cancelorder/<?php echo $value['orderslug']?>">Cancel</a>
</div>
</div>
<?php } ?>


</div>


</div>
<script>
	var base_url = "http://caterplus.thephinixgroup.com/";
	$("#customemailfetch").keyup(function(){
		var custemail = $("#customemail").val();
//alert(custemail);
		$.ajax({
	                type: "POST",
	                url: base_url + "customer/customerfetchdetails",
	                data: {
	                    'search_keyword' : search_key
	                },
	                success: function(msg){
				$('#results').html(msg);
	                }
           	 });
	});
	
</script>