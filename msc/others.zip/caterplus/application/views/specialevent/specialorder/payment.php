<html>
	<head>
		<title>Payment</title>
	</head>
	<body>
		<form action="/specialevent/payment" method="post">
			<select name="order_id">
				<option value="">Select Order Id</option>
				
				<?php
					foreach($orders as $order){
				?>
					<option value="<?php echo $order['orderid'] ; ?>"><?php echo $order['orderid'] ; ?></option>				
				<?php
					}
				?>

			</select>
		</form>	
		<?php
			if($order_id != 0 ){
		?>
		<form>			
			<select name="payment_method">			
				<option value="chash">Cash</option>
				<option value="check">Check</option>
				<option value="card">Card</option>				
			</select>
			<input type="text" name="amount" placeholder="Total Amount">
		</form>
		<?php
			}
		?>
	<script type="text/javascript" src="http://caterplus.thephinixgroup.com/extras/js/jquery-1.10.2.min.js"></script>
	</body>
</html>