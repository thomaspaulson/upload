<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>ADD CUSTOMER</h1></div>
<div class="msprogrm-main">
<form class="validate" id="add-items" action="<?php echo base_url();?>specialevent/customer/insert_customer" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
<div class="msprogrm-left">


         <div class="master-left-1">
           <div class="master-name">Customer Name *</div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="name">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Address: </div>         
<div class="master-select">
<input name="address" type="text" class="master-textfeild" id="address">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Ext: </div>         
<div class="master-select">
<input name="customerphoneext" type="text" class="master-textfeild validate[custom[integer]] " id="customerphoneext">

          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Landline Number:</div>         
<div class="master-select">
<input name="phone" type="text" class="master-textfeild validate[custom[phone]]" id="phone">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile:* </div>         
<div class="master-select">
<input name="mobile1" type="text" class="master-textfeild validate[required,custom[phone]]" id="mobile1">
          </div>
          </div>
          <!---->
  <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile2: </div>         
<div class="master-select">
<input name="mobile2" type="text" class="master-textfeild " id="mobile2">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Email:* </div>         
<div class="master-select">
<input name="email" type="text" class="master-textfeild " id="email">
          </div>
          </div>
          <!---->


</div>
<div class="msprogrm-right">
 
       
         <div class="master-left-1">
           <div class="master-name">Email2: </div>         
<div class="master-select">
  <input id="email2" type="text" name="email2" class="master-textfeild">
</div>
          </div>
           <!---->
 <div class="master-left-1">
           <div class="master-name">County: </div>         
<div class="master-select">
  <input id="country" type="text" name="country" class="master-textfeild">
</div>
          </div>
           <!---->

         <!--
  <div class="master-left-1">
           <div class="master-name">State: </div>         
<div class="master-select">
  <input  type="text" name="state" class="master-textfeild" id="state">
</div>
          </div>
          -->
 <div class="master-left-1">
           <div class="master-name">City: </div>         
<div class="master-select">
  <input name="city" type="text"  class="master-textfeild" id="city">
</div>
          </div>
          <!---->
 <div class="master-left-1">
           <div class="master-name">Postcode: </div>         
<div class="master-select">
  <input name="pincode" type="text"  class="master-textfeild" id="pincode">
</div>
          </div>
         
        <input class="master-submit" type="submit" name="subscribe" value="" /> 

</div>
          
        
</form>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->

<script>
	var base_url = "http://caterplus.thephinixgroup.com/";
	$("#customemailfetch").keyup(function(){
		var custemail = $("#customemail").val();
//alert(custemail);
		$.ajax({
	                type: "POST",
	                url: base_url + "customer/customerfetchdetails",
	                data: {
	                    'search_keyword' : search_key
	                },
	                success: function(msg){
				$('#results').html(msg);
	                }
           	 });
	});
	
</script>