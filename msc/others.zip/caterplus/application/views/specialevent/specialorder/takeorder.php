<form name="order" id="order" method="post" action="<?php echo base_url(); ?>specialevent/takeorder/saveorder">
	<table name="ordertable" id="ordertable">
		<select name="menu" id="menu">
			<option value="Select Menu">Select Menu</option>
			<?php foreach($menu as $menu){ ?>
			<option value="<?php echo $menu['menutypeid'];?>"><?php echo $menu['menutypename'];?></option>
			<?php } ?>
		</select>
	
		<select name="item" id="item">
			<option value="Select Item">Select Item</option>		
		</select>
		
		<p>
			<strong>Select Packages</strong>
		</p>
		<p>
			<?php
				foreach($packages as $package){
			?>
				<input type="checkbox" name="packages[]" value="<?php echo $package['specialp_id'],'_',$package['specialp_qty']; ?>"><?php echo $package['specialp_qty']; ?> <span class="packs">kg</span> <input type="text" name="packqty_<?php echo $package['specialp_id'] ?>" placeholder="Quantity">
			<?php
				}
			?>
		</p>
		
		<p>
			<strong>Select Containers</strong>
		</p>
		<p>
			<?php
				foreach($containers as $container){
			?>
				<input type="checkbox" name="containers[]" value="<?php echo $container['special_cid'] ?>"><?php echo $container['special_cname']; ?> <input type="text" name="containerqty_<?php echo $container['special_cid'] ?>" placeholder="Container Quantity">
			<?php
				}
			?>
		</p>
		<p>
			Delivery Date
		</p>
		<p>
			<input type="date" name="deliverydate" placeholder="Delivery Date">
		</p>
		
		<p>
			Delivery Time
		</p>
		<p>
			<input type="time" name="deliverytime" placeholder="Delivery Time">
		</p>
		<p>
			<input type="submit" value="Cancel Order" name="action" /> / <input type="submit" name="action" value="Hold Order"/> / <input type="submit" name="action" value="Print Order"/>
			
		</p>
	</table>
</form>	
<script src="<?php echo base_url();?>extras/js/jquery-1.8.2.min.js"></script>
<script src="<?php echo base_url();?>extras/js/custom.js""></script>