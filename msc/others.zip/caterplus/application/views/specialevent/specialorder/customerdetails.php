<script type="text/javascript">
                    	$(document).ready (function(){
							$('.time_inner li').click(function() {
    $('.time_inner li').removeClass('active');
    $(this).addClass('active');
var radbtn = $(this).find('input[type="radio"]');
$(radbtn).prop("checked", true);
checkedtime=$(radbtn).val();
$('#spectime').val(checkedtime);
});
						});
                    </script>
  


                </div>
        </header>
        <div class="container">
                <div class="row custemor_dtls "></div>
               <form class="validate" id="add-items" action="<?php echo base_url();?>specialevent/customer/updatecustomer" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
<?php
        // List up all results.
        foreach ($results as $val)
        {
         
    ?>
                <div class="row">
                <ul>
                    	<li class="main_header"><p class="custheading">Customer Details</p>
<p class="collectionheading">Collection time</p>
                      </li>

                      </ul>
                	<div class="col-lg-5 col-md-5" id="custdetailscollection">
                    	
                        	<div class="fill_details wr">
                            	<ul>
                                	<li> <label>Customer Name</label>
                                   <input type="text" name="name" class="required validate[required,custom[onlyLetterSp]]" value="<?php echo $val['customername'];?>"/>
                                    </li>
                                    
                                   
                                    
    <li> <div class="landinput"><label>Landline Number: </label>
                                    <input class="required" id="phone" type="text" name="phone" value="<?php echo $val['customerphone'];?>" /></div>
<div class="mobileinput"><label>Mobile Number: </label>
                                    <input class="required" id="mobile1" type="text" name="mobile1" value="<?php echo $val['customermobile1'];?>" /></div>
                                    </li>                                
                                <li> <label>Address Line 1</label>
                                    <textarea name="address" id="txtenq" cols="40" rows="5" class="area "><?php echo $val['customeraddress'];?></textarea>
                                    </li>
                                    <li><div class="landinput"> <label>Postcode: </label>
  <input type="text" name="pincode" class="required " id="required-1" /></div><div class="mobileinput"><label>City: </label>
                                    <input type="text" name="city" class="required " id="required-1" value="<?php echo $val['city'];?>"/></div>
                                    </li>
                                   
                                    <li><div class="landinput"> <label>County: </label>
                                    <input type="text" name="country" class="required " id="required-1" value="<?php echo $val['country'];?>"/></div><div class="mobileinput"><label>Mobile2:</label>
                                    <input type="text" name="mobile2" class="required" id="required-1"  value="<?php echo $val['customermobile2'];?>"/></div>
                                    </li>
                                   
                                  
                                    <li><div class="landinput"> <label>Email:</label>
                                   <input type="text" name="email" class="required " id="required-1" value="<?php echo $val['customeremail'];?>" /></div><div class="mobileinput"><label>Email2:</label>
                                    <input type="text" name="email2" class="required" id="required-1" value="<?php echo $val['customeremail2'];?>"/></div>
                                    </li>
                                  <li><div class="landinput"> <label>Delivery Date</label>
                                   <input type="date" name="delivery_date" class="required form-control " id="required-1" value="2018-06-14"/></div><div class="mobileinput">
                                    </div>
                                    </li>
                                <li class="collection_timenew"> 

                                    <input  name="submittimedate" type="submit" value="Select Menu" onclick="this.style.visibility='hidden';">
                                    </li>      
                                    
                                    
                                    
                                    
<input type="hidden" name="customerId" id="custid" value="<?php echo $val['customerId'];?>"/>
 
<?php } ?>
<?php $colldate=$this->session->userdata('temprdate');
                            	if($colldate){}else{$colldate=date('d-m-Y');} ?>
<input type="hidden" name="specifictime" id="spectime" value="11:30"/>
<input type="hidden" name="specificdate" value="<?= $colldate;?>"/>
                                   
                             
                                    
                                </ul>
                            </div>
                        </form>
                    </div>
                    <div class="col-lg-7 col-md-7 collection_time column" id="collection_timecolumn">
                    	
                        
                         <form class="validate" id="myForm" action="" method="post" name="myForm" novalidate  enctype="multipart/form-data">
<div class="collectiontimedate"><label>Date : </label><input type="text" class="mystyle" name="deliverydate" id="datepicker" value="<?= $colldate;?>"/></div>
			<div class="wr">
            <div class="tabbable" id="tabs-84203">
				<ul class="nav nav-tabs">
					<li class="active">
						<a href="#panel-1" data-toggle="tab" id="panel-12">
                       <img src="<?php echo base_url();?>extras/mergeddesign/images/mng_icon.png">
                         <span>Morning</span></a>
					</li>
					<li>
						<a href="#panel-2" data-toggle="tab" id="panel-23">
                       <img src="<?php echo base_url();?>extras/mergeddesign/images/sun.png">
                         <span>After noon</span></a>
					</li>
                    <li>
						<a href="#panel-3" data-toggle="tab" id="panel-34">
                       <img src="<?php echo base_url();?>extras/mergeddesign/images/sun_low.png">
                         <span>Evening</span></a>
					</li>
                    <li>
						<a href="#panel-4" data-toggle="tab" id="panel-45">
                       <img src="<?php echo base_url();?>extras/mergeddesign/images/cm.png">
                         <span>Night</span></a>
					</li>
				</ul>
				<div class="tab-content custom_tab">
					<div class="tab-pane active" id="panel-1">
						<div class="time_wrap ">
                        	<div class="time_inner">
                            	<ul>
                            	
                                	
                                    
                                    <li><input  type="radio" name="timeslot" value="11:00" style="display:none;"><span class="left_time">11.00 - 11.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'11:00:00-11:30:00'); ?> Orders</span></li>
                                    <li class="active"><input type="radio"  name="timeslot" value="11:30" checked="checked" style="display:none;"><span class="left_time">11.30 - 12.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'11:30:00-12:00:00'); ?> Orders</span></li>
                                    <li><input type="radio"  name="timeslot" value="12:00" style="display:none;"><span class="left_time">12.00 - 12.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'12:00:00-12:30:00'); ?> Orders</span></li>
                                  <li><input type="radio"  name="timeslot" value="12:30" style="display:none;"><span class="left_time">12.30 -
 13.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'12:30:00-13:00:00'); ?> Orders</span></li>
                                    <li><input type="radio"  name="timeslot" value="13:00" style="display:none;"><span class="left_time">13.00-13.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'13:00:00-13:30:00'); ?> Orders</span></li>
                                    
                                </ul>
                            </div>
                        </div>
					</div>
					<div class="tab-pane" id="panel-2">
						<div class="time_wrap time_wrap2"><div class="time_inner">
                            	<ul>
                            	<li><input type="radio"  name="timeslot" value="13:30" style="display:none;"><span class="left_time">13.30 - 14.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'13:30:00-14:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="14:00" style="display:none;"><span class="left_time">14.00 - 14.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'14:00:00-14:30:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="14:30" style="display:none;"><span class="left_time">14.30-15.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'14:30:00-15:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="15:00" style="display:none;"><span class="left_time">15.00 - 15.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'15:00:00-15:30:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="15:30" style="display:none;"><span class="left_time">15.30 - 16.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'15:30:00-16:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="16:00" style="display:none;"><span class="left_time">16.00 -16.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'16:00:00-16:30:00'); ?> Orders</span></li>    
                                    <li><input type="radio" name="timeslot" value="16:30" style="display:none;"><span class="left_time">16.30-17.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'16:30:00-17:00:00'); ?> Orders</span></li>
                                                                          </ul>
                            </div></div>
					</div>
                    <div class="tab-pane" id="panel-3">
						<div class="time_wrap time_wrap3"><div class="time_inner">
                            	<ul>
                            	<li><input type="radio" name="timeslot" value="17:00" style="display:none;"><span class="left_time">17.00 - 17.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'17:00:00-17:30:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="17:30" style="display:none;"><span class="left_time">17.30 - 18.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'17:30:00-18:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="18:00" style="display:none;"><span class="left_time">18.00 -18.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'18:00:00-18:30:00'); ?> Orders</span></li>
                                	<li><input type="radio" name="timeslot" value="18:30" style="display:none;"><span class="left_time">18.30 - 19.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'18:30:00-19:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="19:00" style="display:none;"><span class="left_time">19.00 - 19.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'19:00:00-19:30:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="19:30" style="display:none;"><span class="left_time">19.30 - 20.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'19:30:00-20:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="20:00" style="display:none;"><span class="left_time">20.00 - 20.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'20:00:00-20:30:00'); ?> Orders</span></li>
                                    
                                </ul>
                            </div></div>
					</div>
                    <div class="tab-pane" id="panel-4">
						<div class="time_wrap time_wrap4"><div class="time_inner">
                            	<ul><li><input type="radio" name="timeslot" value="20:30" style="display:none;"><span class="left_time">20.30 - 21.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'20:30:00-21:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="22:30" style="display:none;"><span class="left_time">22.30 - 23.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'22:30:00-23:00:00'); ?> Orders</span></li>
                                	<li><input type="radio" name="timeslot" value="23:00" style="display:none;"><span class="left_time">23.00 -23.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'23:00:00-23:30:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="23:30" style="display:none;"><span class="left_time">23.30 - 24.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'23:30:00-24:00:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="23:40" style="display:none;"><span class="left_time">24.00 - 24.30</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'24:00:00-24:30:00'); ?> Orders</span></li>
                                    <li><input type="radio" name="timeslot" value="23:50" style="display:none;"><span class="left_time">24.30 - 01.00</span>
                                    <span class="right_order"><?php echo $this->specialorder_model->ordernum_timeslot($colldate,'24:30:00-01:00:00'); ?> Orders</span></li>
                                   
                                </ul>
                            </div></div>
					</div>
                    
				</div>
			</div></div>
					
                    </div>
                </div>
         </form>
                 <footer>
                 <ul>
                 	
                    <li>
                    	<a href="<?php echo base_url()?>">Cancel</a>
                    </li>
                    
                    <li>
                    	<a href="<?php echo base_url()?>specialevent/customer/new_customer">New</a>
                    </li>
                    
                 </ul>
                 </footer>
          </div>  
</body>
</html>
 
<script type="text/javascript">

		$(document).ready(function() {


var date = new Date();
var m = date.getMonth(), d = date.getDate(), y = date.getFullYear();
$("#datepicker").datepicker({
minDate: new Date(y, m, d),
        inline: true,
        showOtherMonths: true,       
        dateFormat: "dd-mm-yy"
    });
$("#datepicker").keydown(false);

}); 




		</script>

<script>
function myFunction()
{
dateval=document.getElementById("datepicker").value;
//getcollectiontime
//alert(dateval);
//document.forms["myForm"].submit();
document.getElementById('myForm').submit();
//var dateslot= document.getElementById('dateslot');
}


</script>