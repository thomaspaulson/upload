<script type="text/javascript">
jQuery(document).ready(function ($) {
    $("#customemailfetch").validationEngine();
//console.log ( '#add-items was clicked' );
   });
</script>
<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">
<div class="col-md-3 col-sm-3">
 <div class="listing_title"> <img src="<?php echo base_url();?>extras/extra/images/add-customer.png"/></div>
</div>


<!--<div class="col-md-3 col-sm-3">
<section class="main">
	 <form class="search-item" id="customemailfetch" method="post" action="<?php echo base_url();?>specialevent/customer/customerfetchdetails" >
 Search Existing Customer
		 <input type="text" placeholder="Mobile/Name" name="customemail" id="customemail" autocomplete="off" value="" class="validate[required,custom[phone]]">
		 <ul class="results" >
			 <li><a href="">Search Result #1<br /><span>Description...</span></a></li>
			 <li><a href="">Search Result #2<br /><span>Description...</span></a></li>
	 		<li><a href="">Search Result #3<br /><span>Description...</span></a></li>
         	<li><a href="">Search Result #4</a></li>
		 </ul>
	 </form>
</section>

</div>-->
    <div class="col-md-3 col-sm-3" id="listback" style="float:right;">

     <div class="listing_title"> <a href="<?php echo base_url();?>/specialevent/customer/"><img src="<?php echo base_url();?>extras/extra/images/back-to-list.png"></a> </div>
    </div>

    
   <div class="list_line"></div> 


<div class="list_table1">

<div class="listtable-white">
<form class="validate" id="add-items" action="<?php echo base_url();?>specialevent/customer/save_customer" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">

<div class="mc-field-group"><label for="mce-LNAME">Customers Name: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="name" class="required validate[required,custom[onlyLetterSp]]" id="required-1" />
</div>

<div class="mc-field-group"><label for="mce-EMAIL">Address: <span class="asterisk">*</span><br />
</label><br />
 <textarea name="address" id="txtenq" cols="" rows="" class="area "></textarea></div>

<div class="mc-field-group">
<div class="ext">
<label for="mce-LNAME">Ext: <br />
</label><br />
<input class="required" id="required-1" type="text" name="customerphoneext" value="" />
</div>
<div class="landnum">
<label for="mce-LNAME">Landline Number: <br />
</label><br />
<input class="required" id="required-1" type="text" name="phone" value="" />
</div>
</div>
<div class="mc-field-group"><label for="mce-LNAME">Mobile: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="mobile1" class="required " id="required-1" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">Mobile2: <br />
</label><br />
<input type="text" name="mobile2" class="required" id="required-1" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">Email: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="email" class="required " id="required-1" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">Email2:<br />
</label><br />
<input type="text" name="email2" class="required" id="required-1" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">Country: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="country" class="required " id="required-1" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">State: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="state" class="required " id="required-1" />
</div>
<div class="mc-field-group"><label for="mce-LNAME">City: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="city" class="required " id="required-1" />
</div>

<div class="mc-field-group"><label for="mce-LNAME">Pincode: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="pincode" class="required " id="required-1" />
</div>
<div class="clear" id="mce-responses"></div>
<div class="clear"><input type="hidden" name="order_id" value="<?php echo $order_id; ?>"><input class="button" id="mc-embedded-subscribe" type="submit" name="subscribe" value="Submit" /></div>


</form>
</div>
 </div>
 
<script>
	var base_url = "<?php echo base_url(); ?>";	
</script>

<script>
	$("#customemailfetch").keyup(function(){
		var custemail = $("#customemail").val();
//alert(custemail);
		$.ajax({
	                type: "POST",
	                url: base_url + "customer/customerfetchdetails",
	                data: {
	                    'search_keyword' : search_key
	                },
	                success: function(msg){
				$('#results').html(msg);
	                }
           	 });
	});
	
</script>