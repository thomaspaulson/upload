<?php
	foreach($contents as $content){
	$key_words= explode(' ',$content['orderid']);
	$key_words = implode('+',$key_words);
?>
	 <li><a  href="<?php echo base_url(),'specialevent/orderlist/search?search=',$key_words; ?>"><?php echo $content['orderid']?></span></a></li>
<?php
	}
?>