<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>EDIT CUSTOMER</h1></div>
<div class="msprogrm-main">
<form class="validate" id="add-items" action="<?php echo base_url();?>specialevent/customer/updatecustomerdetails" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
<?php
        // List up all results.
        foreach ($results as $val)
        {
         
    ?>
<div class="msprogrm-left">


         <div class="master-left-1">
           <div class="master-name">Customer Name *</div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="name" value="<?php echo $val['customername'];?>">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Address: </div>         
<div class="master-select">
<input name="address" type="text" class="master-textfeild" id="address" value="<?php echo $val['customeraddress'];?>">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Ext: </div>         
<div class="master-select">
<input name="customerphoneext" type="text" class="master-textfeild validate[custom[integer]]" id="customerphoneext" value="<?php echo $val['customerphoneext'];?>">

          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Landline Number:</div>         
<div class="master-select">
<input name="phone" type="text" class="master-textfeild validate[custom[phone]]" id="phone" value="<?php echo $val['customerphone'];?>">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile:* </div>         
<div class="master-select">
<input name="mobile1" type="text" class="master-textfeild validate[required,custom[phone]]" id="mobile1" value="<?php echo $val['customermobile1'];?>">
          </div>
          </div>
          <!---->
  <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile2: </div>         
<div class="master-select">
<input name="mobile2" type="text" class="master-textfeild " id="mobile2" value="<?php echo $val['customermobile2'];?>">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Email:* </div>         
<div class="master-select">
<input name="email" type="text" class="master-textfeild " id="email" value="<?php echo $val['customeremail'];?>">
          </div>
          </div>
          <!---->


</div>
<div class="msprogrm-right">
 
       
         <div class="master-left-1">
           <div class="master-name">Email2: </div>         
<div class="master-select">
  <input id="email2" type="text" name="email2" class="master-textfeild" value="<?php echo $val['customeremail2'];?>">
</div>
          </div>
           <!---->
 <div class="master-left-1">
           <div class="master-name">County: </div>         
<div class="master-select">
  <input id="country" type="text" name="country" class="master-textfeild" value="<?php echo $val['country'];?>">
</div>
          </div>
           <!---->

         <!--
  <div class="master-left-1">
           <div class="master-name">State: </div>         
<div class="master-select">
  <input  type="text" name="state" class="master-textfeild" id="state" value="<?php echo $val['state'];?>">
</div>
          </div>
          -->
 <div class="master-left-1">
           <div class="master-name">City: </div>         
<div class="master-select">
  <input name="city" type="text"  class="master-textfeild" id="city" value="<?php echo $val['city'];?>">
</div>
          </div>
          <!---->
 <div class="master-left-1">
           <div class="master-name">Postcode: </div>         
<div class="master-select">
  <input name="pincode" type="text"  class="master-textfeild" id="pincode" value="<?php echo $val['pincode'];?>">
</div>
          </div>
         <input type="hidden" name="customerId" id="custid" value="<?php echo $val['customerId'];?>"/>
        <input class="master-submit" type="submit" name="subscribe" value="" /> 

</div>
          
   <?php } ?>     
</form>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->

<script>
	var base_url = "http://caterplus.thephinixgroup.com/";
	$("#customemailfetch").keyup(function(){
		var custemail = $("#customemail").val();
//alert(custemail);
		$.ajax({
	                type: "POST",
	                url: base_url + "customer/customerfetchdetails",
	                data: {
	                    'search_keyword' : search_key
	                },
	                success: function(msg){
				$('#results').html(msg);
	                }
           	 });
	});
	
</script>