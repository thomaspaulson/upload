 <?php 
$orderid='';
$custname='';
$mobile='';
$email='';
$address='';
$orderdate='';
$deliverydate='';
$deliverytime='';
$pstatus='';
$totalamount='';
$collection_status='';



if(($orderitem)||($ordercontainer)){ 
foreach($orderitem as $itlist) { 
$orderid=$itlist['orderid'];
$custname=$itlist['customername'];
$mobile=$itlist['customermobile1'];
$email=$itlist['customeremail'];
$address=$itlist['customeraddress'];
$orderdate=$itlist['ordereddate'];
$deliverydate=$itlist['deliverydate'];
$deliverytime=$itlist['deliverytime'];
$pstatus=$itlist['payment_status'];
$totalamount=$itlist['totalamount'];
$collection_status=$itlist['collection_status'];
/*$balamount=$itlist['']; */
}
foreach($ordercontainer as $citlist) { 
$orderid=$citlist['orderid'];
$custname=$citlist['customername'];
$mobile=$citlist['customermobile1'];
$email=$citlist['customeremail'];
$address=$citlist['customeraddress'];
$orderdate=$citlist['ordereddate'];
$deliverydate=$citlist['deliverydate'];
$deliverytime=$citlist['deliverytime'];
$pstatus=$citlist['payment_status'];
$totalamount=$citlist['totalamount'];
$collection_status=$citlist['collection_status'];
$orderslug=$citlist['orderslug'];
/*$balamount=$itlist['']; */
}
 } ?>




      
    
<div id="content_wrapper">
    <div class="container ">
    	<div class="ordercollection_heading">
        <div class="row">
        	<div class="col-md-12">
            	<h1>Order Collection #<?php echo $orderid; ?> </h1> 
   <div class="top_search" id="topsearch-collection">
            <form action="<?php echo base_url()?>specialevent/collectorder/fetchorder" method="post" id="paymentordercollectsearch" name="balpayform">
           <input name="orderno" type="text" class="search_01 validate[required,custom[integer]]" placeholder="Proceed to collection" id="ordnn"/>
<input type="submit" class="btn" value=""/>
                    </form>
          </div>
            </div>
            
        </div>
        </div>




        <div class="row">
            	<div class="col-md-6" id="ordercollectionleft">
<div class="ordercollection_heading">
        <div class="row">
        	<div class="col-md-12">
            	<h1>Order Details </h1> 
  
            </div></div></div>
                	<div class="user_dtls " id="ordercollectionleftuser_scroll">
                  
                    
                    <ul>
                    	<li class="userlistingdet">
                        <div class="left_feild">Customer</div>
                        <div class="left_feild right_feild"><?php  echo $custname; ?></div>
                        </li>
                        <li class="userlistingdet">
                        <div class="left_feild">Mobile</div>
                        <div class="left_feild right_feild"><?php echo $mobile; ?></div>
                        </li>
                        <li class="userlistingdet">
                        <div class="left_feild">Email</div>
                        <div class="left_feild right_feild"><?php echo $email; ?></div>
                        </li>
                        
                        <li class="userlistingdet">
                        <div class="left_feild">Address</div>
                        <div class="left_feild right_feild"><?php echo $address; ?></div>
                        </li>
                        <li class="userlistingdet">
                        <div class="left_feild">Order Date</div>
                        <div class="left_feild right_feild"><?php echo date("d-m-Y", strtotime($orderdate));?></div>
                        </li>
 <li class="userlistingdet">
                        <div class="left_feild">Delivery Date</div>
                        <div class="left_feild right_feild"><?php echo date("d-m-Y", strtotime($deliverydate));?></div>
                        </li>
<li class="userlistingdet">
 <div class="left_feild">Delivery Time</div>
                        <div class="left_feild right_feild"><?php echo $deliverytime; ?></div>
                        </li>
                        <li class="userlistingdet">
                        <div class="left_feild">Payment Status</div>
                        <div class="left_feild right_feild"><?php echo $pstatus; ?></div>
                        </li>
 <li class="userlistingdet">
                        <div class="left_feild">Total Amount</div>
                        <div class="left_feild right_feild"><?php echo '£ '.number_format((float)$totalamount, 2, '.', ''); ?></div>
                        </li>
 <!--  <li>
                        <div class="left_feild">Balance Amount</div>
                        <div class="left_feild right_feild"></div>
                        </li>  -->
<li class="userlistingdet">
                        <div class="left_feild">Collection Status</div>
                        <div class="left_feild right_feild"><?php echo $collection_status; ?></div>
                        </li>
                        
                        </ul>
                    	
                    </div>
                </div>
                <div class="col-md-6" id="ordercollectionright">
                	<div class="user_dtls order_detils wr">
                    	<ul>
                        	<li class="edititem">Item </li>
                            <li class="edittotqty">Pkg </li>
 <li class="edittotqty">Pkg Nos </li>
<li class="edittotqty">Total Weight </li>
                            <li class="edititem">Status<span> <img class="selectall" id="readybutton" src="<?php echo base_url()?>extras/new/images/selectall-button.jpg" /></span></li>
                              
                        </ul>
                       

 <div class="order_wrap">

<?php $atag=0; if($orderitem){ foreach($orderitem as $itemlist) { ++$atag;?>


<ul class="oreder_content">                      	
<li class="edititem">                           	<div class="item_img">
                        <img src="<?php echo base_url();?>uploads/items/<?php echo $itemlist['item_image']; ?>" />
                                </div>
                                	<h4><?php echo $itemlist['itemname']; ?> </h4>
                                    <p> <?php echo $itemlist['itemdescription']; ?></p>
                             </li>
                           
<li class="edittotqty"><span><?php echo $itemlist['package_quantity']; ?></span></li>
<li class="edittotqty"><span><?php echo $itemlist['package_ordered_number']; ?></span></li>
<li class="edittotqty"><span><?php echo $itemlist['total_item']; ?></span></li>
<li class="edititem"><a class="changestatus" id="statusid<?php echo $atag;?>" onclick="showhideimage(this.id)"><img id="readybutton" src="<?php echo base_url()?>extras/new/images/ready-button.jpg" /></a>
</li>
                        </ul>


<?php } }?>





<?php $atag=9000; if($ordercontainer){ foreach($ordercontainer as $conlist) { ++$atag; ?>

<ul class="oreder_content">                      	
<li class="description">                           	<div class="item_img">
                              <img src="<?php echo base_url();?>extras/images/container.jpg" width="90" height="67"/>
                                </div>
                                	<h4><?php echo $conlist['special_cname']; ?> </h4>
                                    <p> <?php echo $conlist['special_cdesc']; ?></p>
                             </li>
                           
<li class="quantity"><span></span></li>
<li class="quantity"><span></span></li>
<li class="quantitynew"><span><?php echo $conlist['container_quantity']; ?></span></li>
                            <li class="description">    <a class="changestatus" id="statusid<?php echo $atag;?>" onclick="showhideimage(this.id)"><img id="readybutton" src="<?php echo base_url()?>extras/new/images/ready-button.jpg" /></a></li>
                        </ul>


<?php } }?>


</div>
                    </div>
  <div class="row">
            	
                    <div class="col-md-12">
                	<div class="user_dtls  payment012 wr">
                    	<form action="<?php echo base_url()?>specialevent/collectorder/confirmcollection" method="post">
                        	<!--<div class="wr"><input name="" type="checkbox" value=""><label>Discound</label>
                            <b>$125</b></div>-->
                        
                            
                            <div class="abount_bx">
                            £ <?php echo number_format((float)$totalamount, 2, '.', '');  ?>
                            </div>


<input type="hidden" name="orderid" value="<?php echo $orderid; ?>" />
<input name="collected" type="submit" value="OK" class="submitcollection" onclick="this.style.visibility='hidden';"/>
  <input name="collected" type="button" value="Cancel" class="submitcollection" onclick="window.location='<?php echo base_url()?>specialevent/collectorder'"/>                        
                            
                        </form>
                    </div>
                    </div>
            </div>
            
                </div>
            </div>
          
              
           
        </div>
    </div>

 
<script>

function showhideimage(anchorid)
{

buttonid=$("#"+anchorid).children("img").attr("id");
if(buttonid=="readybutton")
{ imgvar='<img id="collectedbutton" src="<?php echo base_url()?>extras/new/images/collected-button.jpg" />';
$("#"+anchorid).html(imgvar);
}
else
{
imgvar='<img id="readybutton" src="<?php echo base_url()?>extras/new/images/ready-button.jpg" />';
$("#"+anchorid).html(imgvar);
}
}

$(".selectall").click(function(){
allselect='<img id="collectedbutton" src="<?php echo base_url()?>extras/new/images/collected-button.jpg" />';
$(".changestatus").html(allselect);
});

</script>
       
        
</body>
</html>