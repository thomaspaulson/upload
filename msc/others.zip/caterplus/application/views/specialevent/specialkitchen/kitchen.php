<?php
$path = APPPATH.'views/headerkitchen.php';
include_once($path);
?>
  
<div id="content_wrapper">
    <div class="container ">
    	<div class="kitchen_heading wr">
        <div class="row">
        	<div class="col-md-12">
            	<h1>Kitchen view - special events </h1>
            </div>
        </div></div>
        
        <!-- left sidebar starts -->
            <div class="sidebar_wrap">
            	<div class="lsidebar wr">
                	<div class="side_wrap">
	                	     <ul class="row2" style="background:black;font-size:16px;font-weight:bold;">
		                         <li class="">Cooking In Progress</li>
		                     </ul>
	                	<?php 
	                		if($started_items){
	                			foreach($started_items as $started_item){	                			
	                	?>
	                	     <ul class="row2">

		                         <li class="item1"><?php echo ucwords(strtolower($started_item['itemname'])),'(',$started_item['additional'],')'; ?></li>
		                     </ul>
		                     <ul class="slide_side">
		                        <li>
		                        <p></p>
		                        </li>
		                     </ul>
	                	<?php
	                			}	                	
	                		}else{
	                	?>
	                	     <!-- <ul class="row2">

		                         <li class="item1">Nothing Started</li>
		                     </ul> -->
	                	<?php
	                		}
	                	?>     
                         </div>
                    <!-- <a href="#" onclick="return false;" class="strat_c">Started</a> -->
                </div>
                <div class="lsidebar">
                	<div class="side_wrap">
	                	     <ul class="row2" style="background:black;font-size:16px;font-weight:bold;">
		                         <li class="">Cooking Completed</li>
		                     </ul>
	                	<?php 
	                		if($completed_items){
	                			foreach($completed_items as $completed_item){	                			
	                	?>
	                	     <ul class="row2">
		                         <li class="item1"><?php echo ucwords(strtolower($completed_item['itemname'])),'(',$completed_item['cooked_stock'],')'; ?></li>
		                     </ul>
		                     <ul class="slide_side">
		                        <li>
		                        <p></p>
		                        </li>
		                     </ul>
	                	<?php
	                			}	                	
	                		}else{
	                	?>
	                	<!--     <ul class="row2">
		                         <li class="item1">Nothing Completed</li>
		                     </ul> -->
	                	<?php
	                		}
	                	?>
                     


                     	</div>
                   <!--  <a href="#" onclick="return false;" class="strat_c">Completed</a> -->
                </div></div>
        <!-- left sidebar ends -->                
                <div class="table_right">
                	<div class="top_bar"><div class="row ">
                    	<div class="col-md-12 ">
                        	<div class="row">
                           <!-- 	<div class="col-md-1 col-sm-2">
                                	<a href="#" class="back">Back </a> 
                                </div> -->
                                <div class="col-md-12 col-sm-12">
                                	<ul>
                                    	<li>                                      	
                                        	<a  href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen"><button   class="btn <?php if($active == 0000){echo 'btn-danger';}else{ echo 'btn-success';} ?>" id="kitchen_all" value="all">All</button></a>
                                        </li>                                	
                                    	<li>
                                        	<form name="form_morning"  id="form_morning" action="" method="post" >
                                        	<input type="hidden" name="start" id="morning_start" value="10">
                                        	<input type="hidden" name="end" id="morning_end" value="13">                                       	
                                        	<input type="submit" class="btn" value="Morning " name="slotname" id="<?php if($active == 1013){echo 'form_morning_button_selected';}else{ echo 'form_morning_button';} ?>">
                                        	</form>
                                        </li>
                                        <li>
                                        	<form name="form_afternoon" id="form_afternoon" action="" method="post">    
                                        	<input type="hidden" name="start" id="afternoon_start" value="13">
                                        	<input type="hidden" name="end" id="afternoon_end" value="16">                                        	                                        	                                    
                                        	<input type="submit" class="btn" value="Afternoon " name="slotname" id="<?php if($active == 1316){echo 'form_afternoon_button_selected';}else{ echo 'form_afternoon_button';} ?>">
                                        	</form>                                        	
                                        </li>
                                        <li>
                                        	<form name="form_evening" id="form_evening" action="" method="post">  
                                        	<input type="hidden" name="start" id="evening_start" value="16">
                                        	<input type="hidden" name="end" id="evening_end" value="19">                                         	                                        	                                      
                                        	<input type="submit" class="btn" value="Evening " name="slotname" id="<?php if($active == 1619){echo 'form_evening_button_selected';}else{ echo 'form_evening_button';} ?>">
                                        	</form>                                        	
                                        </li>
                                        <li class="sel">
                                        	<form name="form_night" id="form_night" action="" method="post">  
                                        	<input type="hidden" name="start" id="night_start" value="19">
                                        	<input type="hidden" name="end" id="night_end" value="22">                                         	                                        	                                      
                                        	<input type="submit" class="btn" value="Night " name="slotname" id="<?php if($active == 1922){echo 'form_night_button_selected';}else{ echo 'form_night_button';} ?>">
                                        	</form>                                        	
                                        </li>
                                    </ul>
                                </div>
                             <!--    <div class="col-md-4 col-sm-4">
                                	<form action="" method="get">
                                    	<input name="" type="text">
                                    </form>
                                </div> -->
                            </div>
                        </div>
                        <div class="col-md-12">
                        <div class="row tab_wrap">
                	<div class="col-md-12">
                    <div class="row clearfix">
		<div class="col-md-12 column">
			<div class="tabbable" id="tabs-931882">
				<ul class="nav nav-tabs nav_tabs2" id="myTab">
					<li class="active">
						<a href="#panel-all" data-toggle="tab">All</a>
					</li>					
				<?php

				$i = 1;
				foreach($menus as $menu){
				?>
					<li>
						<a href="#panel-<?php echo $i; ?>" data-toggle="tab"><?php echo $menu['menutypename'];  ?></a>
					</li>				
				<?php
					$i = $i +1;
				}
				
				?>
                    
				</ul>
				
			<div class="tab-content tab-content2">
			
			
			
			<div class="tab-pane personal_info active" id="panel-all">
				<div class="row">
	                        	<div class="col-md-12 sub_top_bar">
		                            	<ul>

		                                    <li class="item1">Item</li>
		                                    <li class="item2">Unit</li>
		                                    <li class="item3">Order taken</li>
		                                    <li class="item4">cooked stock</li>
		                                    <li class="item5">Total Stock</li>
		                                    <li class="item6">To cook</li>
		                                    <li class="item7">status</li>
		                                 <!--   <li class="item8">Temperature</li>	-->			                                    				                                    
		                                </ul>
	                            	</div>
<?php  

								foreach($allitems as $item){
	
									$total_order_taken = 0;
									$cooked_stock = 0;
									$additional = 0;  
									$itemname = $item['itemname'];
									$itemunits = $item['itemunits'];
									$item_id = $item['itemid'];
									$item_temp_check = $item['itemtemperaturecheck'];
									$item_temp = $item['temperature_value'];



									foreach($total_cooked_stocks as $total_cooked_stock){
										if($item['itemid'] == $total_cooked_stock['item_id']){
											$to_co_stock = 	$total_cooked_stock['cooked_stock'];
											$to_collected = $total_cooked_stock['collected'];
											if($to_co_stock >= $to_collected){
												$to_co_stock = $to_co_stock - $to_collected;												
											}																						
										}									
									}

									
                                                                                    
									$st = 0;
									$temp = 0;
									foreach($temperatures as $temperature){

											if($item['itemid'] == $temperature['item_id']){
												$temp = $temperature['temperatue'];
												$additional =  $temperature['additional'];
												$cooked_stock =  $temperature['cooked_stock'];
												$total_order_taken =  $temperature['total_order_taken'];
												$collected = $temperature['collected'];
												if($active == 0000){
													$session_table = $temperature['session'];
												}

												if($cooked_stock >= $collected){
													$cooked_stock = $cooked_stock - $collected;												
												}												

												$total_order_taken = $total_order_taken - $collected;
												if($st == 0){
													$cooking_status = $temperature['status'];
													if($cooking_status != 'not started'){
														$st = 1;													
													}
												
												}
												
												if($to_co_stock > $total_order_taken){
													$to_cook = 0 ;
												}else{
													$to_cook = ($total_order_taken) - $to_co_stock;																								
												}

											}									
									
									}

									
							?>
								
							                            	
			                            <div class="col-md-12 sub_top_bar table_conntent">			                            
			                            	<form action="" method="post">
								<ul>

				                                    <li class="item1"><?php echo ucwords(strtolower($itemname)); ?> 
				                                    <?php 
				                                    if($item_temp_check == 'yes'){ 
				                                    ?>
				                                    <img src="<?php echo base_url(); ?>extras/images/avatar_3cf58ba8866d_16.png"></li>				                                    
				                                    <?php 
				                                    	}
				                                    ?>

				                                    <li class="item2"><?php echo $itemunits; ?></li>
				                                    <li class="item3"><?php echo $total_order_taken; ?></li>
				                                    <li class="item4"><?php  echo $cooked_stock;  ?></li>
				                                    <li class="item5"><?php  echo $to_co_stock;  ?></li>				                                    					                                   
				                                    <li class="item6"><?php echo $to_cook; ?></li>
				                                    <li class="item7">
				                                    	<?php
					                                    	if($cooking_status == "not started"){					                                    					                                    					                                    	
				                                    	?>
				                                    	
				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>" class="btn btn-danger <?php if($active != 0000){echo 'popup_link3';}else{echo 'popup_link4';} ?>"  >Start Cooking</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	
				                                    	<?php
					                                    	if($cooking_status == "started"){					                                    					                                    					                                    	
				                                    	?>
									<?php
				                                    		if($active == 0000){
				                                    	
				                                    	?>
				                                    	<input type="hidden" name="session_<?php echo $item_id; ?>" id="session_<?php echo $item_id; ?>" value="<?php echo $session_table; ?>" />
                                                                        <?php
                                                                        	}
                                                                        
                                                                        ?>
				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>"  class="btn btn-warning <?php if($active != 0000){echo 'popup_link3';}else{echo 'popup_link4';} ?>"   >Started</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	<?php
					                                    	if($cooking_status == "completed"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>"  class="btn btn-success <?php if($active != 0000){echo 'popup_link3';}else{echo 'popup_link4';} ?>"   >Completed</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>				                                    	
				                                    	
				                                    </li>
				                           <!--         <li class="item8">
				                                    	<?php 
				                                    		if($temp == 0){
				                                    	?>
				                                    		<button onclick="return false;"   class="btn btn-success">Not Set</button>
				                                    	<?php
				                                    		}else{ 
				                                    			echo $temp;
				                                    		} 
				                                    	?>
				                                    </li> -->				                                    		             
				                                </ul>

							</form>							
			                            </div>		                            
						<?php
							} 
							
						?>	                            	
	                            	
	                            	
	                            	
	                            	
	                        </div>
                        </div>
			
			
			
			
			
			<input name="ajax_item_id" id="ajax_item_id" type="hidden"  value="0">
			<input name="ajax_item_status" id="ajax_item_status" type="hidden"  value="">
			<input name="ajax_item_temp" id="ajax_item_temp" type="hidden"  value="0">
			<input name="ajax_additional" id="ajax_additional" type="hidden"  value="0">
			<input name="ajax_temp_check" id="ajax_temp_check" type="hidden"  value="0">			
			<input name="ajax_which_table" id="ajax_which_table" type="hidden"  value="0">			
			<input name="ajax_session" id="ajax_session" type="hidden"  value="0">			
			<input name="ajax_pop_up_open" id="ajax_pop_up_open" type="hidden"  value="no">			
			
			
			
			
												
				<?php
				$i = 1;
				foreach($menus as $menu){
				?>
					<div class="tab-pane personal_info" id="panel-<?php echo $i; ?>">
						<div class="row">
			                        	<div class="col-md-12 sub_top_bar">
				                            	<ul>

				                                    <li class="item1">Item</li>
				                                    <li class="item2">Unit</li>
				                                    <li class="item3">Order taken</li>
				                                    <li class="item4">cooked stock</li>
				                                    <li class="item5">Total Stock</li>
				                                    <li class="item6">To cook</li>
				                                    <li class="item7">status</li>
				                                <!--    <li class="item8">Temperature</li>	-->			                                    				                                    
				                                </ul>
			                            	</div>
							<?php  

								foreach($allitems as $item){
								if($item['menutype'] == $menu['menutypeid']){	
									$total_order_taken = 0;  
									$itemname = $item['itemname'];
									$itemunits = $item['itemunits'];
									$item_id = $item['itemid'];
									$item_temp_check = $item['itemtemperaturecheck'];
									$item_temp = $item['temperature_value'];
									
									foreach($total_cooked_stocks as $total_cooked_stock){
										if($item['itemid'] == $total_cooked_stock['item_id']){
											$to_co_stock = 	$total_cooked_stock['cooked_stock'];
											$to_collected = $total_cooked_stock['collected'];
											if($to_co_stock >= $to_collected){
												$to_co_stock = $to_co_stock - $to_collected;												
											}																						
										}									
									}																		
									
									
									foreach($temperatures as $temperature){
											if($item['itemid'] == $temperature['item_id']){
												$temp = $temperature['temperatue'];
												$additional = $temperature['additional'];
												$cooked_stock = $temperature['cooked_stock'];
												$total_order_taken = $temperature['total_order_taken'];
												$collected = $temperature['collected'];
												if($cooked_stock >= $collected){
													$cooked_stock = $cooked_stock - $collected;												
												}

												$total_order_taken = $total_order_taken - $collected;												
												$cooking_status = $temperature['status'];												
												if($to_co_stock > $total_order_taken){
													$to_cook = 0 ;
												}else{
													$to_cook = ($total_order_taken) - $to_co_stock;																								
												}

											}									
									
									}
									
									
							?>
								
							                            	
			                            <div class="col-md-12 sub_top_bar table_conntent">			                            
			                            	<form action="" method="post">
								<ul>

				                                    <li class="item1">
				                                    <?php echo ucwords(strtolower($itemname)); ?>
				                                    
				                                    <?php 
				                                    if($item_temp_check == 'yes'){ 
				                                    ?>
				                                    <img src="<?php echo base_url(); ?>extras/images/avatar_3cf58ba8866d_16.png"></li>				                                    
				                                    <?php 
				                                    	}
				                                    ?>				                                    </li>
				                                    <li class="item2"><?php echo $itemunits; ?></li>
				                                    <li class="item3"><?php echo $total_order_taken; ?></li>
				                                    <li class="item4"><?php echo $cooked_stock; ?></li>
				                                    <li class="item5"><?php  echo $to_co_stock;  ?></li>				                                    					                                    			                                    				                                     
				                                    <li class="item6"><?php echo $to_cook; ?></li>
				                                    <li class="item7">
				                                    	<?php
					                                    	if($cooking_status == "not started"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>" class="btn btn-danger <?php if($active != 0000){echo 'popup_link3';}else{echo 'popup_link4';} ?>"  >Start Cooking</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	
				                                    	<?php
					                                    	if($cooking_status == "started"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>"  class="btn btn-warning <?php if($active != 0000){echo 'popup_link3';}else{echo 'popup_link4';} ?>"   >Started</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	<?php
					                                    	if($cooking_status == "completed"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>"  class="btn btn-success <?php if($active != 0000){echo 'popup_link3';}else{echo 'popup_link4';} ?>"   >Completed</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>				                                    	
				                                    	
				                                    </li>
				                             <!--       <li class="item8">
				                                    	<?php 
				                                    		if($temp == 0){
				                                    	?>
				                                    		<button onclick="return false;"   class="btn btn-success">Not Set</button>
				                                    	<?php
				                                    		}else{ 
				                                    			echo $temp;
				                                    		} 
				                                    	?>
				                                    </li> -->				                                    		             
				                                </ul>

							</form>							
			                            </div>		                            
						<?php

						 	}
							} 
							
						?>                            			
			                            
			                        </div> 		
		                        </div>			
				<?php
					$i = $i +1;
				}
				
				?>
                         
                        </div>
                        </div>
                    </div>
                    </div>

                </div>                	
              
           
        </div>
    </div>
  </div>
 
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 
<script type="text/javascript">


</script>

		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquerypp.custom.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquery.elastislide.js"></script>
		<script type="text/javascript">
			
			$( '#carousel' ).elastislide();
				$( '#carousel1' ).elastislide();
				$( '#carousel2' ).elastislide();
				$( '#carousel3' ).elastislide();
				$( '#carousel4' ).elastislide();
				$( '#carousel5' ).elastislide();
				
				$(document).ready(function() {
					$( ".more_list" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});
      
	    $( ".arrow_side" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});            
                });
			
		</script>
        <script type="text/javascript">
		$(document).ready(function() {
			$("#popup_link1").click (function(){
				$(".popup1").show(300);
				});
				$(".close3a").click (function(){
				$(".popup1").hide(300);
				}); 
				$("#popup_link2").click (function(){
				$(".popup2").show(300);
				});
				$(".close3a").click (function(){
  					$('#set_temp').val(0);				
				$(".popup2").hide(300);
				});
				$(".popup_link3").click (function(){
					$('#ajax_session').val($(this).html());				
					if($(this).html() == "Started"){
						$('#total_cooking_items').attr('disabled','true');
					}
					if($(this).html() == "Completed"){											
						var status  = '<option value="completed">Completed</option><option value="started">Started</option>';
						$('#change_cooking_status').html(status);						
						
					}
					if($(this).html() == "Start Cooking"){						
						var status  = '<option value="started">Started</option>';
						$('#change_cooking_status').html(status);						
						
					}														
					var val = $(this).val();
					$('#ajax_item_id').val(val);
					$('#ajax_pop_up_open').val('yes');					
					var add = $(this).attr('name');
					var temp_check = $(this).attr('id');
					var spli = temp_check.split("_");
					temp_check = spli[0];
					var temp = spli[1];                                            						
					$('#ajax_temp_check').val(temp_check);									
					$('#ajax_item_temp').val(temp);					
					$('#total_cooking_items').val(add);
					if(temp_check == 'yes'){
						$('#display_temp').show();
					}else{
						$('#display_temp').hide();					
					}										
					$(".statuspopup").show(300);
				});
				$(".popup_link4").click (function(){
					$('#ajax_pop_up_open').val('yes');				
					var val = $(this).val();
					$('#ajax_item_id').val(val);
					$('#ajax_session').val($(this).html());									
					if($(this).html() == "Started"){
						$('#all_total_cooking_items').attr('disabled','true');
						var session = $('#session_'+val).val();
						if(session == 'morning'){
							var session_option = '<option value="' + session  + '">Morning</option>';						
						}else if(session == 'afternoon'){
							var session_option = '<option value="' + session  + '">Afternoon</option>';												
						}else if(session == 'evening'){
							var session_option = '<option value="' + session  + '">Evening</option>';												
						}else if(session == 'night'){
							var session_option = '<option value="' + session  + '">Night</option>';												
						}

						$('#change_session').html(session_option);
						$('#change_session').attr('disabled','true');
						var status  = '<option value="started">Started</option><option value="completed">Completed</option>';
						$('#all_change_cooking_status').html(status);						
												
					}
					
					if($(this).html() == "Start Cooking"){
						$('#all_total_cooking_items').removeAttr('disabled');
						var status = '<option value="morning">Morning</option><option value="afternoon">Afternoon</option><option value="evening">Evening</option><option value="night">Night</option>';
						$('#change_session').html(status);						
						$('#change_session').removeAttr('disabled');
						var statuss  = '<option value="started">Started</option>';
						$('#all_change_cooking_status').html(statuss);						
					}					
					
					
					if($(this).html() == "Completed"){
						$('#all_total_cooking_items').attr('disabled','true');
						var session = $('#session_'+val).val();
						if(session == 'morning'){
							var session_option = '<option value="' + session  + '">Morning</option>';						
						}else if(session == 'afternoon'){
							var session_option = '<option value="' + session  + '">Afternoon</option>';												
						}else if(session == 'evening'){
							var session_option = '<option value="' + session  + '">Evening</option>';												
						}else if(session == 'night'){
							var session_option = '<option value="' + session  + '">Night</option>';												
						}

						$('#change_session').html(session_option);
						$('#change_session').attr('disabled','true');
						var status  = '<option value="completed">Completed</option>';
						$('#all_change_cooking_status').html(status);						
						
					}										
															
					
					var add = $(this).attr('name');
					var temp_check = $(this).attr('id');
					var spli = temp_check.split("_");
					temp_check = spli[0];
					var temp = spli[1];                                            						
					$('#ajax_temp_check').val(temp_check);									
					$('#ajax_item_temp').val(temp);					
					$('#all_total_cooking_items').val(add);
					if(temp_check == 'yes'){
						$('#all_display_temp').show();
					}else{
						$('#all_display_temp').hide();					
					}										
					$(".allstatuspopup").show(300);
				});				
				$(".close3a").click (function(){
					$(".popup3").hide(300);
				});	
				$(".close3a").click (function(){
					$(".temperatuepopup").hide(300);
				});
				$(".close3a").click (function(){
  					$('#set_temp').val(0);				
					$(".statuspopup").hide(300);
					$('#ajax_pop_up_open').val('no');					
				});
				$(".close3a").click (function(){
					$(".allstatuspopup").hide(300);
				});				
				$(".additional_pop_up_link").click (function(){
					var val = $(this).val();
					$('#ajax_item_id').val(val);
					$(".additional_pop_up").show(300);
				});				
				$(".close3a").click (function(){
  					$('#set_temp').val(0);	
  					$('#user_id').val('');
  					$('#user_pin').val('');
  					$('#all_error').html('');
  					$('#part_error').html('');  					  					  								
					$(".additional_pop_up").hide(300);
					$('#ajax_pop_up_open').val('no');					
										
				});															
		});
		</script>
    <div class="popupWrap2a popup1">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <h3>Pop up heading </h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut dictum sem id porta tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra</p>
      <a href="#" class="ok">Ok</a>
       <a href="#" class="cancel">Cancel</a>
    	
  <a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
    </div>
    </div> 
    </div>
    
   <!-- 3rd popup --> 
   <div class="popupWrap2a popup3">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      	<a href="#" onclick="close_temp();" class="ok" style="margin-left:73px;">Temperature</a>
        <a href="#" onclick="close_status();" class="cancel">Status</a>    	
  	<a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
  	<script>
  		function close_temp(){
		       	$('#ajax_item_status').val('temp');  		
			$(".popup3").hide(300);  		
			$(".temperatuepopup").show(300);  		
  		}
  	</script>
  	  <script>
  		function close_status(){  		
			$(".popup3").hide(300);  		
			$(".statuspopup").show(300);  		
  		}
  	</script>
    </div>
    </div> 
    </div>
    
   <!-- 3rd popup ends -->  
   
  
   
   
   <!-- temperature popup -->
   <div class="popupWrap2a temperatuepopup">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
    	<input type="text" class="form-control" name="temperature" id="temperature" placeholder="temperature">
	<a href="#"  class="ok" style="margin-left:0px;" onclick="set_temp();" >Set</a>    	    	
  	<a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
  	<script>
  		function set_temp(){
		       var temperature = $('#temperature').val();
		       	$('#ajax_item_temp').val(temperature);
			$(".statuspopup").hide(300);  		
			$(".popup2").show(300);  	
  		}

  	</script>
  	  	
    </div>
    </div> 
    </div>
    
   <!-- temperature popup ends-->
   
   
      <!-- addtional popup -->
   <div class="popupWrap2a additional_pop_up">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
    	<input type="text" class="form-control" name="additional" id="additional" placeholder="additional number of items">
	<a href="#"  class="ok" style="margin-left:0px;" onclick="set_additional();" >Set</a>    	    	
  	<a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
  	<script>
  		function set_additional(){
		        var additional = $('#additional').val();
		       	$('#ajax_additional').val(additional);
		       	$('#ajax_item_status').val('additional');		       	
			$(".additional_pop_up").hide(300);  		
			$(".popup2").show(300);  	
  		}

  	</script>  	
    </div>
    </div> 
    </div>
    
   <!-- additional popup ends--> 
   
   
      <!-- status popup -->
   <div class="popupWrap2a statuspopup">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
    	<p id="part_error" style="color:red;">
    	</p>
	<p>
	Total Item To Be Cooked
	</p>
	<input type="text" name="total_cooking_items" id="total_cooking_items" placeholder="Total item To Be Cooked" class="form-control" value=""> 
	<p>
	Status
	</p>   
	<select name="change_cooking_status" id="change_cooking_status" class="form-control" autocomplete="off">
		<option value="started">Started</option>
		<option value="completed">Completed</option>				
	<select>
	<span id="display_temp" style="display:none;">
		<h6>Set Temperature</h6>
		<input type="text" name="set_temp" disabled="true" id="set_temp" placeholder="Set Temperature" class="form-control" value="0"> 
	</span>	
	<a href="#"  class="ok" style="margin-left:0px;" onclick="get_ajax_item_id();" >Submit</a>
  	<a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
  	<script>
  		function get_ajax_item_id(){
		       var cook_status = $('#change_cooking_status').val();
		       	$('#ajax_item_status').val(cook_status);
  
  			 var temp = $('#set_temp').val();			
			$('#ajax_item_temp').val(temp);	
			var check_session = $('#ajax_session').val();
			if(check_session == 'Started' && cook_status == 'started'){
				$('#part_error').html('Cooking Already Started!');
			}else{
				$(".statuspopup").hide(300);  		
				$(".popup2").show(300);			
			}			
  		}
  		
  		$('#change_cooking_status').change(
  			function(){
  				var cook_status = $('#change_cooking_status').val();
				var temp = $('#ajax_item_temp').val();  				
  				if(cook_status == 'completed'){
  					$('#set_temp').val(temp);
  					$('#set_temp').removeAttr('disabled');

  				}else if(cook_status == 'started'){
  					$('#set_temp').attr('disabled','true');
  					$('#set_temp').val(0);  					  				
  				}
  			}
  		);

  	</script>
   	
    </div>
    </div> 
    </div>
    
   <!-- status popup ends--> 
   
   
      <!-- all status popup -->
   <div class="popupWrap2a allstatuspopup">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
    	<p id="all_error" style="color:red;">
    	</p>
	<p>
	Total Item To Be Cooked
	</p>
	<input type="text" name="all_total_cooking_items" id="all_total_cooking_items" placeholder="Total item To Be Cooked" class="form-control" value=""> 
	<p>
	Session
	</p>   
	<select name="change_session" id="change_session" class="form-control" autocomplete="off">
		<option value="morning">Morning</option>
		<option value="afternoon">Afternoon</option>
		<option value="evening">Evening</option>
		<option value="night">Night</option>								
	<select>	
	<p>
	Status
	</p>   
	<select name="all_change_cooking_status" id="all_change_cooking_status" class="form-control" autocomplete="off">
		<option value="started">Started</option>
		<option value="completed">Completed</option>				
	<select>
	<span id="all_display_temp" style="display:none;">
		<h6>Set Temperature</h6>
		<input type="text" name="all_set_temp" disabled="true" id="all_set_temp" placeholder="Set Temperature" class="form-control" value="0"> 
	</span>	
	<a href="#"  class="ok" style="margin-left:0px;" onclick="all_get_ajax_item_id();" >Change</a>
  	<a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
  	<script>
  		function all_get_ajax_item_id(){
		        var cook_status = $('#all_change_cooking_status').val();
		       	$('#ajax_item_status').val(cook_status);
			var change = $('#change_session').val();
			$('#ajax_which_table').val(change);
  			var temp = $('#all_set_temp').val();			
			$('#ajax_item_temp').val(temp);
			var check_session = $('#ajax_session').val();
			if(check_session == 'Started' && cook_status == 'started'){
				$('#all_error').html('Cooking Already Started!');
			}else{
				$(".allstatuspopup").hide(300);  		
				$(".popup2").show(300);			
			}									       	
  
  		}
  		
  		$('#all_change_cooking_status').change(
  			function(){
  				var cook_status = $('#all_change_cooking_status').val();
				var temp = $('#ajax_item_temp').val();  				
  				if(cook_status == 'completed'){
  					$('#all_set_temp').val(temp);
  					$('#all_set_temp').removeAttr('disabled');
  				}else if(cook_status == 'started'){
  					$('#all_set_temp').attr('disabled','true');
  					$('#all_set_temp').val(0);  					  				
  				}
  			}
  		);
 		

  	</script>
   	
    </div>
    </div> 
    </div>
    
   <!-- all status popup ends-->    
   
   
   
   
         
    
    
    <div class="popupWrap2a popup2">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <p id="auth_error" style="color:black;"></p>
      <input type="text" class="form-control" name="user_id" id="user_id" placeholder="Enter Your User ID" autocomplete="off">    
      <input type="password" name="user_pin" id="user_pin" class="form-control" placeholder="Enter Your Pin Number"> 
      <p style="margin-top:6px;">
       <button name="auth" onclick="auth()" id="auth" class="btn btn-primary">Submit</button>
      </p>
      
    	
  <a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
  <script>
	var base_url = "<?php echo base_url() ?>";
  </script>
  <script>
  	function auth(){
		var status_table_name = "<?php echo $status_table_name; ?>";	
		var ajax_additional = $('#total_cooking_items').val();		
		if(status_table_name == 'all'){
			var ajax_additional = $('#all_total_cooking_items').val();

		}			
		
		if(status_table_name == 'all'){
			status_table_name = $('#ajax_which_table').val();
		}
		var user_id = $('#user_id').val();
		var user_pin = $('#user_pin').val();	
		var ajax_id = $('#ajax_item_id').val();
		var ajax_status = $('#ajax_item_status').val();
		var ajax_item_temp = $('#ajax_item_temp').val();                                                                               				
		$.ajax(
			{
				url: base_url + 'specialevent/specialkitchen/auth_ajax/' + user_id + '/' + user_pin + '/' + status_table_name + '/' + ajax_id + '/' + ajax_status + '/' + ajax_item_temp + '/' + ajax_additional,
				type: "get",					
				success: function(msg){
    
					if(msg == 0){
						$('#auth_error').html('Incorrect User ID / Pin Combination!.');					
					}else if(msg == 'error'){
						$('#auth_error').html('Some Error Occured.');
					}else{
						if(status_table_name == 'morning'){												
							$('#form_morning').submit();
						}else if(status_table_name == 'afternoon'){
							$('#form_afternoon').submit();						
						}else if(status_table_name == 'evening'){
							$('#form_evening').submit();						
						}else if(status_table_name == 'night'){
							$('#form_night').submit();						
						}else{
							location.reload();						
						}
										
					}

				}
			}							
		);


  	}
  </script>
  <script>
    $('#myTab a').click(function (e) {
        e.preventDefault();
        $(this).tab('show');
    });

    // store the currently selected tab in the hash value
    $("ul.nav-tabs > li > a").on("shown.bs.tab", function (e) {
        var id = $(e.target).attr("href").substr(1);
        window.location.hash = id;
    });

    // on load of the page: switch to the currently selected tab
    var hash = window.location.hash;
    $('#myTab a[href="' + hash + '"]').tab('show');
</script>
<script>
	var base_url = "<?php echo base_url(); ?>";		
</script>
<script>
$(window).bind("load", function() {
	(function ajax_reload() {

			var base_url = "<?php echo base_url(); ?>";	
			var status_table_name = "<?php echo $status_table_name; ?>";
			if(status_table_name == 'all'){
				$.ajax(
					{
						url: base_url + 'specialevent/specialkitchen/viewkitchen',
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);

															
							}

						},															
					
					}
				);			
			}else if(status_table_name == 'morning'){
				var morning_start = $('#morning_start').val();
				var morning_end = $('#morning_end').val();
				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'specialevent/specialkitchen/viewkitchen',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
					
					
					
					}
				);			
			}else if(status_table_name == 'evening'){
				var morning_start = $('#evening_start').val();
				var morning_end = $('#evening_end').val();
				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'specialevent/specialkitchen/viewkitchen',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
										
					
					}
				);			
			}else if(status_table_name == 'afternoon'){
				var morning_start = $('#afternoon_start').val();
				var morning_end = $('#afternoon_end').val();

				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'specialevent/specialkitchen/viewkitchen',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
					
					
					
					}
				);			
			}else if(status_table_name == 'night'){
				var morning_start = $('#night_start').val();
				var morning_end = $('#night_end').val();
				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'specialevent/specialkitchen/viewkitchen',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
					
					
					
					}
				);			
			}		
	
	})();
	
});
</script>




    </div>
    </div>         
    <div class="clear"></div>
    <div class="wrapper-footer"></div>         
<?php
$path = APPPATH.'views/footerkitchen.php';
include_once($path);
?>