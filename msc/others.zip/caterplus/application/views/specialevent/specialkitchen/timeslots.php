<html>
	<head>
	
	</head>
	<body>

			<select name="timeslots" id="timeslots">
				<option value=" ">Select Time Slots</option>
				<?php
					$available_time_slots = [1,2,3,6,9];
					for($i = 0;$i < count($available_time_slots);$i++){
				?>
				<option value="<?php echo $available_time_slots[$i] ; ?>"><?php echo $available_time_slots[$i] ; ?> hours</option>
				
				<?php
					}
				?>												
			</select>
			<div id="radio_buttons">


			</div>
		
			<div id="details">

			</div>			

	<script src="<?php echo base_url();?>extras/extra/js/jquery.min.js"></script>
	<script>
		var base_url = "<?php echo base_url() ?>";
	</script>
	<script>
		$('#timeslots').change(
			function(){
				var val = $(this).val();
				$.ajax(
					{
						url: base_url + 'specialevent/specialkitchen/get_timeslots_ajax/' + val,
						type: "get",					
						success: function(msg){
							$('#radio_buttons').html(msg);
						}
					}							
				);

			}
		);
	</script>
	<script>
		function get_time_slot_details(value){
				var val = value;
				$.ajax(
					{
						url: base_url + 'specialevent/specialkitchen/get_timeslot_orders_ajax/' + val,
						type: "get",					
						success: function(msg){
							$('#details').html(msg);
						}
					}							
				);
		}
		
		function additional(){
			var val = $("input[name=time_slots_avail]:checked").val();
				$.ajax(
					{
						url: base_url + 'specialevent/specialkitchen/add_additional_ajax/' + val,
						type: "get",					
						success: function(msg){
							$('#details').html(msg);
						}
					}							
				);
		}
	</script>		
	</body>
</html>