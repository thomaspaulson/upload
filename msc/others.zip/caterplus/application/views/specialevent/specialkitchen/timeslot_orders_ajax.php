<form action="" method="post">
	<table border="1">
		<tr>
			<th>Item</th>
			<th>Item Unit</th>
			<th>Total Order</th>						
		</tr>
<?php
	foreach($allitems as $item){
		$total_order_taken = 0;  
		$itemname = $item['itemname'];
		$itemunits = $item['itemunits'];
		foreach($timeslot_orders as $order){
			if($item['itemid'] == $order['itemid']){
				$total_order_taken = $total_order_taken + $order['total_item'] ;
			}
		}
?>
	<tr>
		<td><?php echo $itemname; ?></td>
		<td><?php echo $itemunits; ?></td>
		<td><?php echo $total_order_taken; ?></td>
	</tr>
<?php
	}
?>
	</table>
</form>