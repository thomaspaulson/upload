<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Special Kitchen</title>
</head>

<body>
<table border="2">
<caption>KITCHEN VIEW</caption>
<th  width="100">Items</th>
<th  width="100">Units</th>
<th width="100">Order taken</th>
<th  width="100">Cooked Stock</th>
<th  width="100">Raw Stock</th>
<th  width="100">Short Stock</th>
<th  width="100">To Coock</th>
<th  width="100">Cooking Status</th>
<?php  
	foreach($allitems as $item){
		$total_order_taken = 0;  
		$itemname = $item['itemname'];
		$itemunits = $item['itemunits'];
		foreach($orders as $order){
			if($item['itemid'] == $order['itemid']){
				$total_order_taken = $total_order_taken + $order['total_item'] ;
			}
		}
		if($cooked_items){
			foreach($cooked_items as $cooked_item){
				if($item['itemid'] == $cooked_item['itemid']){
					$total_cooked = $cooked_item['balance_items'];
					$balance = $total_order_taken - $total_cooked;
				}else{
					$total_cooked = 0;
					$balance = $total_order_taken - $total_cooked;				
				}
			}		
		
		}else{
			$total_cooked = 0;
			$balance = $total_order_taken ;
		}
		
?>
		<form action="">
			<tr>
				<td><?php echo $itemname; ?></td>
				<td><?php echo $itemunits; ?></td>
				<td><?php echo $total_order_taken; ?></td>
				<td><?php echo $total_cooked; ?></td>	
				<td></td>	
				<td></td>
				<td><?php echo $balance; ?></td>
				<td style="text-align:center;"><input type="submit" name="action" value="Started"></td>																		
			</tr>
		</form>
<?php
 
	} 
	
?>
</table>





</body>
</html>