<?php
	$first = 6;
	$last = 24;
	for($i = $first;($i+$interval)<=$last;$i=$i+$interval){
?>
	<input type="radio" name="time_slots_avail" value="<?php echo $i,'-',$i+$interval; ?>" onclick="get_time_slot_details(this.value)"> <?php echo $i,'-',$i+$interval; ?>	
<?php	
	}
?>
<button id="select_time_slot" onclick="additional();return false;">Select</button>