  <body>
<div id="top_wrapper">
    <div class="container">
    <div class="row">
        <div class=" col-md-3 col-sm-3">
        <div class="caterplus_logo"> <img src="<?php echo base_url();?>extras/extra/images/caterplus_logo.png" alt="Cater Plus"> </div>
      </div>



      </div>
  </div>
  </div>
<div id="content_wrapper">
    <div class="container ">
    	<div class="kitchen_heading wr">
        <div class="row">
        	<div class="col-md-12">
            	<h1>Kitchen view - special events </h1>
            </div>
        </div></div>
        
        <!-- left sidebar starts -->
            <div class="sidebar_wrap">
            	<div class="lsidebar wr">
                	<div class="side_wrap">
	                	<?php 
	                		if($started_items){
	                			foreach($started_items as $started_item){	                			
	                	?>
	                	     <ul class="row2">
		                         <li class="arrow_side"></li>
		                         <li class="item1"><?php echo $started_item['itemname'] ?></li>
		                     </ul>
		                     <ul class="slide_side">
		                        <li>
		                        <p></p>
		                        </li>
		                     </ul>
	                	<?php
	                			}	                	
	                		}else{
	                	?>
	                	     <ul class="row2">
		                         <li class="arrow_side"></li>
		                         <li class="item1">Nothing Started</li>
		                     </ul>
	                	<?php
	                		}
	                	?>     
                         </div>
                     <a href="#" onclick="return false;" class="strat_c">Started</a>
                </div>
                <div class="lsidebar">
                	<div class="side_wrap">
	                	<?php 
	                		if($completed_items){
	                			foreach($completed_items as $completed_item){	                			
	                	?>
	                	     <ul class="row2">
		                         <li class="arrow_side"></li>
		                         <li class="item1"><?php echo $completed_item['itemname'] ?></li>
		                     </ul>
		                     <ul class="slide_side">
		                        <li>
		                        <p></p>
		                        </li>
		                     </ul>
	                	<?php
	                			}	                	
	                		}else{
	                	?>
	                	     <ul class="row2">
		                         <li class="arrow_side"></li>
		                         <li class="item1">Nothing Completed</li>
		                     </ul>
	                	<?php
	                		}
	                	?>
                     


                     	</div>
                     <a href="#" onclick="return false;" class="strat_c">Completed</a>
                </div></div>
        <!-- left sidebar ends -->                
                <div class="table_right">
                	<div class="top_bar"><div class="row ">
                    	<div class="col-md-12 ">
                        	<div class="row">
                           <!-- 	<div class="col-md-1 col-sm-2">
                                	<a href="#" class="back">Back </a> 
                                </div> -->
                                <div class="col-md-12 col-sm-12">
                                	<ul>
                                    	<li>
                                        	<form action="" method="post">
                                        	<input type="hidden" name="start" value="10">
                                        	<input type="hidden" name="end" value="13">                                       	
                                        	<input type="submit" class="btn <?php if($active == 1013){echo 'btn-danger';}else{ echo 'btn-success';} ?>" value="Morning ">
                                        	</form>
                                        </li>
                                        <li>
                                        	<form action="" method="post">    
                                        	<input type="hidden" name="start" value="13">
                                        	<input type="hidden" name="end" value="16">                                        	                                        	                                    
                                        	<input type="submit" class="btn <?php if($active == 1316){echo 'btn-danger';}else{ echo 'btn-success';} ?>" value="Afternoon ">
                                        	</form>                                        	
                                        </li>
                                        <li>
                                        	<form action="" method="post">  
                                        	<input type="hidden" name="start" value="16">
                                        	<input type="hidden" name="end" value="19">                                         	                                        	                                      
                                        	<input type="submit" class="btn <?php if($active == 1619){echo 'btn-danger';}else{ echo 'btn-success';} ?>" value="Evening ">
                                        	</form>                                        	
                                        </li>
                                        <li class="sel">
                                        	<form action="" method="post">  
                                        	<input type="hidden" name="start" value="19">
                                        	<input type="hidden" name="end" value="22">                                         	                                        	                                      
                                        	<input type="submit" class="btn <?php if($active == 1922){echo 'btn-danger';}else{ echo 'btn-success';} ?>" value="Night ">
                                        	</form>                                        	
                                        </li>
                                    </ul>
                                </div>
                             <!--    <div class="col-md-4 col-sm-4">
                                	<form action="" method="get">
                                    	<input name="" type="text">
                                    </form>
                                </div> -->
                            </div>
                        </div>
                        <div class="col-md-12">
                        <div class="row tab_wrap">
                	<div class="col-md-12">
                    <div class="row clearfix">
		<div class="col-md-12 column">
			<div class="tabbable" id="tabs-931882">
				<ul class="nav nav-tabs nav_tabs2">
				<?php
				$i = 1;
				foreach($menus as $menu){
				?>
					<li <?php if($i == 1){echo 'class="active"';} ?>>
						<a href="#panel-<?php echo $i; ?>" data-toggle="tab"><?php echo $menu['menutypename'];  ?></a>
					</li>				
				<?php
					$i = $i +1;
				}
				
				?>
                    
				</ul>
				
			<div class="tab-content tab-content2">
			<?php
				$i = 1;
				foreach($menus as $menu){
				?>
					<div class="tab-pane personal_info <?php if($i == 1){echo 'active';} ?>" id="panel-<?php echo $i; ?>">
						<div class="row">
			                        	<div class="col-md-12 sub_top_bar">
				                            	<ul>
				                                    <li></li>
				                                    <li class="item1">Item</li>
				                                    <li class="item2">Unit</li>
				                                    <li class="item3">Order taken</li>
				                                    <li class="item4">cooked stock</li>
				                                    <li class="item5">Additional</li>
				                                    <li class="item6">To cook</li>
				                                    <li class="item7">status</li>
				                                    
				                                    
				                                </ul>
			                            	</div>
							<?php  
								$head = 1;
								foreach($allitems as $item){
								if($item['menutype'] == $menu['menutypeid']){	
									$total_order_taken = 0;  
									$itemname = $item['itemname'];
									$itemunits = $item['itemunits'];
									foreach($orders as $order){
										if($item['itemid'] == $order['itemid']){
											$total_order_taken = $total_order_taken + $order['total_item'] ;
										}
									}
									if($cooked_items){
										foreach($cooked_items as $cooked_item){
											if($item['itemid'] == $cooked_item['itemid']){
												$total_cooked = $cooked_item['balance_items'];
												$balance = $total_order_taken - $total_cooked;
											}else{
												$total_cooked = 0;
												$balance = $total_order_taken - $total_cooked;				
											}
										}		
									
									}else{
										$total_cooked = 0;
										$balance = $total_order_taken ;
									}
									
									if($cooking_status_items){
										foreach($cooking_status_items as $cooking_status_item){
											if($item['itemid'] == $cooking_status_item['item_id']){
												$cooking_status = $cooking_status_item['status'];
											}
										}
									
									}
									
							?>
							
				<!--		<?php
							if($head == 1){
						?>
						<div class=" sub_top_bar table_conntent">
		                            		<div class="table_wrap">
		                            		<form action="" method="post">
								<ul>
				                                <li  class="more_list" ></li>
				                                    <li class="item1"><?php echo $itemname; ?></li>
				                                    <li class="item2"><?php echo $itemunits; ?></li>
				                                    <li class="item3"><?php echo $total_order_taken; ?></li>
				                                    <li class="item4"><?php echo $total_cooked; ?></li>

				                                    <li class="item7"><?php echo $balance; ?></li>
				                                    <li class="item7"><input name="" type="button" value="Started"  id="popup_link2"></li>
				                                </ul>
				                                <ul class="drop_down color2">
					                               	<li style="
					                               	ground:none"></li>
					                                <li class="item1"></li>
					                                <li class="item2"></li>
					                                <li class="item3"></li>
					                                <li class="item4"></li>
					                                <li class="item7"></li>
					                                <li class="item7"><input name="" type="button" value="Submit" id="popup_link2"></li>	                                    	                                   
				                                </ul>
							</form>
						<?php
							}
						?> -->		
							                            	
			                            <div class="col-md-12 sub_top_bar table_conntent">			                            
			                            	<form action="" method="post">
								<ul>
				                                <li  class="more_list" ></li>
				                                    <li class="item1"><?php echo $itemname; ?></li>
				                                    <li class="item2"><?php echo $itemunits; ?></li>
				                                    <li class="item3"><?php echo $total_order_taken; ?></li>
				                                    <li class="item4"><?php echo $total_cooked; ?></li>
				                                    <li class="item5"></li>
				                                    <li class="item6"><?php echo $balance; ?></li>
				                                    <li class="item7">
				                                    	<?php
					                                    	if($cooking_status == "not started"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;"  class="btn btn-danger"   id="popup_link2">Yet To Start</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	
				                                    	<?php
					                                    	if($cooking_status == "started"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;"  class="btn btn-warning"   id="popup_link2">Started</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	<?php
					                                    	if($cooking_status == "completed"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;"  class="btn btn-success"   id="popup_link2">Completed</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>				                                    	
				                                    	
				                                    </li>		             
				                                </ul>
				                                <ul class="drop_down">
					                               	<li style="
					                               	ground:none"></li>
					                                <li class="item1"></li>
					                                <li class="item2"></li>
					                                <li class="item3"></li>
					                                <li class="item4"></li>
				                                    	<li class="item5"></li>
					                                <li class="item7"></li>
					                                <li class="item7"><input name="" type="button" value="Submit" id="popup_link1"></li>	                                    	                                   
				                                </ul>
							</form>							
			                            </div>
					<!--	<?php
							if($head == 1){
								$head = 2;
						?>
							</div>
		                            	</div>
						<?php
							}
						?>	-->		                            
						<?php

						 	}
							} 
							
						?>                            
			
			
			 
			                            
			                        </div> 		
		                        </div>			
				<?php
					$i = $i +1;
				}
				
				?>
                         
                   <!--     <div class="tab-pane personal_info " id="panel-2">
                   	tab2
                        </div>
                        <div class="tab-pane personal_info " id="panel-3">
                   	tab2
                        </div>
                        <div class="tab-pane personal_info active " id="panel-4">
	                   	<div class="row">
	                        	<div class="col-md-12 sub_top_bar">
		                            	<ul>
		                                    <li></li>
		                                    <li class="item1">Item</li>
		                                    <li class="item2">Unit</li>
		                                    <li class="item3">Order taken</li>
		                                    <li class="item4">cooked stock</li>
		                                    <li class="item5">raw stock</li>
		                                    <li class="item6">Short stock</li>
		                                    <li class="item7">To cook</li>
		                                    <li class="item7">status</li>
		                                    
		                                    
		                                </ul>
	                            	</div>
					<?php  
						foreach($allitems as $item){
							$total_order_taken = 0;  
							$itemname = $item['itemname'];
							$itemunits = $item['itemunits'];
							foreach($orders as $order){
								if($item['itemid'] == $order['itemid']){
									$total_order_taken = $total_order_taken + $order['total_item'] ;
								}
							}
							if($cooked_items){
								foreach($cooked_items as $cooked_item){
									if($item['itemid'] == $cooked_item['itemid']){
										$total_cooked = $cooked_item['balance_items'];
										$balance = $total_order_taken - $total_cooked;
									}else{
										$total_cooked = 0;
										$balance = $total_order_taken - $total_cooked;				
									}
								}		
							
							}else{
								$total_cooked = 0;
								$balance = $total_order_taken ;
							}
							

							
					?>                            	
	                            <div class="col-md-12 sub_top_bar table_conntent">
	                            	<form action="" method="post">
						<ul>
		                                <li  class="more_list" ></li>
		                                    <li class="item1"><?php echo $itemname; ?></li>
		                                    <li class="item2"><?php echo $itemunits; ?></li>
		                                    <li class="item3"><?php echo $total_order_taken; ?></li>
		                                    <li class="item4"><?php echo $total_cooked; ?></li>
		                                    <li class="item5"></li>
		                                    <li class="item6"></li>
		                                    <li class="item7"><?php echo $balance; ?></li>
		                                    <li class="item7">
		                                    	
		                                    	<input name="" type="button" value="Started"  id="popup_link1">
		                                    	
		                                    </li>
		                                </ul>
		                                <ul class="drop_down">
			                               	<li style="
			                               	ground:none"></li>
			                                <li class="item1">Item</li>
			                                <li class="item2">Pcs</li>
			                                <li class="item3">600</li>
			                                <li class="item4">200</li>
			                                <li class="item5">800</li>
			                                <li class="item6">Short stock</li>
			                                <li class="item7">400</li>
			                                <li class="item7"><input name="" type="button" value="Submit" id="popup_link2"></li>	                                    	                                   
		                                </ul>
					</form>
	                            </div>
				<?php
				 
					} 
					
				?>                            
	
	
	 
	                            
	                        </div> 
                        </div> 
                        <div class="tab-pane personal_info " id="panel-5">
                   	tab
                        </div> -->
                        </div>
                        </div>
                    </div></div>
                </div>                	
              
           
        </div>
    </div>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 
<script type="text/javascript">


</script>

		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquerypp.custom.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquery.elastislide.js"></script>
		<script type="text/javascript">
			
			$( '#carousel' ).elastislide();
				$( '#carousel1' ).elastislide();
				$( '#carousel2' ).elastislide();
				$( '#carousel3' ).elastislide();
				$( '#carousel4' ).elastislide();
				$( '#carousel5' ).elastislide();
				
				$(document).ready(function() {
					$( ".more_list" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});
      
	    $( ".arrow_side" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});            
                });
			
		</script>
        <script type="text/javascript">
		$(document).ready(function() {
			$("#popup_link1").click (function(){
				$(".popup1").show(300);
				});
				$(".close3a").click (function(){
				$(".popup1").hide(300);
				}); 
				$("#popup_link2").click (function(){
				$(".popup2").show(300);
				});
				$(".close3a").click (function(){
				$(".popup2").hide(300);
				});
		});
		</script>
    <div class="popupWrap2a popup1">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <h3>Pop up heading </h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut dictum sem id porta tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra</p>
      <a href="#" class="ok">Ok</a>
       <a href="#" class="cancel">Cancel</a>
    	
  <a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
    </div>
    </div> 
    </div>
    
    <div class="popupWrap2a popup2">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <form action="" method="get">
      <input type="text" name="user_id" placeholder="Enter Your User ID">    
      <input type="text" name="pin" placeholder="Enter Your Pin Number"> 
      <p style="margin-top:6px;">
       <input name="" type="submit">
      </p>
      </form>
      
    	
  <a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
    </div>
    </div>         
        
</body>
</html>