<form action="<?php echo base_url(); ?>specialevent/specialkitchen/add_to_cook" method="post">
	<table border="1">
		<tr>
			<th>Item</th>
			<th>Item Unit</th>
			<th>Total Order</th>
			<th>Additional Number of Items</th>									
		</tr>
<?php
	foreach($allitems as $item){
		$total_order_taken = 0;  
		$itemname = $item['itemname'];
		$itemunits = $item['itemunits'];
		foreach($timeslot_orders as $order){
			if($item['itemid'] == $order['itemid']){
				$total_order_taken = $total_order_taken + $order['total_item'] ;
			}
		}
?>
	<tr>
		<input type="hidden" name="item[]" value="<?php echo $item['itemid']; ?>">
		<input type="hidden" name="total_order_<?php echo  $item['itemid']; ?>" value="<?php echo $total_order_taken; ?>">		
		<td><?php echo $itemname; ?></td>
		<td><?php echo $itemunits; ?></td>
		<td><?php echo $total_order_taken; ?></td>
		<td><input type="text" name="add_additional_<?php echo  $item['itemid']; ?>"></td>		
	</tr>
<?php
	}
?>
	</table>
	<input type="submit" value="submit">
</form>