  <body>
<div id="top_wrapper">
    <div class="container">
    <div class="row">
        <div class=" col-md-3 col-sm-3">
        <div class="caterplus_logo"> <img src="<?php echo base_url();?>extras/extra/images/caterplus_logo.png" alt="Cater Plus"> </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_sett_ord">
            <div class="top_settings"> <a href="#"><img src="<?php echo base_url();?>extras/extra/images/top_settings.png" title="settings" alt="Cater Plus"></a> </div>
            <div class="top_order"> Order No : 1003 </div>
          </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_dropdown">
            <select class="top_dropdown_style">
            <option>--Select--</option>
          </select>
          </div>
      </div>
        <div class="col-md-3 col-sm-3">
        <div class="top_search">
            <form action="#" method="post">
            <input name="" type="text" class="search_01"   />
            <button class="btn" title="Submit"></button>
          </form>
          </div>
      </div>
      </div>
  </div>
  </div>
<div id="content_wrapper">
    <div class="container ">
    	<div class="kitchen_heading wr">
        <div class="row">
        	<div class="col-md-12">
            	<h1>Kitchen view - special events </h1>
            </div>
        </div></div>
            	<div class="lsidebar">
                	<ul>
                         <li class="arrow_side"></li>
                         <li class="item1">Chikken ticka roast</li>
                     </ul>
                     <ul class="slide_side">
                        <li>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dignissim lectus lorem, in faucibus dolor venenatis vitae. Cras dignissim dolor ut enim sodales, ut molestie neque ultrices. In ultricies odio et justo pellentesque, quis consequat massa bibendum. Suspen</p>
                        </li>
                     </ul>
                     <ul class="row2">
                         <li class="arrow_side"></li>
                         <li class="item1">Chikken ticka roast</li>
                     </ul>
                     <ul class="slide_side">
                        <li>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dignissim lectus lorem, in faucibus dolor venenatis vitae. Cras dignissim dolor ut enim sodales, ut molestie neque ultrices. In ultricies odio et justo pellentesque, quis consequat massa bibendum. Suspen</p>
                        </li>
                     </ul>
                     <ul>
                         <li class="arrow_side"></li>
                         <li class="item1">Chikken ticka roast</li>
                     </ul>
                     <ul class="slide_side">
                        <li>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dignissim lectus lorem, in faucibus dolor venenatis vitae. Cras dignissim dolor ut enim sodales, ut molestie neque ultrices. In ultricies odio et justo pellentesque, quis consequat massa bibendum. Suspen</p>
                        </li>
                     </ul>
                     <ul class="row2">
                         <li class="arrow_side"></li>
                         <li class="item1">Chikken ticka roast</li>
                     </ul>
                     <ul class="slide_side">
                        <li>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dignissim lectus lorem, in faucibus dolor venenatis vitae. Cras dignissim dolor ut enim sodales, ut molestie neque ultrices. In ultricies odio et justo pellentesque, quis consequat massa bibendum. Suspen</p>
                        </li>
                     </ul>
                     <ul >
                         <li class="arrow_side"></li>
                         <li class="item1">Chikken ticka roast</li>
                     </ul>
                     <ul class="slide_side">
                        <li>
                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam dignissim lectus lorem, in faucibus dolor venenatis vitae. Cras dignissim dolor ut enim sodales, ut molestie neque ultrices. In ultricies odio et justo pellentesque, quis consequat massa bibendum. Suspen</p>
                        </li>
                     </ul>
                     <a href="#" class="strat_c">Start cooking</a>
                </div>
                <div class="table_right">
                	<div class="top_bar"><div class="row ">
                    	<div class="col-md-12 ">
                        	<div class="row">
                           <!-- 	<div class="col-md-1 col-sm-2">
                                	<a href="#" class="back">Back </a> 
                                </div> -->
                                <div class="col-md-12 col-sm-12">
                                	<ul>
                                    	<li>
                                        	<form action="" method="post">
                                        	<input type="submit" class="btn btn-success" value="Morning(10.00-01.00)">
                                        	</form>
                                        </li>
                                        <li>
                                        	<form action="" method="post">                                        
                                        	<input type="submit" class="btn btn-success" value="Afternoon(01.00-04.00)">
                                        	</form>                                        	
                                        </li>
                                        <li>
                                        	<form action="" method="post">                                        
                                        	<input type="submit" class="btn btn-success" value="Evening(04.00-07.00)">
                                        	</form>                                        	
                                        </li>
                                        <li class="sel">
                                        	<form action="" method="post">                                        
                                        	<input type="submit" class="btn btn-success" value="Night(07.00-10.00)">
                                        	</form>                                        	
                                        </li>
                                    </ul>
                                </div>
                             <!--    <div class="col-md-4 col-sm-4">
                                	<form action="" method="get">
                                    	<input name="" type="text">
                                    </form>
                                </div> -->
                            </div>
                        </div>
                        <div class="col-md-12">
                        <div class="row tab_wrap">
                	<div class="col-md-12">
                    <div class="row clearfix">
		<div class="col-md-12 column">
			<div class="tabbable" id="tabs-931882">
				<ul class="nav nav-tabs nav_tabs2">
				<?php
				$i = 1;
				foreach($menus as $menu){
				?>
					<li <?php if($i == 4){echo 'class="active"';} ?>>
						<a href="#panel-<?php echo $i; ?>" data-toggle="tab"><?php echo $menu['menutypename'];  ?></a>
					</li>				
				<?php
					$i = $i +1;
				}
				
				?>
                    
				</ul>
				
			<div class="tab-content tab-content2">
			<?php
				$i = 1;
				foreach($menus as $menu){
				?>
					<div class="tab-pane personal_info " id="panel-<?php echo $i; ?>">
						<div class="row">
			                        	<div class="col-md-12 sub_top_bar">
				                            	<ul>
				                                    <li></li>
				                                    <li class="item1">Item</li>
				                                    <li class="item2">Unit</li>
				                                    <li class="item3">Order taken</li>
				                                    <li class="item4">cooked stock</li>
				                                    <li class="item5">raw stock</li>
				                                    <li class="item6">Short stock</li>
				                                    <li class="item7">To cook</li>
				                                    <li class="item7">status</li>
				                                    
				                                    
				                                </ul>
			                            	</div>
							<?php  
								foreach($allitems as $item){
								if($item['menutype'] == $menu['menutypeid']){	
									$total_order_taken = 0;  
									$itemname = $item['itemname'];
									$itemunits = $item['itemunits'];
									foreach($orders as $order){
										if($item['itemid'] == $order['itemid']){
											$total_order_taken = $total_order_taken + $order['total_item'] ;
										}
									}
									if($cooked_items){
										foreach($cooked_items as $cooked_item){
											if($item['itemid'] == $cooked_item['itemid']){
												$total_cooked = $cooked_item['balance_items'];
												$balance = $total_order_taken - $total_cooked;
											}else{
												$total_cooked = 0;
												$balance = $total_order_taken - $total_cooked;				
											}
										}		
									
									}else{
										$total_cooked = 0;
										$balance = $total_order_taken ;
									}
									
							?>                            	
			                            <div class="col-md-12 sub_top_bar table_conntent">
			                            	<form action="" method="post">
								<ul>
				                                <li  class="more_list" ></li>
				                                    <li class="item1"><?php echo $itemname; ?></li>
				                                    <li class="item2"><?php echo $itemunits; ?></li>
				                                    <li class="item3"><?php echo $total_order_taken; ?></li>
				                                    <li class="item4"><?php echo $total_cooked; ?></li>
				                                    <li class="item5"></li>
				                                    <li class="item6"></li>
				                                    <li class="item7"><?php echo $balance; ?></li>
				                                    <li class="item7"><input name="" type="button" value="Started"  id="popup_link1"></li>
				                                </ul>
				                                <ul class="drop_down">
					                               	<li style="
					                               	ground:none"></li>
					                                <li class="item1"></li>
					                                <li class="item2"></li>
					                                <li class="item3"></li>
					                                <li class="item4"></li>
					                                <li class="item5"></li>
					                                <li class="item6"></li>
					                                <li class="item7"></li>
					                                <li class="item7"><input name="" type="button" value="Submit" id="popup_link2"></li>	                                    	                                   
				                                </ul>
							</form>
			                            </div>
						<?php
						 	}
							} 
							
						?>                            
			
			
			 
			                            
			                        </div> 		
		                        </div>			
				<?php
					$i = $i +1;
				}
				
				?>
                         
                   <!--     <div class="tab-pane personal_info " id="panel-2">
                   	tab2
                        </div>
                        <div class="tab-pane personal_info " id="panel-3">
                   	tab2
                        </div>
                        <div class="tab-pane personal_info active " id="panel-4">
	                   	<div class="row">
	                        	<div class="col-md-12 sub_top_bar">
		                            	<ul>
		                                    <li></li>
		                                    <li class="item1">Item</li>
		                                    <li class="item2">Unit</li>
		                                    <li class="item3">Order taken</li>
		                                    <li class="item4">cooked stock</li>
		                                    <li class="item5">raw stock</li>
		                                    <li class="item6">Short stock</li>
		                                    <li class="item7">To cook</li>
		                                    <li class="item7">status</li>
		                                    
		                                    
		                                </ul>
	                            	</div>
					<?php  
						foreach($allitems as $item){
							$total_order_taken = 0;  
							$itemname = $item['itemname'];
							$itemunits = $item['itemunits'];
							foreach($orders as $order){
								if($item['itemid'] == $order['itemid']){
									$total_order_taken = $total_order_taken + $order['total_item'] ;
								}
							}
							if($cooked_items){
								foreach($cooked_items as $cooked_item){
									if($item['itemid'] == $cooked_item['itemid']){
										$total_cooked = $cooked_item['balance_items'];
										$balance = $total_order_taken - $total_cooked;
									}else{
										$total_cooked = 0;
										$balance = $total_order_taken - $total_cooked;				
									}
								}		
							
							}else{
								$total_cooked = 0;
								$balance = $total_order_taken ;
							}
							
					?>                            	
	                            <div class="col-md-12 sub_top_bar table_conntent">
	                            	<form action="" method="post">
						<ul>
		                                <li  class="more_list" ></li>
		                                    <li class="item1"><?php echo $itemname; ?></li>
		                                    <li class="item2"><?php echo $itemunits; ?></li>
		                                    <li class="item3"><?php echo $total_order_taken; ?></li>
		                                    <li class="item4"><?php echo $total_cooked; ?></li>
		                                    <li class="item5"></li>
		                                    <li class="item6"></li>
		                                    <li class="item7"><?php echo $balance; ?></li>
		                                    <li class="item7"><input name="" type="button" value="Started"  id="popup_link1"></li>
		                                </ul>
		                                <ul class="drop_down">
			                               	<li style="
			                               	ground:none"></li>
			                                <li class="item1">Item</li>
			                                <li class="item2">Pcs</li>
			                                <li class="item3">600</li>
			                                <li class="item4">200</li>
			                                <li class="item5">800</li>
			                                <li class="item6">Short stock</li>
			                                <li class="item7">400</li>
			                                <li class="item7"><input name="" type="button" value="Submit" id="popup_link2"></li>	                                    	                                   
		                                </ul>
					</form>
	                            </div>
				<?php
				 
					} 
					
				?>                            
	
	
	 
	                            
	                        </div> 
                        </div> 
                        <div class="tab-pane personal_info " id="panel-5">
                   	tab
                        </div> -->
                        </div>
                        </div>
                    </div></div>
                </div>                	
              
           
        </div>
    </div>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 
<script type="text/javascript">


</script>

		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquerypp.custom.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquery.elastislide.js"></script>
		<script type="text/javascript">
			
			$( '#carousel' ).elastislide();
				$( '#carousel1' ).elastislide();
				$( '#carousel2' ).elastislide();
				$( '#carousel3' ).elastislide();
				$( '#carousel4' ).elastislide();
				$( '#carousel5' ).elastislide();
				
				$(document).ready(function() {
					$( ".more_list" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});
      
	    $( ".arrow_side" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});            
                });
			
		</script>
        <script type="text/javascript">
		$(document).ready(function() {
			$("#popup_link1").click (function(){
				$(".popup1").show(300);
				});
				$(".close3a").click (function(){
				$(".popup1").hide(300);
				}); 
				$("#popup_link2").click (function(){
				$(".popup2").show(300);
				});
				$(".close3a").click (function(){
				$(".popup2").hide(300);
				});
		});
		</script>
    <div class="popupWrap2a popup1">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <h3>Pop up heading </h3>
      <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut dictum sem id porta tincidunt. Class aptent taciti sociosqu ad litora torquent per conubia nostra</p>
      <a href="#" class="ok">Ok</a>
       <a href="#" class="cancel">Cancel</a>
    	
  <a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
    </div>
    </div> 
    </div>
    
    <div class="popupWrap2a popup2">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <h3>Pop up heading </h3>
      <form action="" method="get">
      <input type="text" placeholder="Name">
       <input type="text" placeholder="email">
       <textarea name="" cols="" rows=""></textarea>
       <input name="" type="submit">
      
      </form>
      
    	
  <a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
    </div>
    </div>         
        
</body>
</html>