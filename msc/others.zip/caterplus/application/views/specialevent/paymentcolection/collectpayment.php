<body>
<link href="<?php echo base_url()?>extras/paymentcss/css/checkboxcss.css" rel="stylesheet" type="text/css" />
<div id="top_wrapper">
    <div class="container">
    <div class="row">
        <div class=" col-md-3 col-sm-3">
        <div class="caterplus_logo"> <img src="<?php echo base_url();?>extras/images/caterplus_logo.png" alt="Cater Plus"> </div>
      </div>
        <div class="col-md-3 col-sm-3">
        
      </div>
        <div class="col-md-3 col-sm-3">
      <!--  <div class="top_dropdown">
            <select class="top_dropdown_style">
            <option>--Select--</option>
          </select>
          </div> -->
      </div>
        <div class="col-md-3 col-sm-3">
      <!--  <div class="top_search">
            <form action="#" method="post">
            <input name="" type="text" class="search_01"   />
            <button class="btn" title="Submit"></button>
          </form>
          </div> -->
      </div>
      </div>
  </div>
  </div>
<div id="content_wrapper">
    <div class="container">
    <div class="row content_bg">
        <div class="col-md-12">
<div class="kitchen_heading wr">
        <div class="row">
        	<div class="col-md-12">
            	<div class="customername_orderframe">
          
            <div class="customername_orderno"> <a href="#"><?php echo $custname;?></a> </div>
<div class="customername_orderno"> <a href="#"><?php echo '# '.$orderid; ?></a> </div>
           <div class="bookyour_order">Payment Collection</div>             
          </div>



            </div>
            
        </div>
        </div>
        <div class="customerorder_frame">
            
            <div class="clearfix"></div>
            <div class="customer_filling_frame">
            <div class="customer_over">
<div class="customer_filling">
            <!--    <div class="customer_filling_top_title">
                    <div class="customer_name">Name</div>
                    <div class="customer_qty">Qty</div>
                    <div class="customer_each">Each</div>
                    <div class="customer_total">Total</div>
                  </div> -->


                <div class="customer_filling_btm_title">
                    <div class="customer_name_result">Name</div>
                    <div class="customer_qty_result"><?php echo $custname;?></div>
                    
                  </div>
                <div class="customer_filling_btm_title">
                    <div class="customer_name_result"><?php if($custmob) { echo 'Mobile';  } ?></div>
                    <div class="customer_qty_result">
                    <?php echo $custmob;?>
                  </div>
                   
                  </div>

<div class="customer_filling_btm_title">
                    <div class="customer_name_result"><?php if($email) { echo 'Email';  } ?></div>
                    <div class="customer_qty_result">
                   <?php echo $email;?>
                  </div>

                <div class="customer_filling_btm_title">
                    <div class="customer_name_result"><?php if($address) { echo 'Address';  } ?></div>
                    <div class="customer_qty_result"> <?php echo $address;?></div>                    
                  </div>

                
                    
                  </div>
              </div>
              </div>
            <div class="customer_filling_result">
               <!-- <div class="sub_total">Sub Total   :   $385</div>
                <div class="total"><span class="total_color"></span></div> -->
              </div>
            <div class="customer_filling_result">
               <!-- <div class="sub_total">Discount    :   $30</div> -->
                <div class="total"></div>
              </div>
            <div class="customer_filling_result">
              <!--  <div class="sub_total">Tax              :   $10</div>-->
                <div class="total">Total <span class="balncetotal_color"> :   <?php echo '£  '.number_format((float)$alltotal, 2, '.', '');?></span></div>
              </div>
            <div class="clearfix"></div>
          <!--  <div class="customer_btm_btn">
               <input type="button" class="cancel_order" value="Cancel Order" title="Cancel Order">
                <input type="button" class="cancel_order" value="Hold Order" title="Hold Order">
                <input type="button" class="send_order" value="Send Order" title="Send Order">
              </div>  -->
            <div class="clearfix"></div>
          <!--  <div class="five_buttons_frame">
                <div class="add_extra_items_frame">
                <input type="button" class="add_extra_items" alt="add extra items">
                <span class="five_btn_txt">Add <br>
                  Extra Item</span> </div>
                <div class="add_extra_items_frame">
                <input type="button" class="amount_order" title="Amount Order">
                <span class="five_btn_txt">Amount <br>
                  Order</span> </div>
                <div class="add_extra_items_frame">
                <input type="button" class="track_order" title="Track Order">
                <span class="five_btn_txt">Track <br>
                  Order</span> </div>
                <div class="add_extra_items_frame">
            <input type="button" class="print_order" title="Print Order">
                <span class="five_btn_txt">Print <br>
                  Order</span> </div>
                <div class="add_extra_items_frame">
                <input type="button" class="pay" title="Pay">
                <span class="five_btn_txt">Pay <br>
                  </span> </div>
              </div>-->
          </div>
          </div>
        <div class="payment_collection_frame">
          
<form name="collectionform" id="collectionform" action="<?php echo base_url(); ?>specialevent/paymentcollection/collect" method="post">
            <div class="payment_collection_inner">
            <div class="payment_collection_leftframe">




                <div class="balance_dueframe">
                <div class="balance_dueframe_top">
                    <div class="balance_due">Total Due</div>
                    <div class="amount_tendered">Amount Paid</div>
                    <div class="change">Balance</div>
                  </div>
                <div class="balance_dueframe_bottom">
                    <div class="balance_due_result" id="displaytotal"><?php echo $alltotal;?></div>
                    <div class="amount_tendered_result" style="display:none;" id="displaypaid_old"><?php echo $amt_paid;?></div>
                    <div class="amount_tendered_result" id="displaypaid"><?php echo $amt_paid;?></div>
                    
                    <div class="change_result" id="displaybalance" name="displaybalance"><?php echo $bal_amt;?></div>
                  </div>
              </div>
                <div class="number_frame">
                <div class="number_top">
                    <input name="b7" type="button" class="seven" value="7" id="7" onClick="calc(this.id)">
                    <input name="b8" type="button" class="seven" value="8" id="8" onClick="calc(this.id)">
                    <input name="b9" type="button" class="seven" value="9" id="9" onClick="calc(this.id)">
                   <input name="b10" type="button" class="ten" value="PAY FULL" id="autofull" onClick="autofillcalc()">
                  </div>
                <div class="number_top">
                    <input name="b4" type="button" class="seven" value="4" id="4" onClick="calc(this.id)">
                    <input name="b5" type="button" class="seven" value="5" id="5" onClick="calc(this.id)">
                    <input name="b6" type="button" class="seven" value="6" id="6" onClick="calc(this.id)">
<input name="ok" type="button" class="tenok" value="ok" id="ok" onClick="endcalc()">
               <!--    <input name="" type="button" class="ten" value="$20">-->
                  </div>
                <div class="number_top">
                    <input name="b1" type="button" class="seven" value="1" id="1" onClick="calc(this.id)">
                    <input name="b2" type="button" class="seven" value="2" id="2" onClick="calc(this.id)">
                    <input name="b3" type="button" class="seven" value="3" id="3" onClick="calc(this.id)">
                    
                   
                  </div>
                <div class="number_top">
                    <input name="breset" type="button" class="seven" value="C" id="C" onClick="resetform(<?php echo $bal_amt;?>)">
                    <input name="b0" type="button" class="seven" value="0" id="0" onClick="calc(this.id)">
                    <input name="b11" type="button" class="dot" id="decimalbtn" value="." >
                    <input name="minus" type="button" class="arrow" value="<" id="minus" onClick="minusf()">
                  </div>
              </div>
              </div>


 <div class="payment_collection_rightframe_icon">
                <div class="prepared_point">
               <!--  <input name="" type="button" class="prepared_point_btn" value="">
                <br>
               <span class="prepared_pointtxt">Prepared Point</span>
                <input name="" type="button" class="giftcard_btn" value="">
                <br>
                <span class="prepared_pointtxt">Gift Cards</span>
                <input name="" type="button" class="topamount_btn" value="">
                <br>
                <span class="prepared_pointtxt">Top Amount</span> -->
<br><br><br><br><br>
            <!--    <input name="" type="button" class="email_butn" value=""> -->
<?php if($email){ ?>
<!-->
<span class="prepared_pointtxt">E-mail</span> <br> 
<div class="slideThree">	
	<input type="checkbox" value="email" id="slideThree" name="emailcheck" />
	<label for="slideThree"></label>
</div>
<!-->
<!--<input name="emailcheck" type="checkbox" class="email_butn" value="email" checked>
                <br> 
               <span class="prepared_pointtxt">E-mail</span> --><?php } ?>
               
<input name="homedelivery" type="hidden" class="email_butn" value="no" > <br>
              
              <!--  <span class="prepared_pointtxt">Home</span>-->
            
 <div class="payment_collection_btm_rightbuttons">
               <input  type="submit" class="done_button" value="Done" name="donepayment" 
onclick="this.style.visibility='hidden';" />
               </div>

<?php /*alert('Balance To Pay  :'+document.getElementById('hiddenbalance').value); */ ?>


 </div>
              </div>
              
            <div class="payment_collection_btm_buttons">
            <div class="payment_collection_btm_frame">
            	<div class="payment_collection_btm_leftbuttons">
              <!--    <input name="" type="button" class="cash_btn" value="Cash" id="cash" onclick="changecashtype(this.id)">
                 <input name="" type="button" class="credit_button" value="Credit" id="credit" onclick="changecashtype(this.id)">
                   <input name="" type="button" class="credit_button" value="Cheque" id="cheque" onclick="changecashtype(this.id)"> 
-->
                
                
                </div>
                <div class="payment_collection_btm_leftbuttons1">
          <!-- <input name="" type="button" class="cash_btn" value="Gift Card">
                  <input name="" type="button" class="credit_button" value="Manual Credit">
                   <input name="" type="button" class="credit_button" value="Credit">-->
                
                
                </div>
                </div>
              
                
            </div>  
              
              
          </div>
          </div>
<input type="hidden" name="custid" id="custid" value="<?php echo $custid; ?>"/>
<input type="hidden" name="orderid" id="orderid" value="<?php echo $orderid; ?>"/>
<input type="hidden" name="orderslug" id="orderslug" value="<?php echo $orderslug; ?>"/>
<input type="hidden" name="initialtotal" id="initialtotal" value="<?php echo $alltotal; ?>"/>
<input type="hidden" name="hiddenbalance" id="hiddenbalance" value="<?php echo $alltotal; ?>"/>
<input type="hidden" name="hiddencashtype" id="hiddencashtype" value="cash"/>
<input type="hidden" name="hiddenpaid" id="hiddenpaid" value="0"/>
</form>
      </div>
      </div>
  </div>
  </div>
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 

<script type="text/javascript">
    function calc(buttonid){
        $(".done_button").hide();
        paidamount=document.getElementById('displaypaid').innerHTML;
        if(paidamount.length<8) // max input val
        {
            if(paidamount=="0")
            { $('#displaypaid').html(''); }
            paidamount=document.getElementById('displaypaid').innerHTML;
            $('#displaypaid').html(paidamount+buttonid);
            if((buttonid=="0")&&(paidamount=="0")){ $('#displaypaid').html("0"); }
        } //max input val
    }
    
</script>
<script type="text/javascript">

function resetform(balu)
{
$(".done_button").hide();
$('#displaypaid').html("0");
$('#displaybalance').html(balu);
}
</script>
<script type="text/javascript">

    function minusf(){
        $(".done_button").hide();
        paidamount=document.getElementById('displaypaid').innerHTML;
        var newval = paidamount.substring(0,paidamount.length-1);
        $('#displaypaid').html(newval);
        paidamount=document.getElementById('displaypaid').innerHTML;
        if(paidamount=='')
        {$('#displaypaid').html("0");}
    }

</script>


<script>
$(document).ready(function(){
$(".done_button").hide();
$("#decimalbtn").click(function(e){
    e.preventDefault();
    var paidamount=document.getElementById('displaypaid').innerHTML;
    if(paidamount.indexOf(".")<0){
        $('#displaypaid').html(paidamount+'.');
    }
    else{
        alert('Sorry');
    }
});
});
</script>


<script type="text/javascript">

    function endcalc(){
        $(".done_button").show();
        paidamount=document.getElementById('displaypaid').innerHTML;
        gtotal=document.getElementById('displaytotal').innerHTML;
        /*var curr_disp_bal=document.getElementById('displaybalance').innerHTML;
        paidamount=parseFloat(paidamount);
        gtotal=parseFloat(gtotal);
        curr_disp_bal=parseFloat(curr_disp_bal);
        curr_disp_bal=parseFloat(curr_disp_bal).toFixed(2);

        if(curr_disp_bal>0) 
            var balance=curr_disp_bal-paidamount;
        else*/
	       var balance=gtotal-paidamount;

        balance=parseFloat(balance).toFixed(2);
        $('#displaybalance').html(balance);
        var pbalance=parseFloat(balance);

        $('#hiddenbalance').val(balance); // store to read form
        $('#hiddenpaid').val(paidamount); // store to read form
        if(pbalance<0)
        { alert("Negative Value Balance"); $(".done_button").hide(); }

    }



</script>


<script type="text/javascript">

function autofillcalc()
{


paidamount=document.getElementById('displaypaid').innerHTML;
gtotal=document.getElementById('displaytotal').innerHTML;
paidamount_for_calc=document.getElementById('displaypaid_old').innerHTML;

//alert(paidamount);
//alert(gtotal);
$(".done_button").show();
if(paidamount_for_calc==gtotal) {
	alert('You have already paid full amount for this order');
}

$('#displaypaid').html(gtotal);
$('#displaybalance').html('0');
$('#hiddenbalance').val('0'); // store to read form
$('#hiddenpaid').val(gtotal); // store to read form
}

</script>


<script type="text/javascript">

function changecashtype(chtypes)
{

if(chtypes=="cheque")
{ 
var credits="credit";var cashs="cash";
document.getElementById(chtypes).className = "cash_btn";
document.getElementById(credits).className = "credit_button";
document.getElementById(cashs).className = "credit_button";
}
if(chtypes=="credit")
{
var che="cheque"; var cashs="cash";
document.getElementById(chtypes).className = "cash_btn";
document.getElementById(che).className = "credit_button";
document.getElementById(cashs).className = "credit_button";
}
if(chtypes=="cash")
{
var credits="credit"; var che="cheque"; 
document.getElementById(chtypes).className = "cash_btn";
document.getElementById(che).className = "credit_button";
document.getElementById(credits).className = "credit_button";
}
$('#hiddencashtype').val(chtypes);
}


</script>

</body>
</html>