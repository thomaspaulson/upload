<script src="<?php echo base_url();?>extras/extra/js/jquery.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine-en.js"></script> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/validationEngine.jquery.css">
<script type="text/javascript">
jQuery(document).ready(function ($) {
   // $("#paymentcollectsearch").validationEngine();
  $("#paymentcollectsearch").validationEngine('attach', {promptPosition : "centerRight", scroll: false});
  $("#paymentordercollectsearch").validationEngine('attach', {promptPosition : "centerRight", scroll: false}); 
   });
</script> 

<div id="content_wrapper">
    <div class="container ">
    	<div class="kitchen_heading wr">
        <div class="row">
        	<div class="col-md-12">
            	<h1>Select Order to Payment 
<span style="font-size: 16px;margin-left: 19%;
font-weight: bold;">Home Delivery  </span> </h1> 


        <div class="top_search" id="topsearch-collection">
<form action="<?php echo base_url()?>specialevent/paymentcollection/balancepay" method="post" id="paymentcollectsearch" name="balpayform">
            <input name="orderno" type="text" class="search_01 validate[required,custom[integer]]" placeholder="Proceed to Payment" id="ordnn"/>
<input type="submit" class="btn" value=""/>
          </select>
</form>
          </div>
     



            </div>
            
        </div>
        </div>



        <div class="row">
       <!--     	<div class="col-md-6">
                	<div class="user_dtls user_scroll wr">
                    <h3>Details</h3>
                    
                    <p> </p>
                    
                    <ul>
                    	<li>
                        <div class="left_feild">Customer</div>
                        <div class="left_feild right_feild"></div>
                        </li>
                        <li>
                        <div class="left_feild">Mobile</div>
                        <div class="left_feild right_feild"></div>
                        </li>
                        <li>
                        <div class="left_feild">Email</div>
                        <div class="left_feild right_feild"></div>
                        </li>
                        
                        <li>
                        <div class="left_feild">Address</div>
                        <div class="left_feild right_feild"></div>
                        </li>
                        <li>
                        <div class="left_feild">Order Date</div>
                        <div class="left_feild right_feild"></div>
                        </li>
 <li>
                        <div class="left_feild">Delivery Date</div>
                        <div class="left_feild right_feild"></div>
                        </li>
 <div class="left_feild">Delivery Time</div>
                        <div class="left_feild right_feild"></div>
                        </li>
                        <li>
                        <div class="left_feild">Payment Status</div>
                        <div class="left_feild right_feild"></div>
                        </li>
 <li>
                        <div class="left_feild">Total Amount</div>
                        <div class="left_feild right_feild"></div>
                        </li>
                        
                        </ul>
                    	
                    </div>
                </div> -->










                
                <div class="col-md-12">
                	<div class="user_dtls order_detils wr">
                    	<ul>
                        	<li class="description">Order</li>
                            <li class="quantity">Price</li>
                            
<li class="quantity">P.Status</li> 
<li class="price">Action</li>
                        </ul>
                        <div class="order_wrap">

<?php if($orderlist) { foreach($orderlist as $list) { $orderid=$list['orderid']; $custname=$list['customername'];
$tprice=$list['totalamount']; $pstatus=$list['payment_status']; $bal = $this->payment_model->get_balpay($orderid); ?>
<ul class="oreder_content">
                        	<li class="description">
                            	<div class="item_img">
                                <img src="<?php echo base_url()?>extras/images/Untitled-1.jpg" />
                                </div>
                                	<h4><?php echo '# '.$orderid; ?></h4>
                                    <p> <?php echo $custname; ?></p>
                             </li>
                            <li class="quantity"><span><?php echo '£  '.$tprice; ?></span></li>
 

<li class="quantity"><span><?php if(($bal<$tprice)&&($bal>0)){ echo 'Partial'; } else{ echo $pstatus; } ?></span></li>
                            

<li class="price"><?php if($pstatus!='paid') { ?><form action="<?php echo base_url()?>specialevent/paymentcollection/balancepay" method="post" >
<input type="hidden" name="orderno" value="<?php echo $orderid; ?>"/><input name="submit" class="btn btn-success" type="submit" value="Proceed"></form> <?php } ?></li>

                        </ul>
                        


                    

<?php } } ?>




</div>
                    </div>
                </div>
            </div>







            <div class="row">
            	<div class="col-md-6">
                	<!--<div class="user_dtls  wr">
                    <div class="customer_btm_btn customer_btm_btn2">
               <form action="" method="get"> <input type="button" class="cancel_order" value="Cancel Order" title="Cancel Order">
                <input type="button" class="cancel_order" value="Hold Order" title="Hold Order">
                <input type="button" class="send_order" value="Send Order" title="Send Order"></form>
              </div> 
                    </div>-->
                    </div>
                <!--    <div class="col-md-6">
                	<div class="user_dtls  payment012 wr">
                    	<form action="#" method="post">
                        	<div class="wr"><input name="" type="checkbox" value=""><label>Discount</label>
                            <b>$125</b></div>
                           <div class="wr"><input name="" type="checkbox" value="" checked><label>Tax</label>
                            <b>$0.54</b></div> 
                            
                            <div class="abount_bx">
                            £ 
                            </div>
                           <a href="#"></a>


<input name="collected" type="submit" value="OK" class="submitcollection"/>
                            <div class="clearfix"></div>
                            <a href="#" class="devit_btn">Debit</a>
                            <a href="#" class="devit_btn devit_btn2">Crdeit</a> 
                            
                        </form>
                    </div>
                    </div> -->
            </div>
            
              
           
        </div>
    </div>

<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 
<script type="text/javascript">

/*$(window).load(function() {

   $("#flexiselDemo3").flexisel({
        visibleItems: 5,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,            
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });
	
	 $("#flexiselDemo4").flexisel({
        visibleItems: 4,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,            
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });

	 $("#flexiselDemo5").flexisel({
        visibleItems: 4,
        animationSpeed: 1000,
        autoPlay: true,
        autoPlaySpeed: 3000,            
        pauseOnHover: true,
        enableResponsiveBreakpoints: true,
        responsiveBreakpoints: { 
            portrait: { 
                changePoint:480,
                visibleItems: 1
            }, 
            landscape: { 
                changePoint:640,
                visibleItems: 2
            },
            tablet: { 
                changePoint:768,
                visibleItems: 3
            }
        }
    });

    
});*/
</script>

		<script type="text/javascript" src="<?php echo base_url()?>extras/js/jquerypp.custom.js"></script>
		<script type="text/javascript" src="<?php echo base_url()?>extras/js/jquery.elastislide.js"></script>
		<script type="text/javascript">
			
			$( '#carousel' ).elastislide();
				$( '#carousel1' ).elastislide();
				$( '#carousel2' ).elastislide();
				$( '#carousel3' ).elastislide();
				$( '#carousel4' ).elastislide();
				$( '#carousel5' ).elastislide();
				
				$(document).ready(function() {
					$( ".more_list" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});
      
	    $( ".arrow_side" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});            
                });
			
		</script>



<!--pop up -->
 <div class="popupWrap2a popup2">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <form action="<?php echo base_url()?>specialevent/collectorder/fetchorder" method="post">
 <input name="orderno" type="text" class="search_01" placeholder="Enter OrderId"/> 
      <input type="text" name="pin" placeholder="Enter Your Pin Number"> 
      <p style="margin-top:6px;">
       <input name="ok" type="submit" value="submit">
      </p>
      </form>
      
    	
<a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>
    </div>
    </div>   
 <script type="text/javascript">
/*
		$(document).ready(function() {

				$(".popup2").show(300);

$(".close3a").click (function(){
					$(".popup2").hide(300);
				});


}); */
		</script>
<!---->





       
        
</body>
</html>