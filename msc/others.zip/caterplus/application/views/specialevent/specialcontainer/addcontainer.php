<html>
	<head>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/validationEngine.jquery.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine-en.js"  charset="utf-8"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine.js"  charset="utf-8"></script>


	</head>
	<body>
		<h1>Add Container</h1>
		<form name="addform" id="formID" action="<?php echo base_url(); ?>specialevent/specialcontainer/insertcontainer" method="post">
			<p><input type="text" name="cname" id="cname" placeholder="Container name" class="validate[required]"/></p>
			<p><input type="text" name="cprice" id="cprice" placeholder="Container Price" class="validate[required]"/></p>
			<p><textarea name="cdesc" id="cdesc" placeholder="Container Description" class="validate[required]"></textarea></p>
			
		        <p>
				<input type="submit" value="Add"/>
			</p>						
		</form>
<script>
$(document).ready(function(){
    $("#formID").validationEngine('attach', {promptPosition : "centerRight", scroll: false});
   });
</script>
	</body>
</html>