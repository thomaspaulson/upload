<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>CONTAINER</h1></div>
<div class="master-left">
<?php
		foreach($containers as $container){
		?>
<form class="validate" id="add-items" action="<?php echo base_url();?>specialevent/specialcontainer/edit_existing_container" method="post" name="Add Items-form" novalidate  >
         <!---->
         <div class="master-left-1">
           <div class="master-name">Container Name: *</div>         
<div class="master-select">
<input name="special_cname" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="special_cname" value="<?php echo $container['special_cname'];  ?>">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Container Price: *</div>         
<div class="master-select">
<input name="special_cprice" id="special_cprice" type="text" class="master-textfeild validate[required,custom[number]]" value="<?php echo $container['special_cprice'];  ?>">
          </div>
          </div>
          <!---->
          
         <div class="master-left-1">
           <div class="master-name">Description: </div>         
<div class="master-select">
<input name="special_cdesc" id="special_cdesc" type="text" class="master-textfeild " value="<?php echo $container['special_cdesc'];  ?>">
          </div>
          </div>
          <!----> 
          
       <input type="hidden" name="id" value="<?php echo $id; ?>"/>
        <input class="master-submit" type="submit" name="subscribe" value="" /> 
</form>
<?php
		}
		?>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
