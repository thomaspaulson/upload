 
  <script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine-en.js"></script> 
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/validationEngine.jquery.css">

<script type="text/javascript">

jQuery(document).ready(function ($) {
 jQuery("#add-items").validationEngine();
});
  
</script>              
                 <!--   <script type="text/javascript">
                    	$(document).ready (function(){
							$('#sadvance').click (function(){
								$('.hide_serch').slideToggle()
							});
						});
                    </script> -->
                </div>
                </div>
        </header>
        <div class="container">
                <div class="row custemor_dtls ">
                	<div class="col-md-12">
                     <script type="text/javascript" src="<?php echo base_url()?>extras/mergeddesign/js/cycle.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
			$('.slider_wrap').cycle({ 
				fx:     'scrollHorz', 
				speed:  1000, 
				timeout: 5000,
				 timeout: 0,
				slideExpr:".slider",
				pager: ".pager233",
				 next: ".nxt0", 
				 prev:  ".prv0",
				
			});			
	});
</script>
                    <ul>
                    	<li class="main_header"><p>Container Details</p>
<div class="row search_cus newstyleedited" >
                	<div class="col-md-12">

                    <form class="search-1" method="post" action="<?php echo base_url(); ?>specialevent/specialcontainer/insertcontainer" id="add-items" name="add-items">
 <input type="text" name="cname" id="cname"  placeholder="Name" class="validate[required]"/>
                        	
 <input type="text" name="cprice" id="cprice"  placeholder="Price" class="validate[required,custom[number]]"/>
                            <input name="" type="submit" value="Add"> 


 <ul class="results" id="results">
                           <!-- <a href="#" id="sadvance"> Advanced search</a>
                            <div class="clearfix"></div>
                            <div class="hide_serch"><input type="text" placeholder="Name">
                            <input type="text" placeholder="Last Name">
                            <input name="" type="submit" value="Search customer"> -->
                            </div>
                        </form>
                    </div>
   <?php     $totcount =  count($containers); //echo $totcount;  
if($totcount > 15) {?> 
                        	<div class="pag_nav">
                            	<a href="#"  class="prv0"><img src="<?php echo base_url()?>extras/mergeddesign/images/prev_p.png" width="29" height="31"></a>
                                <a href="#" class="nxt0"><img src="<?php echo base_url()?>extras/mergeddesign/images/nxtp.png" width="29" height="31"></a>
                            </div>
<?php } ?>
                      </li>
                      </ul>
                      <div class="slider_wrap wr">


<?php if($totcount < 15){ ?>
 <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                                            
                                <li class="otheritem_fld">Price</li>  
                                 <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li> 
                   <?php     $totcount =  count($containers); //echo $totcount; ?>
                       <?php $i=0;foreach($containers as $container){ $i++;if($i%2==0){$v=2;}else{$v=1;} ?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url(); ?>specialevent/specialcontainer/edit_container/<?php echo $container['special_cslug']; ?>"><?php echo $container['special_cname']; ?></a></li>
                                <li class="otheritem_fld"><?php echo '£  '.number_format((float)$container['special_cprice'], 2, '.', ''); ?> </li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url(); ?>specialevent/specialcontainer/edit_container/<?php echo $container['special_cslug']; ?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>specialevent/specialcontainer/changestatus/<?php echo $container['special_cid'];?>" >
								                  
 <?php if ($container['special_cstatus']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php } ?>
                                            
                    </ul>


<?php } else { ?>


                     <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                                            
                                <li class="otheritem_fld">Price</li>  
                                 <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li> 
                   <?php     $totcount =  count($containers); //echo $totcount; ?>
                       <?php $i=0;foreach($containers as $container){ $i++;if($i%2==0){$v=2;}else{$v=1;}  if($i<=15){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url(); ?>specialevent/specialcontainer/edit_container/<?php echo $container['special_cslug']; ?>"><?php echo $container['special_cname']; ?></a></li>
                                <li class="otheritem_fld"><?php echo '£  '.number_format((float)$container['special_cprice'], 2, '.', ''); ?>  </li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url(); ?>specialevent/specialcontainer/edit_container/<?php echo $container['special_cslug']; ?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>specialevent/specialcontainer/changestatus/<?php echo $container['special_cid'];?>" >
								                  
 <?php if ($container['special_cstatus']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                                            
                    </ul>

                  <ul class="slider wr">
                      	<li class="sub_header">
                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                 <li class="otheritem_fld">Price</li>  
                               <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li>
                     <?php $i=0;  foreach($containers as $container){ $i++;if($i%2==0){$v=2;}else{$v=1;}   if($i>15){?>
                         <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url(); ?>specialevent/specialcontainer/edit_container/<?php echo $container['special_cslug']; ?>"><?php echo $container['special_cname']; ?></a></li>
                                <li class="otheritem_fld"><?php echo '£  '.$container['special_cprice']; ?> </li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url(); ?>specialevent/specialcontainer/edit_container/<?php echo $container['special_cslug']; ?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>specialevent/specialcontainer/changestatus/<?php echo $container['special_cid'];?>" >
								                  
 <?php if ($container['special_cstatus']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                    </ul>
<?php } ?>
                    </div>
                    </div>
                </div>
                <footer>
                 <ul>
                 	
                    <li>
                    	<a href="<?php echo base_url();?>">Home</a>
                    </li>
                    
                    <li>
                    	<!--<a href="<?php echo base_url();?>specialevent/specialcontainer/">New</a>-->
                    </li>
                   
                 </ul>
                 </footer>
          </div>  
</body>
</html>