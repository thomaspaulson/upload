<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cater Plus</title>
<link rel="shortcut icon" href="<?php echo base_url();?>extras/images/favicon.png">
<!-- bootstrap js -->
<script src="<?php echo base_url();?>extras/extra/js/jquery.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/bootstrap.min.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine.js"></script>
<script src="<?php echo base_url();?>extras/extra/js/jquery.validationEngine-en.js"></script>

<!--font css style-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/fonts/stylesheet.css">

<!--bootsrap css style-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/validationEngine.jquery.css">

<!--common style-->
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/style.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/newstyle.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/view_port.css">







<script type="text/javascript">

jQuery(document).ready(function ($) {
 jQuery("#add-items").validationEngine();
});
  
</script>

<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lte IE 8]>
<script src="<?php echo base_url();?>extras/extra/js/html5.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>extras/extra/js/respond.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/ie8-and-down.css" />
<![endif]-->

</head>
<body>
<div id="top_wrapper">
<div class="container">
<div class="row">
<div class=" col-md-3 col-sm-3">
        <div class="caterplus_logo"><a href="<?php echo base_url(); ?>">
 <img src="<?php echo base_url();?>extras/extra/images/caterplus_logo.png" alt="Cater Plus"></a> </div>
      </div>

<div class="col-lg-9 col-md-9">
                      <div class="icons">
                      <a href="<?php echo base_url();?>admin">
                      <img src="<?php echo base_url();?>extras/extra/images/icon9.png" class="icons-image">
                          <span>Home</span>
                      </a>
                      </div>
                  <div class="icons">
                      <a href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen">
                      <img src="<?php echo base_url();?>extras/extra/images/icon1.png" class="icons-image">
                          <span>Kitchen</span>
                      </a>
                      </div>
                  <div class="icons">
                      <a href="<?php echo base_url();?>office">
                      <img src="<?php echo base_url();?>extras/extra/images/icon2.png" class="icons-image">
                          <span>Office</span>
                      </a>
                      </div>
                      <div class="icons">
                      <a href="<?php echo base_url();?>specialevent/orderlist">
                      <img src="<?php echo base_url();?>extras/extra/images/icon3.png"  class="icons-image">
                          <span>Order</span>
                      </a>
                      </div>
                      <div class="icons">
                      <a href="<?php echo base_url();?>specialevent/collectorder">
                      <img src="<?php echo base_url();?>extras/extra/images/icon42.png" class="icons-image">
                          <span>Order
Collections</span>
                      </a>
                      </div>
                      <div class="icons">
                      <a href="<?php echo base_url();?>specialevent/paymentcollection/balancepayment">
                      <img src="<?php echo base_url();?>extras/extra/images/icon4.png" class="icons-image">
                          <span>Payment</span>
                      </a>
                      </div>
                       <div class="icons">
                       <a href="<?php echo base_url();?>specialevent/customer">
                       	<img src="<?php echo base_url();?>extras/extra/images/icon10.png" class="icons-image">
                           <span>Eid Order</span>
                       </a>
                       </div>
                      <div class="icons">
                      <a href="<?php echo base_url();?>items/listall">
                      <img src="<?php echo base_url();?>extras/extra/images/icon7.png" class="icons-image">
                          <span>Item</span>
                      </a>
                      </div>


                      
                  </div>

</div>
<div class="welcome-topadmin"><h2> <a href="<?php echo base_url();?>logout">Logout</a></h2></div> 
   <div class="welcome-toplogin"><h2> <a href="<?php echo base_url();?>admin">Hello</a></h2></div>  
</div>
</div>
