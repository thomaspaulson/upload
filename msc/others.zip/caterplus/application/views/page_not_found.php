<div>
   <img src="<?php  echo base_url(); ?>extras/images/404-page-not-found.png">
</div>