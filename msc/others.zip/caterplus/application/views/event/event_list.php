 
                <?php  //print_r($contents); ?>

                 <!--   <script type="text/javascript">
                    	$(document).ready (function(){
							$('#sadvance').click (function(){
								$('.hide_serch').slideToggle()
							});
						});
                    </script> -->
                </div>
                </div>
        </header>
        <div class="container">
                <div class="row custemor_dtls ">
                	<div class="col-md-12">
                     <script type="text/javascript" src="<?php echo base_url()?>extras/mergeddesign/js/cycle.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
			$('.slider_wrap').cycle({ 
				fx:     'scrollHorz', 
				speed:  1000, 
				timeout: 5000,
				 timeout: 0,
				slideExpr:".slider",
				pager: ".pager233",
				 next: ".nxt0", 
				 prev:  ".prv0",
				
			});			
	});
</script>
                    <ul>
                    	<li class="main_header"><p>Event List</p>
<div class="row search_cus newstyleedited" >
                	<div class="col-md-12">

                    	 <form class="search-item" id="customemailfetch" method="post" action="" >
                        	<input type="text" placeholder="Event Id" name="orderno" id="orderno" autocomplete="off" value="" required>
                            <ul class="resultsajaxdrop" id="resultsajaxdrop">

		 </ul>	

<a href="<?php echo base_url();?>event/createevent" id="sadvance">New Event</a>
 <ul class="results" id="results">
                           <!-- <a href="#" id="sadvance"> Advanced search</a>
                            <div class="clearfix"></div>
                            <div class="hide_serch"><input type="text" placeholder="Name">
                            <input type="text" placeholder="Last Name">
                            <input name="" type="submit" value="Search customer"> -->
                            </div>
                        </form>
                    </div>
                 <?php if(count($contents)>10){?>         	<div class="pag_nav">
                            	<a href="#"  class="prv0"><img src="<?php echo base_url()?>extras/mergeddesign/images/prev_p.png" width="29" height="31"></a>
                                <a href="#" class="nxt0"><img src="<?php echo base_url()?>extras/mergeddesign/images/nxtp.png" width="29" height="31"></a>
                            </div>
<?php } ?>
                      </li>
                      </ul>
                      <div class="slider_wrap wr">

<?php if(count($contents)<10){?>  

 <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="order_fld">Event Id</li>  <li class="order_fld">Event Title</li> 
                                <li class="orderother_fld">Customer</li>                              
                                <li class="orderother_fld">Mobile</li> 
<li class="orderother_fld">Email</li> 
                             
<li class="orderother_fld">Action</li>

                            </ul>
                      </li> 
                      
                       <?php $i=0;foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}  ?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="order_fld"><a href="<?php echo base_url()?>"><?php  echo $oid=$value['event_id'];?></a></li>
                            	<li class="order_fld"><a href="<?php echo base_url()?>"><?php  echo $value['event_title'];?></a></li>
                                <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customername']?></a></li>
 <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customermobile1']?></a></li>
                     
 <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customeremail']?></a></li>

<li class="orderother_fld"><a href="<?php echo base_url()?>event/event_overview/edit_event_customer/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/> |</a>
<a onclick="" href="<?php echo base_url()?>event/event_overview/remove_event/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>"><img src="<?php echo base_url();?>extras/new/images/close-button.png"/></a></li>   
 <li class="orderother_fld"><li class="orderother_fld"><a href="<?php echo base_url()?>event/event_overview/view_event/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>">View</a></li>                     
                            </ul>
                      </li>
                  
                  
                    <?php } ?>
                                            
                    </ul>


<?php } else { ?>







                     <ul class="slider wr">
                      <li class="sub_header">
                      	                      		<ul>
                            	<li class="order_fld">Event Id</li>  <li class="order_fld">Event Title</li> 
                                <li class="orderother_fld">Customer</li>                              
                                <li class="orderother_fld">Mobile</li>  
<li class="orderother_fld">Email</li> 
                                 
<li class="orderother_fld">Action</li>

                            </ul>
                      </li> 
                      
                       <?php $i=0;foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}  if($i<=10){?>
                     <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="order_fld"><a href="<?php echo base_url()?>"><?php  echo $oid=$value['event_id'];?></a></li>
<li class="order_fld"><a href="<?php echo base_url()?>"><?php  echo $value['event_title'];?></a></li>
                                <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customername']?></a></li>
 <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customermobile1']?></a></li>
                     
 <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customeremail']?></a></li>

<li class="orderother_fld"><a href="<?php echo base_url()?>event/event_overview/edit_event_customer/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/> |</a>
<a onclick="" href="<?php echo base_url()?>event/event_overview/remove_event/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>"><img src="<?php echo base_url();?>extras/new/images/close-button.png"/></a></li>    
<li class="orderother_fld"><a href="<?php echo base_url()?>event/event_overview/view_event/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>">View</a></li>                     
                            </ul>
                      </li>
                       
                  
                    <?php }} ?>
                                            
                    </ul>

                  <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="order_fld">Event Id</li>  <li class="order_fld">Event Title</li> 
                                <li class="orderother_fld">Customer</li>                              
                                <li class="orderother_fld">Mobile</li>  
                                 <li class="orderother_fld">Email</li>  

<li class="orderother_fld">Action</li>

                            </ul>
                      </li> 
                     <?php $i=0;  foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}   if($i>10){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="order_fld"><a href="<?php echo base_url()?>"><?php  echo $oid=$value['event_id'];?></a></li>
<li class="order_fld"><a href="<?php echo base_url()?>"><?php  echo $value['event_title'];?></a></li>
                                <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customername']?></a></li>
 <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customermobile1']?></a></li>
 <li class="orderother_fld"><a href="<?php echo base_url()?>"><?php echo $value['customeremail']?></a></li>
                    

<li class="orderother_fld"><a href="<?php echo base_url()?>event/event_overview/edit_event_customer/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/> |</a>
<a onclick="" href="<?php echo base_url()?>event/event_overview/remove_event/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>"><img src="<?php echo base_url();?>extras/new/images/close-button.png"/></a></li> 
<li class="orderother_fld"><a href="<?php echo base_url()?>event/event_overview/view_event/<?php echo $value['event_id'];?>/<?php echo $value['event_slug']?>">View</a></li>                         
                            </ul>
                      </li>
                      
                    <?php }} ?>
                    </ul>
<?php } ?>
                    </div>
                    </div>
                </div>
                <footer>
                 <ul>
                 	
                    <li>
                    	<a href="<?php echo base_url();?>">Cancel</a>
                    </li>
                    
                    <li>
                    	<a href="<?php echo base_url();?>event/createevent" id="sadvance">New</a>
                    </li>
                   
                 </ul>
                 </footer>
          </div>  
<script>
	var base_url = "<?php echo base_url(); ?>";	
</script>

<script>
	$("#orderno").keyup(function(){
		var search_key = $("#orderno").val();
		$("#resultsajaxdrop").css("visibility", "visible");				
		if(search_key != ''){
			$.ajax({
		                type: "GET",
		                url: base_url + "event/event_detail/search_event", 
		                data: {
		                    'search_keyword' : search_key
		                },
		                success: function(msg){
					 $('#resultsajaxdrop').html(msg);
		                }
	           	 });		
		}else{
        		$('#resultsajaxdrop').css("visibility", "hidden");		
		}
	});

	$( "#search" ).focus(function() {
		$("#resultsajaxdrop").css("visibility", "visible");		
	});


</script>

<script>
$(document).mouseup(function (e)
{
    var container = $(".main");
    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        $('#resultsajaxdrop').css("visibility", "hidden");
    }
});
</script>
<!---Prevent enter key to submit----->

<script>

$(document).ready(function() {
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
</script>
<!---Prevent enter key to submit----->
</body>
</html>