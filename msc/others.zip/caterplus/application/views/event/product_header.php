<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Event New Booking</title>
<link href="<?php echo CSSPATH;?>css/style.css" rel="stylesheet" type="text/css">
<script src="<?php echo CSSPATH;?>js/html5.js"></script>
<script src="<?php echo CSSPATH;?>js/jquery-1.10.2.js"></script>
</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="<?php echo base_url();?>"><img src="<?php echo CSSPATH;?>images/logo.png" alt=""></a></div>
   <div class="header_right"> 
 <a href="<?php echo base_url();?>diary" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/dairy.png" alt="">
      <h6>Dairy</h6>
      </a> 
 
      <a href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/kitchen.png" alt="">
      <h6>Kitchen</h6>
      </a> 
      
   
      <a href="<?php echo base_url();?>items/listall" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/item.png" alt="">
      <h6>Items</h6>
      </a> 
      
 
      <a href="<?php echo base_url();?>specialevent/paymentcollection/balancepayment" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/payment.png" alt="">
      <h6>Payment</h6>
      </a> 
      

      <a href="<?php echo base_url();?>settings" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/settings.png" alt="">
      <h6>Settings</h6>
      </a> 
 
     
    <!--  <a href="#"  id="showmorebutton"  class="top-menuicons"><img src="<?php echo CSSPATH;?>images/more.png" alt="">
      <h6>More </h6>
      </a> -->
      <!----> 
      <!--==== user name =====--> 
      <a>
      <div class="user_box">
        <div class="user">
          <div class="icon"> </div>
          <div class="user_name">
<?php $comp_name= $this->session->userdata('comp_name'); $branch_name=$this->session->userdata('branch_name'); ?>
            <p><?php echo $comp_name;?></p>
            <p><?php echo $branch_name;?></p>
            </div>
          <h6>Admin</h6>
        </div>
      </div>
      </a> 
      <!--==== user name end =====--> 
      <a href="<?php echo base_url()?>logout" class="logout"><img src="<?php echo CSSPATH;?>images/logout.png" alt="">
      <h6>Logout</h6>
      </a> </div>
  </div>
</header>
<script>
$("#showmorebutton").click(function(){                
               if (!$('.showmore:visible').length)
  {         $(".showmore").fadeIn();    }
  else{ $(".showmore").fadeOut(); }
       
               });
               </script>