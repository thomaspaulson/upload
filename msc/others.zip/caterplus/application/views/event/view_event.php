<?php 
//print_r($menu_types);
 
$paid_amount=0;
foreach($get_paid_schedule as $paid_detail)
{
$paid_amount=$paid_amount+$paid_detail['event_paypaid'];
}

/***********/

$grand_total=0;
foreach($event_payment as $epay)
{
$grand_total=$epay['event_grand_tot_price'];
}

$bal_to_pay=$grand_total-$paid_amount;

$paid_amount=number_format((float)$paid_amount, 2, '.', '');
$bal_to_pay=number_format((float)$bal_to_pay, 2, '.', '');

$menu_price=0;
$menu_id=0;
$menu_name=0;
$menu_price=0;
foreach($event_menu as $e_menu)
{
$menu_name=$e_menu['comp_menu_name'];
$menu_id=$e_menu['menu_id'];
$menu_price=$e_menu['total_price'];

}
if($menu_price<0)
{
$menu_price=0;
}

$e_pot_total_price=0;
foreach($event_pot_price as $e_pot_price)
{
$e_pot_total_price=$e_pot_price['pot_total_price'];
}


if($e_pot_total_price<0)
{
$e_pot_total_price=0;
}



$selected_items=$this->get_event_details->item_selected_and_all($event_id,$menu_id);



$menu_price=number_format((float)$menu_price, 2, '.', '');
$e_pot_total_price=number_format((float)$e_pot_total_price, 2, '.', '');
$grand_total=number_format((float)$grand_total, 2, '.', '');
//chef
$edit_chef_id='';
$edit_chef_from='';
$edit_chef_to='';
$edit_chef_date='';
$edit_chef_note='';
$edit_chef_name='';

foreach($event_chefnote as $chef_det)
{
$edit_chef_id=$chef_det['chef_id'];
$edit_chef_from=$chef_det['working_from'];
$edit_chef_to=$chef_det['working_to'];
$edit_chef_date=$chef_det['working_date'];
$edit_chef_note=$chef_det['chef_description'];
$edit_chef_name=$chef_det['employeename'];

$edit_chef_date= str_replace('-', '/', $edit_chef_date);
$edit_chef_date= date('d/m/Y', strtotime($edit_chef_date));

}

//manager
$edit_manager_name='';
$edit_manager_from='';
$edit_manager_date='';
$edit_manager_id='';
$edit_manager_note='';
$edit_manager_to='';
foreach($event_manager_note as $manager_det)
{
$edit_manager_id=$manager_det['manager_id'];
$edit_manager_from=$manager_det['working_from'];
$edit_manager_to=$manager_det['working_to'];
$edit_manager_date=$manager_det['working_date'];
$edit_manager_note=$manager_det['manager_description'];
$edit_manager_name=$manager_det['employeename'];

$edit_manager_date= str_replace('-', '/', $edit_manager_date);
$edit_manager_date= date('d/m/Y', strtotime($edit_manager_date));
}

//event_drivernote
$edit_driver_id='';
$edit_driver_from='';
$edit_driver_to='';
$edit_driver_date='';
$edit_driver_note='';
$edit_driver_name='';
foreach($event_drivernote as $driver_det)
{
$edit_driver_id=$driver_det['driver_id'];
$edit_driver_from=$driver_det['working_from'];
$edit_driver_to=$driver_det['working_to'];
$edit_driver_date=$driver_det['working_date'];
$edit_driver_note=$driver_det['driver_description'];
$edit_driver_name=$driver_det['employeename'];

$edit_driver_date= str_replace('-', '/', $edit_driver_date);
$edit_driver_date= date('d/m/Y', strtotime($edit_driver_date));
}


//agency
$edit_agency_id='';
$edit_agency_name='';
$edit_agency_note='';
$edit_nos_per='';
foreach($get_eventagency as $get_agency)
{
$edit_agency_id=$get_agency['agency_id'];
$edit_agency_name=$get_agency['agency_name'];
$edit_agency_note= $get_agency['agency_notes'];
$edit_nos_per=$get_agency['nos_persons'];
}

//common note
$e_sub1="";$e_note1="";
$e_sub2="";$e_note2="";
$e_sub3="";$e_note3="";
$e_sub4="";$e_note4="";
$e_sub5="";$e_note5="";
$e_sub6="";$e_note6="";
$pi=0; 
foreach($event_commonnote as $event_common_note)
{ $pi++;
$sub="e_sub".$pi;
$nott="e_note".$pi;
$$sub=$event_common_note['common_subject'];
$$nott=$event_common_note['common_description'];
}




/***********/





?>








<!--disable r click-->
<script language="javascript">
//document.onmousedown=disableclick;
status="This Feature Not Available";
function disableclick(e)
{
  if(event.button==2)
   {
     alert(status);
     return false;	
   }
}
</script>
<!--disable r click-->

<?php //print_r($pay_schedule);
//print_r($pots_pans); 
 foreach($custdata as $custmdata){ $custname=$custmdata['customername'];} ?>
 <link rel="stylesheet" href="<?php echo CSSPATH;?>css/jquery-ui.css">
  <script src="<?php echo CSSPATH;?>js/jquery-ui.js"></script>
  <link rel="stylesheet" href="<?php echo CSSPATH; ?>css/timepicker.css">
  <script src="<?php echo CSSPATH; ?>js/timepicker.js"></script>
<script>
  $(function() {
 /*$('#driver_timepickerto').timepicker(); $('#driver_timepickerfrom').timepicker();
  $('#manager_timepickerfrom').timepicker();$('#manager_timepickerto').timepicker();
  $('#chef_timepickerfrom').timepicker();$('#chef_timepickerto').timepicker();
  
    $( "#driver_datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' });   $( "#manager_datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' });   
$( "#chef_datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' }); 
*/
  });
  </script>

<script type="text/javascript">
    $(document).ready(function(){
        $(".custom-select").each(function(){
            $(this).wrap("<span class='select-branch'></span>");
            $(this).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function(){
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        }).trigger('change');


    });
</script>

<!--====== selection end =====-->

<!--tab-->
<script>
$(document).ready(function(){
	$(".tab_cont_01").slideDown();
	$(".tab_cont_02").hide();
	  $(".tab_02").removeClass("active");
  $(this).addClass("active");
	
	$(".tab_01").click(function(){
    $(".tab_cont_01").slideDown();
	$(".tab_cont_02,.tab_cont_03,.tab_cont_04, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_02,.tab_03, .tab_04, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

	$(".tab_02").click(function(){
    $(".tab_cont_02").slideDown();
	$(".tab_cont_01,.tab_cont_03,.tab_cont_04, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_03, .tab_04, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_03").click(function(){
    $(".tab_cont_03").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_04, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_04, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_04").click(function(){
    $(".tab_cont_04").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_05").click(function(){
    $(".tab_cont_05").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_04, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_04, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_06").click(function(){
    $(".tab_cont_06").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_04, .tab_cont_05, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_04, .tab_05, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_07").click(function(){
    $(".tab_cont_07").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_04, .tab_cont_05, .tab_cont_06").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_04, .tab_05,.tab_06").removeClass("active");
  $(this).addClass("active");
});





});
</script>
<!--tab end-->
<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<form action="<?php echo base_url();?>event/event_overview/event_list" method="post" onsubmit="before_submit_form()" id="event_form">
<div class="master-top-add"> <h1>View Event</h1></div>

<div class="super_company_name">
     <div class="super_company_logo"><!--<img src="images/small_logo.png">--></div>
     <div class="super_company_logo_name"><h1><?php echo $branch_name=$this->session->userdata('branch_name'); ?></h1></div>
    </div>

<div class="super_cust_name">
     <div class="super_company_logo"><img src="<?php echo CSSPATH;?>images/user.png"></div>
     <div class="super_company_logo_name"><h1><?php echo $custname; ?></h1></div>
    </div>

<div class="event_booking2_main">
<div class="event_booking2_top">
<div class="print_labels_left">
<a href="#"><div class="event_booking2_top_print">Print</div></a>
<a href="#"><div class="event_booking2_top_email">Email</div></a>
<a href="#"><div class="event_booking2_top_pdf">Pdf</div></a>
</div>
<div class="print_labels_right">
<div class="event_selection"><?php echo $event_title;?></div>
<div class="event_selection_id"># <?php echo $event_id;?></div> </div>
<!--<div class="event_selection">
            <select name="timepass" class="custom-select">
            <option>More</option>
            <option>Delete Booking</option>
            <option>Move Booking</option>
                             
        </select>
          </div> -->

</div>

<div class="event_booking2_left">
<div class="event_booking2_left_date">


<p><?php

$newdate= str_replace('/', '-', $event_date);
$newdate= date('Y-m-d', strtotime($newdate));

echo $mmonthname= date('M', strtotime($newdate)).' '; ?> <?php echo $yyear= date('Y', strtotime($newdate)); ?></p>
<h1><?php echo $datenum= date('d', strtotime($newdate)); ?></h1>
<p><?php  echo $dayname= date('D', strtotime($newdate)); ?></p>
</div>
</div>
<div class="event_booking2_center">
<div class="event_booking2_center_bg">
<div class="event_booking2_center_name"><?php echo $event_title;?></div>
<div class="event_booking2_center_date"><?php echo $event_start_time;?></div> 
 


<div class="event_booking2_center_enquiry"> <?php echo $event_enq_type;?></div>

</div>

</div>
<div class="event_booking2_right">
<div class="event_booking2_right_total">Total Amount: <?php echo $currency." "; ?> <span id="fulltotal_box"><?php echo $grand_total;?></span> </div>
<!--<div class="event_booking2_right_vat">Vat: <span>12%</span> </div>
<div class="event_booking2_right_vat">Net: <span>£320</span> </div> -->
<div class="event_booking2_right_total">Payments: <?php echo $currency." "; ?><span id="total_paid"><?php echo $paid_amount;?></span> </div>
<div class="event_booking2_right_total">Balance:<?php echo $currency." "; ?> <span id="total_balance"><?php echo $bal_to_pay;?></span> </div>
</div>

</div>


<div class="event_booking_dtls">
<div class="event_tab">
  <div class="super_tab_menu">
    <ul>
      <li class="tab_01 active">General</li>
      <li class="tab_02">Menu & Schedule</li>
        <li class="tab_03">Staff on Duty</li>
        <li class="tab_04">Bill and Payment</li>
         <li class="tab_05">Notes</li>
          <li class="tab_06">Tasks</li>
           <li class="tab_07">Pots And Pans</li>
    </ul>
  </div>
  <div class="super_tab_content tab_cont_01">
   <div class="event_booking2_tab">
   <p>
<?php echo $event_title; ?><br><br>
   
 <?php echo $eventtypename.'  '.$subevent_typename; ?><br><br>
   
 <?php 

$event_date2= str_replace('/', '-', $event_date);
$event_date2= date('d/m/Y', strtotime($event_date2));
echo  $event_date2.' '.$event_start_time; ?><br><br>
   
  <?php echo  $venue_address;?><br> <?php echo $venue_city.'  '.$venue_state.'  '.$venue_country; ?><br>
   
 <?php if($event_contact){ echo 'Tel :  '.$event_contact; } ?>
   
   </p> 
   </div> 

  </div>
  
  <div class="super_tab_content tab_cont_02">  

<div class="event_menu_schedule">


<div class="event_menu_schedule_name">
New Menu Name
</div>
<!--<a href="#">
<div class="event_menu_schedule_box">
select
</div></a>-->



<div class="super_master">
<input name="new_menu_name" type="text" value="<?php echo $menu_name;?>" class="event_note_textfeild">
<input name="new_menu_id" type="hidden" value="<?php echo $menu_id;?>" class="event_note_textfeild">

          </div>


</div>
<!-- --> 



<div class="event_menu_schedule_main"> 



<?php //print_r($menu_types); 
if($menu_types){ foreach($menu_types as $type_menu){ $menu_id=$type_menu['menutypeid']; $menu_name=$type_menu['menutypename'];  ?>

<div class="event_menu_schedule_item" id="">
<h1><?php echo $menu_name; ?></h1>
<div class="row_color1">
          <ul>
            <li class="event_item_name">Item Name</li>
            <li class="event_unit">Nos</li>
            <li class="event_unit">Unit</li>
            <li class="event_price">Unit Price</li>
             <li class="event_price">Total</li>
           
          </ul>
        </div>
        <div id="<?php echo $menu_id;?>_itemlist">

<?php foreach($selected_items as $seltd_it)
{ $edit_menu_type_id=$seltd_it['menutype'];

if($menu_id==$edit_menu_type_id){
$itemnamme=$seltd_it['itemname'];
$edit_item_id=$seltd_it['itemid'];
$uniq_edit_rowid='row_'.$edit_menu_type_id.'_'.$edit_item_id.'_';


$item_nos_edit=$seltd_it['item_nos'];
$itemunits_edit=$seltd_it['itemunits'];
$text_f='textfield_'.$edit_item_id;
$base_p='basep_'.$edit_item_id;

$base_p=number_format((float)$base_p, 2, '.', '');

$itemprice_edit=$seltd_it['itemprice'];
$itemprice_edit=number_format((float)$itemprice_edit, 2, '.', '');

$item_subprice_edit=$seltd_it['item_subprice'];
$item_subprice_edit=number_format((float)$item_subprice_edit, 2, '.', '');

?>
<!-->

<div class="row_color2" id="<?php echo $uniq_edit_rowid;?>"><ul><li class="event_item_name"><?php echo $itemnamme; ?></li><li class="event_unit"><input name="<?php echo $text_f;?>" type="text" value="<?php echo $item_nos_edit;?>" class="event_text" id="<?php echo $text_f;?>" onblur="calc(this.id,this.value);"></li><li class="event_unit"><?php echo $itemunits_edit;?></li><li class="event_price" id="<?php echo $base_p; ?>"><?php echo $itemprice_edit;?></li><li class="event_price" id="totalp_<?php echo $edit_item_id;?>"><?php echo $item_subprice_edit;?></li><li class="event_close_button"></li></ul></div>




<?php } // if close
} // for each close
  ?>





<!-->


</div><!--append to this-->
        
  
        
        
</div> 

<?php } } ?>
<!---->






<div class="event_menu_schedule_item">
<div class="event_total_ammount">Total <?php echo $currency." "; ?><span id="grandtotal_view"><?php echo $menu_price;?></span></div>
</div> 

</div> 
 <!---->
  <!--side menutype-->



<?php  if($menu_types){ 

foreach($menu_types as $type_menu){ $menu_id=$type_menu['menutypeid']; $menu_name=$type_menu['menutypename'];

$item_list=$this->event_model->get_items($this->comp_id,$menu_id); 

$item_count=count($item_list);
if($item_count<=1)
{
$item_count=3;
}

 ?>
 <!--rrr-->
<div  class="menu_list_right">
 <div class="event_booking2_driver_menuschedule"><label><?php echo $menu_name;?></label>
<select name="itemid" class="emp_select" id="<?php echo $menu_id;?>" onchange="readfrom_select(this.id);" size="<?php echo $item_count; ?>"> 
<?php if($item_list){ foreach($item_list as $items) { $ittem_id=$items['itemid'];
$sel="";
foreach($item_menu_relation as $menu_relat) 
{ 
$sele_itid= $menu_relat['item_id'];  
if($sele_itid==$ittem_id){ $sel="disabled";}
}  
?>

<option id="itemname_<?php echo $ittem_id;?>" <?php echo $sel;?> value="<?php echo $ittem_id; ?>"><?php echo $items['itemname']; ?></option>
<?php } } ?>
</select>
</div>


</div>

<!---should create temp values-->
<?php if($item_list) { foreach($item_list as $itemss) { $ittem_idd=$itemss['itemid'];?>
<input type="hidden" id="temp_unit_<?php echo $ittem_idd;?>" value="<?php echo $itemss['itemunits'];?>">  
<input type="hidden" id="temp_basep_<?php echo $ittem_idd;?>" value="<?php echo $itemss['itemprice'];?>">  
<?php } } ?>
<!---should create temp values-->

<!--uuuu--->
    
    <?php } } ?>

<input type="hidden" name="event_id" id="event_id" value="<?php echo $event_id;?>">  
<input type="hidden" name="granttotal" id="granttotal" value="<?php echo $menu_price;?>">  <!--item grand total-->


<input type="hidden" name="pots_granttotal" id="pots_granttotal" value="<?php echo $e_pot_total_price;?>">  <!--pots grand total-->




  <!--side menutype ends-->
  </div> <!--tab 2 close-->
  
<!--->
<div class="super_tab_content tab_cont_03">
<div class="event_booking2_tab">











<div class="event_booking2_staff">
<div class="super_master-1">
           <div class="super_name"><h1>Driver</h1></div> 
             </div>

<div class="super_master-1">
           <div class="super_name_ajax" id="driver_name"> <?php echo $edit_driver_name; ?> </div>         

          </div>

<div class="event_booking2_staff_left">
<div class="super_master-1">
           <div class="super_name">Time from :</div>         
<div class="super_master">
<input name="driver_timefrom" value="<?php echo $edit_driver_from;?>" id="" type="text" class="super_master_textfeild" readonly>
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name">Date:</div>         
<div class="super_master">
<input name="driver_date" value="<?php echo $edit_driver_date;?>" type="text" id="" class="super_master_textfeild" readonly>
          </div>
          </div>          
</div>



<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Time to:</div>         
<div class="super_master">
<input name="driver_timeto" id="" value="<?php echo $edit_driver_to;?>" type="text" class="super_master_textfeild" readonly>
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="driver_id" id="driver_id" type="hidden" value="<?php echo $edit_driver_id;?>">
<input name="driver_notes" type="text" value="<?php echo $edit_driver_note;?>" class="super_master_textfeild">
          </div>
          </div>
</div>
       


<div class="super_master-1">
           <div class="super_name"><h1>Manager</h1></div>         

          </div>
    
<div class="super_master-1">
                
 <div class="super_name_ajax" id="manager_name"><?php echo $edit_manager_name; ?></div>  
          </div>
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name">Time from:</div>         
<div class="super_master">
<input name="manager_timefrom" value="<?php echo $edit_manager_from; ?>" id="" type="text" readonly class="super_master_textfeild">
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name">Date:</div>         
<div class="super_master">
<input name="manager_date" value="<?php echo $edit_manager_date; ?>" type="text" id="" readonly class="super_master_textfeild">
          </div>
          </div>          
</div>

<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Time to:</div>         
<div class="super_master">
<input name="manager_timeto" id="manager_timepickerto" value="<?php echo $edit_manager_to; ?>" type="text" readonly class="super_master_textfeild">
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="manager_id" id="manager_id" type="hidden" value="<?php echo $edit_manager_id;?>">
<input name="manager_notes" type="text" value="<?php echo $edit_manager_note; ?>"  class="super_master_textfeild">
          </div>
          </div>

</div>





<div class="super_master-1">
           <div class="super_name"><h1>Chef</h1></div>         
 
          </div>

 <div class="super_master-1">
                
 <div class="super_name_ajax" id="chef_name"><?php echo $edit_chef_name; ?></div>  
          </div>   
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name">Time from:</div>         
<div class="super_master">

<input name="chef_timefrom" type="text" value="<?php echo $edit_chef_from; ?>" id="" readonly class="super_master_textfeild">
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name">Date:</div>         
<div class="super_master">
<input name="chef_date" type="text" value="<?php echo $edit_chef_date; ?>" id="" readonly class="super_master_textfeild">
          </div>
          </div>          
</div>


<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Time to:</div>         
<div class="super_master">
<input name="chef_timeto" type="text" value="<?php echo $edit_chef_to; ?>" id="" readonly class="super_master_textfeild">
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="chef_id" id="chef_id" type="hidden" value="<?php echo $edit_chef_id;?>">
<input name="chef_notes" value="<?php echo $edit_chef_note; ?>" type="text" class="super_master_textfeild">
          </div>
          </div>

</div>





<div class="super_master-1">
           <div class="super_name"><h1>Agency</h1></div>         

          </div>
    
<div class="super_master-1">
                
 <div class="super_name_ajax" id="agency_name"><?php echo $edit_agency_name; ?></div>  
          </div>
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name">Serving Staffs:</div>         
<div class="super_master">
<input name="agency_id" id="agency_id" type="hidden" value="<?php echo $edit_agency_id;?>">
<input name="serve_staff" value="<?php echo $edit_nos_per; ?>" id="serve_staff" type="text" class="super_master_textfeild">
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name"></div>         
<div class="super_master">

          </div>
          </div>          
</div>

<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="agency_note" value="<?php echo $edit_agency_note; ?>" id="agency_note" type="text" class="super_master_textfeild">
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name"></div>         
<div class="super_master">


          </div>
          </div>

</div>

</div>


<div class="event_booking2_driver"><label>DRIVER</label>
<select multiple name="driver" class="emp_select" id="driver_select">
<?php if($drivers){ foreach($drivers as $drive) { ?>
<option <?php if($edit_driver_id==$drive['employeeid']){ echo "selected"; } ?> value="<?php echo $drive['employeeid']; ?>"><?php echo $drive['employeename']; ?></option>
<?php } } ?>
</select>
</div>

<div class="event_booking2_driver" ><label>MANAGER</label>
<select multiple name="manager" class="emp_select" id="manager_select">
<?php if($managers) { foreach($managers as $manage) { ?>
<option <?php if($edit_manager_id==$manage['employeeid']){ echo "selected"; } ?> value="<?php echo $manage['employeeid']; ?>"><?php echo $manage['employeename']; ?></option>
<?php } } ?>
</select>
</div> 

<div class="event_booking2_driver" ><label>CHEF</label>
<select multiple  name="chef" class="emp_select" id="chef_select">
<?php if($chefs) { foreach($chefs as $cheff) { ?>
<option <?php if($edit_chef_id==$cheff['employeeid']){ echo "selected"; } ?>  value="<?php echo $cheff['employeeid']; ?>"><?php echo $cheff['employeename']; ?></option>
<?php } } ?>
</select>
</div> 



<div class="event_booking2_driver" ><label>Agency</label>
<select multiple  name="agency" class="emp_select" id="agency_select">
<?php if($get_agencylist) { foreach($get_agencylist as $agen_list) { ?>
<option <?php if($edit_agency_id==$agen_list['agency_id']){ echo "selected"; } ?>  value="<?php echo $agen_list['agency_id']; ?>"><?php echo $agen_list['agency_name']; ?></option> 
<?php } } ?>
</select>
</div> 


   </div>

  </div>
<!---->
<div class="super_tab_content tab_cont_04">

<div class="event_booking2_tab">
   
 <!--payment-->
   <div class="dashbord_itemlist">
   <div class="row_payment_schedule">
          <ul>
            <li class="payment_schdl">Payment Schedule</li>
<li class="payment_schd2 master-select">
<?php /*
<select id="pay_schedule_id">
<?php foreach($pay_schedule as $pay_sched){ ?>
<option value="<?php echo $pay_sched['pay_schedule_id']; ?>"><?php echo $pay_sched['basic_steps']; ?></option>
<?php } ?>
</select>
*/ ?>
</li>
          </ul>
        </div>

        <div class="row_color1">
          <ul>
            <li class="payment_part">Part#</li>
            <li class="payment_part">Total</li>
            <li class="payment_part">Payments</li>
            <li class="payment_part">Balance</li>
            <li class="payment_part"></li>
            <li class="payment_part"></li>
            <li class="payment_invoice"></li>
           
          </ul>
        </div>
<div id="append_div_pay_schedule"> 
<?php echo $row; ?>
</div>
        
        
       
       
 <?php /*       
        <div class="row_payment">
          <ul>
            <li class="payment_received">Payment Received</li>
           
        <!--    <li class="payment_receive_right">Receive Payment</li>-->
           
          </ul>
        </div>
        <div class="payment_received_border"> No  Payments</div> */ ?>
        <div class="payment_total_bottum">Total: <?php echo $currency." "; ?> <span id="fullpayment_box_schedule"> <?php echo $grand_total;?></span></div>
      </div>
   
   
   <!--payment-->



   </div>

  </div>

  
<div class="super_tab_content tab_cont_07">
<!--new-->
<div class="event_menu_schedule_main"> 

<div class="event_menu_schedule_item" id="">
<h1>Pots and Pans</h1>
<div class="row_color1">
          <ul>
            <li class="event_item_name">Name</li>
            <li class="event_unit">Nos</li>
        <li class="event_unit">Rent per unit</li>
               <li class="event_price">Deposit</li>
             <li class="event_price">Total</li> 
           
          </ul>
        </div>
        <div id="pot_div">

<?php foreach($event_pots_pans as $e_pots_pans) { 

$e_pots_name=$e_pots_pans['pp_name']; 
$e_pots_id=$e_pots_pans['pp_id']; 
$e_pot_value=$e_pots_pans['event_pp_nos']; 
$e_pot_rent=$e_pots_pans['pot_rent']; 
$e_pot_deposit=$e_pots_pans['pot_deposit'];
$e_pot_total=$e_pots_pans['pot_totalprice'];    
$e_pp_name=$e_pots_pans['pp_name']; 

?>

<div class="row_color2" id="potdiv_<?php echo $e_pots_id;?>"><ul><li class="event_item_name"><?php echo $e_pots_name;?></li><li class="event_unit"><input name="textfieldnos_<?php echo $e_pots_id;?>" type="text" value="<?php echo $e_pot_value;?>" class="event_text" id="textfieldnos_<?php echo $e_pots_id;?>" onblur="pot_calc(this.id,this.value);"></li><li class="event_unit"><input name="textfieldrent_<?php  echo $e_pots_id;?>" type="text" value="<?php echo $e_pot_rent;?>" class="event_text" id="textfieldrent_<?php echo $e_pots_id;?>" onblur="pot_calc(this.id,this.value);"></li><li class="event_price"><input name="textfielddeposit_<?php echo $e_pots_id;?>" type="text" value="<?php echo $e_pot_deposit; ?>" class="event_text" id="textfielddeposit_<?php echo $e_pots_id;?>" onblur="pot_calc(this.id,this.value);"></li><li class="event_price" id="pot_subtotal_<?php echo $e_pots_id;?>"><?php echo $e_pot_total;?></li><li class="event_close_button"></li></ul></div>



<?php } ?> 










</div><!--append to this-->
        
  
        
        
</div> 
<?php if($pots_pans) { foreach($pots_pans as $ppp){ $potttid=$ppp['pp_id']; $temppot_deposit=$ppp['pp_deposit']; $temppot_price=$ppp['pp_price']; ?>

<input type="hidden" name="temp_pot_deposit<?php echo $potttid; ?>" id="temp_pot_deposit<?php echo $potttid; ?>" value="<?php echo $temppot_deposit;?>" />
<input type="hidden" name="temp_pot_rent<?php echo $potttid; ?>" id="temp_pot_rent<?php echo $potttid; ?>" value="<?php echo $temppot_price;?>"/>

<?php }  } ?>



<div class="event_menu_schedule_item">
<div class="event_total_ammount">Total <?php echo $currency." "; ?><span id="pots_grandtotal_view"><?php echo $e_pot_total_price; ?></span></div>
</div> 

</div> 
 
  <!--side menutype-->

 <!--rrr-->

<div  class="menu_list_right">
 <div class="event_booking2_driver_menuschedule"><label>Pots and Pans</label>
<select name="pott_id" class="emp_select" id="pott_id" onchange="readpots_select(this.id);" size="2"> 
<?php if($pots_pans) {  foreach($pots_pans as $pp) { $potid=$pp['pp_id']; $edit_stat="";
foreach($event_pots_pans as $sel_pans){ if($sel_pans['pp_id']==$potid){ $edit_stat="disabled"; } }

 ?>
<option id="<?php echo 'potid_'.$potid;?>"  <?php echo $edit_stat;?> value="<?php echo $pp['pp_id'];?>"><?php echo $pp['pp_name'];?></option>
<?php } } ?>
</select>
</div>


</div>


<!---rrr-->


<!---new-->
  </div>
  
  <div class="super_tab_content tab_cont_05">
  
<div class="event_booking2_tab">
  <div class="event_note_staff">
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name"><h1>Extra Notes</h1></div>         
 <div class="event_post"></div>  
          </div>


<div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject1" type="text" value="<?php echo $e_sub1;?>" class="event_note_textfeild">
          </div>



          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject2" value="<?php echo $e_sub2;?>" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject3" value="<?php echo $e_sub3;?>" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject4" value="<?php echo $e_sub4;?>" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject5" value="<?php echo $e_sub5;?>" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject6" value="<?php echo $e_sub6;?>" type="text" class="event_note_textfeild">
          </div>
          </div>
          
</div>
<div class="event_note_staff_right">

<div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note1" cols="" rows="" class="event_notes_textarea"><?php echo $e_note1;?></textarea>

          </div>
          </div>      
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note2" cols="" rows="" class="event_notes_textarea"><?php echo $e_note2;?></textarea>

          </div>
          </div>      
          
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note3" cols="" rows="" class="event_notes_textarea"><?php echo $e_note3;?></textarea>

          </div>
          </div>     
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note4" cols="" rows="" class="event_notes_textarea"><?php echo $e_note4;?></textarea>

          </div>
          </div>  
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note5" cols="" rows="" class="event_notes_textarea"><?php echo $e_note5;?></textarea>

          </div>
          </div>  
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note6" cols="" rows="" class="event_notes_textarea"><?php echo $e_note6;?></textarea>

          </div>
          </div>   
          
          
</div>
  
</div>
  </div>
  </div>
  
  <div class="super_tab_content tab_cont_06">
<div class="event_booking2_tab">



<?php  foreach($tasklist as $task) { 
$compl_chge="event_task_list_left";  
foreach($event_task as $tlist){ 
if(($task['eventtask_id']==$tlist['eventtask_id'])&&($tlist['event_task_status']=='completed')){ $compl_chge="event_task_list_left completed_task_div"; } 
}?>
 <div class="event_task_list_main">
   <div class="<?php echo $compl_chge;?>" id="bordercolor_<?php echo $task['eventtask_id'];?>">
   <div class="event_task_list_left_menu" id="<?php echo 'task_name'.$task['eventtask_id'];?>"><?php echo ucwords($task['subtask_name']); ?></div>
   <div class="event_task_list_left_completed" id="<?php echo 'task_stat'.$task['eventtask_id'];?>"><?php echo $task['event_task_status']; ?></div>
   
   </div>
   <div class="event_task_list_right"><a href="javascript:void(0)" id="<?php echo 'task_change'.$task['eventtask_id']; ?>" onclick="changetask_status(this.id)"></a></div>
   
   </div>
 
<?php } ?>
 
 
 
   </div>
  </div>
</div>
<div class="event_generate_main">


<a href="<?php echo base_url();?>event/create_invoice/create/<?php echo $event_id;?>/<?php echo $event_slug;?>"><div class="event_generate">Generate Invoice</div></a>
<div class="event_summary"> Summary </div>
<input name="proceed" type="submit" value="" class="event_customer_left_submit_exit">

 <input name="edit" type="button" onClick="location.href='<?php echo base_url();?>event/event_overview/edit_event_customer/<?php echo $event_id.'/'.$event_slug; ?>'" value="" class="event_customer_left_submit_edit">
</div>

<div class="event_generate_main">

<!--<a href="#"><div class="event_generate">Save Changes</div></a>-->

</div>

</div>
</form>
</div>

  <div class="clear"></div>
</div>

<!---->
<script>
$(function() {
    $('#event_form input,textarea').attr('readonly', 'readonly');
});



</script>
<!---->