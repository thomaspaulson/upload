<?php
	foreach($contents as $content){
	$key_words= explode(' ',$content['event_id']); 
	$key_words = implode('+',$key_words);
?>
	 <li><a  href="<?php echo base_url()?>event/event_overview/view_event/<?php echo $key_words; ?>/<?php echo $content['event_slug']?>"><?php echo $content['event_id']?></span></a></li>
<?php
	}

?>

