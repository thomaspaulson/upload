<script>
$(window).click(function(e) {
   document.getElementById("form_submit_continue").style.visibility='visible';//visible after  
document.getElementById("form_submit").style.visibility='visible';//visible after 
});


</script>




<?php //print_r($customer); 
foreach($customer as $detail)
{
$enq_t=$detail['event_enq_type'];
$cater_t=$detail['even_caterttype_name'];
$day_t=$detail['eventday_type'];
$event_id=$detail['event_id'];
$customerId=$detail['customerId'];
$event_slug=$detail['event_slug'];
} ?>

<!-- Check box and  Radio button -->
<script>
    function setupLabel() {
     if ($('.label_check input').length) {
            $('.label_check').each(function(){ 
                $(this).removeClass('c_on');
            });
            $('.label_check input:checked').each(function(){ 
                $(this).parent('label').addClass('c_on');
            });                
        };
        if ($('.label_radio input').length) {
            $('.label_radio').each(function(){ 
                $(this).removeClass('r_on');
            });
            $('.label_radio input:checked').each(function(){ 
                $(this).parent('label').addClass('r_on');
            });
        };
    };
    $(document).ready(function(){ 
 document.getElementById("exist_cust_radio").checked = true;  //default checked existing cust
        $('body').addClass('has-js');
        $('.label_check, .label_radio').click(function(){
            setupLabel();
        });
        setupLabel();    

$('#new_cust_div').click(function(){ 
document.getElementById("exist_cust_radio").checked = false;  document.getElementById("new_cust_radio").checked = true;
$('#exist_cust_div').css("opacity", "0.5");
$('#new_cust_div').css("opacity", "1");
  });

$('#exist_cust_div').click(function(){ 

document.getElementById("new_cust_radio").checked = false; document.getElementById("exist_cust_radio").checked = true;
$('#new_cust_div').css("opacity", "0.5");
$('#exist_cust_div').css("opacity", "1");

 });   //existing_cust


    });
</script>
<!-- Check box and  Radio button -->.
<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"> <h1>Edit Event</h1></div>

<div class="super_company_name">
     <div class="super_company_logo"><!--<img src="images/small_logo.png">--></div>
     <div class="super_company_logo_name"><h1><?php
 //$branch_name=$this->session->userdata('branch_name');
echo '# '.$event_id; ?></h1></div>
    </div>

<div class="event_newbooking_main">
<div class="event_newbooking_type">
                      <h1>Type</h1>
          <form action="<?php echo base_url();?>event/event_overview/update_event_customer" method="post" onsubmit="return form_validation()">
            <label class="label_radio r_on">
              <input name="event_enq_type" id="radio_01" value="Enquiry" <?php if($enq_t=='Enquiry') { echo "checked"; } ?> type="radio">
              Enquiry</label>            
          <label class="label_radio r_on">
              <input name="event_enq_type" id="radio_02" value="Confirm" <?php if($enq_t=='Confirm') { echo "checked"; } ?>  type="radio">
              Confirm</label>
              <label class="label_radio r_on">
              <input name="event_enq_type" id="radio_03" value="Provisional" <?php if($enq_t=='Provisional') { echo "checked"; } ?> type="radio">
              Provisional</label>
</div>
<div class="event_newbooking_type">
                      <h1>Catering Type</h1>
          
            <label class="label_radio r_on">
              <input name="cater_type" id="radio_04" value="outsidecatering" <?php if($cater_t=='outsidecatering') { echo "checked"; } ?>  type="radio"> 
              Outside Catering</label>            
          <label class="label_radio r_on">
              <input name="cater_type" id="radio_05" value="delivery" <?php if($cater_t=='delivery') { echo "checked"; } ?> type="radio">
              Delivery</label>
              
</div>


<div class="event_newbooking_type">
                      <h1>Day Schedule</h1>
          
            <label class="label_radio r_on">
              <input name="day_type" id="radio_06" value="singleday" <?php if($day_t=='singleday') { echo "checked"; } ?>   type="radio">
              Single Day</label>            
          <label class="label_radio r_on">
              <input name="day_type" id="radio_07" value="multiday" <?php if($day_t=='multiday') { echo "checked"; } ?>   type="radio">
              Multi Day</label>
              
</div>

</div>

<div class="event_customer_main">
<div class="event_customer_left" id="exist_cust_div">
<div class="event_customer_left_one">
<label>
              <input name="exist_cust_type" id="exist_cust_radio" value="existing_cust"  type="radio" style="display:none;">
              </label>
<h1>Existing Customer</h1></div>

<div class="event_customer_left_one">
<div class="event_search">
  <input type="hidden" name="customer_id" id="customer_id" value="<?php echo $customerId;?>">
<div class="ui-widget">
   
<input id="tags" type="text" name="tags" class="event_search_textfeild">
   </div> </div>
</div>
<div class="event_customer_leftdetails">
<?php $i=0;  foreach($custlist as $list) { $i++; $ph1=''; $ph2='';if($list['customerphone']){ $ph1=$list['customerphone']; }
if($list['customermobile1']){  $ph2=$list['customermobile1'];}
?>

<div class="event_customer_left_row<?php echo $i;?>">
<div class="event_customer_left_row1_radio">
<label class="label_radio r_on">
              <input name="cust_id"  value="<?php echo $list['customerId']; ?>"

 <?php if($list['customerId']==$customerId) { echo "checked"; } ?>  type="radio">

             </label>
</div>
<div class="event_customer_left_row1_name"><h1><?php echo $list['customername'];?></h1></div>
<div class="event_customer_left_row1_phone"><h1><?php echo $ph1;?></h1></div>
<div class="event_customer_left_row1_phone"><h1><?php echo $ph2;?></h1></div>
</div>


<?php if($i==2){$i=0;} } ?>

</div>
</div>

<div class="event_customer_right">
<div id="new_cust_div"><!--for div script -->
<div class="event_customer_right_one">
<label>
              <input name="new_cust_type" id="new_cust_radio" value="new_cust"  type="radio" style="display:none;">
              </label>
<h1>New Customer</h1>
</div>


<div class="event_customer_right_contact">
<h1></h1>
<div class="super_master-1">
           <div class="super_name">Name *:</div>         
<div class="super_master">
<input name="custname" type="text" id="custname" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name"> Phone *:</div>         
<div class="super_master">
<input name="custphone" type="text" class="super_master_textfeild">
          </div>
          </div>

<div class="super_master-1">
           <div class="super_name">Mob *:</div>         
<div class="super_master">
<input name="custmob" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Address :</div>         
<div class="super_master">
<input name="custaddress" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Email :</div>         
<div class="super_master">
<input name="custemail" type="text" class="super_master_textfeild">
          </div>
          </div>

</div>

</div><!--for div for script-->


</div>
<input type="hidden" name="event_id" value="<?php echo $event_id; ?>"/>
<input type="hidden" name="event_slug" value="<?php echo $event_slug; ?>"/>
<input name="save" type="submit" value="" class="event_customer_left_button_save" id="form_submit">
<input name="continue" type="submit" value="" class="event_customer_left_button_save_continue"  id="form_submit_continue">
</form>
</div>

</div>
  <div class="clear"></div>
</div>
<!--========= content end ===============-->

<!---Prevent enter key to submit----->

<script>

$(document).ready(function() {
// document.getElementById("form_submit_continue").style.visibility='hidden';//visible after  
//document.getElementById("form_submit").style.visibility='hidden';//visible after 
  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
</script>
<!---Prevent enter key to submit----->


<!--validation-->
<script>
function form_validation()
{

$(".warning").removeClass("warning"); //remove any warning classes redcolor


if($('#exist_cust_radio').is(':checked'))
                        {  //if exist main radio selected

cust_id_checked_val=($('input[name=cust_id]:checked').val()); //read value of checked
if(isNaN(cust_id_checked_val)==true){ alert("Select any Existing Customer"); return false;  }
else { $("#customer_id").val(cust_id_checked_val);}

                        }

if($('#new_cust_radio').is(':checked'))
{ 

v_cust_name=($('input[name=custname]').val());
v_custphone=($('input[name=custphone]').val());
v_custmob=($('input[name=custmob]').val());

if((v_cust_name=='')||(v_cust_name.match(/^\s*$/))){ 
//alert("Enter Customer Name"); 
$('input[name=custname]').addClass('warning');  $('input[name=custname]').focus();  
 return false;}
else if((v_custphone=='')||(isNaN(v_custphone)==true)||(v_custphone.match(/^\s*$/))){ 
//alert("Invalid Customer Phone"); 
$('input[name=custphone]').addClass('warning');  $('input[name=custphone]').focus();  
return false; }
else if((v_custmob=='')||(isNaN(v_custmob)==true)||(v_custmob.match(/^\s*$/))){ 
//alert("Invalid Customer Mobile"); 
$('input[name=custmob]').addClass('warning'); $('input[name=custmob]').focus();
return false; }


}  //if new cust  main  radio checked


$('#form_submit').attr('disabled','disabled');
document.getElementById("form_submit").style.visibility='hidden';
  

} //fntn close
</script>
<!--validation-->



<!--disable r click-->
<script type="text/javascript">
$(document).ready(function(){
$(document).bind("contextmenu",function(e){
return false;
});
});
</script>
<!--disable r click-->



<!---auto complete-->

 

<script>

$('input[name$="tags"]').keyup(function()
	{ 


var id=$('#tags').val(); 
				$.ajax({
		type: "POST",
		url : "<?php echo base_url()?>event/event_ajax/get_custlist/"+id,
		success: function(msg){
		

var arr=JSON.parse(msg);


$(".event_customer_leftdetails").html("");
$( ".event_customer_leftdetails").append(arr);





/* $( "#tags" ).autocomplete({   source: arr     }); */

  }
	}); 
   

   });
 
   
</script>
<!---auto complete-->

<!---footer-->
<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
      <!--  <td><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/back.png" alt=""></a></td>
        <td align="center"><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/home.png" alt=""></a></td>
        <td align="right"><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/my_order.png" alt=""></a></td>-->
      </tr>
    </table>
  </div>
   <div class="clear"></div>
</footer>
<script type="text/javascript">

var slider1=new accordion.slider("slider1");
slider1.init("slider");


</script>

</body>
</html>

