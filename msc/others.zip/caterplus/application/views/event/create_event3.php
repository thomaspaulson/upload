<?php //echo $row; ?>


<!--disable r click-->
<script type="text/javascript">
$(document).ready(function(){
$(document).bind("contextmenu",function(e){
return false;
});
});
</script>
<!--disable r click-->

<?php //print_r($pay_schedule);
//print_r($pots_pans); 
 foreach($custdata as $custmdata){ $custname=$custmdata['customername'];} ?>
 <link rel="stylesheet" href="<?php echo CSSPATH;?>css/jquery-ui.css">
  <script src="<?php echo CSSPATH;?>js/jquery-ui.js"></script>
  <link rel="stylesheet" href="<?php echo CSSPATH; ?>css/timepicker.css">
  <script src="<?php echo CSSPATH; ?>js/timepicker.js"></script>
<script>
  $(function() {
 $('#driver_timepickerto').timepicker(); $('#driver_timepickerfrom').timepicker();
  $('#manager_timepickerfrom').timepicker();$('#manager_timepickerto').timepicker();
  $('#chef_timepickerfrom').timepicker();$('#chef_timepickerto').timepicker();
  
    $( "#driver_datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' });   $( "#manager_datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' });   
$( "#chef_datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' });
  });
  </script>

<script type="text/javascript">
    $(document).ready(function(){
        $(".custom-select").each(function(){
            $(this).wrap("<span class='select-branch'></span>");
            $(this).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function(){
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        }).trigger('change');


    });
</script>

<!--====== selection end =====-->

<!--tab-->
<script>
$(document).ready(function(){
	$(".tab_cont_01").slideDown();
	$(".tab_cont_02").hide();
	  $(".tab_02").removeClass("active");
  $(this).addClass("active");
	
	$(".tab_01").click(function(){
    $(".tab_cont_01").slideDown();
	$(".tab_cont_02,.tab_cont_03,.tab_cont_04, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_02,.tab_03, .tab_04, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

	$(".tab_02").click(function(){
    $(".tab_cont_02").slideDown();
	$(".tab_cont_01,.tab_cont_03,.tab_cont_04, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_03, .tab_04, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_03").click(function(){
    $(".tab_cont_03").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_04, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_04, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_04").click(function(){
    $(".tab_cont_04").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_05, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_05, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_05").click(function(){
    $(".tab_cont_05").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_04, .tab_cont_06, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_04, .tab_06, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_06").click(function(){
    $(".tab_cont_06").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_04, .tab_cont_05, .tab_cont_07").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_04, .tab_05, .tab_07").removeClass("active");
  $(this).addClass("active");
});

$(".tab_07").click(function(){
    $(".tab_cont_07").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03, .tab_cont_04, .tab_cont_05, .tab_cont_06").hide();
	  $(".tab_01,.tab_02, .tab_03, .tab_04, .tab_05,.tab_06").removeClass("active");
  $(this).addClass("active");
});





});
</script>
<!--tab end-->
<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<form action="<?php echo base_url();?>event/createevent/save_event" method="post" onsubmit="before_submit_form()">
<div class="master-top-add"> <h1>New Event</h1></div>

<div class="super_company_name">
     <div class="super_company_logo"><!--<img src="images/small_logo.png">--></div>
     <div class="super_company_logo_name"><h1><?php echo $branch_name=$this->session->userdata('branch_name'); ?></h1></div>
    </div>

<div class="super_cust_name">
     <div class="super_company_logo"><img src="<?php echo CSSPATH;?>images/user.png"></div>
     <div class="super_company_logo_name"><h1><?php echo $custname; ?></h1></div>
    </div>

<div class="event_booking2_main">
<div class="event_booking2_top">
<!--
<div class="print_labels_left">
<a href="#"><div class="event_booking2_top_print">Print</div></a>
<a href="#"><div class="event_booking2_top_email">Email</div></a>
<a href="#"><div class="event_booking2_top_pdf">Pdf</div></a>
</div>-->
<div class="print_labels_right">
<div class="event_selection"><?php echo $event_title;?></div>
<div class="event_selection_id"># <?php echo $event_id;?></div>
</div>
<!--<div class="event_selection">
            <select name="timepass" class="custom-select">
            <option>More</option>
            <option>Delete Booking</option>
            <option>Move Booking</option>
                             
        </select>
          </div> -->

</div>

<div class="event_booking2_left">
<div class="event_booking2_left_date">


<p><?php

$newdate= str_replace('/', '-', $event_date);
$newdate= date('Y-m-d', strtotime($newdate));

echo $mmonthname= date('M', strtotime($newdate)).' '; ?> <?php echo $yyear= date('Y', strtotime($newdate)); ?></p>
<h1><?php echo $datenum= date('d', strtotime($newdate)); ?></h1>
<p><?php  echo $dayname= date('D', strtotime($newdate)); ?></p>
</div>
</div>
<div class="event_booking2_center">
<div class="event_booking2_center_bg">
<div class="event_booking2_center_name"><?php echo $event_title;?></div>
<div class="event_booking2_center_date"><?php echo $event_start_time;?></div> 
 


<div class="event_booking2_center_enquiry"> <?php echo $event_enq_type;?></div>

</div>

</div>
<div class="event_booking2_right">
<div class="event_booking2_right_total">Total Amount: <?php echo $currency." "; ?> <span id="fulltotal_box">0.00</span> </div>
<!--<div class="event_booking2_right_vat">Vat: <span>12%</span> </div>
<div class="event_booking2_right_vat">Net: <span>£320</span> </div> -->
<div class="event_booking2_right_total">Payments: <?php echo $currency." "; ?><span id="total_paid">0.00</span> </div>
<div class="event_booking2_right_total">Balance:<?php echo $currency." "; ?> <span id="total_balance">0.00</span> </div>
</div>

</div>


<div class="event_booking_dtls">
<div class="event_tab">
  <div class="super_tab_menu">
    <ul>
      <li class="tab_01 active">General</li>
      <li class="tab_02">Menu & Schedule</li>
        <li class="tab_03">Staff on Duty</li>
        <li class="tab_04">Bill and Payment</li>
         <li class="tab_05">Notes</li>
          <li class="tab_06">Tasks</li>
           <li class="tab_07">Pots And Pans</li>
    </ul>
  </div>
  <div class="super_tab_content tab_cont_01">
   <div class="event_booking2_tab">
   <p>
<?php echo $event_title; ?><br><br>
   
 <?php echo $eventtypename.'  '.$subevent_typename; ?><br><br>
   
 <?php echo  $event_date.' '.$event_start_time; ?><br><br>
   
  <?php echo  $venue_name.'  '.$venue_detail.'  '.$venue_address.'  ' .$venue_city.'  '.$venue_state.'  '.$venue_country; ?><br><br>
   
 <?php if($event_contact){ echo 'Tel :  '.$event_contact; } ?>
   
   </p> 
   </div> 

  </div>
  
  <div class="super_tab_content tab_cont_02">  

<div class="event_menu_schedule">


<div class="event_menu_schedule_name">
New Menu Name
</div>
<!--<a href="#">
<div class="event_menu_schedule_box">
select
</div></a>-->



<div class="super_master">
<input name="new_menu_name" type="text" class="event_note_textfeild">
          </div>


</div>
<!-- --> 



<div class="event_menu_schedule_main"> 



<?php if($menu_types){ foreach($menu_types as $type_menu){ $menu_id=$type_menu['menutypeid']; $menu_name=$type_menu['menutypename'];  ?>

<div class="event_menu_schedule_item" id="">
<h1><?php echo $menu_name; ?></h1>
<div class="row_color1">
          <ul>
            <li class="event_item_name">Item Name</li>
            <li class="event_unit">Nos</li>
            <li class="event_unit">Unit</li>
            <li class="event_price">Unit Price</li>
             <li class="event_price">Total</li>
           
          </ul>
        </div>
        <div id="<?php echo $menu_id;?>_itemlist"></div><!--append to this-->
        
  
        
        
</div> 

<?php } } ?>
<!---->






<div class="event_menu_schedule_item">
<div class="event_total_ammount">Total <?php echo $currency." "; ?><span id="grandtotal_view">0.00</span></div>
</div> 

</div> 
 <!---->
  <!--side menutype-->

<?php if($menu_types){ foreach($menu_types as $type_menu){ $menu_id=$type_menu['menutypeid']; $menu_name=$type_menu['menutypename'];

$item_list=$this->event_model->get_items($this->comp_id,$menu_id); 

$item_count=count($item_list);
if($item_count<=1)
{
$item_count=3;
}

 ?>
 <!--rrr-->
<div  class="menu_list_right">
 <div class="event_booking2_driver_menuschedule"><label><?php echo $menu_name;?></label>
<select name="itemid" class="emp_select" id="<?php echo $menu_id;?>" onchange="readfrom_select(this.id);" size="<?php echo $item_count; ?>"> 
<?php if($item_list){ foreach($item_list as $items) { $ittem_id=$items['itemid'];?>

<option id="itemname_<?php echo $ittem_id;?>" value="<?php echo $ittem_id; ?>"><?php echo $items['itemname']; ?></option>
<?php } } ?>
</select>
</div>


</div>

<!---should create temp values-->
<?php if($item_list) { foreach($item_list as $itemss) { $ittem_idd=$itemss['itemid'];?>
<input type="hidden" id="temp_unit_<?php echo $ittem_idd;?>" value="<?php echo $itemss['itemunits'];?>">  
<input type="hidden" id="temp_basep_<?php echo $ittem_idd;?>" value="<?php echo $itemss['itemprice'];?>">  
<?php } } ?>
<!---should create temp values-->

<!--uuuu--->
    
    <?php } } ?>

<input type="hidden" name="cust_id" id="cust_id" value="<?php echo $cust_id;?>"> 
<input type="hidden" name="event_slug" id="event_slug" value="<?php echo $event_slug;?>">  
<input type="hidden" name="event_id" id="event_id" value="<?php echo $event_id;?>">  
<input type="hidden" name="granttotal" id="granttotal" value="0">  <!--item grand total-->


<input type="hidden" name="pots_granttotal" id="pots_granttotal" value="0">  <!--pots grand total-->




  <!--side menutype ends-->
  </div> <!--tab 2 close-->
  
<!--->
<div class="super_tab_content tab_cont_03">
<div class="event_booking2_tab">











<div class="event_booking2_staff">
<div class="super_master-1">
           <div class="super_name"><h1>Driver</h1></div> 
             </div>

<div class="super_master-1">
           <div class="super_name_ajax" id="driver_name"></div>         

          </div>

<div class="event_booking2_staff_left">
<div class="super_master-1">
           <div class="super_name">Time from :</div>         
<div class="super_master">
<input name="driver_timefrom" id="driver_timepickerfrom" type="text" class="super_master_textfeild" readonly>
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name">Date:</div>         
<div class="super_master">
<input name="driver_date" type="text" id="driver_datepicker" class="super_master_textfeild" readonly>
          </div>
          </div>          
</div>




<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Time to:</div>         
<div class="super_master">
<input name="driver_timeto" id="driver_timepickerto" type="text" class="super_master_textfeild" readonly>
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="driver_id" id="driver_id" type="hidden">
<input name="driver_notes" type="text" class="super_master_textfeild">
          </div>
          </div>
</div>
       


<div class="super_master-1">
           <div class="super_name"><h1>Manager</h1></div>         

          </div>
    
<div class="super_master-1">
                
 <div class="super_name_ajax" id="manager_name"><h1></h1></div>  
          </div>
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name">Time from:</div>         
<div class="super_master">
<input name="manager_timefrom" id="manager_timepickerfrom" type="text" readonly class="super_master_textfeild">
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name">Date:</div>         
<div class="super_master">
<input name="manager_date" type="text" id="manager_datepicker" readonly class="super_master_textfeild">
          </div>
          </div>          
</div>




<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Time to:</div>         
<div class="super_master">
<input name="manager_timeto" id="manager_timepickerto" type="text" readonly class="super_master_textfeild">
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="manager_id" id="manager_id" type="hidden">
<input name="manager_notes" type="text" class="super_master_textfeild">
          </div>
          </div>

</div>





<div class="super_master-1">
           <div class="super_name"><h1>Chef</h1></div>         
 
          </div>

 <div class="super_master-1">
                
 <div class="super_name_ajax" id="chef_name"><h1></h1></div>  
          </div>   
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name">Time from:</div>         
<div class="super_master">

<input name="chef_timefrom" type="text" id="chef_timepickerfrom" readonly class="super_master_textfeild">
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name">Date:</div>         
<div class="super_master">
<input name="chef_date" type="text" id="chef_datepicker" readonly class="super_master_textfeild">
          </div>
          </div>          
</div>




<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Time to:</div>         
<div class="super_master">
<input name="chef_timeto" type="text" id="chef_timepickerto" readonly class="super_master_textfeild">
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="chef_id" id="chef_id" type="hidden">
<input name="chef_notes" type="text" class="super_master_textfeild">
          </div>
          </div>

</div>





<div class="super_master-1">
           <div class="super_name"><h1>Agency</h1></div>         

          </div>
    
<div class="super_master-1">
                
 <div class="super_name_ajax" id="agency_name"><h1></h1></div>  
          </div>
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name">Serving Staffs:</div>         
<div class="super_master">
<input name="agency_id" id="agency_id" type="hidden">
<input name="serve_staff" id="serve_staff" type="text" class="super_master_textfeild">
          </div>
          </div>
         <div class="super_master-1">
           <div class="super_name"></div>         
<div class="super_master">

          </div>
          </div>          
</div>




<div class="event_booking2_staff_right">
<div class="super_master-1">
           <div class="super_name">Note :</div>         
<div class="super_master">
<input name="agency_note" id="agency_note" type="text" class="super_master_textfeild">
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name"></div>         
<div class="super_master">


          </div>
          </div>

</div>







</div>
















<div class="event_booking2_driver"><label>DRIVER</label>
<select multiple name="driver" class="emp_select" id="driver_select">
<?php if($drivers){ foreach($drivers as $drive) { ?>
<option value="<?php echo $drive['employeeid']; ?>"><?php echo $drive['employeename']; ?></option>
<?php } } ?>
</select>
</div>

<div class="event_booking2_driver" ><label>MANAGER</label>
<select multiple name="manager" class="emp_select" id="manager_select">
<?php if($managers) { foreach($managers as $manage) { ?>
<option  value="<?php echo $manage['employeeid']; ?>"><?php echo $manage['employeename']; ?></option>
<?php } } ?>
</select>
</div> 

<div class="event_booking2_driver" ><label>CHEF</label>
<select multiple  name="chef" class="emp_select" id="chef_select">
<?php if($chefs) { foreach($chefs as $cheff) { ?>
<option  value="<?php echo $cheff['employeeid']; ?>"><?php echo $cheff['employeename']; ?></option>
<?php } } ?>
</select>
</div> 



<div class="event_booking2_driver" ><label>Agency</label>
<select multiple  name="agency" class="emp_select" id="agency_select">
<?php if($get_agencylist) { foreach($get_agencylist as $agen_list) { ?>
<option  value="<?php echo $agen_list['agency_id']; ?>"><?php echo $agen_list['agency_name']; ?></option>
<?php } } ?>
</select>
</div> 


   </div>

  </div>
<!---->
<div class="super_tab_content tab_cont_04">

<div class="event_booking2_tab">
   
 <!--payment-->
   <div class="dashbord_itemlist">
   <div class="row_payment_schedule">
          <ul>
            <li class="payment_schdl">Payment Schedule</li>
<li class="payment_schd2 master-select">
<select id="pay_schedule_id">
<?php foreach($pay_schedule as $pay_sched){ ?>
<option value="<?php echo $pay_sched['pay_schedule_id']; ?>"  <?php if($schedule_id==$pay_sched['pay_schedule_id'])
echo "selected";?> ><?php echo $pay_sched['basic_steps']; ?></option>
<?php } ?>
</select>
</li>
          </ul>
        </div>

        <div class="row_color1">
          <ul>
            <li class="payment_part">Part#</li>
            <li class="payment_part">Total</li>
            <li class="payment_part">Payments</li>
            <li class="payment_part">Balance</li>
            <li class="payment_part"></li>
            <li class="payment_part"></li>
            <li class="payment_invoice"></li>
           
          </ul>
        </div>
<div id="append_div_pay_schedule"> 
<?php echo $row;?>
</div>
        
        
       
       
      <?php /*  
        <div class="row_payment">
          <ul>
            <li class="payment_received">Payment Received</li>
           
        <!--    <li class="payment_receive_right">Receive Payment</li>-->
           
          </ul>
        </div>
        <div class="payment_received_border"> No  Payments</div> */ ?>
        <div class="payment_total_bottum">Total: <?php echo $currency." "; ?> <span id="fullpayment_box_schedule"> 0.00</span></div>
      </div>
   
   
   <!--payment-->



   </div>

  </div>

  
<div class="super_tab_content tab_cont_07">
<!--new-->
<div class="event_menu_schedule_main"> 

<div class="event_menu_schedule_item" id="">
<h1>Pots and Pans</h1>
<div class="row_color1">
          <ul>
            <li class="event_item_name">Name</li>
            <li class="event_unit">Nos</li>
        <li class="event_unit">Rent per unit</li>
               <li class="event_price">Deposit</li>
             <li class="event_price">Total</li> 
           
          </ul>
        </div>
        <div id="pot_div"></div><!--append to this-->
        
  
        
        
</div> 
<?php if($pots_pans) { foreach($pots_pans as $ppp){ $potttid=$ppp['pp_id']; $temppot_deposit=$ppp['pp_deposit']; $temppot_price=$ppp['pp_price']; ?>

<input type="hidden" name="temp_pot_deposit<?php echo $potttid; ?>" id="temp_pot_deposit<?php echo $potttid; ?>" value="<?php echo $temppot_deposit;?>" />
<input type="hidden" name="temp_pot_rent<?php echo $potttid; ?>" id="temp_pot_rent<?php echo $potttid; ?>" value="<?php echo $temppot_price;?>"/>

<?php }  } ?>



<div class="event_menu_schedule_item">
<div class="event_total_ammount">Total <?php echo $currency." "; ?><span id="pots_grandtotal_view">0.00</span></div>
</div> 

</div> 
 
  <!--side menutype-->

 <!--rrr-->

<div  class="menu_list_right">
 <div class="event_booking2_driver_menuschedule"><label>Pots and Pans</label>
<select name="pott_id" class="emp_select" id="pott_id" onchange="readpots_select(this.id);" size="2"> 
<?php if($pots_pans) { foreach($pots_pans as $pp) { $potid=$pp['pp_id'];  ?>
<option id="<?php echo 'potid_'.$potid;?>" value="<?php echo $pp['pp_id'];?>"><?php echo $pp['pp_name'];?></option>
<?php } } ?>
</select>
</div>


</div>


<!---rrr-->


<!---new-->
  </div>
  
  <div class="super_tab_content tab_cont_05">
  
<div class="event_booking2_tab">
  <div class="event_note_staff">
<div class="event_booking2_staff_left">

<div class="super_master-1">
           <div class="super_name"><h1>Extra Notes</h1></div>         
 <div class="event_post"></div>  
          </div>


<div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject1" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject2" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject3" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject4" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject5" type="text" class="event_note_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Subject:</div>         
<div class="super_master">
<input name="subject6" type="text" class="event_note_textfeild">
          </div>
          </div>
          
</div>
<div class="event_note_staff_right">

<div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note1" cols="" rows="" class="event_notes_textarea"></textarea>

          </div>
          </div>      
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note2" cols="" rows="" class="event_notes_textarea"></textarea>

          </div>
          </div>      
          
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note3" cols="" rows="" class="event_notes_textarea"></textarea>

          </div>
          </div>     
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note4" cols="" rows="" class="event_notes_textarea"></textarea>

          </div>
          </div>  
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note5" cols="" rows="" class="event_notes_textarea"></textarea>

          </div>
          </div>  
          <div class="super_master-1">
           <div class="notes_name">Note :</div>         
<div class="super_master">
  <textarea name="note6" cols="" rows="" class="event_notes_textarea"></textarea>

          </div>
          </div>   
          
          
</div>
  
</div>
  </div>
  </div>
  
  <div class="super_tab_content tab_cont_06">
<div class="event_booking2_tab">



<?php  foreach($tasklist as $task) { ?>
 <div class="event_task_list_main">
   <div class="event_task_list_left" id="bordercolor_<?php echo $task['eventtask_id'];?>">
   <div class="event_task_list_left_menu" id="<?php echo 'task_name'.$task['eventtask_id'];?>"><?php echo ucwords($task['subtask_name']); ?></div>
   <div class="event_task_list_left_completed" id="<?php echo 'task_stat'.$task['eventtask_id'];?>"><?php echo $task['event_task_status']; ?></div>
   
   </div>
   <div class="event_task_list_right"><a href="javascript:void(0)" id="<?php echo 'task_change'.$task['eventtask_id']; ?>" onclick="changetask_status(this.id)">Change</a></div>
   
   </div>
 
<?php } ?>
 
 
 
   </div>
  </div>
</div>
<div class="event_generate_main">

<!--
<a href="#"><div class="event_generate">Generate Invoice</div></a> -->
<div class="event_summary"> Summary </div>
<input name="proceed" type="submit" value="" class="event_customer_left_submit" id="form_submit">
</div>

<div class="event_generate_main">

<!--<a href="#"><div class="event_generate">Save Changes</div></a>-->

</div>

</div>
</form>
</div>

  <div class="clear"></div>
</div>
<!--========= content end ===============-->

<!----item script starts---->

<script type="text/javascript"> 
function readfrom_select(select_id){

cssurl="<?php echo CSSPATH;?>";
menutype_id=select_id;  //id of eg -starter
menutype_list=menutype_id+"_itemlist"; //creating listing parent div variable
item_name=$( "#"+select_id+" option:selected" ).text(); //read selected item name
item_id=$( "#"+select_id+" option:selected" ).val();       //read selected item id


$("#"+select_id+" option:selected").attr('disabled','disabled'); //disable selected option
var row_uniq_id="row_"+menutype_id+"_"+item_id+"_"; //create uniq row id
//var row_uniq_id="row_"+menutype_id+"_"+item_id+"_"+item_name; create old edited uniq row id


document.getElementById(select_id).selectedIndex = -1; // remove current selection


show_item_unit=$('#temp_unit_'+item_id).val();//read item unit from temp hidden
var show_item_basep=$('#temp_basep_'+item_id).val();//read item base price

if(isNaN(show_item_basep)==true)
{
return false; } //exit from js

basep_floated= parseFloat(show_item_basep).toFixed(2);
item_totalp_id="totalp_"+item_id; //total id
basep_uniq_id="basep_"+item_id; //unique baseprice id
text_field_id="textfield_"+item_id; //textfield id
text_field_name="textfield_"+item_id; //textfield name
closebutt_id="closeb_"+item_id; //close button id

var displayrow="<div class='row_color2' id='"+row_uniq_id+"'><ul><li class='event_item_name'>"+item_name+"</li><li class='event_unit'><input name='"+text_field_name+"' type='text' value='0' class='event_text' id='"+text_field_id+"' onblur='calc(this.id,this.value);'></li><li class='event_unit'>"+show_item_unit+"</li><li class='event_price' id='"+basep_uniq_id+"'>"+basep_floated+"</li><li class='event_price' id='"+item_totalp_id+"'>0</li><li class='event_close_button'><img src='"+cssurl+"images/welcome/close.png' id='"+closebutt_id+"' alt='"+row_uniq_id+"' onclick='remove_item(this.id,this.alt);'></li></ul></div>";

$( "#"+menutype_list).append(displayrow); //appennd to parent div for listing

}
</script>
<script>

function calc(textfield_id,field_value)
{ 

//granttotal
if ((isNaN(field_value)==true)||(field_value=='')) //if char
{
document.getElementById(textfield_id).value=0;
field_value=$('#'+textfield_id).val();
}
field_value= parseInt(field_value); //field value


var getitem_id=textfield_id.replace(/^textfield_+/i, ''); //itemid
getitem_id=(getitem_id.trim()); //remove white space
getitem_id= parseInt(getitem_id); 
var item_baseprice=$('#temp_basep_'+getitem_id).val();//read item base price
item_baseprice=parseFloat(item_baseprice).toFixed(2);
field_value =parseFloat(field_value).toFixed(2);

var current_subtotal=document.getElementById("totalp_"+getitem_id).innerHTML; //read current subtotal
current_subtotal=parseFloat(current_subtotal).toFixed(2);
var curr_gtotal=$('#granttotal').val(); //read curr gtotal
curr_gtotal=parseFloat(curr_gtotal).toFixed(2);
curr_gtotal=curr_gtotal-current_subtotal; //reset by subtract current sub total


subtotal=field_value * parseFloat(item_baseprice).toFixed(2); //calculate sub total

var grand_total=0;
grand_total=curr_gtotal+subtotal; //new gtotal
grand_total=parseFloat(grand_total).toFixed(2); 

$('#granttotal').val(grand_total); //put to hidden
//$('#total_payment').val(grand_total); //put to payment textbox

document.getElementById("totalp_"+getitem_id).innerHTML = subtotal;
document.getElementById("grandtotal_view").innerHTML = grand_total; 
put_grandtotal_forpayment();
auto_update_task_status('added-item','<?php echo $event_id;?>');

 }
</script>
<script>
function remove_item(button_id,row_id)
{

var getitem_id=button_id.replace(/^closeb_+/i, ''); //itemid
getitem_id=(getitem_id.trim()); //remove white space
getitem_id= parseInt(getitem_id); 
var item_baseprice=$('#temp_basep_'+getitem_id).val();//read item base price
item_baseprice=parseFloat(item_baseprice).toFixed(2);

var current_subtotal=document.getElementById("totalp_"+getitem_id).innerHTML; //read current subtotal
current_subtotal=parseFloat(current_subtotal).toFixed(2);
var curr_gtotal=$('#granttotal').val(); //read curr gtotal
curr_gtotal=parseFloat(curr_gtotal).toFixed(2);
curr_gtotal=curr_gtotal-current_subtotal; //reset by subtract current sub total

curr_gtotal=parseFloat(curr_gtotal).toFixed(2); 

$('#granttotal').val(curr_gtotal); //put to hidden
document.getElementById("grandtotal_view").innerHTML = curr_gtotal; //to display

//$('#total_payment').val(curr_gtotal); //put to payment textbox

$("#"+row_id).remove();
$('#itemname_'+getitem_id).removeAttr('disabled');   //enable

put_grandtotal_forpayment();
auto_update_task_status('added-item','<?php echo $event_id;?>');

}
</script>

<!----item script ends---->



<!----Staff scripts starts---->
<script>


/** select driver multiple**/
 $("#driver_select").click(function(){ 
$("#driver_id").val(this.value);
$("#driver_name").html(this.options[this.selectedIndex].text);
auto_update_task_status('assignstaff','<?php echo $event_id;?>');
});
/** select driver multiple**/

/** select manager multiple**/
 $("#manager_select").click(function(){ 
$("#manager_id").val(this.value);
$("#manager_name").html(this.options[this.selectedIndex].text);
auto_update_task_status('assignstaff','<?php echo $event_id;?>');
});
/** select driver multiple**/


/** select chef multiple**/
 $("#chef_select").click(function(){ 
$("#chef_id").val(this.value);
$("#chef_name").html(this.options[this.selectedIndex].text);
auto_update_task_status('assignstaff','<?php echo $event_id;?>');
});
/** select driver multiple**/


/** select chef multiple**/
 $("#agency_select").click(function(){ 
$("#agency_id").val(this.value);
$("#agency_name").html(this.options[this.selectedIndex].text);
auto_update_task_status('assignstaff','<?php echo $event_id;?>');
});
/** select driver multiple**/

</script>
<!----Staff scripts ends---->

<!----pots and pans starts---->
<script>
function readpots_select(pott_select_id)
{
cssurl="<?php echo CSSPATH;?>";
var selected_pp_id=$( "#pott_id option:selected" ).val();  
var selected_pp_name=$( "#pott_id option:selected" ).text(); //pot name
var pot_row_uniq_id='potdiv_'+selected_pp_id;  //uiq row id
var pot_closebutt_id="closeb_"+selected_pp_id;   //close button name
var pot_nos_text_field_name="textfieldnos_"+selected_pp_id; //textfield nos name
var pot_rent_text_field_name="textfieldrent_"+selected_pp_id; //textfield rent name
var pot_deposit_text_field_name="textfielddeposit_"+selected_pp_id; //textfield deposit name
var pot_subtotal_id="pot_subtotal_"+selected_pp_id; //subtotal id


var pot_deposit_value=$("#temp_pot_deposit"+selected_pp_id).val();
var pot_rent_price=$("#temp_pot_rent"+selected_pp_id).val();

if((!selected_pp_name)||(selected_pp_name.length<1))
{ return false; }

var pot_displayrow="<div class='row_color2' id='"+pot_row_uniq_id+"'><ul><li class='event_item_name'>"+selected_pp_name+"</li><li class='event_unit'><input name='"+pot_nos_text_field_name+"' type='text' value='0' class='event_text' id='"+pot_nos_text_field_name+"' onblur='pot_calc(this.id,this.value);'></li><li class='event_unit'><input name='"+pot_rent_text_field_name+"' type='text' value='"+pot_rent_price+"' class='event_text' id='"+pot_rent_text_field_name+"' onblur='pot_calc(this.id,this.value);'></li><li class='event_price'><input name='"+pot_deposit_text_field_name+"' type='text' value='"+pot_deposit_value+"' class='event_text' id='"+pot_deposit_text_field_name+"' onblur='pot_calc(this.id,this.value);'></li><li class='event_price' id='"+pot_subtotal_id+"'>0</li><li class='event_close_button'><img src='"+cssurl+"images/welcome/close.png' id='"+selected_pp_id+"' alt='"+pot_row_uniq_id+"' onclick='remove_pots(this.id,this.alt);'></li></ul></div>";

$("#pott_id option:selected").attr('disabled','disabled'); //disable selected option
document.getElementById(pott_select_id).selectedIndex = -1; // remove current selection subjected to onchange

$( "#pot_div").append(pot_displayrow); //appennd to parent div for listing

}

</script>
<script>
function remove_pots(pot_id,rowid)
{

get_currenttotal=document.getElementById("pot_subtotal_"+pot_id).innerHTML;
get_currenttotal=parseFloat(get_currenttotal);



var pots_gtotal=$("#pots_granttotal").val(); //read from hidden  
pots_gtotal=parseFloat(pots_gtotal);
pots_gtotal=pots_gtotal-get_currenttotal;
$("#pots_granttotal").val(pots_gtotal); //put to hidden
document.getElementById("pots_grandtotal_view").innerHTML =pots_gtotal; //put for display


$("#"+rowid).remove();
$('#potid_'+pot_id).removeAttr('disabled');   //enable


put_grandtotal_forpayment();
auto_update_task_status('addpotsandpans','<?php echo $event_id;?>');

}
</script>

<script>
function pot_calc(pottextfield_id,potfield_value)
{

if((pottextfield_id.indexOf("textfieldnos_") > -1)==true) //identify the field
{
var curr_pot_id=pottextfield_id.replace(/^textfieldnos_+/i, ''); 
}

if((pottextfield_id.indexOf("textfieldrent_") > -1)==true)
{
var curr_pot_id=pottextfield_id.replace(/^textfieldrent_+/i, ''); 
}

if((pottextfield_id.indexOf("textfielddeposit_") > -1)==true)
{
var curr_pot_id=pottextfield_id.replace(/^textfielddeposit_+/i, ''); 
}


var pott_deposit_value=$("#textfielddeposit_"+curr_pot_id).val();  //deposit value 
pott_deposit_value=parseFloat(pott_deposit_value).toFixed(2);  
var pott_rent_value=$("#textfieldrent_"+curr_pot_id).val(); //rent value 
pott_rent_value=parseFloat(pott_rent_value).toFixed(2);
var pott_nos_value=$("#textfieldnos_"+curr_pot_id).val(); ////nos value 
pott_nos_value=parseFloat(pott_nos_value).toFixed(2);

get_currenttotal=document.getElementById("pot_subtotal_"+curr_pot_id).innerHTML;
get_currenttotal=parseFloat(get_currenttotal);

if((isNaN(pott_rent_value)==true)||(pott_rent_value==''))
{ $("#textfieldrent_"+curr_pot_id).val('0'); pott_rent_value=0; } //set rent as 0

if((isNaN(pott_deposit_value)==true)||(pott_deposit_value==''))
{ $("#textfielddeposit_"+curr_pot_id).val('0'); pott_deposit_value=0; } //set deposit as 0


if((isNaN(pott_nos_value)==true)||(pott_nos_value==''))
{ $("#textfieldnos_"+curr_pot_id).val('0'); pott_nos_value=0; } //set pott_nos_value as 0 edited added two lines






if((pott_nos_value==0))  //edited if
{

document.getElementById("pot_subtotal_"+curr_pot_id).innerHTML =0;
var pots_gtotal2=$("#pots_granttotal").val(); //read from hidden  
pots_gtotal2=pots_gtotal2-get_currenttotal; //subtract current total
$("#pots_granttotal").val(pots_gtotal2); //put to hidden

document.getElementById("pots_grandtotal_view").innerHTML =pots_gtotal2; //put for display edited added one lines

return false;
} // if value is 0 bcoz no deposit needed

pots_subtotal1=(pott_rent_value*pott_nos_value);
pots_subtotal2=parseFloat(pots_subtotal1) + parseFloat(pott_deposit_value); //subtotal

document.getElementById("pot_subtotal_"+curr_pot_id).innerHTML = pots_subtotal2;  //put subtotal

var pots_gtotal=$("#pots_granttotal").val(); //read from hidden  
pots_gtotal=parseFloat(pots_gtotal);
pots_gtotal=pots_gtotal-get_currenttotal;
pots_gtotal=pots_gtotal + parseFloat(pots_subtotal2); //calc grand pot total with current
$("#pots_granttotal").val(pots_gtotal); //put to hidden
document.getElementById("pots_grandtotal_view").innerHTML =pots_gtotal; //put for display

put_grandtotal_forpayment();
auto_update_task_status('addpotsandpans','<?php echo $event_id;?>');

}

</script>


<!----pots and pans ends---->



<!------>

<script>

function put_grandtotal_forpayment()
{

var pots_gtotal=$("#pots_granttotal").val(); //read from hidden  
pots_gtotal=parseFloat(pots_gtotal);

var curr_gtotal=$('#granttotal').val(); //read curr gtotal item
curr_gtotal=parseFloat(curr_gtotal);

full_total=pots_gtotal+curr_gtotal;

full_total=parseFloat(full_total).toFixed(2)

document.getElementById("fullpayment_box_schedule").innerHTML =full_total; //put for display full total on schedule


document.getElementById("fulltotal_box").innerHTML =full_total; //put for display full total box

again_payment_schedule_calcu();

total_balance_topay();
}



</script>

<!---change task status---->

<script>

function changetask_status(status_id)
{
var task_table_id=status_id.replace(/^task_change+/i, ''); 
var event_idd="<?php echo $event_id;?>";


	$.ajax({
		type: "POST",
		url : "<?php echo base_url();?>event/event_ajax/event_task/"+task_table_id+"/"+event_idd,
		success: function(msg){
		

if(msg){ 
           $("#task_stat"+task_table_id).html(msg); 

              if(msg=='completed')
                    {  $("#bordercolor_"+task_table_id).addClass("completed_task_div"); }

                    else{ $("#bordercolor_"+task_table_id).removeClass("completed_task_div");   }
      } 



  }
	

}); //ajax close
}



</script>

<!---change task status----->



<!---auto change task status---->

<script>

function auto_update_task_status(subtask_name,event_id)
{

$.ajax({
		type: "POST",

		url : "<?php echo base_url();?>event/event_ajax/auto_event_task/"+subtask_name+"/"+event_id,
		success: function(msg){
var obj = $.parseJSON(msg);
var task_table_id=obj.eventtask_id;
var new_status=obj.status;

		

if(msg){ 
           $("#task_stat"+task_table_id).html(new_status); 

              if(new_status=='completed')
                    {  $("#bordercolor_"+task_table_id).addClass("completed_task_div"); }

                    else{ $("#bordercolor_"+task_table_id).removeClass("completed_task_div");   }
      } 



  }
	

}); //ajax close

}


</script>

<!---auto change task status----->

<!---payment schedule select ----->
<script>

$('#pay_schedule_id').change(function(){

var full_total=document.getElementById("fullpayment_box_schedule").innerHTML; 

var selected_pay_id=$( "#pay_schedule_id option:selected" ).val();  
var selected_pay_name=$( "#pay_schedule_id option:selected" ).text(); //schedule name

var event_id="<?php echo $event_id;?>";


$.ajax({
		type: "POST",

		url : "<?php echo base_url();?>event/event_ajax/event_payschedule/"+selected_pay_id+"/"+event_id+"/"+full_total,
		success: function(msg){
if(msg){ 

document.getElementById("append_div_pay_schedule").innerHTML = "";

$( "#append_div_pay_schedule").append(msg); //append to parent div for listing     

document.getElementById("total_paid").innerHTML="0.00"; // when selection changes put to zero initialize

document.getElementById("total_balance").innerHTML=document.getElementById("fulltotal_box").innerHTML; // same as total and balance



      } //if msg



  } //success
	

}); //ajax close






 });



</script>

<!---payment schedule ----->



<!---change payment total- when payment selected and changed item or pots and pans----->

<script>

function again_payment_schedule_calcu()
{
var total_paidmoney=0;

if(document.getElementById('first_percent')!=null)
{
var calc_total_first=document.getElementById("first_percent").innerHTML; 

}
if(document.getElementById('second_percent')!=null)
{
var calc_total_second=document.getElementById("second_percent").innerHTML; 
}
if(document.getElementById('third_percent')!=null)
{
var calc_total_third=document.getElementById("third_percent").innerHTML; 
}

var read_fulltotal=document.getElementById("fullpayment_box_schedule").innerHTML; //read payment total
read_fulltotal=parseFloat(read_fulltotal);


if(calc_total_first)
{

var calc_total_first=calc_total_first.substring(calc_total_first.lastIndexOf("(")+1,calc_total_first.lastIndexOf(")")); //string between ( and )
calc_total_first= calc_total_first.replace(/[^\w\s]/gi, ''); //remove special char %

var first_payment=read_fulltotal*(calc_total_first/100);
}

if(calc_total_second)
{
var calc_total_second=calc_total_second.substring(calc_total_second.lastIndexOf("(")+1,calc_total_second.lastIndexOf(")")); //string between ( and )
calc_total_second= calc_total_second.replace(/[^\w\s]/gi, '');  //remove special char %


var second_payment=read_fulltotal*(calc_total_second/100); //calculation by percent
}


if(calc_total_third)
{
var calc_total_third=calc_total_third.substring(calc_total_third.lastIndexOf("(")+1,calc_total_third.lastIndexOf(")")); //string between ( and )
calc_total_third= calc_total_third.replace(/[^\w\s]/gi, '');  //remove special char %

var third_payment=read_fulltotal*(calc_total_third/100);

}


if(document.getElementById('first_price')!=null)
{
first_payment= parseFloat(first_payment).toFixed(2);
document.getElementById("first_price").innerHTML=first_payment;  //put calculated percent

/**if paid*/
var payment=$("#first_pay").val();
to_pay=document.getElementById("first_price").innerHTML; //read percent total amount
to_pay=to_pay.replace(/^£+/i, ''); // remove symbol if exists
to_pay= parseFloat(to_pay); //float value
if(isNaN(payment)||(payment > to_pay)) //exception
{
alert("CHECK PAYMENT");
payment=00; 
$("#first_pay").val("0");
}
payment= parseFloat(payment);
total_paidmoney=total_paidmoney+payment;  //cal total paid

var bal=to_pay-payment; 
bal= parseFloat(bal).toFixed(2);; //float value
document.getElementById("first_balance").innerHTML=bal;
/*if paid*/


}
if(document.getElementById('second_price')!=null)
{
second_payment= parseFloat(second_payment).toFixed(2);
document.getElementById("second_price").innerHTML=second_payment; //put when again item or pots changed

/**if paid*/
var payment=$("#second_pay").val();
to_pay=document.getElementById("second_price").innerHTML; //read percent total amount
to_pay=to_pay.replace(/^£+/i, ''); // remove symbol if exists
to_pay= parseFloat(to_pay); //float value
if(isNaN(payment)||(payment > to_pay)) //exception
{
alert("CHECK PAYMENT");
payment=00; 
$("#second_pay").val("0");
}
payment= parseFloat(payment);
total_paidmoney=total_paidmoney+payment; //cal total paid

var bal=to_pay-payment; 
bal= parseFloat(bal).toFixed(2); //float value
document.getElementById("second_balance").innerHTML=bal;
/*if paid*/


}
if(document.getElementById('third_price')!=null)
{
third_payment= parseFloat(third_payment).toFixed(2);
document.getElementById("third_price").innerHTML=third_payment;


/**if paid*/
var payment=$("#third_pay").val();
to_pay=document.getElementById("third_price").innerHTML; //read percent total amount
to_pay=to_pay.replace(/^£+/i, ''); // remove symbol if exists
to_pay= parseFloat(to_pay); //float value
if(isNaN(payment)||(payment > to_pay)) //exception
{
alert("CHECK PAYMENT");
payment=00; 
$("#third_pay").val("0");
}

payment= parseFloat(payment);
total_paidmoney=total_paidmoney+payment; //cal total paid

var bal=to_pay-payment;
bal= parseFloat(bal).toFixed(2);; //float value
document.getElementById("third_balance").innerHTML=bal;
/*if paid*/
}

total_paidmoney= parseFloat(total_paidmoney).toFixed(2);
document.getElementById("total_paid").innerHTML=total_paidmoney; //put to display total paid

total_balance_topay();


} //fntn ends



</script>
<!---change payment total----->


<!---bill and payment----->
<script>


function receivepayment(payfield_id)
{
var total_paidmoney=0;

var payment=$("#"+payfield_id).val(); //payment paid

var uniq=payfield_id.slice(0, payfield_id.indexOf("_")); 

to_pay=document.getElementById(uniq+"_price").innerHTML; //read percent total amount
to_pay=to_pay.replace(/^£+/i, ''); // remove symbol if exists
to_pay= parseFloat(to_pay); //float value


if(isNaN(payment)||(payment > to_pay)||(payment=='')) //exception
{

alert("INVALID PAYMENT");
payment=00; 
$("#"+payfield_id).val("0");
}



var bal=to_pay-payment;

bal= parseFloat(bal).toFixed(2); //float value
document.getElementById(uniq+"_balance").innerHTML=bal;


calculate_paid(); //put to display
total_balance_topay();

}
</script>


<!---bill and payment----->

<!---Prevent enter key to submit----->

<script>

$(document).ready(function() {


  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
</script>
<!---Prevent enter key to submit----->



<!--calculate paid to display function to call----->

<script>
 function calculate_paid()
{

var totalpaidd=0;
if(document.getElementById('first_pay')!=null)
{
var payment=$("#first_pay").val(); //payment paid
payment= parseFloat(payment);
totalpaidd=totalpaidd+payment;
}

if(document.getElementById('second_pay')!=null)
{
var payment=$("#second_pay").val(); //payment paid
payment= parseFloat(payment);
totalpaidd=totalpaidd+payment;
}

if(document.getElementById('third_pay')!=null)
{
var payment=$("#third_pay").val(); //payment paid
payment= parseFloat(payment);
totalpaidd=totalpaidd+payment;
}
totalpaidd= parseFloat(totalpaidd).toFixed(2);
document.getElementById("total_paid").innerHTML=totalpaidd; //put to display total paid

}

</script>
<!--calculate paid to display----->





<!--calculate total balance to display function to call----->


<script>

function total_balance_topay()
{

var total_topay=document.getElementById("fulltotal_box").innerHTML;
var total_paid=document.getElementById("total_paid").innerHTML;

var total_bal=total_topay-total_paid;

total_bal=parseFloat(total_bal).toFixed(2);
document.getElementById("total_balance").innerHTML=total_bal;


}
</script>


<!--calculate balance to display----->


<!--js before submit----->

<script>
function before_submit_form()
{
$('#form_submit').attr('disabled','disabled'); //disable submit on click

document.getElementById("form_submit").style.visibility='hidden';

//var $html = $('html').clone();
//$html.find('body').html($response);



}
</script>
<!--js before submit----->

<!---footer-->
<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
      <!--  <td><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/back.png" alt=""></a></td>
        <td align="center"><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/home.png" alt=""></a></td>
        <td align="right"><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/my_order.png" alt=""></a></td>-->
      </tr>
    </table>
  </div>
   <div class="clear"></div>
</footer>
<script type="text/javascript">

var slider1=new accordion.slider("slider1");
slider1.init("slider");


</script>

</body>
</html>

