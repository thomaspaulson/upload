<script>
$(window).click(function(e) {
   document.getElementById("form_submit_continue").style.visibility='visible';//visible after  
document.getElementById("form_submit").style.visibility='visible';//visible after 
});


</script>
<?php 
foreach($event_details as $det)
{
$event_location=$det['event_location'];
$event_address=$det['event_address'];
$event_town=$det['event_town'];
$event_country=$det['event_country'];
$evet_state=$det['evet_state'];
}

foreach($eventguest as $eventguestss)
{
$child=$eventguestss['children'];
$adults=$eventguestss['adult'];
$guest_notes=$eventguestss['guest_notes'];
$eventt_date=$eventguestss['event_date'];
$eventt_time=$eventguestss['event_time'];


//$eventt_date= str_replace('/', '-', $eventt_date);
$eventt_date= date('d/m/Y', strtotime($eventt_date));



}



foreach($typess as $etypess)
{
$maintype=$etypess['eventtypeb_name'];
$subtypename=$etypess['eventstb_name'];
}

foreach($customer as $evtype)
{
$maintype_id=$evtype['eventtypeb_id'];
$subtype_id=$evtype['eventtypestb_id'];
$eventt_title=$evtype['event_title'];
$eventt_contactnum=$evtype['event_contactnum'];
$custname=$evtype['customername'];
}
?>


  <link rel="stylesheet" href="<?php echo CSSPATH;?>css/jquery-ui.css">
  <script src="<?php echo CSSPATH;?>js/jquery-ui.js"></script>


 <link rel="stylesheet" href="<?php echo CSSPATH; ?>css/timepicker.css">
  <script src="<?php echo CSSPATH; ?>js/timepicker.js"></script>



<script> 
  $(function() {
$('#timepicker').timepicker();
    $( "#datepicker" ).datepicker({ dateFormat: 'dd/mm/yy' })
  });
  </script>


<?php //print_r($get_eventtype);

$confirmstat='';
$enquirystat='';
$provisionalstat='';

$singledaystat='';
$multidaystat='';

$deliverystat='';
$outsidecateringstat='';


if($enq_type=='Confirm')
{
$confirmstat='checked';
}elseif($enq_type=='Enquiry')
{
$enquirystat='checked';
}
elseif($enq_type=='Provisional')
{
$provisionalstat='checked';
} 




if($day_type=='singleday')
{
$singledaystat='checked';
}elseif($day_type=='multiday')
{
$multidaystat='checked';
}

if($cater_type=='outsidecatering')
{
$outsidecateringstat='checked';
}elseif($cater_type=='delivery')
{
$deliverystat='checked';
}




?>

<!-- Check box and  Radio button -->
<script>
    function setupLabel() {
        if ($('.label_check input').length) {
            $('.label_check').each(function(){ 
                $(this).removeClass('c_on');
            });
            $('.label_check input:checked').each(function(){ 
                $(this).parent('label').addClass('c_on');
            });                
        };
        if ($('.label_radio input').length) {
            $('.label_radio').each(function(){ 
                $(this).removeClass('r_on');
            });
            $('.label_radio input:checked').each(function(){ 
                $(this).parent('label').addClass('r_on');
            });
        };
    };
    $(document).ready(function(){
        $('body').addClass('has-js');
        $('.label_check, .label_radio').click(function(){
            setupLabel();
        });
        setupLabel(); 

$('#event_type').on('change', function() {
event_type_id=  this.value; 
$("#sub_category").empty(); 
comp_id="<?php echo $this->session->userdata('comp_id'); ?>";
	$.ajax({
		type: "GET",
		url : "<?php echo base_url();?>event/event_ajax/index/"+event_type_id+"/"+comp_id,
		success: function(msg){
		

if(msg!=0){  $("#sub_category").html(msg); }



  }
	}); 


});
 });









   
</script>
<!-- Check box and  Radio button -->
<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"> <h1>Edit Event</h1></div>

<div class="super_company_name">
     <div class="super_company_logo"><!--<img src="images/small_logo.png">--></div>
     <div class="super_company_logo_name"><h1><?php echo '#'.$event_id;
//$branch_name=$this->session->userdata('branch_name');
 ?></h1></div>
    </div>

<div class="super_cust_name">
     <div class="super_company_logo"><img src="<?php echo CSSPATH;?>images/user_name_icon.jpg"></div>
     <div class="super_company_logo_name"><h1><?php echo $custname; ?></h1></div>
    </div>





<div class="event_newbooking_main">
<div class="event_newbooking_type">

                      <h1>Type</h1>
 <form action="<?php echo base_url();?>event/event_overview/update_event_details" method="post" onsubmit="return form_validation()">
          
            <label class="label_radio r_on">
              <input name="event_enq_type" id="radio_01" value="Enquiry" <?php echo $enquirystat;?> type="radio">
              Enquiry</label>            
          <label class="label_radio r_on">
              <input name="event_enq_type" id="radio_02" value="Confirm" <?php echo $confirmstat;?> type="radio">
              Confirm</label>
              <label class="label_radio r_on">
              <input name="event_enq_type" id="radio_03" value="Provisional" <?php echo $provisionalstat;?>  type="radio">
              Provisional</label>
</div>
<div class="event_newbooking_type">
                      <h1>Catering Type</h1>
          
            <label class="label_radio r_on">
              <input name="cater_type" id="radio_01" value="outsidecatering" <?php echo $outsidecateringstat;?>  type="radio"> 
              Outside Catering</label>            
          <label class="label_radio r_on">
              <input name="cater_type" id="radio_02" value="delivery" <?php echo $deliverystat;?> type="radio">
              Delivery</label>
              
</div>


<div class="event_newbooking_type">
                      <h1>Day Schedule</h1>
          
            <label class="label_radio r_on">
              <input name="day_type" id="radio_01" value="singleday" <?php echo $singledaystat;?>  type="radio"> Single Day</label>            
          <label class="label_radio r_on">
              <input name="day_type" id="radio_02" value="multiday" <?php echo $multidaystat;?>  type="radio">
              Multi Day</label>
              
</div>

</div>

<div class="event_customer_main">

<div class="event_booking_details">
<h1>Event Details</h1>

          <!---->

          <div class="event_name_main">
           <div class="event_name">Event Category *:</div>         
<div class="master-select">
<select id="event_type" name="event_type">
            <option value="0">--Select Category--</option>
<?php if($get_eventtype){ foreach($get_eventtype as $type)
{  $id=$type['eventtypeb_id']; $etype=$type['eventtypeb_name']; ?>
            <option value='<?php echo $id;?>' <?php if($maintype_id==$id) { echo "selected"; } ?>  ><?php echo $etype;?>  </option>
             
<?php } } ?>
          </select>
          </div>
          </div>

         <!---->
         <div class="event_name_main">
           <div class="event_name">Sub Category *:</div>         
<div class="master-select">
<select id="sub_category" name="subevent_type">

            <option value="<?php echo $subtype_id; ?>"><?php echo $subtypename; ?></option>
          </select>
          </div>
          </div>
         <!---->
         <div class="event_name_main">
           <div class="master-name">Title *: </div>         
<div class="master-select">
<input name="event_title" value="<?php echo $eventt_title; ?>"  type="text" class="master-textfeild">
          </div>
          </div>
          
          <!---->
         <div class="event_name_main">
           <div class="master-name">Contact *: </div>         
<div class="master-select">
<input name="event_contact" value="<?php echo $eventt_contactnum; ?>" type="text" class="master-textfeild">
          </div>
          </div>
          <!---->
          <h1>Single Day</h1>
          
          <!---->
         <div class="event_name_main">
           <div class="master-name">No. of Adult *: </div>         
<div class="master-select">
<input name="adult_nos" value="<?php echo $adults; ?>" type="text" class="master-textfeild">
          </div>
          </div>
          
          <!---->
         <div class="event_name_main">
           <div class="master-name">No. of Children *: </div>         
<div class="master-select">
<input name="child_nos" value="<?php echo $child; ?>" type="text" class="master-textfeild">
          </div>
          </div>
          
    <!--
         <div class="event_name_main">
           <div class="master-name">Time: </div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild">
          </div>
          </div>
--> 
           <div class="event_name_main">
            <div class="master-name">Notes: </div>
            <div class="master-select">
             
              <textarea name="notes"  cols="" rows="" class="master-textbox"><?php echo $guest_notes; ?></textarea>
            </div>
          </div>
           
          
         <?php /* ?>
          <h1>Multi Day</h1>
          
          
          <div class="event_name_main">
           <div class="master-name">Adult: </div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild">
          </div>
          </div>
                  <!---->  
              <div class="event_name_main">
           <div class="master-name">Children: </div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild">
          </div>
          </div>    
           <!---->  
              <div class="event_name_main">
           <div class="master-name">Date: </div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild">
          </div>
          </div>    
          
           
            <!---->  
              <div class="event_name_main">
           <div class="master-name">Time: </div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild">
          </div>
          </div>           
           <!----> 
           <div class="event_name_main">
            <div class="master-name">Notes: </div>
            <div class="master-select">
             
              <textarea name="description" cols="" rows="" class="master-textbox"></textarea>
            </div>
          </div>
           
           
            <!----> 
              <div class="event_name_main">
           <div class="master-name">Date of Booking: </div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild">
          </div>
          </div> <?php */ ?>
   
  </div>

 
 <div class="event_booking_details">
<h1>Date & Time</h1>


              <div class="event_name_main">
           <div class="master-name">Event Date *: </div>         
<div class="master-select">
<input name="event_date" value="<?php echo $eventt_date;?>" type="text" id="datepicker" class="master-textfeild" readonly>
          </div>
          </div>      
 <!----> 
  <div class="event_name_main">
           <div class="master-name">Start Time *: </div>         
<div class="master-select">
<input name="event_start_time" value="<?php echo $eventt_time;?>" id="timepicker"  type="text" class="master-textfeild" readonly>

          </div>
          </div> 
 
</div>


<div class="event_booking_details">
<h1>Event Location</h1>

 <!----> 
           <div class="event_name_main">
            <div class="master-name">Venue *: </div>
            <div class="master-select">
             
             <input name="venue_name" value="<?php echo $event_location; ?>" type="text" class="master-textfeild">
            </div>
          </div>
 <!----> 
 <div class="event_name_main">
           <div class="master-name">Venue Detail: </div>         
<div class="master-select">

 <textarea name="venue_detail" cols="" rows="" class="master-textbox"></textarea>
          </div>
          </div>
  <!----> 
  <div class="event_name_main">
           <div class="master-name">Address: </div>         
<div class="master-select">
<input name="venue_address" value="<?php echo $event_address; ?>" type="text" class="master-textfeild">
          </div>
          </div>
  <!----> 
  <div class="event_name_main">
           <div class="master-name">City: </div>         
<div class="master-select">
<input name="venue_city" value="<?php echo $event_town; ?>" type="text" class="master-textfeild">
          </div>
          </div>
  <!---->
  
   <div class="event_name_main">
           <div class="master-name">State: </div>         
<div class="master-select">
<input name="venue_state" value="<?php echo $evet_state; ?>" type="text" class="master-textfeild">
          </div>
          </div>
  <!---->  
   <div class="event_name_main">
           <div class="master-name">Country: </div>         
<div class="master-select">
<input name="venue_country" value="<?php echo $event_country; ?>" type="text" class="master-textfeild">
          </div>
          </div>
  <!----> 
 
</div>

<input type="hidden" name="event_id" value="<?php echo $event_id;?>"/>       
<input type="hidden" name="customerid" value="<?php echo $customerid;?>"/>      

<input name="save" type="submit" value="" class="event_customer_left_button_save" id="form_submit">      
<input name="continue" type="submit" value="" class="event_customer_left_button_save_continue" id="form_submit_continue">   
</form>

</div>

</div>
  <div class="clear"></div>
</div>
<!--========= content end ===============-->

<!---Prevent enter key to submit----->

<script>

$(document).ready(function() {

  $(window).keydown(function(event){
    if(event.keyCode == 13) {
      event.preventDefault();
      return false;
    }
  });
});
</script>
<!---Prevent enter key to submit----->


<!--validation-->
<script>
function form_validation()
{
$(".warning").removeClass("warning"); //remove any warning classes redcolor

var e = document.getElementById("event_type");
var strUser = e.options[e.selectedIndex].value;

var sub_cats= document.getElementById("sub_category");
var str_sub=sub_cats.options[sub_cats.selectedIndex].value;

var v_event_title=($('input[name=event_title]').val()); 
var v_event_contact=($('input[name=event_contact]').val());
var v_adult_nos=($('input[name=adult_nos]').val());
var v_child_nos=($('input[name=child_nos]').val());
var v_event_date=($('input[name=event_date]').val());
var v_event_start_time=($('input[name=event_start_time]').val());
var v_venue_name=($('input[name=venue_name]').val());



if(strUser=="0"){ 

$('#event_type').addClass('warning');
//alert("Select Category");
return false; }
else if((str_sub=="0")||(str_sub=="")){ 
$('#sub_category').addClass('warning');
//alert("Select subcategory");
return false; }
else if((v_event_title=='')||(v_event_title.match(/^\s*$/))){ 

$('input[name=event_title]').addClass('warning');  $('input[name=event_title]').focus(); 

//alert("Enter Event Title");
return false;}
else if((v_event_contact=='')||(isNaN(v_event_contact)==true)||(v_event_contact.match(/^\s*$/))){ 
//alert("Invalid Contact"); 

$('input[name=event_contact]').addClass('warning');  $('input[name=event_contact]').focus();
return false; }
else if((v_adult_nos=='')||(isNaN(v_adult_nos)==true)||(v_adult_nos.match(/^\s*$/))){ 

$('input[name=adult_nos]').addClass('warning');  $('input[name=adult_nos]').focus();

//alert("Invalid Adult Number");
 return false; }
else if((v_child_nos=='')||(isNaN(v_child_nos)==true)||(v_child_nos.match(/^\s*$/))){ 
$('input[name=child_nos]').addClass('warning');  $('input[name=child_nos]').focus();

//alert("Invalid Child Number"); 
return false; }
else if((v_event_date=='')){ 

$('input[name=event_date]').addClass('warning');  $('input[name=event_date]').focus();

//alert("Invalid Event Date"); 
return false; }
else if((v_event_start_time=='')){ 

$('input[name=event_start_time]').addClass('warning');  $('input[name=event_start_time]').focus();
//alert("Invalid Start Time");
 return false; }

else if((v_venue_name=='')||(v_venue_name.match(/^\s*$/))){ 

$('input[name=venue_name]').addClass('warning');  $('input[name=venue_name]').focus();
//alert("Enter Venue Name");
return false;}


$('#form_submit').attr('disabled','disabled');
document.getElementById("form_submit").style.visibility='hidden';

}
</script>
<!--validation-->

<!--disable r click-->
<script type="text/javascript">
$(document).ready(function(){
$(document).bind("contextmenu",function(e){
return false;
});
});
</script>
<!--disable r click-->

<!---footer-->
<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
      <!--  <td><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/back.png" alt=""></a></td>
        <td align="center"><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/home.png" alt=""></a></td>
        <td align="right"><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/my_order.png" alt=""></a></td>-->
      </tr>
    </table>
  </div>
   <div class="clear"></div>
</footer>
<script type="text/javascript">

var slider1=new accordion.slider("slider1");
slider1.init("slider");


</script>

</body>
</html>
