<?php
 if($subtype)
{

foreach($subtype as $sub)
{ ?>
<option value="<?php echo $sub['eventstb_id'];?>"><?php echo ucwords($sub['eventstb_name']);?></option>

<?php }  }
else
{ ?> <option value="">No Subcategory</option> <?php }  ?>
