<?php

//echo $company_id;
//print_r($event_pots_pans);
//header("Content-type: application/vnd.ms-word");
//header("Content-Disposition: attachment;Filename=saf.doc");

//print_r($menu_types);


foreach($customer as $cust)
{
$cust_name=$cust['customername'];
$customeraddress=$cust['customeraddress'];
$customeremail=$cust['customeremail'];
$customerphone=$cust['customerphone'];
$customermobile1=$cust['customermobile1'];
$customermobile2=$cust['customermobile2'];
$event_contactnum=$cust['event_contactnum'];
}





$var='<html><meta http-equiv=\"Content-Type\" content=\"text/html; charset=Windows-1252\">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Iqbal Catering</title>
<link rel="stylesheet" type="text/css" href="'.CSSPATH.'invoice/style.css" />
</head>
<body>
<div id="wrapper">
	<div class="inner_container">
    	<div class="header">
        	<div class="logo_container">
            <img src="'.CSSPATH.'invoice/images/logo.png" alt="logo" />
            </div>
            <div class="contact_container">
            	<ul>
                	<li class="icon1">+90 ( 535 ) 386 33 33</li>
                	
                    <li class="icon2">info@workshoping.com</li>
                    <li class="icon3">+90 ( 535 ) 386 46 45</li>
                    <li class="icon4">www.workshoping.com</li>
                    <li class="icon5">Piriçelebi Mah. Pirireis Cad.No.8/A RIZE</li>
                </ul>
            </div>
            <div class="invoice_container">
            	<h1>INVOICE</h1>
                <ul>
                	<li class="icon6">'.$inv_name.'</li>
                    <li class="icon7">29-AGU-2013</li>
                    <li class="icon8">09:30 AM</li>
                </ul>
            </div>
        </div>
        <div class="invoiceTo_container">
        	<h1>INVOICE TO</h1>
            <h2>'.$cust_name.'</h2>
            ';
            
            if($customeraddress){
            	$var=$var.'<ul><li class="icon5">'.$customeraddress.'</li></ul>';
            	}
           $var=$var.'
            <ul>';
            if($customerphone){
            
            	$var=$var.'<li class="icon1">'.$customerphone.'</li>';
            	
            	}
            	
            	if($event_contactnum){
            	
               $var=$var.'<li class="icon3">'.$event_contactnum.'</li>';
               }
           $var=$var.'</ul>
            <ul>';
            
            	
            	if($customeremail){                	
                  $var=$var.'<li class="icon2">'.$customeremail.'</li>';
                  }
            	
            	
            	
            	
$var=$var.'<!--<li class="icon4">www.yourcompany.com</li>-->
            </ul>
        </div>
        <h1>MENU LIST</h1>';

 if($menu_types){ foreach($menu_types as $type_menu){ 
 $i=1;
 $menu_id=$type_menu['menutypeid']; $menu_name=$type_menu['menutypename'];  


    $var=$var.'<h4>'.$menu_name.'</h4>
        <div class="table_container">
        	<table class="table">
            	
            </table>
        	<table class="table" cellspacing="5">
            	<tr style="background:#2ADC97;">
            		<th>SL NO.</th>
                    <th width="380px">ITEM NAME</th>
                    <th>UNIT PRICE</th>
                    <th>QUANTITY</th>
                    <th>TOTAL PRICE</th>
                </tr>';


//print_r($selected_items);
foreach($selected_items as $seltd_it)
{ $edit_menu_type_id=$seltd_it['menutype'];


if($menu_id==$edit_menu_type_id){
$itemnamme=$seltd_it['itemname'];
$edit_item_id=$seltd_it['itemid'];



$item_nos_edit=$seltd_it['item_nos'];
$itemunits_edit=$seltd_it['itemunits'];
$text_f='textfield_'.$edit_item_id;




$itemprice_edit=$seltd_it['itemprice'];
$itemprice_edit=number_format((float)$itemprice_edit, 2, '.', '');

$item_subprice_edit=$seltd_it['item_subprice'];
$item_subprice_edit=number_format((float)$item_subprice_edit, 2, '.', '');





             $var=$var.  '<tr>
                	<td>'.$i++.'</td>
                    <td width="380px">'.$itemnamme.'</td>
                    <td>'.$currency.$itemprice_edit.'</td>
                    <td>'.$item_nos_edit.' '.$itemunits_edit.'</td>
                    <td>'.$currency.$item_subprice_edit.'</td>
                </tr>';
                
                }
                
          
            



} $var=$var.  '</table>
        </div>'; } $var=$var.'<div class="termsCondition_container">
        
        
        
        </div>'; }

        
   $var=$var.'<!--termsCondition_container-->
        
        <div class="total_container">
        	<table class="table" cellspacing="5">
            	<tr>
                	<td>Menu Price</td>
                    <td>'.$currency.$menu_price.'</td>
                </tr>
            </table>
        </div><!--total_container-->
        
        
        
        
        
        <h1>POTS AND PANS</h1>
       <br />

        
         <div class="table_container">
        	<table class="table">
            	
            </table>
        	<table class="table" cellspacing="5">
        	
        	<tr style="background:#2ADC97;">
            		<th>SL NO.</th>
                    <th width="300px">POTS NAME</th>
                    <th>QUANTITY</th>
                     <th>RENT</th>
                    <th>DEPOSIT</th>
                    <th>TOTAL PRICE</th>
                </tr>';
               
        	
        	
        	
        	
        	$j=1;
        	
        	foreach($event_pots_pans as $e_pots_pans) { 

$e_pots_name=$e_pots_pans['pp_name']; 
$e_pots_id=$e_pots_pans['pp_id']; 
$e_pot_value=$e_pots_pans['event_pp_nos']; 
$e_pot_rent=$e_pots_pans['pot_rent']; 
$e_pot_deposit=$e_pots_pans['pot_deposit'];
$e_pot_total=$e_pots_pans['pot_totalprice'];    
$e_pp_name=$e_pots_pans['pp_name']; 



        	$e_pot_rent=number_format((float)$e_pot_rent, 2, '.', '');
        	$e_pot_deposit=number_format((float)$e_pot_deposit, 2, '.', '');
        	$e_pot_total=number_format((float)$e_pot_total, 2, '.', '');
   
            $var=$var.'<tr>
            		 <td>'.$j++.'</td>
                           <td width="300px">'.$e_pots_name.'</td>
                   <td>'.$e_pot_value.'</td>
                       <td>'.$currency.$e_pot_rent.'</td>
                     <td>'.$currency.$e_pot_deposit.'</td>
                     <td>'.$currency.$e_pot_total.'</td>
                </tr>';
               
                }
                $grand_total_price=$menu_price+$e_pot_total_price;
                $grand_total_price=number_format((float)$grand_total_price, 2, '.', '');
          
        $var=$var.'</table>
        </div><!--table_container-->
        
        <div class="termsCondition_container">
        
        
        
        </div><!--termsCondition_container-->
        
        <div class="total_container">
        	<table class="table" cellspacing="5">
            	<tr>
                	<td> Pots and Pans Rent</td>
                    <td>'.$currency.$e_pot_total_price.'</td>
                </tr>
            </table>
        </div><!--total_container-->
          <div class="border_top"></div>
        <div class="termsCondition_container">
        <h2>Terms And Conditions</h2>
        <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>
        <table class="table">
        	<tr>
        		<td>Your Bank</td>
                <td>:Here goes bank name</td>
            </tr>
            <tr>
        		<td>Swift</td>
                <td>:APCHH838412</td>
            </tr>
            <tr>
        		<td>IBAN</td>
                <td>:tr0002223332122449944</td>
            </tr>
            <tr>
        		<td>Account ID</td>
                <td>:193-11241232412-22</td>
            </tr>
        </table>
        </div><!--termsCondition_container-->
      
        <div class="total_container">
        	<table class="table" cellspacing="5">
            	
                <tr>
                	<td style="background:#2ADC97;">Menu Price</td>
                    <td style="background:#2ADC97;">'.$currency.$menu_price.'</td>
                </tr>
                
                <tr>
                	<td style="background:#2ADC97">Pots and Pans Rent</td>
                    <td style="background:#2ADC97;">'.$currency.$e_pot_total_price.'</td>
                </tr>
                <tr>
                	<td style="background:#2ADC97;"><b>Grand Total</b></td>
                    <td style="background:#2ADC97;"><b>'.$currency.$grand_total_price.'</b></td>
                </tr>
            </table>
        </div><!--total_container-->
        <h3 style="background:#2ADC97;">THANK YOU FOR YOUR BUSINESS</h3>
    </div><!--inner_container-->
</div><!--wrapper-->
</body>
</html>';
echo $var;
?>