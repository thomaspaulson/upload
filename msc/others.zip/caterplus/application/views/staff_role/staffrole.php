<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">

 

  <div class="menu-addlist">
<div class="col-md-3 col-sm-3">
 <div class="listing_title"> <span class="listing_title_capital">ADD STAFF ROLE</span> </div>
</div>
 <form class="search-1" method="post" action="<?php echo base_url();?>staff_role/insert_role/"  id="add-items" name="add-items">

<div class="col-md-3 col-sm-3">
<section class="main">
	 
			 <input type="text" name="role_name" id="cname"  placeholder="Role Name" class="validate[required,custom[onlyLetterSp]]" />
	 </section>

</div>  
<div class="col-md-3 col-sm-3">
<section class="main">
	 <span class="search-1">
	 <input type="text" name="role_description" id="cprice"  placeholder="Description" />
	 </span>
	 
</section>

</div>



<div class="col-md-3 col-sm-3">
<section class="main">
     <span class="search">
	 <input class="button" id="search-item-add" type="submit" name="subscribe" value="Add" />
	 </span>
	 
</section>

</div>
</form>
</div>
<div class="clear"></div>
 <!----> 

 <div class="col-md-3 col-sm-3">
 <div class="listing_title"><span class="listing_title_capital"><img src="<?php echo base_url();?>extras/extra/images/staff-role-list.png"/></span> </div>
</div>

<!--<div class="col-md-3 col-sm-3">
<section class="main">
	 <form class="search-item" method="post" action="" >
		 <input type="text" name="q" placeholder="Search..." />
		 <ul class="results" >
			 <li><a href="">Search Result #1<br /><span>Description...</span></a></li>
			 <li><a href="">Search Result #2<br /><span>Description...</span></a></li>
	 		<li><a href="">Search Result #3<br /><span>Description...</span></a></li>
         	<li><a href="">Search Result #4</a></li>
		 </ul>
	 </form>
</section>

</div>-->
 
 <!---->
    
  
    
   <div class="list_line"></div> 
   
   <div class="list_table-1">
	<div class="list_title">
    <div class="listall-image">Role Name</div>
    <div class="listall-itemname">DESCRIPTION</div>
    <div class="listall-item-action">ACTIONS	</div>
    
    </div>
<div class="list_table_result_frame">
	 <?php foreach($role_data as $row){?>
<div class="list_table_result_row1">
<div class="listall-image" style="border-bottom:solid 1px #dedbdb;"><?php echo $row['rolename']; ?></div>
<div class="listall-itemname"><?php echo $row['roledescription']; ?></div>
<div  class="listall-item-action">
<div class="listall-item-action-edit"><a href="<?php echo base_url();?>staff_role/edit_role/<?php echo $row['roleslug'];?>">Edit</a></div>
<div class="listall-item-action-deactivate"><a onclick="return window.confirm('Do you really want to delete this Staff Role?')" href="<?php echo base_url();?>staff_role/deactive_rolestatus/<?php echo $row['roleslug'];?>"> <?php if($row['rolestatus']=="active")
                        echo "deactive";
                      else
                        echo "active";?></a></div>
</div>
</div>
<?php } ?>


</div>


</div>