<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">
<div class="col-md-3 col-sm-3">
 <div class="listing_title"> EDIT STAFF ROLE</div>
</div>


<div class="col-md-3 col-sm-3" id="listback" style="float:right;">

     <div class="listing_title"> <a href="<?php echo base_url();?>staff_role">Back To List </a></div>
    </div>  
    

    
   <div class="list_line"></div> 


<div class="list_table1">

<div class="listtable-white">
<?php
foreach($role_data as $row){
?>
<form class="validate" id="add-items" action="<?php echo base_url();?>staff_role/save_role/" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">

<div class="mc-field-group"><label for="mce-LNAME">Role Name: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="role_name" class="required validate[required,custom[onlyLetterSp]]" id="required-1" value="<?php echo $row['rolename'];?>"/>
</div>

<div class="mc-field-group"><label for="mce-EMAIL">Description: <span class="asterisk">*</span><br />
</label><br />
 <textarea name="role_description" id="txtenq" cols="" rows="" class="area"><?php echo $row['roledescription'];?></textarea></div>



<div class="clear" id="mce-responses"></div>
<div class="clear"><input type="hidden" id="roleslug" name="roleslug" value="<?php echo $row['roleslug'];?>"/><input class="button" id="mc-embedded-subscribe" type="submit" name="subscribe" value="Submit" /></div>


</form>
<?php } ?>
</div>
 </div>