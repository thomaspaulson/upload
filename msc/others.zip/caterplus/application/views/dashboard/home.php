<!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?= base_url();?>newassets/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="<?= base_url();?>newassets/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url();?>newassets/dist/css/AdminLTE.min.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?= base_url();?>newassets/dist/css/skins/_all-skins.min.css">
<br /><br />
<!-- Main content -->
<section class="container">
<div class="row">

    <!-- fix for small devices only -->
    <div class="clearfix visible-sm-block"></div>

    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-aqua"><i class="ion ion-ios-cart-outline"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Total Order</span>
          <span class="info-box-number"><?= $totalorders;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-green"><i class="glyphicon glyphicon-saved"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Collected Orders</span>
          <span class="info-box-number"><?= $collectedorders;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-red"><i class="glyphicon glyphicon-tags"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Pending Orders</span>
          <span class="info-box-number"><?= $pendingorders;?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
</div>
<div class="row">
    <!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-yellow"><i class="fa fa-credit-card"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Advance Payment</span>
          <span class="info-box-number"><?= number_format($advancepayment,2);?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-yellow"><i class="fa fa-database"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Pending Payment</span>
          <span class="info-box-number"><?= number_format($pendingpayment,2);?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
    <div class="col-md-3 col-sm-6 col-xs-12">
      <div class="info-box">
        <span class="info-box-icon bg-yellow"><i class="fa fa-money"></i></span>

        <div class="info-box-content">
          <span class="info-box-text">Total Payment</span>
          <span class="info-box-number"><?= number_format($totalpayment,2);?></span>
        </div>
        <!-- /.info-box-content -->
      </div>
      <!-- /.info-box -->
    </div>
    <!-- /.col -->
  </div>
  <div class="row">
    <div class="col-md-6">
        <!-- BAR CHART -->
        <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Bar Chart <strong class="text-success">[Item Vs Quantity(Total Ordered, Delivered and Pending)]</strong></h3>
        
          <div class="box-tools pull-right"></div>
        </div>
        <div class="box-body">
          <div class="chart">
            <canvas id="barChart" style="height:230px"></canvas>
          </div>
        </div>
        <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
    <div class="col-md-6">
        <!-- BAR CHART -->
        <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Bar Chart <strong class="text-success">[Item Vs Quantity(Total Ordered, Delivered and Pending)]</strong></h3>
        
          <div class="box-tools pull-right"></div>
        </div>
        <div class="box-body">
          <div class="chart">
            <canvas id="barChart2" style="height:230px"></canvas>
          </div>
        </div>
        <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
<div class="row">
    <div class="col-md-6">
    <div class="col-md-12">
        <!-- BAR CHART -->
        <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title">Bar Chart <strong class="text-success">[Item Vs Quantity(Total Ordered, Delivered and Pending)]</strong></h3>
        
          <div class="box-tools pull-right"></div>
        </div>
        <div class="box-body">
          <div class="chart">
            <canvas id="barChart3" style="height:230px"></canvas>
          </div>
        </div>
        <!-- /.box-body -->
        </div>
        <!-- /.box -->
    </div>
        <div class="col-md-12">
        <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title"><strong class="text-success">Order Summary</strong></h3>
        </div>
        <div class="box-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Menu Type</th>
                        <th>Ordered Quantity</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                foreach($rawstock1 as $idata){
                    echo "<tr>";
                    echo "<td>".strtoupper($idata->menutypename)."</td>";
                    echo "<td>".$idata->Qty."</td>";
                    echo "</tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>
    </div>
    <div class="col-md-6">
        <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title"><strong class="text-success">Order Summary</strong></h3>
        </div>
        <div class="box-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th class="text-right">Ordered Quantity</th>
                        <th class="text-right">Rate</th>
                        <th class="text-right">Amount</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $totamount=0;
                foreach($rawstock as $idata){
                    echo "<tr>";
                    echo "<td>".strtoupper($idata->itemname)."</td>";
                    echo "<td class='text-right'>".$idata->Qty." ".$idata->itemunits."</td>";
                    echo "<td class='text-right'>".number_format($idata->base_price_of_item,2)."</td>";
                    echo "<td class='text-right'>".number_format($idata->amount,2)."</td>";
                    echo "</tr>";
                    $totamount=$totamount+$idata->amount;
                }
                $tamount=$totamount+$containeramount;
                ?>
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4">Sub Totals</td>
                        <td class="text-right"><?= number_format($totamount,2); ?></td>
                    </tr>
                    <tr>
                        <td colspan="4">Total Container Amount</td>
                        <td class="text-right"><?= number_format($containeramount,2); ?></td>
                    </tr>
                    <tr>
                        <td colspan="4">Total Amount</td>
                        <td class="text-right"><?= number_format($tamount,2); ?></td>
                    </tr>
                </tfoot>
            </table>
        </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="box box-success">
        <div class="box-header with-border">
          <h3 class="box-title"><strong class="text-success">Order Summary</strong></h3>
        </div>
        <div class="box-body">
            <table class="table">
                <thead>
                    <tr>
                        <th>Item Name</th>
                        <th class="text-right">Ordered Quantity</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $totamount=0;
                foreach($rawstock as $idata){
                    echo "<tr>";
                    echo "<td>".strtoupper($idata->itemname)."</td>";
                    echo "<td class='text-right'>".$idata->Qty." ".$idata->itemunits."</td>";
                    echo "</tr>";
                }
                ?>
                </tbody>
            </table>
        </div>
        </div>
    </div>
</div>
    
    
    
  </div>
  <!-- /.row -->
</section>
<!-- jQuery 2.2.3 -->
<script src="<?= base_url();?>newassets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?= base_url();?>newassets/bootstrap/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?= base_url();?>newassets/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?= base_url();?>newassets/dist/js/app.min.js"></script>
<!-- Sparkline -->
<script src="<?= base_url();?>newassets/plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="<?= base_url();?>newassets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?= base_url();?>newassets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?= base_url();?>newassets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- ChartJS 1.0.1 -->
<script src="<?= base_url();?>newassets/plugins/chartjs/Chart.min.js"></script>
<script>
  $(function () {
    /* ChartJS
     * -------
     * Here we will create a few charts using ChartJS
     */

    //-------------
    //- BAR CHART -
    //-------------
    var barChartCanvas = $("#barChart").get(0).getContext("2d");
    var barChart = new Chart(barChartCanvas);
    var barChartData = {
      labels: [<?= $items?>],
      datasets: [
        {
          label: "Ordered",
          fillColor: "rgba(210, 214, 222, 1)",
          strokeColor: "rgba(210, 214, 222, 1)",
          pointColor: "rgba(210, 214, 222, 1)",
          pointStrokeColor: "#c1c7d1",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(220,220,220,1)",
          data: [<?= $totalordered?>]
        },
        {
          label: "Delivered",
          fillColor: "rgba(210, 214, 222, 1)",
          strokeColor: "rgba(210, 214, 222, 1)",
          pointColor: "rgba(210, 214, 222, 1)",
          pointStrokeColor: "#c1c7d1",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(220,220,220,1)",
          data: [<?= $delivered;?>]
        },
        {
          label: "Pending",
          fillColor: "rgba(60,141,188,0.9)",
          strokeColor: "rgba(60,141,188,0.8)",
          pointColor: "#3b8bba",
          pointStrokeColor: "rgba(60,141,188,1)",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(60,141,188,1)",
          data: [<?= $pending;?>]
        }
      ]
    };
    barChartData.datasets[1].fillColor = "#00a65a";
    barChartData.datasets[1].strokeColor = "#00a65a";
    barChartData.datasets[1].pointColor = "#00a65a";
    var barChartOptions = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero: true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines: true,
      //String - Colour of the grid lines
      scaleGridLineColor: "rgba(0,0,0,.05)",
      //Number - Width of the grid lines
      scaleGridLineWidth: 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines: true,
      //Boolean - If there is a stroke on each bar
      barShowStroke: true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth: 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing: 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing: 1,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
      //Boolean - whether to make the chart responsive
      responsive: true,
      maintainAspectRatio: true
    };

    barChartOptions.datasetFill = false;
    barChart.Bar(barChartData, barChartOptions);
    //chart 2
    var barChartCanvas2 = $("#barChart2").get(0).getContext("2d");
    var barChart2 = new Chart(barChartCanvas2);
    var barChartData2 = {
      labels: [<?= $items2?>],
      datasets: [
        {
          label: "Ordered",
          fillColor: "rgba(210, 214, 222, 1)",
          strokeColor: "rgba(210, 214, 222, 1)",
          pointColor: "rgba(210, 214, 222, 1)",
          pointStrokeColor: "#c1c7d1",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(220,220,220,1)",
          data: [<?= $totalordered2?>]
        },
        {
          label: "Delivered",
          fillColor: "rgba(210, 214, 222, 1)",
          strokeColor: "rgba(210, 214, 222, 1)",
          pointColor: "rgba(210, 214, 222, 1)",
          pointStrokeColor: "#c1c7d1",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(220,220,220,1)",
          data: [<?= $delivered2;?>]
        },
        {
          label: "Pending",
          fillColor: "rgba(60,141,188,0.9)",
          strokeColor: "rgba(60,141,188,0.8)",
          pointColor: "#3b8bba",
          pointStrokeColor: "rgba(60,141,188,1)",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(60,141,188,1)",
          data: [<?= $pending2;?>]
        }
      ]
    };
    barChartData2.datasets[1].fillColor = "#00a65a";
    barChartData2.datasets[1].strokeColor = "#00a65a";
    barChartData2.datasets[1].pointColor = "#00a65a";
    var barChartOptions2 = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero: true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines: true,
      //String - Colour of the grid lines
      scaleGridLineColor: "rgba(0,0,0,.05)",
      //Number - Width of the grid lines
      scaleGridLineWidth: 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines: true,
      //Boolean - If there is a stroke on each bar
      barShowStroke: true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth: 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing: 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing: 1,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
      //Boolean - whether to make the chart responsive
      responsive: true,
      maintainAspectRatio: true
    };
    barChartOptions2.datasetFill = false;
    barChart2.Bar(barChartData2, barChartOptions2);
    
    //chart 3
    var barChartCanvas3 = $("#barChart3").get(0).getContext("2d");
    var barChart3 = new Chart(barChartCanvas3);
    var barChartData3 = {
      labels: [<?= $items3?>],
      datasets: [
        {
          label: "Ordered",
          fillColor: "rgba(210, 214, 222, 1)",
          strokeColor: "rgba(210, 214, 222, 1)",
          pointColor: "rgba(210, 214, 222, 1)",
          pointStrokeColor: "#c1c7d1",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(220,220,220,1)",
          data: [<?= $totalordered3?>]
        },
        {
          label: "Delivered",
          fillColor: "rgba(210, 214, 222, 1)",
          strokeColor: "rgba(210, 214, 222, 1)",
          pointColor: "rgba(210, 214, 222, 1)",
          pointStrokeColor: "#c1c7d1",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(220,220,220,1)",
          data: [<?= $delivered3;?>]
        },
        {
          label: "Pending",
          fillColor: "rgba(60,141,188,0.9)",
          strokeColor: "rgba(60,141,188,0.8)",
          pointColor: "#3b8bba",
          pointStrokeColor: "rgba(60,141,188,1)",
          pointHighlightFill: "#fff",
          pointHighlightStroke: "rgba(60,141,188,1)",
          data: [<?= $pending3;?>]
        }
      ]
    };
    barChartData3.datasets[1].fillColor = "#00a65a";
    barChartData3.datasets[1].strokeColor = "#00a65a";
    barChartData3.datasets[1].pointColor = "#00a65a";
    var barChartOptions3 = {
      //Boolean - Whether the scale should start at zero, or an order of magnitude down from the lowest value
      scaleBeginAtZero: true,
      //Boolean - Whether grid lines are shown across the chart
      scaleShowGridLines: true,
      //String - Colour of the grid lines
      scaleGridLineColor: "rgba(0,0,0,.05)",
      //Number - Width of the grid lines
      scaleGridLineWidth: 1,
      //Boolean - Whether to show horizontal lines (except X axis)
      scaleShowHorizontalLines: true,
      //Boolean - Whether to show vertical lines (except Y axis)
      scaleShowVerticalLines: true,
      //Boolean - If there is a stroke on each bar
      barShowStroke: true,
      //Number - Pixel width of the bar stroke
      barStrokeWidth: 2,
      //Number - Spacing between each of the X value sets
      barValueSpacing: 5,
      //Number - Spacing between data sets within X values
      barDatasetSpacing: 1,
      //String - A legend template
      legendTemplate: "<ul class=\"<%=name.toLowerCase()%>-legend\"><% for (var i=0; i<datasets.length; i++){%><li><span style=\"background-color:<%=datasets[i].fillColor%>\"></span><%if(datasets[i].label){%><%=datasets[i].label%><%}%></li><%}%></ul>",
      //Boolean - whether to make the chart responsive
      responsive: true,
      maintainAspectRatio: true
    };
    barChartOptions3.datasetFill = false;
    barChart3.Bar(barChartData3, barChartOptions3);
  });
</script>
</body>
</html>