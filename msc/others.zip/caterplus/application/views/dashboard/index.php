<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>




<table border="1">
       <tr>
       <td>Item Name</td>
	   <td>Quantity</td>
	   <td>Item Units</td>
       </tr> 
<?php  if ($rawstock) {
		foreach ($rawstock as $stock) {	
		?>
		<tr>
		<td><?php echo $stock['itemname']?></td>
		<td><?php echo $stock['Qty']?></td>
		<td><?php echo $stock['itemunits']; ?></td>
		</tr>
		<?php }}
		?>
</table>



</body>
</html>