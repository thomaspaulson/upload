<div class="block">
			
				<div class="block_head">
					<div class="bheadl"></div>

					<div class="bheadr"></div>
					
					<h2>Accompaniments</h2>
					
					
				</div>		<!-- .block_head ends -->
				
				
				
				<div class="block_content">
				
			<form id="addForm" action="<?php echo base_url();?>accompaniments/insert" method="post" name="addForm" >

						<p><label>Name:</label><br>
							<input type="text"  name="accompanimentsname" id="accompanimentsname"/> <br>
					</p>
						
					
					
				

	
						
				<!-- .block_content ends -->

				
				<p>
				<input type="submit" class="submit small" value="Submit" />
							
						</p>
				
					</form>
					
					
				</div>		<!-- .block_content ends -->
				
				<div class="bendl"></div>
				<div class="bendr"></div>
					
			</div>		<!-- .block ends -->
	