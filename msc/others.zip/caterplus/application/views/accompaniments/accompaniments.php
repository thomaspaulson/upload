<div class="block">
			
				<div class="block_head">
					<div class="bheadl"></div>
					<div class="bheadr"></div>
					
					<h2>Accompanimentslist</h2>
					
					<ul>
						
						<li><a href="<?=base_url()?>accompaniments/addform">Add Accompaniments</a></li>

					</ul>
				</div>		<!-- .block_head ends -->
				
				
				
				<div class="block_content">
					
					<?php if($msg!=''): ?>
						<div class="message success">
						<p>
						<?php if($msg=="added"){ echo "Accompaniments added successfully";} ?>
						<?php if($msg=="edited"){ echo "Accompaniments updated successfully";} ?>
						<?php if($msg=='changestatus'){echo "Accompaniments status updated successfully"; } ?>
						<?php if($msg=="deleted"){ echo "Accompaniments deleted successfully";} ?>
						</p></div>
					<?php endif; ?>	 
											
					<form action="" method="post" >
					
						<table cellpadding="0" cellspacing="0" width="100%" id="table-1">
						
							<tr>
								
								<th>Name</th>
								
								
								
						 	<th>Actions</th> 
						 	
							</tr>
							
						
							<?php foreach($contents as $value):?>
							<tr> <tr  id="<?=$value['accompanimentsid']?>" > 
								
								<td> <a href="<?=base_url();?>accompaniments/updateform/<?php echo $value['accompanimentsid']?>" title="Edit"><?php echo $value['accompanimentsname']?></a></td>
							
                     
								   <td class=""> <a href="<?php echo base_url();?>accompaniments/updateform/<?php echo $value['accompanimentsid']?>" title="Edit">
	<!--<img src="<?=base_url()?>/resources/images/pencil.png" alt="edit" />--> EDIT</a>&nbsp;&nbsp;


	<a  onclick="return window.confirm('Do you really want to delete this Accompaniments?')" href="<?php echo base_url();?>accompaniments/delete/<?php echo $value['accompanimentsid']?>"><!--<img src="<?=base_url()?>/resources/admin/images/error.gif" alt="delete" />-->DELETE</a>&nbsp;&nbsp;


	
        </td>
                       <td></td>
							</tr>
							</tr>
						<?php endforeach; ?>		
							
						</table>
						
						
						
					</form>
					
				</div>		<!-- .block_content ends -->
				
				<div class="bendl"></div>
				<div class="bendr"></div>
			</div>		<!-- .block ends -->
			
			
			
			
			
			
			
			
			
			
			
	