  
  <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>PACKAGES</h1>
    </div>
    <div class="event_list_main">
      
      <div class="master-left">
       <form class="validate" id="add-items" action="<?php echo base_url()?>admin/settings/create_package" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
          <!---->
          
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Package Name:: *</div>
            <div class="master-select">
             <input name="pkg_name" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="pkg_name">
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Quantity: </div>
            <div class="master-select">
             <input name="pkg_qty" id="pkg_qty" type="text" class="master-textfeild">
              
            </div>
          </div>
         
       
          
          <input class="master-submit" type="submit" name="add_ingr" value="" /> 
        </form>
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->