<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Event-List</title>
<link href="<?php echo CSSPATH;?>css/style.css" rel="stylesheet" type="text/css">
<link href="<?php echo CSSPATH;?>css/flexy-menu.css" rel="stylesheet" type="text/css">

<script src="<?php echo CSSPATH;?>js/html5.js"></script>
<script src="<?php echo CSSPATH;?>js/jquery-1.10.2.js"></script>
<script src="<?php echo CSSPATH;?>js/jquery.min.js"></script>

<script type="text/javascript" src="<?php echo CSSPATH;?>js/script.js"></script>

<script type="text/javascript" src="<?php echo CSSPATH;?>js/flexy-menu.js">
</script><script type="text/javascript">$(document).ready(function(){$(".flexy-menu").flexymenu({speed: 400,type: "vertical", indicator: true});});</script>
<script type="text/javascript" src="<?php echo CSSPATH;?>js/jscolor.js"></script>

<!--====== selection =====-->

<script type="text/javascript">
    $(document).ready(function(){
        $(".custom-select").each(function(){
            $(this).wrap("<span class='select-wrapper'></span>");
            $(this).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function(){
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        }).trigger('change');
    })
</script>

<!--====== selection end =====-->



</head>
<?php // print_r($get_eventtype); ?>
<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="<?php echo base_url()?>"><img src="<?php echo CSSPATH;?>images/logo.png" alt=""></a></div>
    <div class="header_right"> <a href="" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/dairy.png" alt="">
      <h6>Dairy</h6>
      </a> 
      <!----> 
      <a href="" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/kitchen.png" alt="">
      <h6>Kitchen</h6>
      </a> 
      
      <!----> 
      <a href="" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/item.png" alt="">
      <h6>Items</h6>
      </a> 
      
      <!----> 
      <a href="" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/payment.png" alt="">
      <h6>Payment</h6>
      </a> 
      
      <!----> 
      <a href="" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/settings.png" alt="">
      <h6>Settings</h6>
      </a> 
      <!----> 
      <!----> 
      <a href="" class="top-menuicons"><img src="<?php echo CSSPATH;?>images/more.png" alt="">
      <h6>More </h6>
      </a> 
      <!----> 
      <!--==== user name =====--> 
      <a href="<?php echo base_url()?>admin/editprofile/edit">
      <div class="user_box">
        <div class="user">
          <div class="icon"> </div>
          <div class="user_name">
<?php $comp_name= $this->session->userdata('comp_name'); $branch_name=$this->session->userdata('branch_name'); ?>
            <p><?php echo $comp_name;?></p>
            <p><?php echo $branch_name;?></p>
          </div>
          <h6>Admin</h6>
        </div>
      </div>
      </a> 
      <!--==== user name end =====--> 
      <a href="<?php echo base_url()?>logout" class="logout"><img src="<?php echo base_url()?>extras/product/images/logout.png" alt="">
      <h6>Logout</h6>
      </a> </div>
  </div>
</header>
<!--========= content ===============-->
<div class="wrapper"> 
<!--menu-->
<div class="event_list_left">

<div class="content">
  <ul class="flexy-menu orange">
  <li><a href="<?php echo base_url();?>admin/admin_dashboard/index"><i class="icon-heart"><img src="<?php echo CSSPATH;?>images/event.png"></i>Event Type</a></li>
 <!--   <li><a href="JavaScript:void(0)"><i class="icon-th"><img src="<?php echo CSSPATH;?>images/menu.png"></i>Menu Set Up</a>
      <ul>
        <li><a href="<?php echo base_url()?>admin/settings/list_item">Item Set Up</a></li> 
        <li><a href="<?php echo base_url();?>admin/settings/list_container">Container set up</a></li>
        <li><a href="<?php echo base_url();?>admin/settings/list_packages">Package Set up</a></li>
        <li><a href="<?php echo base_url()?>admin/settings/list_ingredients">Ingredient</a>
         <li><a href="<?php echo base_url()?>admin/settings/list_menutypes">Menu Types</a> </li>
       
      </ul>
    </li> -->
    <li><a href="JavaScript:void(0)"><i class="icon-th"><img src="<?php echo CSSPATH;?>images/even-staff.png"></i>Staff</a>
      <ul>
        <!--<li><a href="<?php echo base_url()?>admin/settings/add_staff">Staffs</a></li>   -->
        <li><a href="<?php echo base_url()?>admin/settings/list_staffrole">Staff Roles</a></li>
        

      </ul>
    </li>
    <li><a href="JavaScript:void(0)"><i class="icon-comments"><img src="<?php echo CSSPATH;?>images/even-staff.png"></i>Supplier</a>
    <ul>
        <li><a href="JavaScript:void(0)">List</a></li>

      </ul>
    </li>
    
    <li><a href="JavaScript:void(0)"><i class="icon-group"><img src="<?php echo CSSPATH;?>images/general.png"></i>General</a>
     <ul>
     <li><a href="JavaScript:void(0)"><i class="icon-picture"></i>Invoices</a></li>
    <li><a href="JavaScript:void(0)"><i class="icon-copy"></i>Emails</a></li>
    

      </ul>
    </li>
 <li><a href="<?php echo base_url();?>admin/settings/list_pots_pans"><i class="icon-heart"><img src="<?php echo CSSPATH;?>images/event.png"></i>Pots and Pans</a></li>
  </ul>
</div>
</div>