<?php $ran= $this->ran_string; //print_r($container); ?>  
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Container</h1>
    </div>
    <div class="event_list_main">
      <div class="dashbord_itemlist">
        <h1><a href="<?php echo base_url()?>admin/settings/add_container">Add New</a></h1>


        <div class="row_color1">
          <ul>
            <li class="dash_cutomer_name">Container</li>
            <li class="dash_cutomer">price</li>
                     <li class="dash_cutomer_name">Action</li>
          </ul>
        </div>
       
<?php $i=1;if($container)
{ foreach($container as $cont)
{ $id=$cont['pdt_conid']; if($i%2==0){ $i=2;} else { $i=3; } ?>
        
        
        <div class="row_color<?php echo $i; ?>">
          <ul>
            <li class="dash_cutomer_name"><?php echo $cont['pdt_con_name']; ?></li>
           
            <li class="dash_cutomer"><?php echo $cont['pdt_con_price']; ?></li>
           <a href="#"> <li class="row_color2_edit"><img src="<?php echo CSSPATH;?>images/pencil.png">Edit</li></a>
           <a href="<?php echo base_url()?>admin/settings/remove_container/<?php echo $ran.'/'.$id; ?>"><li class="row_color4_edit"><img src="<?php echo CSSPATH;?>images/remove.png" class="list_img"><p>Remove</p></li></a>
          </ul>
        </div>
        
<?php    $i=$i+1;  }} ?>

      </div>
      
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->