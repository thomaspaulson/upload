  <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Item Set Up</h1>
    </div>
    <div class="event_list_main">
      
      <div class="master-left">
       <form class="validate" id="add-items"  action="<?php echo base_url();?>items/insert" method="post" name="addForm" enctype="multipart/form-data">
          <!---->
          <div class="master-left-1">
            <div class="master-name">Select Category: *</div>
            <div class="master-select">
              <select name="menutype[]" >
<option value="">select</option>
	<?php  
		foreach($category as $row){ 
	?>								
			<option value="<?php echo $row['com_tmenu_id'] ;?>"><?php echo $row['com_tmenu_name']; ?></option>																	
	<?php 
		} 
	?>
</select>
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Item Name: *</div>
            <div class="master-select">
              <input name="name" type="text" class="master-textfeild">
              
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Cooking Instructions: *</div>
            <div class="master-select">
              <input name="name" type="text" class="master-textfeild">
            </div>
          </div>
          <!---->
          <div class="master-left-1">
            <div class="master-name">Item Units: *</div>
            <div class="master-select">
              <select>
                <option>--Select Units--</option>
              </select>
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Item Price: *</div>
            <div class="master-select">
              <input name="name" type="text" class="master-textfeild">
            </div>
          </div>
          
         
          <div class="master-left-1">
            <div class="master-name">Ingredients: *</div>
            <div class="master-select">            
              <select id="inglist">
                <option>--Select Ingredients--</option>
                <option>--Chicken--</option>
                <option>--Mutton--</option>
                <option>--Beef--</option>
              </select>
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-ingmore" id="ingmain">
              <div class="master-ingmore-1" id="inglist1">
                <div class="master-ingmore-name" id="ingitem1">Chicken</div>
                <div class="master-ingmoreselect">
                  <select >
                    <option>--Select Unit--</option>
                    <option>--Kg--</option>
                    <option>--g--</option>
                    <option>--Lb--</option>
                  </select>
                </div>
                <div class="master-select">
                  <input name="name" type="text" class="master-ingmoretextfeild">
                </div>
                <div class="master-closebutton"><a><img src="<?php echo CSSPATH;?>images/close-button.png" id="ingclose" onClick="removeing('inglist1','ingitem1')"></a></div>
              </div>
            </div>
          </div>
          <!---->
          <div class="master-left-1">
            <div class="master-namemore">Included in special event: *</div>
            <div class="master-left-2">
              <div class="squaredTwo">
                <input type="checkbox" value="None" id="squaredTwo" name="check" />
                <label for="squaredTwo"></label>
              </div>
            </div>
            <div class="master-namemore">More Ingredients: *</div>
            <div class="master-morebutton"> <a class='example8' href="#"><img src="images/more-button.png"></a> </div>
          </div>
          
          <!--lightbox starting-->
          <div style='display:none'>
            <div id='inline_example1'>
              <div class="top_m">
                <div class="top_lft"></div>
                <div class="top_mdl"></div>
                <div class="top_rght"></div>
              </div>
              <div class="lght_content">
                <div class="mc-field-group size1of2">
                  <label for="mce-MMERGE3-city">Ingredient Name:</label>
                  <br />
                  <input class="required" id="required-5" type="text" name="LNAME" value="" />
                </div>
                <div class="mc-field-group size1of2">
                  <label for="mce-MMERGE3-city">Ingredient Quantity:</label>
                  <br />
                  <input class="required" id="required-5" type="text" name="LNAME" value="" />
                </div>
                <div class="mc-field-group size1of2">
                  <label for="mce-MMERGE3-city">Ingredient Price:</label>
                  <br />
                  <input class="required" id="required-5" type="text" name="LNAME" value="" />
                </div>
                <div class="mc-field-group">
                  <label for="mce-MMERGE3-addr2">Item Units:</label>
                  <br />
                  <select class="required" id="required-5" name="MMERGE3[country]">
                    <option selected="selected" value="164">Kg</option>
                    <option value="286">10kg</option>
                  </select>
                </div>
                <div class="clear">
                  <input class="button" id="mc-embedded-subscribe-1" type="submit" name="subscribe" value="Submit" />
                </div>
              </div>
              <div class="top_m">
                <div class="bot_lft"></div>
                <div class="top_mdl"></div>
                <div class="bot_rght"></div>
              </div>
            </div>
          </div>
          <!--lightbox ending--> 
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">TEMPERATURE: *</div>
            <div class="master-select">
              <input name="name2" type="text" class="master-textfeild">
            </div>
          </div>
          <!---->
          <div class="master-left-1">
            <div class="master-name">BROWSE FILE : *</div>
            <div class="master-select">
              <input name="" type="file" class="form_field_browsestyle">
            </div>
          </div>
          <input class="master-submit" type="submit" name="subscribe" value="" />
        </form>
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>