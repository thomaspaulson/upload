<?php  $ran= $this->ran_string; // print_r($get_staff_subrole); ?>  
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>STAFF ROLES</h1>
    </div>
    <div class="event_list_main">
      <div class="dashbord_itemlist">
        <h1><a href="<?php echo base_url()?>admin/settings/add_staffrole">Add New</a></h1>


        <div class="row_color1">
          <ul>
            <li class="dash_cutomer_name">Subrole</li>
             <li class="dash_cutomer_name">Mainrole</li>
                     <li class="dash_cutomer_name">Action</li>
          </ul>
        </div>
       
<?php $i=1;if($get_staff_subrole)
{ foreach($get_staff_subrole as $staff)
{ $id=$staff['roleid']; if($i%2==0){ $i=2;} else { $i=3; } ?>
        
        
        <div class="row_color<?php echo $i; ?>">
          <ul>
  <li class="dash_cutomer_name"><?php echo $stname= $staff['subrole_name']; $role_subrole_id=$staff['role_subrole_id'];?></li>
            <li class="dash_cutomer_name"><?php echo $stname= $staff['rolename']; $status_curr=$staff['subrole_status']; 
if($status_curr=='active'){ $act_stat='actived'; $act_stat_label='Disable'; }else{ $act_stat=''; $act_stat_label='Enable'; }


?></li>
          <?php $stat='false';  if(($stname=='driver')||($stname=='manager')||($stname=='chef')){ $stat='true';} 
 if($stat=='true') { ?>
           <a href="<?php echo base_url()?>admin/settings/edit_staffrole/<?php echo $role_subrole_id;?>"> <li class="row_color2_edit"><img src="<?php echo CSSPATH;?>images/pencil.png">Edit</li></a>
           <a href="<?php echo base_url()?>admin/settings/changestat_staff/<?php echo $role_subrole_id; ?>"><li class="row_color4_edit <?php echo $act_stat; ?>"><img src="<?php echo CSSPATH;?>images/remove.png" class="list_img"><p><?php echo $act_stat_label; ?></p></li></a> <?php } ?>
          </ul>
        </div>
        
<?php    $i=$i+1;  }} ?>

      </div>
      
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->