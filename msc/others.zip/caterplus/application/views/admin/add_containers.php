  
  <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>CONTAINER</h1>
    </div>
    <div class="event_list_main">
      
      <div class="master-left">
       <form class="validate" id="add-items" action="<?php echo base_url()?>admin/settings/create_container" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
          <!---->
          
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Container Name:: *</div>
            <div class="master-select">
             <input name="cont_name" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="cont_name">
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Price: </div>
            <div class="master-select">
             <input name="cont_price" id="cont_price" type="text" class="master-textfeild">
              
            </div>
          </div>
         
       
          
          <input class="master-submit" type="submit" name="add_ingr" value="" /> 
        </form>
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->