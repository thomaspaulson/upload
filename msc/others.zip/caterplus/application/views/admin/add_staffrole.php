  
  <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>STAFF ROLE</h1>
    </div>
    <div class="event_list_main">
      
      <div class="master-left">
       <form class="validate" id="add-items" action="<?php echo base_url()?>admin/settings/insert_staffrole" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
          <!---->
          
          <div class="master-left-1">
           <div class="master-name">Select Role: *</div>         
<div class="master-select">
<select class="required validate[required]" id="staffrole" name="staffrole">
<option value="">select</option>
<?php foreach($staffrole as $staff) { $id=$staff['roleid']; ?>
							
			<option value="<?php echo $id; ?>"><?php echo $staff['rolename']; ?></option>																	
									
			<?php } ?>															
	</select>
          </div>
          </div>
          <!---->
          <div class="master-left-1">
            <div class="master-name">Sub Role Name:: *</div>
            <div class="master-select">
             <input name="sub_emp_role" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="sub_emp_role">
            </div>
          </div>
          
         
       
          
          <input class="master-submit" type="submit" name="add_ingr" value="" /> 
        </form>
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->