<!--menu ends-->
<div class="super-payment-bg">
<div class="master-top-add"><h1>Event Types</h1></div>
<div class="event_list_main">
<div class="event_list_center">
<div class="accordions">



	<dl class="accordion" id="slider">
	
	<?php $comp_id=$this->session->userdata('comp_id'); foreach($get_eventtype as $etype) { $evtypeid=$etype['eventtypeb_id']; ?>
		<dt style="background:<?php echo $etype['eventtypeb_color'];?>;"><?php echo $etype['eventtypeb_name'];?></dt>
		

<dd><span>
		<?php $subtype=$this->getcomp_details_model->get_subeventtype($comp_id,$evtypeid); 
		if($subtype){
		foreach($subtype as $stype) { 
			?>
		
		
		
            
            <div class="row_event1" style="background:<?php echo $etype['eventtypeb_color'];?>;">
          <ul>
            <li class="event_cutomer_name"><?php echo $stype['eventstb_name'];?></li>
        <!--->
         <a href="#"> <li class="event_edit">Edit</li></a>
          <!--->         
          
          </ul>
        </div>      
            
         
			
		
		
		
		
		<?php } ?> </span>
		</dd> <?php } } ?>
		
		
		</dt>
	</dl>
	
</div>  
</div>
<div class="event_list_right">
<div class="event_list_right_first">
<h1>Enter New Event</h1>
<div class="master-select">
<form action="<?php echo base_url()?>admin/settings/create_eventtype" method="post">
<input name="event_name" type="text" class="event-textfeild">
          </div>
         
 Event Color: <input type="text" readonly name="event_color" class="color" value="66ff00" style="background:url(<?php echo base_url()?>uploads/images/hv.png);" >         

<div class="">
<a href=""><input class="event_button" type="submit" value="Create" name="create_ev_type"/></a>
</div>     
</form>
</div>



<div class="event_list_right_second">
<h1>Enter Sub Event</h1>
<div class="event-select">
<form method="post" action="<?php echo base_url()?>admin/settings/create_subeventtype">
<select name="type_id" >
<?php foreach($get_eventtype as $etype) { $evtypeid=$etype['eventtypeb_id'];  ?>
            <option value="<?php echo $evtypeid; ?>"><?php echo $etype['eventtypeb_name'];?></option>
            <?php } ?>
          </select>
          </div>
 <div class="event-select">
<input name="subtype_name" type="text" class="event-textfeild" >
          </div>                

<div class="">
<a href=""><input class="event_button" type="submit" value="Create" name="create_sub_type"/></a>
</div>  
</form>   
</div>
</div>


</div>




</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
















<?php /*
<link media="screen" rel="stylesheet" href="http://iqbalcatering.kruxsoft.com/extras/extra/css/bootstrap.css" />
<script src="http://iqbalcatering.kruxsoft.com/extras/extra/js/bootstrap.min.js"></script>
<div class="modal fade" id="myModal" aria-hidden="true" style="display: none;">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span><span class="sr-only">Close</span></button>
        <h3 class="modal-title">ADD Ingredient</h3>
      </div>
      <div class="modal-body">
        <form method="post" action="http://iqbalcatering.kruxsoft.com/ingredientquantity/addnew_ingredient" name="ingform" id="ingform">
<p id="showmessage"></p>
Ingredient Name<p><input type="text" class="form-control" name="ingredient_name" id="ingredient_name"></p>
Ingredient Price<p><input type="text" class="form-control" name="ingredient_price" id="ingredient_price"></p>
Ingredient Unit<p><select class="form-control" name="ingredientqty_type" id="ingredientqty_type">
						<option value="G">G</option>
						<option value="KG">KG</option>
						<option value="LB">LB</option>
						<option value="MG">MG</option>
						<option value="PCS">PCS</option>
			

</select></p>
Current Stock<p><input type="text" class="form-control" name="ingredient_stock" id="ingredient_stock"></p>
Reorder Level<p><input type="text" class="form-control" name="ingredient_reorderlevel" id="ingredient_reorderlevel"></p>
 
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  <button type="button" class="btn btn-default" data-dismiss="modal" id="saveingredient">Save changes</button> 
     <!-- <button type="button" class="btn btn-primary" name="saveingredient" id="saveingredient">Save changes</button>-->

    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!--bootstrp pooup ending-->
*/ ?>