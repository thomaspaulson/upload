  <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Add Staff</h1>
    </div>
   
      
     <div class="add_staff_main">
(need to select  branch of employee)
       <form class="validate" id="add-items" action="<?php echo base_url(); ?>admin/settings/create_staff" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
          <!---->
          <div class="add_staff_left">
          
         <div class="master-left-1">
           <div class="master-name">Employee Name *</div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="name">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Username: *</div>         
<div class="master-select">
<input name="username" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="username">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Email: *</div>         
<div class="master-select">
<input name="email" type="text" class="master-textfeild validate[required,custom[email]]" id="email">

          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Email 2: </div>         
<div class="master-select">
<input name="email2" type="text" class="master-textfeild" id="email2">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Address: </div>         
<div class="master-select">
<input name="address" type="text" class="master-textfeild validate[required]" id="address">
          </div>
          </div>
          <!---->
  <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile: *</div>         
<div class="master-select">
<input name="mobile1" type="text" class="master-textfeild validate[required,custom[phone]]" id="mobile1">
          </div>
          </div>
          
         <div class="master-left-1">
           <div class="master-name">Mobile 2: </div>         
<div class="master-select">
<input name="mobile2" type="text" class="master-textfeild " id="mobile2">
          </div>
          </div>
          <!---->
          
          
          </div>
           <div class="add_staff_right">
           <div class="master-left-1">
           <div class="master-name">Ext: </div>         
<div class="master-select">
  <input id="phn_ext" type="text" name="phn_ext" class="master-textfeild">
</div>
          </div>
           <!---->
 <div class="master-left-1">
           <div class="master-name">Landline Number: </div>         
<div class="master-select">
  <input id="phone" type="text" name="phone" class="master-textfeild">
</div>
          </div>
           <!---->
<!----><div class="master-left-1">
           <div class="master-name">Select Role: *</div>         
<div class="master-select">
<select class="required-1" id="role" name="role">
<?php
					foreach($roles as $role){
						if($role['rolename'] != 'Admin'){
				?>
					<option value="<?php echo $role['roleid']; ?>"><?php echo ucfirst($role['rolename']);  ?></option>
				<?php
						}
					}
				?>			

</select>
          </div>
          </div>
          

         <!---->
<div class="master-left-1">
           <div class="master-name">Select Type: *</div>         
<div class="master-select">
<select class="required-1" id="type" name="type">
<option value="permanent">Permanent</option>
<option value="temporary">Temporary</option>		

</select>
          </div>
          </div>
          

         <!---->
  <div class="master-left-1">
           <div class="master-name">Password: </div>         
<div class="master-select">
  <input  type="password" name="password" class="master-textfeild validate[required,minSize[6]]" id="password">
</div>
          </div>
           <!---->
 <div class="master-left-1">
           <div class="master-name">Re-Enter Password: </div>         
<div class="master-select">
  <input name="conf_password" type="password"  class="master-textfeild validate[required,equals[password]]" id="conf_password">
</div>
          </div>
           <!---->
         <div class="master-left-1">
           <div class="master-name">Select Image : *</div>         
<div class="master-select">
<input name="userfile" id="userfile" type="file" class="form_field_browsestyle">
          </div>
          </div>
          <input class="master-submit" type="submit" name="subscribe" value="" />
           
           </div>
          <!---->


         
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->
