  
  <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Ingredient</h1>
    </div>
    <div class="event_list_main">
      
      <div class="master-left">
       <form class="validate" id="add-items" action="<?php echo base_url()?>admin/settings/create_ingredient" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
          <!---->
          
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Ingredient Name:: *</div>
            <div class="master-select">
             <input name="ingredientname" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="ingredientname">
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Description: </div>
            <div class="master-select">
             <input name="ingredientdescription" id="ingredientdescription" type="text" class="master-textfeild">
              
            </div>
          </div>
          <!---->
          <div class="master-left-1">
            <div class="master-name">Ingredient Quantity Unit: *</div>
            <div class="master-select">
            <select name="ingredientqtytype" class="required-1 validate[required]" id="ingredientqtytype">
                <option>KG</option><option>G</option><option>Lb</option><option>MG</option><option>PCS</option>
              </select>
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Ingredient Price: *</div>
            <div class="master-select">
            <input name="ingredientprice" id="ingredientprice" type="text" class="master-textfeild validate[required,custom[number]]">
            </div>
          </div>
          
          <!---->
          <div class="master-left-1">
            <div class="master-name">Current Stock: *</div>
            <div class="master-select">
             <input name="currquantity" type="text" class="master-textfeild validate[required,custom[number]]" id="currquantity">
            </div>
          </div>
          <!---->
          <div class="master-left-1">
            <div class="master-name">Re-Order Level: *</div>
            <div class="master-select">
               <input name="reorderlevel" type="text" class="master-textfeild validate[required,custom[number]]" id="reorderlevel">
            </div>
          </div>
          
       
          
          <input class="master-submit" type="submit" name="add_ingr" value="" /> 
        </form>
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->