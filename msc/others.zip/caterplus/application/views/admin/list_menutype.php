<?php $ran= $this->ran_string; // print_r($menutype); ?>  
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>MENU TYPE</h1>
    </div>
    <div class="event_list_main">
      <div class="dashbord_itemlist">
        <h1><a href="<?php echo base_url()?>admin/settings/add_menutypes">Add New</a></h1>


        <div class="row_color1">
          <ul>
            <li class="dash_cutomer_name">Menutype Name</li>
            <li class="dash_cutomer_name">Action</li>
          </ul>
        </div>
       
<?php $i=1;if($menutype)
{ foreach($menutype as $menu)
{ $id=$menu['com_tmenu_id']; if($i%2==0){ $i=2;} else { $i=3; } ?>
        
        
        <div class="row_color<?php echo $i; ?>">
          <ul>
            <li class="dash_cutomer_name"><?php echo $menu['com_tmenu_name']; ?></li>
            
           <a href="#"> <li class="row_color2_edit"><img src="<?php echo CSSPATH;?>images/pencil.png">Edit</li></a>
           <a href="<?php echo base_url()?>admin/settings/remove_menutype/<?php echo $ran.'/'.$id; ?>"><li class="row_color4_edit"><img src="<?php echo CSSPATH;?>images/remove.png" class="list_img"><p>Remove</p></li></a>
          </ul>
        </div>
        
<?php    $i=$i+1;  }} ?>

      </div>
      
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->