<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Welcome</title>

<link href="<?php echo base_url();?>extras/new/css/style.css" rel="stylesheet" type="text/css">
<link href='<?php echo base_url();?>extras/new/css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url();?>extras/new/css/fullcalendar.print.css' rel='stylesheet' media='print' />

<script src="<?php echo base_url();?>extras/new/js/html5.js"></script>
<script src="<?php echo base_url();?>extras/new/js/jquery-1.10.2.js"></script>
<!--======= Calendar =======-->
<link href="<?php echo base_url();?>extras/new/css/jquery-ui.css" rel="stylesheet" type="text/css">



</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="#"><img src="<?php echo base_url();?>extras/new/images/logo.png" alt=""></a></div>
    <div class="header_right"><!----> 
       
      <!--==== user name =====--> 
      <a href="#">
      <div class="user_box">
        <div class="user">
          <div class="icon"> </div>
          <div class="user_name">
<?php $comp_name= $this->session->userdata('comp_name'); $branch_name=$this->session->userdata('branch_name'); ?>
            <p><?php echo $comp_name;?></p>
            <p><?php echo $branch_name;?></p>
          
          </div>
          <h6>Current : <?php echo $this->session->userdata('type');?></h6>
        </div>
      </div>
      </a> 
      <!--==== user name end =====--> 
      <a href="<?php echo base_url();?>logout" class="logout"><img src="<?php echo base_url();?>extras/new/images/logout.png" alt="">
      <h6>Logout</h6>
    </a> </div>
  </div>
</header>
<!--========= content ===============-->
<div class="wrapper"> 
<div class="welcome-main">
<?php 
if($this->session->flashdata('message'))
{
  echo '<div class="alert alert-success alert-dismissible" role="alert">
  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
  <strong>';
  echo $this->session->flashdata('message');
  echo '</strong></div>'; 
}?>
     
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen"><img src="<?php echo base_url();?>extras/new/images/welcome/kitchen.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>office"><img src="<?php echo base_url();?>extras/new/images/welcome/office.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/customer"><img src="<?php echo base_url();?>extras/new/images/welcome/special-events.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/collectorder"><img src="<?php echo base_url();?>extras/new/images/welcome/order-collection.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/paymentcollection/balancepayment"><img src="<?php echo base_url();?>extras/new/images/welcome/payment.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/orderlist"><img src="<?php echo base_url();?>extras/new/images/welcome/manage-order.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/paymentcollection/homedeliverybalpay"><img src="<?php echo base_url();?>extras/new/images/home-delivery.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>staff"><img src="<?php echo base_url();?>extras/new/images/welcome/staff.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/customer/listcustomer/"><img src="<?php echo base_url();?>extras/new/images/welcome/customers.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>menu/listall"><img src="<?php echo base_url();?>extras/new/images/welcome/menu-type.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>items/listall"><img src="<?php echo base_url();?>extras/new/images/welcome/item.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialingredients/listall"><img src="<?php echo base_url();?>extras/new/images/welcome/ingredeins.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialpackage"><img src="<?php echo base_url();?>extras/new/images/welcome/packages.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>specialevent/specialcontainer"><img src="<?php echo base_url();?>extras/new/images/welcome/containers.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>settings"><img src="<?php echo base_url();?>extras/new/images/welcome/settings.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>admin/admin_dashboard/index"><img src="<?php echo base_url();?>extras/new/images/welcome/general.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>event/event_overview/event_list"><img src="<?php echo base_url();?>extras/new/images/welcome/events.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>diary"><img src="<?php echo base_url();?>extras/new/images/welcome/diary_home.png"></a></div>
<div class="welcome-icon"><a href="<?php echo base_url();?>dashboard/dashboard/"><img src="<?php echo base_url();?>extras/new/images/welcome/dashbord.png"></a></div>
<!--<div class="welcome-icon"><a href="#" onclick="reset()"><img src="<?php echo base_url();?>extras/new/images/welcome/reset.png"></a></div>-->
</div>
  <div class="clear"></div>
</div>
<script type="text/javascript">
    function reset()
    {
        var r = confirm("Are you sure you want to reset all orders?? ");
        if (r == true) {

            window.location = "<?php echo base_url(); ?>web_data/reset_orders/";
        }
    }
    function displayDiv(i, c)
    {
        alert(i);
    }
</script>
<!--========= content end ===============-->
<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
        <td><a href="javascript:window.history.go(-1);"><img src="<?php echo base_url();?>extras/new/images/back.png" alt=""></a></td>
        <td align="<?php echo base_url();?>"><a href=""><img src="<?php echo base_url();?>extras/new/images/home.png" alt=""></a></td>
      </tr>
    </table>
  </div>
</footer>
</body>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</html>