<?php $ran= $this->ran_string; // print_r($ingredients); ?>  
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>INGREDIENTS</h1>
    </div>
    <div class="event_list_main">
      <div class="dashbord_itemlist">
        <h1><a href="<?php echo base_url()?>admin/settings/add_ingredient">Add New</a></h1>


        <div class="row_color1">
          <ul>
            <li class="dash_cutomer_name">Ing Name</li>
            <li class="dash_cutomer">Unit</li>
            <li class="dash_cutomer">Reorder-level</li>
            <li class="dash_cutomer_name">Action</li>
          </ul>
        </div>
       
<?php $i=1;if($ingredients)
{ foreach($ingredients as $ingr)
{ $ingid=$ingr['ing_id']; if($i%2==0){ $i=2;} else { $i=3; } ?>
        
        
        <div class="row_color<?php echo $i; ?>">
          <ul>
            <li class="dash_cutomer_name"><?php echo $ingr['ing_name']; ?></li>
            <li class="dash_cutomer"><?php echo $ingr['ing_unit']; ?></li>
            <li class="dash_cutomer"><?php echo $ingr['ing_reorder']; ?></li>
           <a href="#"> <li class="row_color2_edit"><img src="<?php echo CSSPATH;?>images/pencil.png">Edit</li></a>
           <a href="<?php echo base_url()?>admin/settings/remove_ingredients/<?php echo $ran.'/'.$ingid; ?>"><li class="row_color4_edit"><img src="<?php echo CSSPATH;?>images/remove.png" class="list_img"><p>Remove</p></li></a>
          </ul>
        </div>
        
<?php    $i=$i+1;  }} ?>

      </div>
      
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->