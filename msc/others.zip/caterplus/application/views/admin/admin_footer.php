<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
        <td><a href="javascript:window.history.go(-1);"><img src="<?php echo CSSPATH;?>images/back.png" alt=""></a></td>
        <td align="right"><a href="<?php echo base_url();?>"><img src="<?php echo CSSPATH;?>images/home.png" alt=""></a></td>
     <!--   <td align="right"><a href="javascript:void(0)"><img src="<?php echo CSSPATH;?>images/my_order.png" alt=""></a></td>-->
      </tr>
    </table>
  </div>
   <div class="clear"></div>
</footer>
<script type="text/javascript">

var slider1=new accordion.slider("slider1");
slider1.init("slider");


</script>

</body>
</html>