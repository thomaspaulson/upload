<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<a style="float: right;margin-top: 10px;margin-right: 60px;" href="<?php echo base_url(); ?>settings"><img src="<?php echo base_url();?>extras/extra/images/Edit--profile.png"/></a>	
<div class="master-top-add"><h1>PASSWORD</h1></div>


<div class="msprogrm-main">
<?php if(@$msg!=''): ?>
					
						<div class="success"  style="font-size: 16px;  color: green;  font-weight: bold;">
						<?php if($msg=="edited"){ echo "<div class='message success'><p class='success'>Profile updated successfully</p></div>";} ?>
						
						</div>
<div class="error" style="font-size: 16px;  color: red;  font-weight: bold;">
						<?php if($msg=="error"){ echo "<div class='message success'><p class='error' >Please Enter Correct Old Password</p></div>";} ?>
						
						</div>

					<?php endif; ?>	
<form class="validate" id="add-items" action="<?php echo base_url(); ?>settings/update_password" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
<div class="msprogrm-left">


         <div class="master-left-1">
           <div class="master-name">Old Password*</div>         
<div class="master-select">
<input name="password" type="password" class="master-textfeild validate[required]" id="password" >
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">New Password: *</div>         
<div class="master-select">
<input type="password" name="new_password" class="master-textfeild validate[required,minSize[6]]" id="new_password">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Re-Enter Password:* </div>         
<div class="master-select">
<input type="password" name="confirm-password" class="master-textfeild validate[required,equals[new_password]]" id="confirm-password" >

          </div>
          </div>
          
          <!---->
         
       

<input type="hidden" name="id" id="id" value="<?php echo $users->employeeid; ?>"/>
        <input class="master-submit" type="submit" name="subscribe" value="" /> 

</div>
          
        
</form>

  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			

$("#user_id").blur(function() {
       //gets the value of the field
       var user_id = $("#user_id").val();
      var currentuserid=<?php echo $id; ?>;

       //here would be a good place to check if it is a valid email before posting to your db

       //displays a loader while it is checking the database
       //$("#emailError").html('');

       //here is where you send the desired data to the PHP file using ajax
var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

if(user_id)
{
       $.post("<?php echo base_url().'specialevent/ajaxprocess/index'; ?>", {user_id:user_id,currentuserid:currentuserid},
           function(result) {
         
               if(result == 1) {
                                   //the email is available
                   $("#errmsg").html("Available");
               }
               else {
                   //the email is not available
                   $('#user_id').val('');
                   $("#errmsg").html("Not available");
               }
           });
}
    });

         });


                       </script>