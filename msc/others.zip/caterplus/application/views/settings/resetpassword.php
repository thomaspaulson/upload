<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">

<div class="col-md-3 col-sm-3">
 <div class="listing_title"> Change Password</div>
</div>


<div class="col-md-3 col-sm-3" id="listback" style="float:right;">

     <div class="listing_title"> <a href="<?php echo base_url(); ?>settings/">Edit Profile</a> </div>
    </div>  
    

    
   <div class="list_line"></div> 

<div class="list_table1">

<div class="listtable-white">
<?php
						if($this->session->flashdata('status'))
						{
						?>
					
						<div class="success">
						<?php 	echo $this->session->flashdata('status'); ?>
						
						</div>
<?php 
						}					
						?>	
						
							<?php
						if($this->session->flashdata('error'))
						{
						?>
				
					
						<div class="success">
						<?php 	echo $this->session->flashdata('error'); ?>
						
						</div>

					<?php } ?>	
<form class="validate" id="add-items" action="<?php echo base_url(); ?>resetpassword/submit" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">

<div class="mc-field-group"><label for="mce-LNAME">Email: <span class="asterisk">*</span><br />
</label><br />
<input type="text" name="password" class="required" id="required-1" />
</div>



<div class="clear" id="mce-responses"></div>
<div class="clear"><input class="button" id="mc-embedded-subscribe" type="submit" name="subscribe" value="Submit" /></div>


</form>
</div>
 </div>