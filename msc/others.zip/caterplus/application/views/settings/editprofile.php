<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<a style="float: right;margin-top: 10px;margin-right: 60px;" href="<?php echo base_url(); ?>settings/password"><img src="<?php echo base_url();?>extras/extra/images/change-password.png"/></a>	
<div class="master-top-add"><h1>EDIT PROFILE</h1></div>


<div class="msprogrm-main">
<?php if(@$msg!=''): ?>
					
						<div class="success" style="font-size: 16px;  color: green;  font-weight: bold;">
						<?php if($msg=="edited"){ echo "<div class='message success'><p>Profile updated successfully</p></div>";} ?>
						
						</div>
					<?php endif; ?>	
<form class="validate" id="add-items" action="<?php echo base_url(); ?>settings/update" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
<div class="msprogrm-left">


         <div class="master-left-1">
           <div class="master-name">Name *</div>         
<div class="master-select">
<input name="employeename" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="name" value="<?php echo $users->employeename;  ?>">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Email: *</div>         
<div class="master-select">
<input name="email" type="text" class="master-textfeild validate[required,custom[email]]" id="email" value="<?php echo $users->email;  ?>">
          </div>
          </div>
          <!---->
         <div class="master-left-1">
           <div class="master-name">Email 2: </div>         
<div class="master-select">
<input name="email2" type="text" class="master-textfeild validate[custom[email]]" id="email2" value="<?php echo $users->email2;  ?>">

          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Address: </div>         
<div class="master-select">
<input name="employeeaddress" type="text" class="master-textfeild" id="employeeaddress" value="<?php echo $users->employeeaddress;  ?>">
          </div>
          </div>
          
           <!---->
       
  <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile: *</div>         
<div class="master-select">
<input name="mobile1" type="text" class="master-textfeild validate[required,custom[phone]]" id="mobile1" value="<?php echo $users->mobile1;  ?>">
          </div>
          </div>
          
           <!---->
         <div class="master-left-1">
           <div class="master-name">Mobile 2: </div>         
<div class="master-select">
<input name="mobile2" type="text" class="master-textfeild " id="mobile2" value="<?php echo $users->mobile2;  ?>">
          </div>
          </div>
          <!---->


</div>
<div class="msprogrm-right">
 
       
         <div class="master-left-1">
           <div class="master-name">Ext: </div>         
<div class="master-select">
  <input id="phn_ext" type="text" class="master-textfeild validate[custom[number]]" id="phn_ext" type="text" name="phn_ext" value="<?php echo $users->phn_ext;  ?>">
</div>
          </div>
           <!---->
 <div class="master-left-1">
           <div class="master-name">Landline Number: </div>         
<div class="master-select">
  <input  class="master-textfeild validate[custom[phone]]" id="employeephone" type="text" name="employeephone" value="<?php echo $users->employeephone;  ?>" >
</div>
          </div>
           <!---->

        
         <!---->
  <div class="master-left-1">
           <div class="master-name">Pin: </div>         
<div class="master-select">
  <input  type="text" name="pin" class="master-textfeild validate[required,custom[integer],minSize[4]]" id="pin" value="<?php echo $users->pin;  ?>">
</div>
          </div>
         
           <!---->
         <div class="master-left-1">
           <div class="master-name">Select Image : *</div>         
<div class="master-select">
<input name="staff_image" id="userfile" type="file" class="form_field_browsestyle">
<img src="<?php echo base_url(),'uploads/staff/',$users->staff_image; ?>" width="75" height="75">

          </div>
          </div>
       <input type="hidden" name="id" value="<?php echo $users->employeeid; ?>"/>
        <input class="master-submit" type="submit" name="subscribe" value="" /> 

</div>
          
        
</form>

  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
<script>
		jQuery(document).ready(function(){
			// binds form submission and fields to the validation engine
			

$("#user_id").blur(function() {
       //gets the value of the field
       var user_id = $("#user_id").val();
      var currentuserid=<?php echo $id; ?>;

       //here would be a good place to check if it is a valid email before posting to your db

       //displays a loader while it is checking the database
       //$("#emailError").html('');

       //here is where you send the desired data to the PHP file using ajax
var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

if(user_id)
{
       $.post("<?php echo base_url().'specialevent/ajaxprocess/index'; ?>", {user_id:user_id,currentuserid:currentuserid},
           function(result) {
         
               if(result == 1) {
                                   //the email is available
                   $("#errmsg").html("Available");
               }
               else {
                   //the email is not available
                   $('#user_id').val('');
                   $("#errmsg").html("Not available");
               }
           });
}
    });

         });


                       </script>