<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Select Branch</title>
<link href="<?php echo CSSPATH;?>css/style.css" rel="stylesheet" type="text/css">
<link href='<?php echo CSSPATH;?>css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo CSSPATH;?>css/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src="<?php echo CSSPATH;?>js/html5.js"></script>
<script src="<?php echo CSSPATH;?>js/jquery-1.10.2.js"></script>
<link href="<?php echo CSSPATH;?>css/jquery-ui.css" rel="stylesheet" type="text/css">

<!--====== selection =====-->
<script type="text/javascript">
    $(document).ready(function(){
        $(".custom-select").each(function(){
            $(this).wrap("<span class='select-branch'></span>");
            $(this).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function(){
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        }).trigger('change');
    })
</script>

<!--====== selection end =====-->


</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="#"><img src="<?php echo CSSPATH?>images/logo.png" alt=""></a></div>
    
  </div>
</header>
<!--========= content ===============-->
<div class="wrapper"> 
<div class="login_wrap">
<div class="login-main">

<div class="login-main-right">

<div class="login-main-righbottom">
<img src="<?php echo CSSPATH?>images/good-luck-4leafclover.gif">
</div>
<div class="login-main-righttop">

<div class="login_box">
          <div class="left_box">
            <div class="hd">
              <h1><?php echo $comp_name;?></h1>
            </div>
            <div class="left_branch">
              
              <div class="branch-selection">
<form action="<?php echo base_url()?>login/verify_branch" method="post">
            <select name="branchid" class="custom-select">
          <?php foreach($br_list as $blist) { $bname=$blist['br_name']; 
$bid=$blist['br_id']; ?>
<option value="<?php echo $bid;?>"> <?php echo $bname;?></option>
<?php } ?>
</select>

          </div>
              
            </div>
          </div>
          <input  name="select_branch"  type="submit" class="go" value="go">

</form>
          <div class="clear"></div>
        </div>
</div>

</div>
</div>





</div>

  <div class="clear"></div>
</div>
<!--========= content end ===============-->

</body>
</html>
