<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
        <td><a href=""><img src="<?php echo base_url() ?>extras/new/images/back.png" alt=""></a></td>
        
        <td align="right"><a href="<?php echo base_url() ?>"><img src="<?php echo base_url() ?>extras/new/images/home.png" alt=""></a></td>
      </tr>
    </table>
  </div>
   <div class="clear"></div>
</footer>
</body>
</html>
