<!DOCTYPE HTML>
<!--[if lt IE 7 ]> <html class="no-js ie6 oldie" lang="en"> <![endif]-->
<!--[if IE 7 ]>    <html class="no-js ie7 oldie" lang="en"> <![endif]-->
<!--[if IE 8 ]>    <html class="no-js ie8 oldie" lang="en"> <![endif]-->
<!--[if IE 9 ]>    <html class="no-js ie9" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html class="no-js" lang="en">
<!--<![endif]-->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Select Dishes</title>
<link href="<?php echo base_url()?>extras/new/css/style.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url()?>extras/new/js/html5.js"></script>
<script src="<?php echo base_url()?>extras/new/js/jquery-1.10.2.js"></script>
<!--======= Calendar =======-->
<link href="<?php echo base_url()?>extras/new/css/jquery-ui.css" rel="stylesheet" type="text/css">

<script type="text/javascript" src="<?php echo base_url()?>extras/new/js/jquery-1.7.1.min.js"></script>
<script type="text/javascript" src="<?php echo base_url()?>extras/new/js/jquery.flexisel.js"></script>
<!--tab-->
