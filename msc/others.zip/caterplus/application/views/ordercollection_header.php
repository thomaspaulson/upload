<!doctype html>
<html>
  <head>
  <meta charset="utf-8">
  <title>Iqbal Catering</title>
  <link rel="shortcut icon" href="favicon.png">
  <!--common style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/extra/css/newstyle.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/view_port.css">
  <!--font css style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/fonts/stylesheet.css">
<link href="<?php echo base_url() ?>extras/new/css/style.css" rel="stylesheet" type="text/css">

  <!--bootsrap css style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/bootstrap.css">

  <!-- bootstrap js -->


<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/elastislide.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/custom.css" />
		<script src="<?php echo base_url();?>extras/js/modernizr.custom.17475.js"></script>


  <!-- tab and slide js -->
  <link type="text/css" rel="stylesheet" href="<?php echo base_url();?>extras/css/easy-responsive-tabs.css" />
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
<!--<script type="text/javascript" src="<?php echo base_url();?>extras/js/jquery-1.10.2.min.js"></script>-->
  <script src="<?php echo base_url();?>extras/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>extras/js/easyResponsiveTabs.js" type="text/javascript"></script>
  

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lte IE 8]>
<script src="<?php echo base_url();?>extras/js/html5.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>extras/js/respond.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/ie8-and-down.css" />
<![endif]-->

  </head>
<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="<?php echo base_url();?>admin"><img src="<?php echo base_url() ?>extras/new/images/logo.png" alt=""></a></div>
<div class="header_right">
    <ul>
  
      <li> <a href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/kitchen.png" alt="">
      <h6>Kitchen</h6>
      </a> </li>
      
      <li> <a href="<?php echo base_url();?>items/listall" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/item.png" alt="">
      <h6>Items</h6>
      </a> </li>
      
      <li>  <a href="<?php echo base_url();?>specialevent/paymentcollection/balancepayment" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/payment.png" alt="">
      <h6>Payment</h6>
      </a> </li>
      
      <li> <a href="<?php echo base_url();?>settings"  class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/settings.png" alt="">
      <h6>Settings</h6>
      </a> </li>
      
      <li> <a href="#"  id="showmorebutton" class="top-menuicons"><img src="<?php echo base_url() ?>extras/new/images/more.png" alt="">
      <h6>More </h6>
      </a> 
      <ul class="showmore">
            <li><a href="<?php echo base_url();?>specialevent/customer/listcustomer/"><img src="<?php echo base_url() ?>extras/new/images/customers.png" alt="" title="CUSTOMERS">  </a></li>
            <li><a href="<?php echo base_url();?>specialingredients/listall"><img src="<?php echo base_url() ?>extras/new/images/ingredients.png" alt="" title="INGREDIENTS"></a></li>
            <li><a href="<?php echo base_url();?>menu/listall "><img src=" <?php echo base_url() ?>extras/new/images/menu-type.png" alt="" title="MENU TYPE"></a></li>
            <li class="more-drop"><a href="<?php echo base_url();?>specialevent/orderlist"><img src="<?php echo base_url() ?>extras/new/images/manage-order.png" alt="" title="MANAGE ORDER"></a></li>
           
             <li class="more-drop"><a href="<?php echo base_url();?>staff"><img src="<?php echo base_url() ?>extras/new/images/staff.png" alt="" title="STAFF"></a></li>
              <li class="more-drop"><a href="<?php echo base_url();?>office"><img src="<?php echo base_url() ?>extras/new/images/office.png" alt="" title="OFFICE"></a></li>
               <li><a href="<?php echo base_url();?>specialevent/specialcontainer"><img src="<?php echo base_url() ?>extras/new/images/containers.png" alt="" title="CONTAINERS"></a></li>
                <li><a href="<?php echo base_url();?>specialpackage"><img src="<?php echo base_url() ?>extras/new/images/packages.png" alt="" title="PACKAGES"></a></li>
               
          </ul>
      </li>
      
      <li> <a href="">
      <div class="user_box">
        <div class="user">
          <div class="icon"> </div>
          <div class="user_name">
             <?php $pobj = new staff_model(); ?>
<?php $bal = $pobj->get_adminname();  ?>
            <p><?php echo $bal; ?></p>
          
          </div>
          <h6>Admin</h6>
        </div>
      </div>
      </a> </li>
      
      <li> <a href="<?php echo base_url();?>logout" class="logout"><img src="<?php echo base_url() ?>extras/new/images/logout.png" alt="">
      <h6>Logout</h6>
      </a></li>
    
    </ul>
    
      </div>
<script>
$("#showmorebutton").click(function(){                
               if (!$('.showmore:visible').length)
  {         $(".showmore").fadeIn();    }
  else{ $(".showmore").fadeOut(); }
       
               });
               </script>
</header>