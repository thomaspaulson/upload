<script>
$(document).ready(function(){
$("#profile").addClass("active");

	$(".tab_cont_01").slideDown();
	$(".tab_cont_02").hide();
	  $(".tab_02").removeClass("active");
  $(this).addClass("active");
	
	$(".tab_01").click(function(){
    $(".tab_cont_01").slideDown();
	$(".tab_cont_02,.tab_cont_03,.tab_cont_04").hide();
	  $(".tab_02,.tab_03,.tab_04").removeClass("active");
  $(this).addClass("active");
});

	$(".tab_02").click(function(){
    $(".tab_cont_02").slideDown();
	$(".tab_cont_01,.tab_cont_03,.tab_cont_04").hide();
	  $(".tab_01,.tab_03,.tab_04").removeClass("active");
  $(this).addClass("active");
});

$(".tab_03").click(function(){
    $(".tab_cont_03").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_04").hide();
	  $(".tab_01,.tab_02,.tab_04").removeClass("active");
  $(this).addClass("active");
});

$(".tab_04").click(function(){
    $(".tab_cont_04").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03").hide();
	  $(".tab_01,.tab_02,.tab_03").removeClass("active");
  $(this).addClass("active");
});

});
</script>
<!--tab end-->

<?php //print_r($detail); 
?> 
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Profile</h1>
    </div>
    <div class="super_company_name">
     <div class="super_company_logo"><img src="<?php echo $comp_logo;?>"></div>
     <div class="super_company_logo_name"><h1>Iqbal Catering</h1></div>
    </div>
    
    <div class="super_addcaterer">
<div class="super_tab">
  <div class="super_tab_menu">
    <ul>
      <li class="tab_01 active">Personal</li>
      <li class="tab_02">Contact</li>
      <li class="tab_03">Work</li>
      <li class="tab_04">Login</li>
    </ul>
  </div>
  <div class="super_tab_content tab_cont_01">
    <p>
    License : Abdul Hakeem
    <br><br>
    No. of Branches: 5
    </p>

  </div>
  
  <div class="super_tab_content tab_cont_02">
    <div class="super_profile_addres"> 
    <p>
    Address 
    <br><br>
    Phone 
     <br><br>
     Email 
    </p>
    </div>
    <div class="super_profile_adddtls">
    <p>
    : kkv villas, plot no 112, uk 
    <br><br>
    : Phone : 0484 123 456
     <br><br>
     : Email :info@iqbal.com
    </p>
    
     </div>
    
  </div>
  
<div class="super_tab_content tab_cont_03">
     <p>Company : Iqbal Catering</p>
  </div>

<div class="super_tab_content tab_cont_04">
    
        <div class="dashbord_itemlist">
       
        <div class="row_color1">
          <ul>
            <li class="super_branch_name">Name</li>
            <li class="super_branch_add">Sex</li>
            <li class="super_branch_phone">Age</li>
            <li class="super_branch_phone">Branch</li>
             <li class="super_profile_edit">Edit</li>
           
          </ul>
        </div>
        <div class="row_color2">
          <ul>
            <li class="super_branch_name">John Paul </li>
            <li class="super_branch_add">Male</li>
            <li class="super_branch_phone">34</li>
            <li class="super_branch_phone">B3</li>
           <a href="#"> <li class="row_color2_edit"><img src="images/pencil.png">Edit</li></a>
          </ul>
        </div>
        
        <div class="row_color3">
          <ul>
            <li class="super_branch_name">Meena </li>
            <li class="super_branch_add">Female</li>
            <li class="super_branch_phone">30</li>
            <li class="super_branch_phone">B1</li>
           <a href="#"> <li class="row_color2_edit"><img src="images/pencil.png">Edit</li></a>
          </ul>
        </div>
        <div class="row_color2">
          <ul>
            <li class="super_branch_name">John  </li>
            <li class="super_branch_add">Male</li>
            <li class="super_branch_phone">25</li>
            <li class="super_branch_phone">B2</li>
           <a href="#"> <li class="row_color2_edit"><img src="images/pencil.png">Edit</li></a>
          </ul>
        </div>
      </div> 
       
     <div class="super_newbranch_add">
     
     <div class="super_master-1">
           <div class="super_name">Selected User :</div>         
 <div class="super_profile_name">John</div> 
          </div>
     
    <div class="super_master-1">
           <div class="super_name">Edit Password :</div>         
<div class="super_master">
<input name="name" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Repeat Password :</div>         
<div class="super_master">
<input name="name" type="text" class="super_master_textfeild">
          </div>
          </div>
    <input class="master-submit" type="submit" name="subscribe" value="" />

   </div>    
    
  </div>

</div>

</div>
    
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->
