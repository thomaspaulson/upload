<!--========= content ===============-->
<div class="wrapper"> 
<div class="super_admin_caterer">

<?php foreach($data as $dat) { $comp_id=$dat['comp_id']; $img=$dat['comp_logo'];?>

<div class="super_caterer_one">
<div class="super_caterer_img">
<a href=""><img src="<?php echo base_url();?>uploads/company_logo/<?php echo $img;?>"></a>
</div>
<div class="super_caterer_name">
<a href="<?php echo base_url();?>superadmin/company/edit_company/<?php echo $comp_id;?>"><h1><?php echo $dat['comp_name'];?></h1></a>
<p><?php echo $dat['comp_status'];?></p>
</div>

</div>

<?php } ?>


</div>
  <div class="clear"></div>
</div>
<!--========= content end ===============-->