<script>
$(document).ready(function(){

$("#licence").addClass("active");

});
</script>


<?php foreach($data as $d) ?>
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>License Details</h1>
    </div>
    <div class="event_list_main">
    <div class="super_company_name">
     <div class="super_company_logo"><img src="<?php echo $comp_logo;?>"></div>
     <div class="super_company_logo_name"><h1><?php echo $comp_name;?></h1></div>
    </div>
      <div class="dashbord_itemlist">
       
        <div class="row_color1">
          <ul>
            <li class="super_branch_name">License No</li>
            <li class="super_branch_add">Valid From</li>
            <li class="super_branch_phone">Valid To</li>
            <li class="super_branch_phone">Description</li>
           
          </ul>
        </div>
        <div class="row_color2">
          <ul>
            <li class="super_branch_name"><?php echo $d['lic_no']; ?> </li>
            <li class="super_branch_add" ><?php echo $d['lic_startdate']; ?></li>
            <li class="super_branch_phone"> <?php echo $d['lic_enddate']; ?></li>
            <li class="super_branch_phone"> <?php echo $d['lic_desc']; ?></li>
           
          </ul>
        </div>
        
       
      
        
      </div>
      
    </div>
    <div class="super_newbranch_add">
   
          <div class="super_master-1">
           <div class="super_name">Renew License :</div>         
<div class="super_master">
<form action="<?php echo base_url()?>superadmin/company/update_licence" method="post">
<input type="text" id="datepicker" class="license_textfeild" name="enddate">
<input type="hidden" name="comp_id" value="<?php echo $d['comp_id'];?> "/>
<input type="hidden" name="license"  value="<?php echo $d['lic_no']; ?> "/>
<input type="hidden" name="startdate" value="<?php echo $d['lic_startdate']; ?>"/>


<a href="#"></a>
          </div>



          </div>
          <div class="super_name">Description :</div>   
<div class="super_master">
<input type="text" class="license_textfeild" name="desc">
 </div>
    <input class="super-submit" type="submit" name="subscribe" value="" />

    </form>
          
    </div>  

    
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  </script>