<div class="wrapper">
  <div class="event_list_left">
    <div class="content">
      <ul class="flexy-menu orange">
        <li id="payment"><a href="<?php echo base_url()?>superadmin/company/edit_company/<?php echo $comp_id; ?>"><i class="icon-heart"><img src="<?php echo CSSPATH;?>images/event.png"></i>Payment</a></li>
        <li id="branch"><a href="<?php echo base_url()?>superadmin/company/add_branch/<?php echo $comp_id; ?>"><i class="icon-th"><img src="<?php echo CSSPATH;?>images/menu.png"></i>Branch</a> </li>
        <li id="licence"><a href="<?php echo base_url()?>superadmin/company/licence/<?php echo $comp_id; ?>"><i class="icon-th"><img src="<?php echo CSSPATH;?>images/even-staff.png"></i>License</a></li>
        <li id="profile"><a href="<?php echo base_url()?>superadmin/company/profile_company/<?php echo $comp_id; ?>"><i class="icon-comments"><img src="<?php echo CSSPATH;?>images/even-staff.png"></i>Profile</a></li>
        <li id="remove"><a href="<?php echo base_url()?>superadmin/company/remove_company/<?php echo $comp_id; ?>"><i class="icon-group"><img src="<?php echo CSSPATH;?>images/general.png"></i>Remove</a></li>
          <li id="module"><a href="<?php echo base_url()?>superadmin/company/module_company/<?php echo $comp_id; ?>"><i class="icon-group"><img src="<?php echo CSSPATH;?>images/general.png"></i>Privileges</a></li>
      </ul>
    </div>
  </div>