<?php //print_r($branches); ?>

<script>
$(document).ready(function(){

$("#branch").addClass("active");

});
</script>


<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Branch List</h1>
    </div>
    <div class="event_list_main">
    <div class="super_company_name">
     <div class="super_company_logo"><img src="<?php echo $comp_logo;?>"></div>
     <div class="super_company_logo_name"><h1><?php echo $comp_name; ?></h1></div>
    </div>
      <div class="dashbord_itemlist">
       

        <div class="row_color1">
          <ul>
            <li class="super_branch_name">Branch Name</li>
            <li class="super_branch_add">Address</li>
            <li class="super_branch_phone">Phone</li>
            <li class="super_branch_phone">Email</li>
            <li class="super_branch_action">Action</li>
          </ul>
        </div>



<?php $i=2; foreach($branches as $dat) { $br_id=$dat['br_id'];  $comp_id=$dat['comp_id']; $br_name=$dat['br_name']; $address=$dat['br_address'];$br_ph1=$dat['br_ph1'];
$br_email1=$dat['br_email1']; $cur_status=$dat['br_status']; if($cur_status=='active'){ $stat='Deactivate'; }else{ $stat='Activate'; } ?>
        <div class="row_color<?php echo $i;?>">
          <ul>
            <li class="super_branch_name"><?php echo $br_name; ?></li>
            <li class="super_branch_add"><?php echo $address; ?></li>
            <li class="super_branch_phone"><?php echo $br_ph1; ?></li>
            <li class="super_branch_phone"><?php echo $br_email1; ?></li>
           <a href="#"> <li class="row_color2_edit"><img src="<?php echo CSSPATH; ?>images/pencil.png">Edit</li></a>
           <a href="<?php echo base_url();?>superadmin/company/disable_branch/<?php echo $comp_id; ?>/<?php echo $br_id; ?>"><li class="row_color4_edit"><img src="<?php echo CSSPATH; ?>images/remove.png" class="list_img"><p><?php echo $stat;?></p></li></a>
          </ul>
        </div>
        
       
        <?php if($i>=3){ $i=1; } $i++; } ?>
        
   
        
      </div>
      
    </div>
    
 <div class="super_newbranch_add">
 <h1> Add New Branch</h1>

<form action="<?php echo base_url()?>superadmin/company/create_branch" method="post">
    <div class="super_master-1">
           <div class="super_name">Branch Name :</div>         
<div class="super_master">

<input name="br_name" type="text" class="super_master_textfeild">
<input name="comp_id" type="hidden" value="<?php echo $comp_id;?>" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Address :</div>         
<div class="super_master">
<input name="br_address" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Contact :</div>         
<div class="super_master">
<input name="br_ph1" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Email :</div>         
<div class="super_master">
<input name="br_email1" type="text" class="super_master_textfeild">
          </div>
          </div>
    <input class="master-submit" type="submit" name="addcaterer" value="" />
    </form>
    
   </div> 
    
    
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->