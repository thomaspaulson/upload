<!--tab-->
<script>
$(document).ready(function(){

$("#payment").addClass("active");
	$(".tab_cont_01").slideDown();
	$(".tab_cont_02").hide();
	  $(".tab_02").removeClass("active");
  $(this).addClass("active");
	
	$(".tab_01").click(function(){
    $(".tab_cont_01").slideDown();
	$(".tab_cont_02,.tab_cont_03").hide();
	  $(".tab_02,.tab_03").removeClass("active");
  $(this).addClass("active");
});

	$(".tab_02").click(function(){
    $(".tab_cont_02").slideDown();
	$(".tab_cont_01,.tab_cont_03").hide();
	  $(".tab_01,.tab_03").removeClass("active");
  $(this).addClass("active");
});

$(".tab_03").click(function(){
    $(".tab_cont_03").slideDown();
	$(".tab_cont_01,.tab_cont_02").hide();
	  $(".tab_01,.tab_02").removeClass("active");
  $(this).addClass("active");
});


});
</script>
<!--tab end-->
<!--tab end-->
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Payment</h1>
    </div>
    
    <div class="super_addcaterer">
<div class="super_company_name">
     <div class="super_company_logo"><img src="<?php echo $comp_logo;?>"></div>
     <div class="super_company_logo_name"><h1><?php echo $comp_name; ?></h1></div>
    </div>
<div class="super_tab">
  <div class="super_tab_menu">
    <ul>
      <li class="tab_01 active">Payment</li>
      <li class="tab_02">Bank Details</li>
        <li class="tab_03">History</li>
    </ul>
  </div>
  <div class="super_tab_content tab_cont_01">
    <div class="super_master-1">
<?php $tot_paidall=0; foreach($pay as $data) { $tot_amtall= $data['pay_totamount'];  $tot_paidall=$tot_paidall+$data['pay_paid']; $tot_baldall=$data['pay_bal']; } ?>
<form action="<?php echo base_url()?>superadmin/company/newpay" method="post">
<input type="hidden" name="tot_bal" value="<?php echo $tot_baldall;?>"/>
<input type="hidden" name="pay_totamount" value="<?php echo $tot_amtall;?>"/>
<input type="hidden" name="comp_id" value="<?php echo $comp_id;?>"/>
           <div class="super_name">Total :</div>         
<div class="super_master">
<input name="name" type="text" value="<?php echo $tot_amtall;?>" class="super_master_textfeild" readonly>
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Paid Amount : </div>         
<div class="super_master">
<input name="name" type="text" value="<?php echo $tot_paidall;?>" class="super_master_textfeild" readonly>
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Balance Amount : </div>         
<div class="super_master">
<input name="name" type="text" value="<?php echo $tot_baldall;?>" class="super_master_textfeild" readonly>
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Amount Recieved :</div>         
<div class="super_master">
<input type="text" name="newpay_paid" class="super_master_textfeild">


          </div>
          </div>

<input type="submit" name="addcaterer" value="" class="master-submit"/>
</form>
    
  </div>
  
  <div class="super_tab_content tab_cont_02">
    <div class="super_master-1">
           <div class="super_name">Bank Name :</div>         
<div class="super_master">
<input name="name" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Branch :</div>         
<div class="super_master">
<input name="name" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Account No :</div>         
<div class="super_master">
<input name="name" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">IFSC :</div>         
<div class="super_master">
<input name="name" type="text" class="super_master_textfeild">
          </div>
          </div>
    
    
  </div>
  

<div class="super_tab_content tab_cont_03">

<?php $i=0;foreach($pay as $dat) { $i++;$comp_id=$dat['comp_id']; $tot_amt= $dat['pay_totamount']; $tot_paid= $dat['pay_paid']; $tot_bal= $dat['pay_bal']; $pay_date=$dat['pay_date']; $receipt_id=$dat['receipt_id']; $pay_description= $dat['pay_description'];?>

<?php if($i==1) { ?>

<div class="super_history_one"><p>Total Amount : <?php echo $tot_amt;?></p></div>

<?php } ?>




    <div class="super_history_two"> 
    <h1> <?php echo $i;?> </h1>
    <p>Received Amount : <span><?php echo $tot_paid;?></span>
    <br><br>
    Balance Amount : <span><?php echo $tot_bal;?></span>
    <br><br>
    Date :<span><?php echo $pay_date;?></span>
     <br><br>
     Receipt No : <span><?php echo $receipt_id;?></span>
     <br><br>
      Description :<span><?php echo $pay_description;?></span>
    </p>
    
    </div> 
    
<?php } ?>


    
   



        

  </div>


</div>

</div>
    
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>