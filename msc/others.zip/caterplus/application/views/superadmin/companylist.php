<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<table>
<tr>
<th>comp name</th>    
<th>address</th>
<th>phone</th>
<th>join date</th>
<th>status</th>
<th>email</th>
</tr>
<form action="" method="post">
<?php foreach($data as $dat) { $comp_id=$dat['comp_id'];?>
<tr>
<td><?php echo $dat['comp_name'];?></td>
<td><?php echo $dat['comp_address'];?></td>
<td><?php echo $dat['comp_ph1'];?></td>
<td><?php echo $dat['comp_joindate'];?></td>
<td><?php echo $dat['comp_status'];?></td>
<td><?php echo $dat['comp_email1'];?></td>
<td><a href="<?php echo base_url();?>superadmin/company/edit_company/<?php echo $comp_id;?>">EDIT</a></td>
</tr>
<?php } ?>

</form>
</table>
<body>
</body>
</html>