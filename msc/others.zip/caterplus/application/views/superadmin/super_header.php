<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Supe admin Dashboard</title>
<link href="<?php echo CSSPATH; ?>css/style.css" rel="stylesheet" type="text/css">
<link href='<?php echo CSSPATH; ?>css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo CSSPATH; ?>css/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src="<?php echo CSSPATH; ?>js/html5.js"></script>
<script src="<?php echo CSSPATH; ?>js/jquery-1.10.2.js"></script>
<link href="<?php echo CSSPATH; ?>css/jquery-ui.css" rel="stylesheet" type="text/css">
<script src="<?php echo CSSPATH; ?>js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo CSSPATH; ?>js/flexy-menu.js">
</script><script type="text/javascript">$(document).ready(function(){$(".flexy-menu").flexymenu({speed: 400,type: "vertical", indicator: true});});</script>
</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="<?php echo base_url()?>superadmin/login"><img src="<?php echo CSSPATH; ?>images/logo.png" alt=""></a></div>
    <div class="super_right "><!----> 
   <div class="super_header_search">
   <input name="search" type="text" class="super-textfeild">
   
   </div>
      <a href="<?php echo base_url()?>superadmin/addcaterer/add" class="logout"><img src="<?php echo CSSPATH; ?>images/add-new.png" alt="">
      <h6>Add-New</h6>
    </a>
      
      <a href="<?php echo base_url()?>superadmin/superlogout/super_logout" class="logout"><img src="<?php echo CSSPATH; ?>images/superadmin-logout.png" alt="">
      <h6>Logout</h6>
    </a> 
       
      <a href="#" class="logout"><img src="<?php echo CSSPATH; ?>images/superadmin-settings.png" alt="">
      <h6>Settings</h6>
    </a> </div>
  </div>
</header>