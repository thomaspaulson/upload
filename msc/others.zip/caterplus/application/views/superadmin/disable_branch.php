<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<?php //  print_r($data); ?>
<form action="<?php echo base_url()?>superadmin/company/disable_branch" method="post">
Branch name<select name="br_id">
<?php  foreach($data as $dat) {
$br_id=$dat['br_id']; $comp_id=$dat['comp_id']; $br_name= $dat['br_name']; $br_status=$dat['br_status']; ?>
<option value="<?php echo $br_id;?>"><?php echo $br_name;?></option>
<?php } ?>
</select>
<label>

</label>
<input type="hidden" name="comp_id" value="<?php echo $comp_id;?>"/><br />

<br />
<label>
change
</label>
<select name="change">
<?php if($br_status=='active') { ?>
<option value="deactivate">deactivate</option>
<?php } else { ?>
<option value="activate">activate</option>
<?php } ?>
</select>

<input type="submit" name="changestatus" value="Change"/>


<body>
</body>
</html>