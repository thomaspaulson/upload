<script>
$(document).ready(function(){

$("#remove").addClass("active");

});
</script>

<?php foreach($detail as $dat) $cur_status = $dat['comp_status'];if($cur_status=='active'){ $stat='Deactivate'; }else{ $stat='Activate'; } ?>

 <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Settings</h1>
    </div>
    <div class="event_list_main">
    <div class="super_company_name">
     <div class="super_company_logo"><img src="<?php echo $comp_logo;?>"></div>
     <div class="super_company_logo_name"><h1><?php echo $comp_name;?></h1></div>
    </div>

<div class="super_settings_main">
<div class="super_settings_hd">Are you sure want to<span> <?php echo $stat; ?></span> Iqbal Catering ?</div>
<div class="super_settings_yesmain">
 <a href="<?php echo base_url();?>superadmin/company/disable/<?php echo  $comp_id; ?>"> <li class="super_settings_yes">Yes</li></a>

</div>

</div>


<div class="super_settings_main">
<div class="super_settings_hd">Are you sure want to<span> Remove </span> Iqbal Catering Permanently ?</div>
<div class="super_settings_yesmain">
 <a href="<?php echo base_url();?>superadmin/company/delete_company/<?php echo  $comp_id; ?>"> <li class="super_settings_yes">Yes</li></a>    

</div>

</div>


    </div>

  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
