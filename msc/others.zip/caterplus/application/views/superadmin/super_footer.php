<!--========= content end ===============-->
<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
        <td><a href=""><img src="<?php echo CSSPATH;?>images/back.png" alt=""></a></td>
        <td align="center"><a href=""><img src="<?php echo CSSPATH;?>images/home.png" alt=""></a></td>
        <td align="right"><a href=""><img src="<?php echo CSSPATH;?>images/my_order.png" alt=""></a></td>
      </tr>
    </table>
  </div>
</footer>
</body>
</html>
