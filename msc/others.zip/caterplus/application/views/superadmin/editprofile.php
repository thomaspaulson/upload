<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="<?php echo base_url()?>superadmin/editprofile/update" method="post">
<?php foreach($data as $d) ?>
<label>fname</label>
<input type="text" name="fname" value="<?php echo $d['sa_fname']; ?> "/><br/>
<label>lname</label>
<input type="text" name="lname" value="<?php echo $d['sa_lname']; ?>"/><br/>

<label>Email</label>
<input type="text" name="email" value="<?php echo $d['sa_email']; ?>"/><br/>
<label>mobile</label>
<input type="text" name="mobile" value="<?php echo $d['sa_mob']; ?>"/><br/>

<label>username</label>
<input type="text" name="username" value="<?php echo $d['sa_username'];?> "readonly/><br/>
<label>Password</label>
<input type="text" name="password" value="" /><br/>

<br />
<input type="submit" name="editsuperadmin" value="Edit"/>
</form>
</body>
</html>