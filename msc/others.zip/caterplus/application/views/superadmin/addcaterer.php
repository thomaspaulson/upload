<!--tab-->
<script>
$(document).ready(function(){
$(".tab_cont_01").slideDown();
	$(".tab_cont_02,.tab_cont_03,.tab_cont_04").hide();
	  $(".tab_02,.tab_03,.tab_04").removeClass("active");
  $(this).addClass("active");


	$(".tab_01").click(function(){
    $(".tab_cont_01").slideDown();
	$(".tab_cont_02,.tab_cont_03,.tab_cont_04").hide();
	  $(".tab_02,.tab_03,.tab_04").removeClass("active");
  $(this).addClass("active");
});

	$(".tab_02").click(function(){
    $(".tab_cont_02").slideDown();
	$(".tab_cont_01,.tab_cont_03,.tab_cont_04").hide();
	  $(".tab_01,.tab_03,.tab_04").removeClass("active");
  $(this).addClass("active");
});

$(".tab_03").click(function(){
    $(".tab_cont_03").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_04").hide();
	  $(".tab_01,.tab_02,.tab_04").removeClass("active");
  $(this).addClass("active");
});

$(".tab_04").click(function(){
    $(".tab_cont_04").slideDown();
	$(".tab_cont_01,.tab_cont_02,.tab_cont_03").hide();
	  $(".tab_01,.tab_02,.tab_03").removeClass("active");
  $(this).addClass("active");
});

<!--nomber generate-->
$("#generate").click(function(){
	 lic1=Math.floor((Math.random()*10000)+1000);
	 	 lic2=Math.floor((Math.random()*10000)+1000);
		 	 lic3=Math.floor((Math.random()*10000)+1000);
			 	 lic4=Math.floor((Math.random()*10000)+1000);

lic=lic1+'-'+lic2+'-'+lic3+'-'+lic4;				 	
$("#license_feild").val(lic);
	
});
<!--nomber generate end-->
});
</script>
<!--tab end-->

<!--date picker-->

<script>
$(function() {
$( "#datepicker" ).datepicker({
changeMonth: true,
changeYear: true
});
});
</script>

<!--date picker end-->
<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"> <h1>Add Caterer</h1></div>
<div class="super_addcaterer">
<div class="super_tab">
  <div class="super_tab_menu">
    <ul>
      <li class="tab_01 active">Company</li>
      <li class="tab_02">License</li>
      <li class="tab_03">Branch</li>
      <li class="tab_04">Payment</li>
    </ul>
  </div>
  <div class="super_tab_content tab_cont_01">
    <div class="super_master-1">
           <div class="super_name">Company Name :</div>         
<div class="super_master">
<form action="<?php echo base_url()?>superadmin/addcaterer/create" method="post" enctype="multipart/form-data">

<input name="compname" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Address :</div>         
<div class="super_master">
<input name="compaddress" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Contact :</div>         
<div class="super_master">
<input name="compcontact" type="text" class="super_master_textfeild">
          </div>
          </div>
          <div class="super_master-1">
           <div class="super_name">Email :</div>         
<div class="super_master">
<input name="compemail" type="text" class="super_master_textfeild">
          </div>
          </div>
<div class="master-left-1">
           <div class="master-name">Logo:</div>         
<div class="master-select">
<input name="com_logo" type="file" class="master-textfeild">
          </div>
          </div>
   <!-- <input class="master-submit" type="submit" name="subscribe" value="" /> -->

    
  </div>
  
  <div class="super_tab_content tab_cont_02">
   
   <div class="super_master-1">
           <div class="super_name">License No :</div>         
<div class="super_master">
<input name="complicnum" type="text" class="license_textfeild" id="license_feild">
<a href="#"><div class="super_generate_button" id="generate">Generate</div></a>
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Valid From :</div>         
<div class="super_master">
<input name="complicfrom" type="text" class="license_textfeild" >
<a href="#"></a>
          </div>
          </div>
          
          <div class="super_master-1">
           <div class="super_name">Valid To :</div>         
<div class="super_master">
<input name="complicto" type="text" class="license_textfeild" >
<a href="#"></a>
          </div>
          </div>
          
      <!--    <input class="super-submit" type="submit" name="subscribe" value="" /> -->

  </div>
  
  <div class="super_tab_content tab_cont_03">
    
    <div class="master-left-1">
           <div class="master-name">Branch Name :</div>         
<div class="master-select">
<input name="brname" type="text" class="master-textfeild">
          </div>
          </div>
          <div class="master-left-1">
           <div class="master-name">Address :</div>         
<div class="master-select">
<input name="braddress" type="text" class="master-textfeild">
          </div>
          </div>
          
          <div class="master-left-1">
           <div class="master-name">Email :</div>         
<div class="master-select">
<input name="bremail" type="text" class="master-textfeild">
          </div>
          </div>


<div class="master-left-1">
           <div class="master-name">Contact:</div>         
<div class="master-select">
<input name="brcontact" type="text" class="master-textfeild">
          </div>
          </div>
         <!-- <a href=""><div class="super_addmore_branch"> Add more branch</div></a>-->
          
  <!--   <input class="master-submit" type="submit" name="subscribe" value="" /> -->
    
  </div>
  
  <div class="super_tab_content tab_cont_04">
   
   <div class="master-left-1">
           <div class="master-name">Total Payment :</div>         
<div class="master-select">
<input name="totpay" type="text" class="master-textfeild">
          </div>
          </div>
          <div class="master-left-1">
           <div class="master-name">Received :</div>         
<div class="master-select">
<input name="received" type="text" class="master-textfeild">
          </div>
          </div>
          <div class="master-left-1">
           <div class="master-name">Description:</div>         
<div class="master-select">
<input name="pay_description" type="text" class="master-textfeild">
          </div>
          </div>
 <input class="master-submit" type="submit" name="subscribe" value="" />

  </div>
  
</div>

</div>



</div>
  <div class="clear"></div>
</div>




















