<script>
    function setupLabel() {
        if ($('.label_check input').length) {
            $('.label_check').each(function(){ 
                $(this).removeClass('c_on');
            });
            $('.label_check input:checked').each(function(){ 
                $(this).parent('label').addClass('c_on');
            });                
        };
        if ($('.label_radio input').length) {
            $('.label_radio').each(function(){ 
                $(this).removeClass('r_on');
            });
            $('.label_radio input:checked').each(function(){ 
                $(this).parent('label').addClass('r_on');
            });
        };
    };
    $(document).ready(function(){
  $('#module').addClass('active');
        $('body').addClass('has-js');
        $('.label_check, .label_radio').click(function(){
            setupLabel();
        });
        setupLabel(); 
    });
</script>
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Privileges</h1>
    </div>
    <div class="event_list_main">
    <div class="super_company_name">
     <div class="super_company_logo"><img src="images/small_logo.png"></div>
     <div class="super_company_logo_name"><h1>Iqbal Catering</h1></div>
    </div>
      <div class="dashbord_itemlist">
       
        <div class="row_color1">
          <ul>
            <li class="super_privileges_name">Module Name </li>
            <li class="super_privilege_action">Activate</li>
            <li class="super_privilege_action">Deactivate</li>
          </ul>
        </div>
        <div class="row_color2">
          <ul>
            <li class="super_privileges_name">Module 1 </li>
            <li class="super_privilege_action"> 
           
                <label class="label_check c_on" for="checkbox-01">
                  <input name="sample-checkbox-01" id="checkbox-01" value="1" checked="checked" type="checkbox">
                  </label>
             
           </li>
            <li class="super_privilege_action"> 
                <label class="label_check c_on" for="checkbox-02">
                  <input name="sample-checkbox-01" id="checkbox-02" value="1" checked="checked" type="checkbox">
                  </label>
               </li>
          </ul>
        </div>
        
        <div class="row_color3">
          <ul>
            <li class="super_privileges_name">Module 1 </li>
            <li class="super_privilege_action"> <label class="label_check c_on" for="checkbox-03">
                  <input name="sample-checkbox-01" id="checkbox-03" value="1" checked="checked" type="checkbox">
                  </label></li>
            <li class="super_privilege_action"><label class="label_check c_on" for="checkbox-04">
                  <input name="sample-checkbox-01" id="checkbox-04" value="1" checked="checked" type="checkbox">
                  </label></li>
          </ul>
        </div>
        <div class="row_color2">
          <ul>
            <li class="super_privileges_name">Module 1 </li>
            <li class="super_privilege_action"> <label class="label_check c_on" for="checkbox-05">
                  <input name="sample-checkbox-01" id="checkbox-05" value="1" checked="checked" type="checkbox">
                  </label> </li>
            <li class="super_privilege_action"><label class="label_check c_on" for="checkbox-06">
                  <input name="sample-checkbox-01" id="checkbox-06" value="1" checked="checked" type="checkbox">
                  </label></li>
          </ul>
        </div>
        
      </div>
      
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->
