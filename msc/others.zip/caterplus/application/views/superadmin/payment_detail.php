<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>


<?php $i=0;foreach($pay as $dat) { $i++;$comp_id=$dat['comp_id']; $tot_amt= $dat['pay_totamount']; $tot_paid= $dat['pay_paid']; $tot_bal= $dat['pay_bal']; $pay_date=$dat['pay_date']; $receipt_id=$dat['receipt_id'];  ?>

<form action="<?php echo base_url()?>superadmin/company/newpay" method="post">
<?php if($i==1) { ?>
<label>
Total Amount : <?php echo $tot_amt;?>
</label>
<?php } ?>
<br />
<input type="hidden" name="tot_bal" value="<?php echo $tot_bal;?>"/>
<input type="hidden" name="pay_totamount" value="<?php echo $tot_amt;?>"/>
<input type="hidden" name="comp_id" value="<?php echo $comp_id;?>"/>
<label> 
Received : <?php echo $tot_paid;?>
</label><br />

<label>
Balance : <?php echo $tot_bal;?>
</label><br />
<label>
Date: <?php echo $pay_date;?>
</label><br />
<label><a>Receipt No : </a></label><?php echo $receipt_id;?>
<br /><br />
<?php } ?>
<label>
New Payment : 
</label><input type="text" name="newpay_paid"/><br />
<input type="submit" name="addcaterer" value="submit"/>
</form>
<body>
</body>
</html>