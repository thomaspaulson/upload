 
                
                 <!--   <script type="text/javascript">
                    	$(document).ready (function(){
							$('#sadvance').click (function(){
								$('.hide_serch').slideToggle()
							});
						});
                    </script> -->
                </div>
                </div>
        </header>
        <div class="container">
                <div class="row custemor_dtls ">
                	<div class="col-md-12">
                     <script type="text/javascript" src="<?php echo base_url()?>extras/mergeddesign/js/cycle.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
			$('.slider_wrap').cycle({ 
				fx:     'scrollHorz', 
				speed:  1000, 
				timeout: 5000,
				 timeout: 0,
				slideExpr:".slider",
				pager: ".pager233",
				 next: ".nxt0", 
				 prev:  ".prv0",
				
			});			
	});
</script>
<?php 
if($this->session->flashdata('message'))
{
  echo '<div class="col-md-12 col-sm-6"> <div class="panel panel-success">
                        <div class="panel-heading">';
  echo $this->session->flashdata('message');
  echo '</div> </div></div>'; 
}?>
                    <ul>
                    	<li class="main_header"><p>Item Details</p>
<div class="row search_cus newstyleedited" >
                	<div class="col-md-12">

                    	<form action="<?php echo base_url();?>items/search"  class="search-item" id="search_item"> 
                        	 <input type="text" placeholder="Search Items" name="search" id="search" autocomplete="off" value="<?php echo $search_term; ?>" class="validate[required]" required>
                            <input name="" type="submit" value="Search Menu"> 
 
	

<a href="<?php echo base_url();?>items/addform" id="sadvance">New Item</a>
 </form>
 <ul class="results" id="results">
                           <!-- <a href="#" id="sadvance"> Advanced search</a>
                            <div class="clearfix"></div>
                            <div class="hide_serch"><input type="text" placeholder="Name">
                            <input type="text" placeholder="Last Name">
                            <input name="" type="submit" value="Search customer"> -->
                            </div>
                        
                    </div>
<?php if((count($contents)>15) || (count($contents)==0)){?>  
                        	<div class="pag_nav">
                            	<a href="#"  class="prv0"><img src="<?php echo base_url()?>extras/mergeddesign/images/prev_p.png" width="29" height="31"></a>
                                <a href="#" class="nxt0"><img src="<?php echo base_url()?>extras/mergeddesign/images/nxtp.png" width="29" height="31"></a>
                            </div>
<?php } ?>
                      </li>
                      </ul>
                      <div class="slider_wrap wr">

<?php if(count($contents)<=15){?>  

<ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                                            
                                <li class="otheritem_fld">Image</li>  
                                 <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li> 
    <?php     $totcount =  count($contents); //echo $totcount; ?>     
  
                       <?php $i=0;foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;} ?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><?php echo $value['itemname']?></a></li>
                                <li class="otheritem_fld"><img src="<?php echo base_url(),'uploads/items/',$value['item_image'];?>" width="100" height="75"></li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png" title="Edit"/></a> <a href="<?=base_url()?>items/changestatus/<?php echo $value['itemid'];?>" >
								                  
 <?php if ($value['item_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif" title="Click to Inactive"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif" title="Click to Activate"/> <?php } ?></a>
 
 <a href="#" onclick="reset(<?php echo $value['itemid']?>)" class="btn btn-danger">Delete</a>
 
 </li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }?>
                                            
                    </ul>

<?php } else { ?>


                     <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                                            
                                <li class="otheritem_fld">Image</li>  
                                 <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li> 
    <?php     $totcount =  count($contents); //echo $totcount; ?>     
  
                       <?php $i=0;foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}  if($i<=15){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><?php echo $value['itemname']?></a></li>
                                <li class="otheritem_fld"><img src="<?php echo base_url(),'uploads/items/',$value['item_image'];?>" width="100" height="75"></li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>items/changestatus/<?php echo $value['itemid'];?>" >
								                  
 <?php if ($value['item_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a>
 
  <a href="#" onclick="reset(<?php echo $value['itemid']?>)" class="btn btn-danger">Delete</a>
 </li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                                            
                    </ul>

                  <ul class="slider wr">
                      	<li class="sub_header">
                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                 <li class="otheritem_fld">Image</li>  
                               <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li>
                     <?php $i=0;  foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}   if(($i<=30)&&($i>15)){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><?php echo $value['itemname']?></a></li>
                                <li class="otheritem_fld"><img src="<?php echo base_url(),'uploads/items/',$value['item_image'];?>" width="100" height="75"></li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>items/changestatus/<?php echo $value['itemid'];?>" >
								                  
 <?php if ($value['item_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                    </ul>

 <ul class="slider wr">
                      	<li class="sub_header">
                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                 <li class="otheritem_fld">Image</li>  
                               <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li>
                     <?php $i=0;  foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}   if($i>30){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><?php echo $value['itemname']?></a></li>
                                <li class="otheritem_fld"><img src="<?php echo base_url(),'uploads/items/',$value['item_image'];?>" width="100" height="75"></li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>items/changestatus/<?php echo $value['itemid'];?>" >
								                  
 <?php if ($value['item_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                    </ul>
<?php } ?>
                    </div>
                    </div>
                </div>
<script>
	var base_url = "<?php echo base_url(); ?>";	
</script>

<script type="text/javascript">
    function reset(id)
    {
        var r = confirm("Are you sure you want to delete?? ");
        if (r == true) {

            window.location = "<?php echo base_url(); ?>items/delete_item/"+ id;
        }
    }
    function displayDiv(i, c)
    {
        alert(i);
    }
</script>
<script>
	$("#search").keyup(function(){
		var search_key = $("#search").val();
		$("#results").css("visibility", "visible");
		if(search_key != ''){				
			$.ajax({
		                type: "GET",
		                url: base_url + "staff/get_search",
		                data: {
		                    'search_keyword' : search_key
		                },
		                success: function(msg){
					$('#results').html(msg);
		                }
	           	 });
	        }else{
        		$('#results').css("visibility", "hidden");		
		}
	});

	$( "#search" ).focus(function() {
		$("#results").css("visibility", "visible");		
	});
</script>


<script>
$(document).mouseup(function (e)
{
    var container = $(".main");
    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        $('#results').css("visibility", "hidden");
    }
});
</script>

                <footer>
                 <ul>
                 	
                    <li>
                    	<a href="<?php echo base_url();?>">Home</a>
                    </li>
                   
                    <li>
                    	<a href="<?php echo base_url();?>items/addform">Add Item</a>
                    </li>
                   
                 </ul>
                 </footer>
          </div>  
</body>
</html>