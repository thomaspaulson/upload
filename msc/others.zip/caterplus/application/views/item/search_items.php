<?php
	foreach($contents as $content){
	$key_words= explode(' ',$content['itemname']);
	$key_words = implode('+',$key_words);
?>
	 <li><a  href="<?php echo base_url(),'items/search?search=',$key_words; ?>"><?php echo $content['itemname']?></span></a></li>
<?php
	}
?>			