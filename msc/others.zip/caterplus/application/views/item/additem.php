<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>ADD ITEM</h1></div>
<div class="msprogrm-main">
<form  id="add-items"  action="<?php echo base_url();?>items/insert" method="post" name="addForm" enctype="multipart/form-data">
<div class="msprogrm-left">

<!----><div class="master-left-1">
           <div class="master-name">Select Category: *</div>         
<div class="master-select">
<select class="required validate[required]" id="menutype[]" name="menutype[]" >
<option value="">select</option>
	<?php  
		foreach($menutype as $row){ 
	?>								
			<option value="<?php echo $row['menutypeid'] ;?>"><?php echo $row['menutypename']; ?></option>																	
	<?php 
		} 
	?>
</select>
          </div>
          </div>
          

         <!---->
         <div class="master-left-1">
           <div class="master-name">Item Name: *</div>         
<div class="master-select">
<input class="required validate[required] master-textfeild" id="itemname" type="text" name="itemname" value="<?php echo set_value('itemname'); ?>" />
          </div>
          </div>
          



  <!---->
         <div class="master-left-1">
           <div class="master-name">Description: *</div>         
<div class="master-select">
<textarea name="itemdescription" id="txtenq" cols="" rows="" class="master-textfeild"></textarea>
          </div>
          </div>
          




         
         <div class="master-left-1">
           <div class="master-name">Item Units: *</div>         
<div class="master-select">
<select class="required validate[required]" id="itemunits" name="itemunits" >
			<?php 
				foreach($units as $unit){
					
			?>
			<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
			<?php
				}	
			?>

</select>
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Item Price: *</div>         
<div class="master-select">
 <input class="validate[custom[number]] master-textfeild" id="itemprice" type="text" name="itemprice" value="" />
          </div>
          </div>
          <label>Select Ingredients</label>
           <?php /*  hide quantity and use hidden
         <div class="master-left-1">
           <div class="master-name">Item Quantity: *</div>         
<div class="master-select">
<input class="required validate[custom[number]] master-textfeild" id="itemqty" type="text" name="itemqty" value="1" />
          </div>
          </div>
          */ ?>
<input class="required validate[custom[number]] master-textfeild" id="itemqty" type="hidden" name="itemqty" value="1" />
 <!---->
     <?php /* hide    <div class="master-left-1">
           <div class="master-name">Item Unit: *</div>         
<div class="master-select">
<select class="required" id="itemunit" name="itemunit">
			<?php 
				foreach($units as $unit){
					
			?>
			<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
			<?php
				}	
			?>


</select>
          </div>
          </div> */ ?>
          <!---->


<!---->
         <div class="master-left-1">
           <div class="master-name">COOKING INSTRUCTIONS:  *</div>         
<div class="master-select">
<textarea name="instructions" id="instructions" cols="" rows="" class="master-textfeild"></textarea>
          </div>
          </div>
          <!---->







</div>
<div class="msprogrm-right">
 <div class="master-left-1">
           <div class="msprgrm-name">Ingredients: *  </div>
             
   <!--button-->
<p><a data-toggle="modal" href="#myModal"><img src="<?php echo base_url()?>extras/new/images/more-button.png" align="left" alt=""/></a></p> 
 <!--button-->  
             <!------------------------------------------------------------------------------------------------------------------------------->
                  
<div class="master-select">
<select id="inglist" name="inglist">
            <option value="">--Select Ingredients--</option>
          <?php
		foreach($ingredients as $ingredient){
	?>
             <option value="<?php echo $ingredient['ingredientid'];  ?>"><?php echo $ingredient['ingredientname'];  ?></option>
            
             <?php
			}	
		?>
                        </select>
                 
                      
                        
                        
                        
                        
                        
          </div>
          </div>
          
           <!---------->
         <div class="master-left-1">
           <div class="master-ingmore" id="ingmain">
                
           </div>        
          </div>
         
         <div class="master-left-1">
           <div class="master-namemore">Included in special event: *</div>         
<div class="master-left-2">
<div >
	<input  type="checkbox" name="included_specialevent" value="yes" id="included_specialevent" />
	
</div>
    
          </div>
                   
          </div>
        
          
          
           <!---->
         <div class="master-left-1">
           <div class="master-name"><input id="itemtemp" type="checkbox" name="itemtemperaturecheck" value="yes" />TEMPERATURE: *</div>         
<div class="master-select">
<input class="validate[custom[number]] master-textfeild"  type="text" maxlength="20" name="temperaturevalue"  />
</div>
          </div>
           <!---->
 <!---->
         <div class="master-left-1">
           <div class="master-name">Packages: *</div>     
<div class="master-select">
<select class="required validate[required]" id="item_packages[]" name="item_packages[]" multiple>
	<?php  
		foreach($packages as $row){ 
	?>								
			<option value="<?php echo $row['specialp_id'] ;?>"><?php echo $row['specialp_name']; ?></option>																	
	<?php 
		} 
	?>
</select>
</div>
          </div>
           <!---->
         <div class="master-left-1">
           <div class="master-name">BROWSE FILE : *</div>         
<div class="master-select">
<input name="userfile" id="userfile" type="file" class="form_field_browsestyle validate[required]">
          </div>
          </div>
         
        <input class="master-submit" id="mc-embedded-subscribe" type="submit" name="action" value="" />

</div>
          
        
</form>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->

<script>
   $('#inglist').on('change',function() {
   
var ingid=($('#inglist option:selected').val()); //overrule default selection
if(ingid!="")
{
var ingname=($('#inglist option:selected').text());
$('#inglist option:selected').attr('disabled','disabled');
var dividremove="inglist_"+ingid;



var newdiv=' <div class="master-ingmore-1" id="inglist_'+ingid+'"><input id="ingredients" type="checkbox" name="ingredients[]" value="'+ingid+'" style="display:none;" checked/><div class="master-ingmore-name" id="ingitem1">'+ingname+'</div><div class="master-ingmoreselect"><select id="itemunits_'+ingid+'" name="itemunits_'+ingid+'" class="validate[required]"><option value=" ">Select Unit</option><?php foreach($units as $unit){ ?><option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option><?php } ?></select></div><div class="master-select"><input id="ing_qty_'+ingid+'" name="ing_qty_'+ingid+'" type="text" class="validate[required,custom[integer]] master-ingmoretextfeild" placeholder="quantity"></div><div class="master-closebutton"><a><img src="<?php echo base_url()?>extras/new/images/close-button.png" id="ingclose" onclick="removeing('+"'"+dividremove+"'"+','+ingid+')"></a></div></div>';

$('#ingmain').append(newdiv);
}
});
</script>
<script>
   
function removeing(toremoveid,ingid){
$('#inglist option[value='+ingid+']').removeAttr('disabled');
$('#'+toremoveid).remove();
	}

</script>




<!--bootstrp pooup starting-->

<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h3 class="modal-title">ADD Ingredient</h3>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo base_url()?>ingredientquantity/addnew_ingredient" name="ingform" id="ingform">
<p id="showmessage"></p>
Ingredient Name<p><input type="text" class="form-control" name="ingredient_name" id="ingredient_name" ></p>
Ingredient Price<p><input type="text" class="form-control" name="ingredient_price" id="ingredient_price" ></p>
Ingredient Unit<p><select   class="form-control"  name="ingredientqty_type" id="ingredientqty_type">
			<?php 
				foreach($units as $unit){
					
			?>
			<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
			<?php
				}	
			?>


</select></p>
Current Stock<p><input type="text" class="form-control" name="ingredient_stock" id="ingredient_stock" ></p>
Reorder Level<p><input type="text" class="form-control" name="ingredient_reorderlevel" id="ingredient_reorderlevel" ></p>
 
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
  <button type="button" class="btn btn-default" data-dismiss="modal" id="saveingredient">Save changes</button> 
     <!-- <button type="button" class="btn btn-primary" name="saveingredient" id="saveingredient">Save changes</button>-->

    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<!--bootstrp pooup ending-->

<script>

$("#saveingredient").click(function(e) {

if( document.ingform.ingredient_name.value == "" )
   {
  // $("#showmessage").html("Invalid Ingredient Name");
   //  document.ingform.ingredient_name.focus() ;            
   }
   else if(document.ingform.ingredient_price.value == "" ){}
   else if(document.ingform.ingredient_stock.value == "" ){}
   else if(document.ingform.ingredient_reorderlevel.value == "" ){}
 else
{
   $("#showmessage").html(""); e.preventDefault();
  var ingredient_name = $("#ingredient_name").val(); 
  var ingredient_price = $("#ingredient_price").val();
  var ingredientqty_type = $("#ingredientqty_type").val();  //unit
  var ingredient_stock = $("#ingredient_stock").val();
  var ingredient_reorderlevel = $("#ingredient_reorderlevel").val();
  var dataString = 'ingredient_name='+ingredient_name+'&ingredient_price='+ingredient_price+'&ingredientqty_type='+ingredientqty_type+'&ingredient_stock='+ingredient_stock+'&ingredient_reorderlevel='+ingredient_reorderlevel;
  $.ajax({
    type:'POST',
    data:dataString,
    url:'<?php echo base_url()?>saveingredient/save',
    success:function(data) {
    if(data!=0)
    {
    retdata='<option value="'+data+'">'+ingredient_name+'</option>'; 
           $('#inglist').append(retdata);
      }
      else { /*alert("Some Error Occured,Try Again"); */ }
    }
  });
  } //else end
});

</script>
