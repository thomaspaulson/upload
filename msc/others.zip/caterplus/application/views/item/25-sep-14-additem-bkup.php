<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">
<div class="col-md-3 col-sm-3">
 <div class="listing_title"> <img src="<?php echo base_url();?>extras/extra/images/add-item.png"/></div>
</div> 
  <div class="col-md-3 col-sm-3 pull-right">
 <div class="listing_title"> <a href="<?php echo base_url();?>items/listall" /><img src="<?php echo base_url();?>extras/extra/images/back-to-list.png"/></a></div>
</div>   
 
    
   <div class="list_line"></div> 
   
   <div class="list_table">
   
   <form class="validate" id="add-items"  action="<?php echo base_url();?>items/insert" method="post" name="addForm" enctype="multipart/form-data">
<div class="list_table-2">


<div class="mc-field-group"><label for="FNAME">Select Category:  <span class="asterisk">*</span><br />
</label><br />
<select class="required validate[required]" id="required-1" name="menutype[]" >
<option value="">select</option>
	<?php  
		foreach($menutype as $row){ 
	?>								
			<option value="<?php echo $row['menutypeid'] ;?>"><?php echo $row['menutypename']; ?></option>																	
	<?php 
		} 
	?>
</select>
</div>




<div class="mc-field-group"><label for="mce-LNAME">Item Name: <span class="asterisk">*</span><br />
</label><br />
<input class="required validate[required]" id="required-1" type="text" name="itemname" value="<?php echo set_value('itemname'); ?>" /></div>

<div class="mc-field-group"><label for="mce-EMAIL">Description: <br />
</label><br />
 <textarea name="itemdescription" id="txtenq" cols="" rows="" class="area"></textarea></div>
 
 <div class="mc-field-group"><label for="mce-MMERGE3-addr1">Included in Special Event: <br />
</label><br />
<input id="mce-group[12357]-12357-0" type="checkbox" name="included_specialevent" value="yes" /></div>
<div class="mc-address-group">
<div class="mc-field-group"><label for="mce-MMERGE3-addr2">Item Units:</label><br />
<select class="required validate[required]" id="required-1" name="itemunits" >
			<?php 
				foreach($units as $unit){
					
			?>
			<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
			<?php
				}	
			?>

</select></div>
<div class="mc-field-group size1of2"><label for="mce-MMERGE3-city">Item Price:</label><br />
<input class="required validate[required,custom[number]]" id="required-1" type="text" name="itemprice" value="" /></div>


<h4>SELECT INGREDIENTS</h4>

<div class="mc-field-group size1of2"><label for="mce-MMERGE3-state">Item Qty:</label><br />
<input class="required validate[custom[number]]" id="required-1" type="text" name="itemqty" value="" /></div>

<div class="mc-field-group"><label for="mce-MMERGE3-addr2">Item Units:</label><br />
<select class="required" id="required-1" name="itemunit">
			<?php 
				foreach($units as $unit){
					
			?>
			<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
			<?php
				}	
			?>


</select></div>

<div class="mc-field-group"><label for="mce-EMAIL">Cooking Instructions: <br />
</label><br />
 <textarea name="instructions" id="txtenq" cols="" rows="" class="area"></textarea></div>
</div>

<div class="clear" id="mce-responses"></div>

</div>

<!--2-->

<div class="list_table-2">
	<?php
		foreach($ingredients as $ingredient){
	?>
	
	<div class="required-mainck">
	<input id="ingredients" type="checkbox" name="ingredients[]" value="<?php echo $ingredient['ingredientid'];  ?>" class="" /><label for=""><span class="chicken"><?php echo $ingredient['ingredientname'];  ?></span></label><input class="required-2"  type="text" maxlength="20" name="ing_qty_<?php  echo $ingredient['ingredientid']; ?>" id="ingredientquantity"  />
	
	<select class="required" id="required-3" name="itemunits_<?php  echo $ingredient['ingredientid']; ?>">
		<option value=" ">Select Unit</option>
		<?php 
			foreach($units as $unit){						
		?>
		<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
		<?php
			}	
		?>
	</select>
	</div>
	
	<?php
		}				
	?>

<!--button-->
<p><a data-toggle="modal" href="#myModal"><img src="<?php echo base_url();?>extras/extra/images/button-dark-plus-icon.png" align="left" alt=""/></a></p> 
 <!--button-->

<div class="required-mainck">
<input id="itemtemp" type="checkbox" name="itemtemperaturecheck" value="1" /><label for=""><span class="chicken">Temperature :</span></label><input class="required-4"  type="text" maxlength="20" name="temperaturevalue"  />
</div>


<div class="mc-field-group"><label for="FNAME">Select Packages:  <span class="asterisk">*</span><br />
</label><br />
<select class="required validate[required]" id="required-1" name="item_packages[]" multiple>
	<?php  
		foreach($packages as $row){ 
	?>								
			<option value="<?php echo $row['specialp_id'] ;?>"><?php echo $row['specialp_name']; ?></option>																	
	<?php 
		} 
	?>
</select>
</div>


  <div class="mc-field-group"><label for="mce-MMERGE3-addr1">Accompaniments: <span class="asterisk">*</span><br />
</label><br />
<input id="mce-group[12357]-12357-0" type="checkbox" name="check_accompaniments" value="yes" onClick="test()"/>
 			<span id="showaccompaniments" style="display:none;"><label>Select Accompaniments:</label> <br />
						<select class="required" id="required-1" name="accompaniments[]"  multiple>
								
								<?php  foreach($accompaniments as $row){ ?>								
								
									<option value="<?php echo $row['accompanimentsid'] ;?>"><?php echo $row['accompanimentsname']; ?></option>
										<?php } ?>			
							</select>
							</span>

</div>

<div class="form_field_name">Browse file :</div>
 <div class="form_field_textfield"><input name="userfile" id="userfile" type="file" class="form_field_browsestyle validate[required]"></div>

<div class="clear" id="mce-responses"></div>
<div class="clear"><input class="button" id="mc-embedded-subscribe" type="submit" name="action" value="Submit" /></div>
<div class="clear" id="mce-responses"></div>

</div>

</form>


</div>

   </div>
   
   
   </div>
    
  </div>



 
 <!--bootstrp pooup starting-->
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h3 class="modal-title">ADD Ingredient</h3>
      </div>
      <div class="modal-body">
        <form method="post" action="<?php echo base_url()?>ingredientquantity/addnew_ingredient">
Ingredient Name<p><input type="text" class="form-control" name="ingredient_name"></p>
Ingredient Price<p><input type="text" class="form-control" name="ingredient_price"></p>
Ingredient Unit<p><select   class="form-control"  name="ingredientqty_type">
			<?php 
				foreach($units as $unit){
					
			?>
			<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
			<?php
				}	
			?>


</select></p>
Current Stock<p><input type="text" class="form-control" name="ingredient_stock"></p>
Reorder Level<p><input type="text" class="form-control" name="ingredient_reorderlevel"></p>
 <input type="submit" value="Save changes" name="save">
</form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
<button type="button" class="btn btn-primary">Save changes</button>

    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<!--bootstrp pooup ending-->
 
<script type="text/javascript">
function test(){
 if($("input[name=check_accompaniments]").is(':checked')){
 	document.getElementById("showaccompaniments").style.display="block";
 }
 else{
 	document.getElementById("showaccompaniments").style.display="none";
 }
}

</script>


</body>
</html>