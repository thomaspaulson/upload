<script type="text/javascript">
function test(){
 if(document["addForm"]["check_accompaniments"].checked){
 document.getElementById("showaccompaniments").style.visibility="visible"
 }
 else{
 document.getElementById("showaccompaniments").style.visibility="hidden"
 }
}

$(document).ready(function()
{
if(document["addForm"]["check_accompaniments"].checked){
 document.getElementById("showaccompaniments").style.visibility="visible"
 }
 else{
 document.getElementById("showaccompaniments").style.visibility="hidden"
 }

});

</script>
<div id="content_wrapper">
<div class="container">
<div class="row content_bg">
<div class="listing_inner">
<div class="col-md-3 col-sm-3">
 <div class="listing_title"> Edit ITEMS</div>
</div> 
    
  <div class="col-md-3 col-sm-3">
 <div class="listing_title"> <a href="<?php echo base_url();?>items/listall" /><img src="<?php echo base_url();?>extras/extra/images/back-to-list.png"/></a></div>
</div>   
    
   <div class="list_line"></div> 
   
   <div class="list_table">
   
   <form class="validate" id="add-items"  action="<?php echo base_url();?>items/update" method="post" name="addForm" enctype="multipart/form-data">
<div class="list_table-2">


<div class="mc-field-group"><label for="FNAME">Select Category:  <span class="asterisk">*</span><br />
</label><br />
<select class="required validate[required]" id="required-1" name="menutype[]" >

<?php foreach($menutype as $row){ ?>
							
									<option value="<?php echo $row['menutypeid'] ?>" <?php if($data['menutype']==$row['menutypeid']) echo "selected=selected"; ?>><?php echo $row['menutypename']; ?></option>

						
								
									<?php } ?>		

</select>
</div>




<div class="mc-field-group"><label for="mce-LNAME">Item Name: <span class="asterisk">*</span><br />
</label><br />
<input class="required validate[required]" id="required-1" type="text" name="itemname" value="<?php echo $data['itemname'];?>" /></div>

<div class="mc-field-group"><label for="mce-EMAIL">Description: <br />
</label><br />
 <textarea name="itemdescription" id="txtenq" cols="" rows="" class="area"><?php echo $data['itemdescription']; ?> </textarea></div>
 
 <div class="mc-field-group"><label for="mce-MMERGE3-addr1">Included in Special Event: <span class="asterisk">*</span><br />
</label><br />
	<input type="checkbox"  name="included_specialevent" 
				<?php if($data['included_specialevent']=='yes') { echo "checked"; } ?>
				value="yes" id="mce-group[12357]-12357-0"/>
</div>
<div class="mc-address-group">
<div class="mc-field-group"><label for="mce-MMERGE3-addr2">Item Units:</label><br />
<select class="required validate[required]" id="required-1" name="itemunits">
			
			<option value="<?php echo $data['itemunits'];  ?>"><?php echo ucfirst($data['itemunits']);  ?></option>
			<?php
							foreach($units as $unit){
								if($data['itemunits'] != $unit['unit_name']){
							?>
							<option value="<?php echo $unit['unit_name'];  ?>"><?php echo ucfirst($unit['unit_name']);  ?></option>				
							
							<?php
								}
							}
							?>

</select></div>
<div class="mc-field-group size1of2"><label for="mce-MMERGE3-city">Item Price:</label><br />
<input class="required validate[required,custom[number]]" id="required-1" type="text" name="itemprice" value="<?php echo $data['itemprice'];?>" /></div>


<h4>SELECT INGREDIENTS</h4>

<div class="mc-field-group size1of2"><label for="mce-MMERGE3-state">Item Qty:</label><br />
<input class="required" id="required-1" type="text" name="itemqty" value="<?php if($ingitem != 0){echo $ingitem[0]['item_qty'];} ?>" /></div>

<div class="mc-field-group"><label for="mce-MMERGE3-addr2">Item Units:</label><br />
<select class="required" id="required-1" name="ingitem_unit">

			<?php
				if($ingitem != 0){
			?>
						<option value="<?php echo  $ingitem[0]['item_unit']; ?>"><?php echo $ingitem[0]['item_unit']; ?></option>
			<?php
				}
			?>
			
			<?php
			foreach($units as $unit){			
				  if($ingitem[0]['item_unit'] != $unit['unit_name']){ 
			?>
			<option value="<?php echo $unit['unit_name'];  ?>"><?php echo ucfirst($unit['unit_name']);  ?></option>				
			
			<?php
	                          }
			}
			?>


</select></div>

<div class="mc-field-group"><label for="mce-EMAIL">Cooking Instructions: <br />
</label><br />
 <textarea name="instructions" id="txtenq" cols="" rows="" class="area"><?php echo $data['instructions']; ?></textarea></div>
</div>

<div class="clear" id="mce-responses"></div>

</div>

<!--2-->

<div class="list_table-2">
	<?php
	                            if($ingitem !=0){
						foreach($ingitem as $item){						
					?>
	<div class="required-mainck">
	<input id="" type="checkbox" checked name="ingredients[]" value="<?php echo $item['ing_id'];  ?>" class=""/><label for=""><span class="chicken"><?php echo $item['ingredientname'];  ?> </span></label><input class="required-2"  type="text" maxlength="20" name="ing_qty_<?php  echo $item['ingredientid']; ?>" value="<?php echo $item['ing_qty'];  ?>" id="ingqty"/>
	
	<select class="required" id="required-3" name="itemunits_<?php  echo $item['ingredientid']; ?>">
		<option value="<?php echo $item['ing_unit'] ?>"><?php echo ucfirst($item['ing_unit']); ?></option>
		<?php 
							foreach($units as $unit){
								if($item['ing_unit'] != $unit['unit_name'] ){						
						?>
						<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>					
						<?php
								}
							}					
						?>
	</select>
	</div>
	
	<?php
	          }
		}				
	?>
	<?php
						$ing_id_array = array();
						if($ingitem !=0){
							foreach($ingitem as $item){
								$ing_id_array[] = $item['ing_id']; 	
							}
						}
						foreach($ingredients as $ingredient){
							if(!in_array($ingredient['ingredientid'],$ing_id_array)){
					?>
				<div class="required-mainck">	<input type="checkbox"  name="ingredients[]" value="<?php echo $ingredient['ingredientid'];  ?>" id="ingredint" class=""/><label for=""><span class="chicken"><?php echo $ingredient['ingredientname'];  ?></span></label> <input type="text" name="ing_qty_<?php  echo $ingredient['ingredientid']; ?>" value="" placeholder="Ingredients Quantity" class="required-2" id="ingqty"/>
					<select name="itemunits_<?php  echo $ingredient['ingredientid']; ?>" class="required" id="required-3" >
						<option value=" ">Select Unit</option>
						<?php 
							foreach($units as $unit){						
						?>
						<option value="<?php echo $unit['unit_name']; ?>"><?php echo ucfirst($unit['unit_name']); ?></option>
						<?php
							}	
						?>
					</select>
					</div>
					<?php
							}
						}				
					?>

<!---->
 
<!-- <p><a class='example8' href="#"><img src="<?php echo base_url();?>extras/extra/images/button-dark-plus-icon.png" align="left" alt=""/></a></p>  -->
 
 

 
<div class="required-mainck">
<input id="tempqnty" type="checkbox" <?php if($data['itemtemperaturecheck']=='yes'){ echo "checked";}?> name="itemtemperaturecheck" value="yes" /><label for=""><span class="chicken">Temperature :</span></label><input class="required-4"  type="text" maxlength="20" name="temperaturevalue" value="<?php echo $data['temperature_value']; ?>" />
</div>

<div class="mc-field-group"><label for="FNAME">Select Packages: <span class="asterisk">*</span><br />
</label><br />
<select class="required validate[required]" id="required-1" name="item_packages[]" multiple>
	<?php  
		$item_package_array = explode(",",$data['item_packages']);

		foreach($packages as $row){ 
	?>								
			<option value="<?php echo $row['specialp_id'] ;?>" <?php if(in_array($row['specialp_id'], $item_package_array)){echo "selected" ;} ?> ><?php echo $row['specialp_name']; ?></option>																	
	<?php 
		} 
	?>
</select>
</div>


  <div class="mc-field-group"><label for="mce-MMERGE3-addr1">Accompaniments: <span class="asterisk">*</span><br />
</label><br />
<input id="check_accompaniments" type="checkbox" name="check_accompaniments" value="yes" onClick="test()" <?php if($data['accompaniments'] != 'NULL'){echo 'checked';} ?> />
 			<span id="showaccompaniments" style="visibility:hidden"><label>Select Accompaniments:</label> <br />
						<select class="required" id="required-1" name="accompaniments[]"  multiple>
								
								<?php  
								$accomp = explode(',',$data['accompaniments']);
								foreach($accompaniments as $row){ ?>								
								
									<option value="<?php echo $row['accompanimentsid'] ;?>" <?php if(in_array($row['accompanimentsid'],$accomp)) echo "selected=selected"; ?>><?php echo $row['accompanimentsname']; ?></option>
										<?php } ?>						
							</select>
							</span>

</div>

<div class="form_field_name">Browse file :</div>
           <div class="form_field_textfield"><img src="<?php echo base_url(),'uploads/items/',$data['item_image']; ?>" width="112" height="88"> <input name="userfile" type="file" class="form_field_browsestyle"></div>

<div class="clear" id="mce-responses"></div>
<div class="clear"> <input type="hidden" name="itemid" value="<?php echo $data['itemid']?>"/><input class="button" id="mc-embedded-subscribe" type="submit" name="action" value="Submit" /></div>
<div class="clear" id="mce-responses"></div>

</div>

</form>


</div>

   </div>
   
   
   </div>
    
  </div>


</body>
</html>