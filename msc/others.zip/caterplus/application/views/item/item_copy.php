<div class="block">
			
				<div class="block_head">
					<div class="bheadl"></div>
					<div class="bheadr"></div>
						<a href="<?php echo base_url();?>logout">Logout</a> / <a href="<?php echo base_url();?>staff">Staffs</a> / <a href="<?php echo base_url();?>kitchen">Kitchen</a> / <a href="<?php echo base_url();?>items/listall">Items</a> / <a href="<?php echo base_url();?>specialevent/specialcontainer">Containers</a> / <a href="<?php echo base_url();?>supplier">Suplliers</a>
	<br/>
					<h2>Item list</h2>
					<form action="/items/search">
						<input type="text" placeholder="Search Items" name="search" value="<?php echo $search_term; ?>">
						<input type="submit" value="Search">
					</form>
					
					<ul>
						
						<li><a href="<?=base_url()?>items/addform">Add ITEMS</a></li>

					</ul>
				</div>		<!-- .block_head ends -->
				
				
				
				<div class="block_content">
					
					<?php if($msg!=''): ?>
						<div class="message success">
						<p>
						<?php if($msg=="added"){ echo "ITEM added successfully";} ?>
						<?php if($msg=="edited"){ echo "ITEM  updated successfully";} ?>
						<?php if($msg=='changestatus'){echo "ITEM  status updated successfully"; } ?>
						<?php if($msg=="deleted"){ echo "ITEM  deleted successfully";} ?>
						</p></div>
					<?php endif; ?>	 
											
					<form action="" method="post" >
					
						<table cellpadding="0" cellspacing="0" width="100%" id="table-1">
						
							<tr>
							<th>Image</th> 	
							<th>Item Name</th>														
						 	<th>Actions</th> 

							</tr>
							
						
							<?php foreach($contents as $value):?>
							<tr> 
							<td><img src="<?php echo base_url(),'uploads/items/',$value['item_image']; ?>"></td>
							<td  id="<?=$value['itemid']?>" > 
								
								<td> <a href="<?=base_url();?>items/updateform/<?php echo $value['itemid']?>" title="Edit"><?php echo $value['itemname']?></td>

								
                     
								   <td class=""> <a href="<?php echo base_url();?>items/updateform/<?php echo $value['itemid']?>" title="Edit">EDIT
	<!--<img src="<?=base_url()?>/resources/images/pencil.png" alt="edit" />--></a>&nbsp;&nbsp;

	<?php
	if($value['item_status'] == 'active'){
	?>
	<a  onclick="return window.confirm('Do you really want to deactivate this ITEM?')" href="<?php echo base_url();?>items/delete/<?php echo $value['itemid']?>">Deactivate<!--<img src="<?=base_url()?>/resources/admin/images/error.gif" alt="delete" />--></a>&nbsp;&nbsp;	
	
	<?php
	}else{
	?>
	<a  onclick="return window.confirm('Do you really want to activate this ITEM?')" href="<?php echo base_url();?>items/activate/<?php echo $value['itemid']?>">Activate<!--<img src="<?=base_url()?>/resources/admin/images/error.gif" alt="delete" />--></a>&nbsp;&nbsp;	
	<?php
	}
	?>

	
        </td>
                       <td></td>
							</tr>
							</tr>
						<?php endforeach; ?>		
							
						</table>
						
						
						
					</form>
					
				</div>		<!-- .block_content ends -->
				
				<div class="bendl"></div>
				<div class="bendr"></div>
			</div>		<!-- .block ends -->
			
			
			
			
			
			
			
			
			
			
			
	