<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>EDIT MENU TYPE</h1></div>
<div class="master-left">
<form class="validate" id="add-items" action="<?php echo base_url();?>menu/update" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
         
         <!---->
         <div class="master-left-1">
           <div class="master-name">Name:: *</div>         
<div class="master-select">
<input name="menutypename" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="menutypename" value="<?php echo $data['menutypename'] ;?>">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Description: </div>         
<div class="master-select">
<input name="menutypedescription" id="menutypedescription" type="text" class="master-textfeild" value="<?php echo $data['menutypedescription']; ?>">
          </div>
          </div>
          <!---->
          <!---->
         <div class="master-left-1">
           <div class="master-name">Select Image : *</div>         
<div class="master-select">
<input name="userfile" id="userfile" type="file" class="form_field_browsestyle">
<img src="<?php echo base_url(),'uploads/menu/',$data['menu_image']; ?>" width="75" height="75">
          </div>
          </div>
          
         <input type="hidden" name="menutypeid" value="<?php echo $data['menutypeid']?>"/>
        <input class="master-submit" type="submit" name="subscribe" value="" /> 
</form>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
