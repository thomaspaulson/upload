 
                
                 <!--   <script type="text/javascript">
                    	$(document).ready (function(){
							$('#sadvance').click (function(){
								$('.hide_serch').slideToggle()
							});
						});
                    </script> -->
                </div>
                </div>
        </header>
        <div class="container">
                <div class="row custemor_dtls ">
                	<div class="col-md-12">
                     <script type="text/javascript" src="<?php echo base_url()?>extras/mergeddesign/js/cycle.js"></script>
<script type="text/javascript">
	$(document).ready(function(){
			$('.slider_wrap').cycle({ 
				fx:     'scrollHorz', 
				speed:  1000, 
				timeout: 5000,
				 timeout: 0,
				slideExpr:".slider",
				pager: ".pager233",
				 next: ".nxt0", 
				 prev:  ".prv0",
				
			});			
	});
</script>
                    <ul>
                    	<li class="main_header"><p>Menu Details</p>
<div class="row search_cus newstyleedited" >
                	<div class="col-md-12">

                    	<form action="<?php echo base_url();?>menu/search" method="post" id="menufetch" name="menufetch"> 
                        	 <input type="text" placeholder="Menu Name" name="menutypename" id="menutypename" autocomplete="off" value="" class="validate[required]" required>
                            <input name="" type="submit" value="Search Menu"> 

<a href="<?php echo base_url();?>menu/addform" id="sadvance">New Menu</a>
 <ul class="results" id="results">
                           <!-- <a href="#" id="sadvance"> Advanced search</a>
                            <div class="clearfix"></div>
                            <div class="hide_serch"><input type="text" placeholder="Name">
                            <input type="text" placeholder="Last Name">
                            <input name="" type="submit" value="Search customer"> -->
                            </div>
                        </form>
                    </div>
 
                        	<div class="pag_nav">
                            	<a href="#"  class="prv0"><img src="<?php echo base_url()?>extras/mergeddesign/images/prev_p.png" width="29" height="31"></a>
                                <a href="#" class="nxt0"><img src="<?php echo base_url()?>extras/mergeddesign/images/nxtp.png" width="29" height="31"></a>
                            </div>

                      </li>
                      </ul>
                      <div class="slider_wrap wr">
                     <ul class="slider wr">
                      	<li class="sub_header">
                      	                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                                            
                                <li class="otheritem_fld">Image</li>  
                                 <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li> 
     <?php     $totcount =  count($contents); //echo $totcount; ?>                 
                       <?php $i=0;foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}  if($i<10){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url();?>menu/updateform/<?php echo $value['menutypeid'];?>"><?php echo $value['menutypename']?></a></li>
                                <li class="otheritem_fld"><img src="<?php echo base_url(),'uploads/menu/',$value['menu_image'];?>" width="100" height="75"></li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url();?>menu/updateform/<?php echo $value['menutypeid'];?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>menu/changestatus/<?php echo $value['menutypeid'];?>" >
								                  
 <?php if ($value['menu_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                                            
                    </ul>

                  <ul class="slider wr">
                      	<li class="sub_header">
                      		<ul>
                            	<li class="nameitem_fld">Name</li>
                                 <li class="otheritem_fld">Image</li>  
                               <li class="otheritem_fld">Actions</li>
                            </ul>
                      </li>
                     <?php $i=0;  foreach($contents as $value){ $i++;if($i%2==0){$v=2;}else{$v=1;}   if($i>10){?>
                      <li class="sub_header tab_sontent01 row_color<?php echo $v;?>">
                      		<ul>
                            	<li class="nameitem_fld"><a href="<?php echo base_url();?>menu/updateform/<?php echo $value['menutypeid'];?>"><?php echo $value['menutypename']?></a></li>
                                <li class="otheritem_fld"><img src="<?php echo base_url(),'uploads/menu/',$value['menu_image'];?>" width="100" height="75"></li>
 
                     <li class="otheritem_fld"><a href="<?php echo base_url();?>menu/updateform/<?php echo $value['menutypeid'];?>"><img src="<?php echo base_url();?>extras/new/images/pencil.png"/></a> <a href="<?=base_url()?>specialevent/menu/changestatus/<?php echo $value['menutypeid'];?>" >
								                  
 <?php if ($value['menu_status']=='active'){ ?> <img src="<?php echo base_url();?>extras/new/images/active.gif"/><?php }else { ?><img src="<?php echo base_url();?>extras/new/images/inactive.gif"/> <?php } ?></a></li>      
           
                                
                            </ul>
                      </li>
                      
                  
                    <?php }} ?>
                    </ul>
                    </div>
                    </div>
                </div>
                <footer>
                 <ul>
                 	
                    <li>
                    	<a href="<?php echo base_url();?>">Cancel</a>
                    </li>
                    
                    <li>
                    	<a href="<?php echo base_url();?>menu/addform">New</a>
                    </li>
                   
                 </ul>
                 </footer>
          </div>  
</body>
</html>