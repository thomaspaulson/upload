<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<link href="<?php echo base_url()?>extras/css/style.css" rel="stylesheet" type="text/css">
<link href='<?php echo base_url()?>extras/css/fullcalendar.css' rel='stylesheet' />
<link href='<?php echo base_url()?>extras/css/fullcalendar.print.css' rel='stylesheet' media='print' />
<script src="<?php echo base_url()?>extras/js/html5.js"></script>
<script src="<?php echo base_url()?>extras/js/jquery-1.10.2.js"></script>
<!--======= Calendar =======-->
<link href="<?php echo base_url()?>extras/css/jquery-ui.css" rel="stylesheet" type="text/css">



</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="#"><img src="<?php echo base_url()?>extras/images/logo.png" alt=""></a></div>
    
  </div>
</header>
<!--========= content ===============-->
<div class="wrapper"> 
<div class="login_wrap">
<div class="login-main">

<div class="login-main-right">

<div class="login-main-righbottom">
<img src="<?php echo base_url()?>extras/images/loadingAnimation.gif">
</div>
<div class="login-main-righttop">

<div class="login_box">
          <div class="left_box">
            <div class="hd">
              <h1>Login</h1>
            </div>
            <div class="left_from">
              <div class="col">
<form action="<?php echo base_url()?>login/verify" method="post">
                <p>Username :
                  <input name="username" type="text" class="user_name">
                </p>
              </div>
              <div class="col">
                <p>Password :</p>
                <input  name="password" type="password" class="password">
              </div>
            <div class="bottom_row">
                <div class="col2">
                </div>
                <div class="col3">
                 
                </div>
              </div>
            </div>
          </div>
          <input name="loginsubmit" type="submit" class="go" value="go">
          <div class="clear"></div>
        </div>
</div>

</div>
</div>





</div>

  <div class="clear"></div>
</div>
<!--========= content end ===============-->

</body>
</html>