<html>
	<body>
		<?php
		foreach($suppliers as $supplier){
		?>
		<h1>Edit <?php echo $supplier['supplier_name'];  ?></h1>
		<form action="http://caterplus.thephinixgroup.com/supplier/edit_existing_supplier" method="post">
			<p><input type="hidden" name="id" value="<?php echo $id; ?>"/></p>		
			<p><input type="text" name="name"  value="<?php echo $supplier['supplier_name'];  ?>" placeholder="supplier name"/></p>
			<p>
                        <input type="text" name="phn_ext" placeholder="phn_ext" value="<?php echo $supplier['phn_ext'];  ?>">
                        <input type="text" name="phone" value="<?php echo $supplier['supplier_phone'];  ?>" placeholder="supplier phone"/>
                        </p>
                        <p>
                        <input type="text" name="mobile1" placeholder="Phone Number" value="<?php echo $supplier['mobile1'];  ?>">
                        </p>
                        <p>
                        <input type="text" name="mobile2" placeholder="Phone Number" value="<?php echo $supplier['mobile2'];  ?>">
                        </p>
			<p><textarea name="address" placeholder="supplier address"><?php echo $supplier['supplier_address'];  ?></textarea></p>
			<p><input type="text" name="email" value="<?php echo $supplier['supplier_email'];  ?>" placeholder="supplier phone"/></p>			
			
		        <p>
				<input type="submit" value="Edit"/>
			</p>						
		</form>
	</body>
		<?php
		}
		?>
	
</html>