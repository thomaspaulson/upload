<?php
	if($this->session->flashdata('message')){
		 echo $this->session->flashdata('message'); 	
	}
?>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>login</title>
</head>

<body>
	<a href="<?php echo base_url();?>logout">Logout</a> / <a href="<?php echo base_url();?>staff">Staffs</a> / <a href="<?php echo base_url();?>kitchen">Kitchen</a> / <a href="<?php echo base_url();?>items/listall">Items</a> / <a href="<?php echo base_url();?>specialevent/specialcontainer">Containers</a> / <a href="<?php echo base_url();?>supplier">Suplliers</a>
	<h1>Supplier</h1>
	<a href="<?php echo base_url(); ?>supplier/add_new_supplier">Add New Supplier</a>
	<table>
		<tr>
			<th>Name</th>
			<th>Phone</th>
			<th>Address</th>
			<th>Email</th>			
			<th>Actions</th>
		</tr>
		<?php
		  if(count($suppliers) == 0){
		    echo 'No results found';
		  }else{
		    foreach($suppliers as $supplier){	    
		?>
		<tr>
		<td><?php echo $supplier['supplier_name']; ?></td>
		<td><?php echo $supplier['supplier_phone']; ?></td>
		<td><?php echo $supplier['supplier_address']; ?></td>
		<td><?php echo $supplier['supplier_email']; ?></td>				
		<td><a href="<?php echo base_url(); ?>supplier/edit_supplier/<?php echo $supplier['supplier_slug']; ?>">Edit</a>/<a href="<?php echo base_url(); ?>supplier/delete_supplier/<?php echo $supplier['supplier_slug']; ?>" onclick="return window.confirm('Do you really want to delete this Package?')">Delete</a></td>
		</tr>						
		<?php 
		    }
		 }
		
		?>
		
	</tabl
</body>
</html>