<html>
	<body>
		<h1>Add New Supplier</h1>
		<form action="<?php echo base_url(); ?>supplier/add_supplier" method="post">
			<p><input type="text" name="name" placeholder="Supplier name"/></p>
			<p><input type="text" name="address" placeholder="Address"/></p>
			<p><input type="text" name="phn_ext" placeholder="phn_ext">
                           <input type="text" name="phone" placeholder="Land Line"></p>
			<p><input type="text" name="mobile1" placeholder="Mobile 1"></p>
			<p><input type="text" name="mobile2" placeholder="Mobile 2"></p>
			<p><input type="text" name="email" placeholder="email"/></p>								        
			<p>
				<input type="submit" value="Add"/>
			</p>						
		</form>
	</body>
</html>