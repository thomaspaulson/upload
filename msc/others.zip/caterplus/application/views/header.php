<!doctype html>
<html>
  <head>
  <meta charset="utf-8">
  <title>Cater Plus</title>
  <link rel="shortcut icon" href="<?php echo base_url();?>extras/images/favicon.png">
  <!--common style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/style.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/view_port.css">
  <!--font css style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/fonts/stylesheet.css">

  <!--bootsrap css style-->
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/bootstrap.css">

  <!-- bootstrap js -->


<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/elastislide.css" />
		<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/custom.css" />
		<script src="<?php echo base_url();?>extras/js/modernizr.custom.17475.js"></script>


  <!-- tab and slide js -->
  <link type="text/css" rel="stylesheet" href="<?php echo base_url();?>extras/css/easy-responsive-tabs.css" />
<!--  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>-->
  <script type="text/javascript" src="<?php echo base_url();?>extras/js/jquery-1.10.2.min.js"></script>
  <script src="<?php echo base_url();?>extras/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url();?>extras/js/easyResponsiveTabs.js" type="text/javascript"></script>
  

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lte IE 8]>
<script src="<?php echo base_url();?>extras/js/html5.js" type="text/javascript"></script>
<script src="<?php echo base_url();?>extras/js/respond.js" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="<?php echo base_url();?>extras/css/ie8-and-down.css" />
<![endif]-->

  </head>