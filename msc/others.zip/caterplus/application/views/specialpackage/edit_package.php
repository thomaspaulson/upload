<!--========= content ===============-->
<div class="wrapper"> 
<div class="master-program-bg">
<div class="master-top-add"><h1>EDIT PACKAGE</h1></div>
<div class="master-left">
<?php
		foreach($packages as $package){
		?>
<form class="validate" id="add-items" action="<?php echo base_url();?>specialpackage/edit_existing_package" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
         
         <!---->
         <div class="master-left-1">
           <div class="master-name">Package Name:: *</div>         
<div class="master-select">
<input name="name" type="text" class="master-textfeild validate[required]" id="name" value="<?php echo $package['specialp_name'];  ?>">
          </div>
          </div>
          
          <!---->
         <div class="master-left-1">
           <div class="master-name">Package Quantity: </div>         
<div class="master-select">
<input name="qty" id="qty" type="text" class="master-textfeild" value="<?php echo $package['specialp_qty'];  ?>">
          </div>
          </div>
          <!---->
          <!---->
         
          
        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
        <input class="master-submit" type="submit" name="subscribe" value="" /> 
</form>
<?php
		}
		?>
  <div class="clear"></div>
</div>



</div>
  <div class="clear"></div>
</div>
 <div class="clear"></div>
<!--========= content end ===============-->
