<html>
	<body>
		<h1>Add New Package</h1>
		<form action="<?php echo base_url(); ?>specialpackage/add_package" method="post">
			<p><input type="text" name="name" placeholder="Package name"/></p>
			<p><input type="text" name="qty" placeholder="Quantity"/></p>		        
			<p>
				<input type="submit" value="Add"/>
			</p>						
		</form>
	</body>
</html>