<html>
	<body>
		<h1>Take order</h1>
		<form action="<?php echo base_url(); ?>specialorder/take_order" method="post">
			<p>Select Category</p>
			<p>
				<select name="menu" id="menu">
					<?php
						foreach($menus as $menu){				
					?>
						<option value="<?php echo $menu['menutypeid'];  ?>"><?php echo $menu['menutypename'];  ?></option>
					<?php
						}			
					?>
				</select>
			</p>
			
			<p>Select Category</p>
			<p>
				<select name="item" id="item">
					<?php
						foreach($menus as $menu){				
					?>
						<option value="<?php echo $menu['menutypeid'];  ?>"><?php echo $menu['menutypename'];  ?></option>
					<?php
						}			
					?>
				</select>
			</p>
			<p><input type="text" name="qty" placeholder="Quantity"/></p>		        
			<p>
				<input type="submit" value="Add"/>
			</p>						
		</form>
	<script src="<?php echo base_url();?>extras/js/jquery-1.8.2.min.js"></script>
	<script src="<?php echo base_url();?>extras/js/specialorder/order.js""></script>		
	</body>
</html>