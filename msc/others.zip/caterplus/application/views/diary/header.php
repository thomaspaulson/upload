<!DOCTYPE HTML>
<html>
<head>
<meta charset="utf-8">
<title>Diary</title>
<link href="<?php echo base_url();?>extras/diary/css/style.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url();?>extras/diary/js/html5.js"></script>
<script src="<?php echo base_url();?>extras/diary/js/jquery-1.10.2.js"></script>
<!--======= Calendar =======-->
<link href="<?php echo base_url();?>extras/diary/css/jquery-ui.css" rel="stylesheet" type="text/css">
<script src="<?php echo base_url();?>extras/diary/js/bootstrapmodal.min.js"></script>
<!--[if IE 6]><link rel="stylesheet" href="http://mysite.com/path/to/ie6.css" type="text/css" media="screen, projection"><![endif]-->
<!--[if IE 7]><link rel="stylesheet" href="http://mysite.com/path/to/ie7.css" type="text/css" media="screen, projection"><![endif]-->

<!--======= Calendar end =========-->
<!--====== touch support =====-->
<script src="<?php echo base_url();?>extras/diary/js/jquery.ui.touch-punch.js"></script>
<script>$('#widget').draggable();</script>
<!--====== touch support end =====-->
<!--====== selection =====-->
<!--<script type="text/javascript" src="http://code.jquery.com/jquery.min.js"></script>-->
<script type="text/javascript">
    $(document).ready(function(){
        $(".custom-select").each(function(){
            $(this).wrap("<span class='select-wrapper'></span>");
            $(this).after("<span class='holder'></span>");
        });
        $(".custom-select").change(function(){
            var selectedOption = $(this).find(":selected").text();
            $(this).next(".holder").text(selectedOption);
        }).trigger('change');
    })
</script>

<!--====== selection end =====-->
<link rel='stylesheet' type='text/css' href='<?php echo base_url();?>extras/diary/css/fullcalendar.css' />
<link rel='stylesheet' type='text/css' href='<?php echo base_url();?>extras/diary/css/fullcalendar.print.css' media='print' />
<script type='text/javascript' src='<?php echo base_url();?>extras/diary/js/jquery-1.5.min.js'></script>
<script type='text/javascript' src='<?php echo base_url();?>extras/diary/js/jquery-ui-1.8.9.custom.min.js'></script>
<script type='text/javascript' src='<?php echo base_url();?>extras/diary/js/fullcalendar.js'></script>

<!--popup start-->
<script>
$(document).ready(function() { 
    $('#bootstrapModalFullCalendar').fullCalendar({
        events: '/hackyjson/cal/',
        header: {
            left: '',
            center: 'prev title next',
            right: ''
        },
        eventRender: function (event, element) {
            element.attr('href', 'javascript:void(0);');
            element.click(function() {
                //set the modal values and open
                $('#modalTitle').html(event.title);
                $('#modalBody').html(event.description);
                $('#eventUrl').attr('href',event.url);
                $('#fullCalModal').modal();
            });
        }
    });
});
</script>
<!--popup end-->
</head>

<body class="bg_image">
<header>
  <div class="wrapper">
    <div class="logo"><a href="<?php echo base_url();?>admin"><img src="<?php echo base_url();?>extras/new/images/logo.png" alt=""></a></div>
    <div class="header_right"> 
  <a href="#" class="top-menuicons"><img src="<?php echo base_url();?>extras/diary/images/dairy.png" alt="">
      <h6>Dairy</h6>
      </a> 
      <!----> 
      <a href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen" class="top-menuicons"><img src="<?php echo base_url();?>extras/diary/images/kitchen.png" alt="">
      <h6>Kitchen</h6>
      </a> 
      
      <!----> 
      <a href="<?php echo base_url();?>items/listall" class="top-menuicons"><img src="<?php echo base_url();?>extras/diary/images/item.png" alt="">
      <h6>Items</h6>
      </a> 
      
      <!----> 
      <a href="<?php echo base_url();?>specialevent/paymentcollection/balancepayment" class="top-menuicons"><img src="<?php echo base_url();?>extras/diary/images/payment.png" alt="">
      <h6>Payment</h6>
      </a> 
      
      <!----> 
      <a href="<?php echo base_url();?>settings" class="top-menuicons"><img src="<?php echo base_url();?>extras/diary/images/settings.png" alt="">
      <h6>Settings</h6>
      </a> 
      <!----> 
      <!----> 
      <a href="#" class="top-menuicons"><img src="<?php echo base_url();?>extras/diary/images/more.png" alt="">
      <h6>More </h6>
      </a> 
      <!----> 
      <!--==== user name =====--> 
      <a href="#">
      <div class="user_box">
        <div class="user">
          <div class="icon"> </div>
          <div class="user_name">
            <p>iqbal catering</p>
            <p>branch 1 </p>
          </div>
          <h6>Admin</h6>
        </div>
      </div>
      </a> 
      <!--==== user name end =====--> 
      <a href="#" class="logout"><img src="<?php echo base_url();?>extras/diary/images/logout.png" alt="">
      <h6>Logout</h6>
      </a> </div>
  </div>
</header>
<!--========= content ===============-->
<div class="wrapper"> 

<?php //print_r($eventslist);  
//echo json_encode($eventslist);
 
?>
<script type='text/javascript'>

	$(document).ready(function() {
	
		var date = new Date();
		var d = date.getDate();
		var m = date.getMonth();
		var y = date.getFullYear();
		
		$('#calendar').fullCalendar({
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'year,month,agendaWeek,agendaDay'
			},
			editable: true,
			events: [<?php foreach($eventslist as $event){?>
				{
					title: "<?php echo $event['event_title'];?>",
					start: new Date(y, m, <?php echo  date("d",strtotime($event['event_date']));?>,<?php echo  date("G",strtotime($event['event_time']));?>),
                                        url: '<?php echo base_url();?>event/event_overview/edit_event_customer/<?php echo $event['event_id'];?>/<?php echo $event['event_slug'];?>'
				},
				
			<?php } ?>]
		});
		
	});
</script>