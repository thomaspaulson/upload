 
 <!--======= diary =======-->

  <div class="diary">
  
    <table border="0" cellpadding="0" cellspacing="0" class="diary_bg">
      <tr>
      
        <td class="diary_top_left"></td>
        <td class="diary_top"><div class="diary_top_center"></div></td>
        <td class="diary_top_right"></td>        
      </tr>
      <tr>
        <td class="diary_left"></td>
        <td class="diary_center"><!--======== Diary Content =========-->
          
          <div class="diary_content">
            <div class="month_diary"> </div>
<div class="top-menu">
          <div class="top-menuleft">
            <ul>
              <li class="top-menuleft-active"><a href="<?php echo base_url();?>diary">All </a></li>
              <li class="top-menuleft-gap"></li>
              <li><a href="<?php echo base_url();?>diary/enquiry"> Enquiry</a></li>
             <li class="top-menuleft-gap"></li>
              <li><a href="<?php echo base_url();?>diary/provincial">Provisional</a></li>
            <li class="top-menuleft-gap"></li>
              <li><a href="<?php echo base_url();?>diary/confirmed">Confirmed</a></li>
             <li class="top-menuleft-gap"></li>
              <li><a href="<?php echo base_url();?>diary/completed">Completed</a></li>
            </ul>
          </div>
     <?php /* ?>    <div class="top-menuright">
            <select name="timepass" class="custom-select">
            <option>Event</option>
            <option>Wedding</option>
            <option>Birthday</option>              
        </select>
          </div> 
          
          <div class="top-menuright">
              <select name="timepass" class="custom-select">
            <option>Branch name</option>
            <option>Cochin</option>
            <option>Trissur</option>               
        </select>
          </div><?php */ ?>
        </div>
        <div class="special_button">
            <ul>
            <li><a href="#">List</a></li>

            </ul>
            </div>
              <div id='calendar'></div>
            </div>
         
             
          
          <!--======== Diary Content end =========--></td>
        <td class="diary_right"></td>
      </tr>
      <tr>
        <td class="diary_bottom_left"></td>
        <td class="diary_bottom"><div class="diary_bottom_center"></div></td>
        <td class="diary_bottom_right"></td>
      </tr>
    </table>
  </div>
  </div>
  </div>
  
  <!--======= diary end  =======-->
  <div class="clear"></div>
</div>
<!--========= content end ===============-->

