<footer>
  <div class="wrapper">
    <table border="0" cellpadding="0" cellspacing="0" class="footer_icons">
      <tr>
        <td><a href="javascript:window.history.go(-1);"><img src="<?php echo base_url();?>extras/diary/images/back.png" alt=""></a></td>
       
        <td align="right"><a href="<?php echo base_url();?>admin_home"><img src="<?php echo base_url();?>extras/diary/images/home.png" alt=""></a></td>
      </tr>
    </table>
  </div>
</footer>
<script>
$(document).ready(function() { 
    $('#bootstrapModalFullCalendar').fullCalendar({
        events: '/hackyjson/cal/',
        header: {
            left: '',
            center: 'prev title next',
            right: ''
        },
        eventRender: function (event, element) {
            element.attr('href', 'javascript:void(0);');
            element.click(function() {
                //set the modal values and open
                $('#modalTitle').html(event.title);
                $('#modalBody').html(event.description);
                $('#eventUrl').attr('href',event.url);
                $('#fullCalModal').modal();
            });
        }
    });
});
</script>
</body>
</html>