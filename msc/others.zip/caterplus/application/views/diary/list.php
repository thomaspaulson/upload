
<!--tabs-->
 <link type="text/css" rel="stylesheet" href="<?php echo base_url();?>extras/diary/css/easy-responsive-tabs.css" />
    <script src="<?php echo base_url();?>extras/diary/js/jquery-1.6.3.min.js"></script>
    <script src="<?php echo base_url();?>extras/diary/js/easyResponsiveTabs.js" type="text/javascript"></script>

<!--tabs end-->





  <!--======= diary =======-->

  <div class="diary">
  
    <table border="0" cellpadding="0" cellspacing="0" class="diary_bg">
      <tr>
      
        <td class="diary_top_left"></td>
        <td class="diary_top"><div class="diary_top_center"></div></td>
        <td class="diary_top_right"></td>        
      </tr>
      <tr>
        <td class="diary_left"></td>
        <td class="diary_center"><!--======== Diary Content =========-->
          
          <div class="diary_content">
           
<div class="list-menu">
<div class="list-menu-main">
<div class="list-left">
<div class="list-left-date"> <h2>March 2014</h2></div>

 <div class="list-left-arrow"> <p>Date: <input type="text" id="datepicker"> </p></div> 
 <div class="list-left-bg"></div>
</div>
<div class="list-right">
 <div class="list-menuleft">
            <ul>
              <li ><a href="<?php echo base_url();?>diary">Year </a></li>
              <li class="list-menuleft-gap"></li>
              <li><a href="<?php echo base_url();?>diary"> Month</a></li>
             <li class="list-menuleft-gap"></li>
              <li><a href="<?php echo base_url();?>diary">Week</a></li>
            <li class="list-menuleft-gap"></li>
              <li><a href="<?php echo base_url();?>diary">Day</a></li>
             <li class="list-menuleft-gap"></li>
              <li class="list-menuleft-active"><a href="<?php echo base_url();?>diary/listview">List</a></li>
            </ul>
          </div>
   
          
 </div>

</div>
<div class="list-tab">

<div id="verticalTab">
            <ul class="resp-tabs-list">
            
                <li style="background:#930"><h1> Wedding</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London
                 </li>
                 <!---->
                 <li style="background:#660099"><h1> BirthDay</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar birth day
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London birth day
                 </li>
                 <!---->
                 <li style="background:#006"><h1> Baptism</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London
                 </li>
                 <!---->
                  <li style="background:#F09"><h1> Inaguration</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London
                 </li>
                 <!---->
                 
                 <li style="background:#930"><h1> Wedding</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London
                 </li>
                 <!---->
                
                 
                 <li style="background:#660099"><h1> Birthday</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London
                 </li>
                 <!---->

                 <li style="background:#006"><h1> Baptism</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London
                 </li>
                 <!---->
     <li style="background:#F09"><h1> Inaguration</h1> <div class="list-left-box-3"> 11.30pm</div>
                <br>
                <div class="list-left-box-4"></div>Manoj Kumar
                <br>
                <br>
                <div class="list-left-box-5"></div>HML Hall, Whiteline street, London
                 </li>
            </ul>
            
            <div class="list-center"></div>
            <div class="resp-tabs-container">
           
                <div>
                    <h1>Wedding </h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                   
                    
                </div>
                
                <!---->
                
                <div >
                    <h1>Birthday</h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar birthday</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London birthday</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                </div>
                
                <!---->
               <div >
                    <h1>Baptism </h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                </div>
                
                <!---->
                
               <div >
                    <h1>Inaguration</h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                </div>
                
                <!---->
                
               <div >
                    <h1>Wedding </h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                </div>
                <!---->
                
               <div >
                    <h1>Birthday</h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                </div>
                <!---->
                
               <div >
                    <h1>Baptism</h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                </div>
                <!---->
                <div >
                    <h1>Inaguration</h1>
                     <p><img src="<?php echo base_url();?>extras/diary/images/time-symbol.png" style="margin-right:10px; margin-top:8px;">11.30pm</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/man-symbol.png" style="margin-right:10px; margin-top:10px;">Manoj Kumar</p>
                    <p><img src="<?php echo base_url();?>extras/diary/images/place-symbol.png" style="margin-right:10px; margin-top:10px;">HML Hall, Whiteline street, London</p>
                  <div class="list-right-box">
       <div class="list-right-box-1">
       
       <div class="list-right-box-task">Task</div>
        <div class="list-right-box-task">Total</div>
         <div class="list-right-box-balance">Balance</div>
         <div class="list-right-box-completed">Completed</div>
         <div class="list-right-box-completed">$ 120</div>
         <div class="list-right-box-doler">$ 5</div>
       </div>
       </div>
                    <br>
                </div>
                
                
        </div>


</div>

        </div>
        <div class="clear"></div>
            
            </div>
         
             
          
          <!--======== Diary Content end =========--></td>
        <td class="diary_right"></td>
      </tr>
      <tr>
        <td class="diary_bottom_left"></td>
        <td class="diary_bottom"><div class="diary_bottom_center"></div></td>
        <td class="diary_bottom_right"></td>
      </tr>
    </table>
  </div>
  </div>

  
  <!--======= diary end  =======-->
  <div class="clear"></div>

<!--========= content end ===============-->
<!--tabs-->
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script>

<!--tabs end-->

<!--date picker-->
 <script src="<?php echo base_url();?>extras/diary/js/jquery-ui.js"></script>
<script>
$(function() {
$( "#datepicker" ).datepicker({
changeMonth: true,
changeYear: true
});
});
</script>



<!--date picker end-->


