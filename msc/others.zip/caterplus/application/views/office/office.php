<?php
$path = APPPATH.'views/headerkitchen.php';
include_once($path);
?>
  
<div id="content_wrapper">
    <div class="container ">
    	<div class="kitchen_heading wr">
        <div class="row">
        	<div class="col-md-12">
            	<h1>Office view - Special Event </h1>
            </div>
        </div></div>
        
        <!-- left sidebar starts -->
            <div class="sidebar_wrap">
<!----stock starts-->
<div class="lsidebar wr">
                	<div class="side_wrap">
                		     <ul class="row2" style="background:black;font-size:16px;font-weight:bold;">
		                         <li class="">Ingredient Stock</li>
		                     </ul>
	                	<?php 
	                		if($rawstock){
	                			foreach($rawstock as $stock){ $stk=$stock['current_stock'];	                			
	                	?>
	                	     <ul class="row2" <?php if($stk<200){ echo "style='background-color: red;'"; } ?> >
		                         <li class="item1">

<?php echo $stock['ingredientname'].'   '.$stock['current_stock'].'   '.$stock['ingredientqtytype']; ?></li>

		                     </ul>
		                     <ul class="slide_side">
		                        <li>
		                        <p></p>
		                        </li>
		                     </ul>
	                	<?php
	                			}	                	
	                		}else{
	                	?>
	                	     <ul class="row2">
		                         <li class="item1">Sufficient stock</li>
		                     </ul>
	                	<?php
	                		}
	                	?>     
                         </div>
                </div>

<!---stock ends-->
            	<div class="lsidebar wr">
                	<div class="side_wrap">
	                	     <ul class="row2" style="background:black;font-size:16px;font-weight:bold;">
		                         <li class="">Cooking In Progress</li>
		                     </ul>
	                	<?php 
	                		if($started_items){
	                			foreach($started_items as $started_item){	                			
	                	?>
	                	     <ul class="row2">

		                         <li class="item1"><?php echo ucwords(strtolower($started_item['itemname'])),'(',$started_item['additional'],')'; ?></li>
		                     </ul>
		                     <ul class="slide_side">
		                        <li>
		                        <p></p>
		                        </li>
		                     </ul>
	                	<?php
	                			}	                	
	                		}else{
	                	?>
	                	     <!-- <ul class="row2">

		                         <li class="item1">Nothing Started</li>
		                     </ul> -->
	                	<?php
	                		}
	                	?>     
                         </div>
                    <!-- <a href="#" onclick="return false;" class="strat_c">Started</a> -->
                </div>
                <div class="lsidebar">
                	<div class="side_wrap">
	                	     <ul class="row2" style="background:black;font-size:16px;font-weight:bold;">
		                         <li class="">Cooking Completed</li>
		                     </ul>
	                	<?php 
	                		if($completed_items){
	                			foreach($completed_items as $completed_item){	                			
	                	?>
	                	     <ul class="row2">
		                         <li class="item1"><?php echo ucwords(strtolower($completed_item['itemname'])),'(',$completed_item['cooked_stock'],')'; ?></li>
		                     </ul>
		                     <ul class="slide_side">
		                        <li>
		                        <p></p>
		                        </li>
		                     </ul>
	                	<?php
	                			}	                	
	                		}else{
	                	?>
	                	<!--     <ul class="row2">
		                         <li class="item1">Nothing Completed</li>
		                     </ul> -->
	                	<?php
	                		}
	                	?>
                     


                     	</div>
                   <!--  <a href="#" onclick="return false;" class="strat_c">Completed</a> -->
                </div></div>
        <!-- left sidebar ends -->                
                <div class="table_right">
                	<div class="top_bar"><div class="row ">
                    	<div class="col-md-12 ">
                        	<div class="row">
                           <!-- 	<div class="col-md-1 col-sm-2">
                                	<a href="#" class="back">Back </a> 
                                </div> -->
                                <div class="col-md-12 col-sm-12">
                                	<ul>
                                    	<li>                                      	
                                        	<a  href="<?php echo base_url();?>specialevent/specialkitchen/viewkitchen"><button   class="btn <?php if($active == 0000){echo 'btn-danger';}else{ echo 'btn-success';} ?>" id="kitchen_all" value="all">All</button></a>
                                        </li>                                	
                                    	<li>
                                        	<form name="form_morning"  id="form_morning" action="" method="post" >
                                        	<input type="hidden" name="start" id="morning_start" value="10">
                                        	<input type="hidden" name="end" id="morning_end" value="13">                                       	
                                        	<input type="submit" class="btn" value="Morning " name="slotname" id="<?php if($active == 1013){echo 'form_morning_button_selected';}else{ echo 'form_morning_button';} ?>">
                                        	</form>
                                        </li>
                                        <li>
                                        	<form name="form_afternoon" id="form_afternoon" action="" method="post">    
                                        	<input type="hidden" name="start" id="afternoon_start" value="13">
                                        	<input type="hidden" name="end" id="afternoon_end" value="16">                                        	                                        	                                    
                                        	<input type="submit" class="btn" value="Afternoon " name="slotname" id="<?php if($active == 1316){echo 'form_afternoon_button_selected';}else{ echo 'form_afternoon_button';} ?>">
                                        	</form>                                        	
                                        </li>
                                        <li>
                                        	<form name="form_evening" id="form_evening" action="" method="post">  
                                        	<input type="hidden" name="start" id="evening_start" value="16">
                                        	<input type="hidden" name="end" id="evening_end" value="19">                                         	                                        	                                      
                                        	<input type="submit" class="btn" value="Evening " name="slotname" id="<?php if($active == 1619){echo 'form_evening_button_selected';}else{ echo 'form_evening_button';} ?>">
                                        	</form>                                        	
                                        </li>
                                        <li class="sel">
                                        	<form name="form_night" id="form_night" action="" method="post">  
                                        	<input type="hidden" name="start" id="night_start" value="19">
                                        	<input type="hidden" name="end" id="night_end" value="22">                                         	                                        	                                      
                                        	<input type="submit" class="btn" value="Night " name="slotname" id="<?php if($active == 1922){echo 'form_night_button_selected';}else{ echo 'form_night_button';} ?>">
                                        	</form>                                        	
                                        </li>
                                    </ul>
                                </div>
                             <!--    <div class="col-md-4 col-sm-4">
                                	<form action="" method="get">
                                    	<input name="" type="text">
                                    </form>
                                </div> -->
                            </div>
                        </div>
                        <div class="col-md-12">
                        <div class="row tab_wrap">
                	<div class="col-md-12">
                    <div class="row clearfix">
		<div class="col-md-12 column">
			<div class="tabbable" id="tabs-931882">
				<ul class="nav nav-tabs nav_tabs2" id="myTab">
					<li class="active">
						<a href="#panel-all" data-toggle="tab">All</a>
					</li>					
				<?php

				$i = 1;
				foreach($menus as $menu){
				?>
					<li>
						<a href="#panel-<?php echo $i; ?>" data-toggle="tab"><?php echo $menu['menutypename'];  ?></a>
					</li>				
				<?php
					$i = $i +1;
				}
				
				?>
                    
				</ul>
				
			<div class="tab-content tab-content2">
			
			
			
			<div class="tab-pane personal_info active" id="panel-all">
				<div class="row">
	                        	<div class="col-md-12 sub_top_bar">
		                            	<ul>

		                                    <li class="item1">Item</li>
		                                    <li class="item2">Unit</li>
		                                    <li class="item3">Order taken</li>
		                                    <li class="item4">cooked stock</li>
		                                    <li class="item5">Total Stock</li>
		                                    <li class="item6">To cook</li>
		                                    <li class="item7">status</li>
		                                 <!--   <li class="item8">Temperature</li>	-->			                                    				                                    
		                                </ul>
	                            	</div>
<?php  

								foreach($allitems as $item){
	
									$total_order_taken = 0;
									$cooked_stock = 0;
									$additional = 0;  
									$itemname = $item['itemname'];
									$itemunits = $item['itemunits'];
									$item_id = $item['itemid'];
									$item_temp_check = $item['itemtemperaturecheck'];
									$item_temp = $item['temperature_value'];



									foreach($total_cooked_stocks as $total_cooked_stock){
										if($item['itemid'] == $total_cooked_stock['item_id']){
											$to_co_stock = 	$total_cooked_stock['cooked_stock'];
											$to_collected = $total_cooked_stock['collected'];
											if($to_co_stock >= $to_collected){
												$to_co_stock = $to_co_stock - $to_collected;												
											}																						
										}									
									}

									
                                                                                    
									$st = 0;
									$temp = 0;
									foreach($temperatures as $temperature){

											if($item['itemid'] == $temperature['item_id']){
												$temp = $temperature['temperatue'];
												$additional =  $temperature['additional'];
												$cooked_stock =  $temperature['cooked_stock'];
												$total_order_taken =  $temperature['total_order_taken'];
												$collected = $temperature['collected'];
												if($active == 0000){
													$session_table = $temperature['session'];
												}

												if($cooked_stock >= $collected){
													$cooked_stock = $cooked_stock - $collected;												
												}												

												$total_order_taken = $total_order_taken - $collected;
												if($st == 0){
													$cooking_status = $temperature['status'];
													if($cooking_status != 'not started'){
														$st = 1;													
													}
												
												}
												
												if($to_co_stock > $total_order_taken){
													$to_cook = 0 ;
												}else{
													$to_cook = ($total_order_taken) - $to_co_stock;																								
												}

											}									
									
									}

									
							?>
								
							                            	
			                            <div class="col-md-12 sub_top_bar table_conntent">			                            
			                            	<form action="" method="post">
								<ul>

				                                    <li class="item1"><?php echo ucwords(strtolower($itemname)); ?> 
				                                    <?php 
				                                    if($item_temp_check == 'yes'){ 
				                                    ?>
				                                    <img src="<?php echo base_url(); ?>extras/images/avatar_3cf58ba8866d_16.png"></li>				                                    
				                                    <?php 
				                                    	}
				                                    ?>

				                                    <li class="item2"><?php echo $itemunits; ?></li>
				                                    <li class="item3"><?php echo $total_order_taken; ?></li>
				                                    <li class="item4"><?php  echo $cooked_stock;  ?></li>
				                                    <li class="item5"><?php  echo $to_co_stock;  ?></li>				                                    					                                   
				                                    <li class="item6"><?php echo $to_cook; ?></li>
				                                    <li class="item7">
				                                    	<?php
					                                    	if($cooking_status == "not started"){					                                    					                                    					                                    	
				                                    	?>
				                                    	
				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>" class="btn btn-danger"  >Start Cooking</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	
				                                    	<?php
					                                    	if($cooking_status == "started"){					                                    					                                    					                                    	
				                                    	?>
									<?php
				                                    		if($active == 0000){
				                                    	
				                                    	?>
				                                    	<input type="hidden" name="session_<?php echo $item_id; ?>" id="session_<?php echo $item_id; ?>" value="<?php echo $session_table; ?>" />
                                                                        <?php
                                                                        	}
                                                                        
                                                                        ?>
				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>"  class="btn btn-warning"   >Started</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	<?php
					                                    	if($cooking_status == "completed"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>"  class="btn btn-success"   >Completed</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>				                                    	
				                                    	
				                                    </li>
				                           <!--         <li class="item8">
				                                    	<?php 
				                                    		if($temp == 0){
				                                    	?>
				                                    		<button onclick="return false;"   class="btn btn-success">Not Set</button>
				                                    	<?php
				                                    		}else{ 
				                                    			echo $temp;
				                                    		} 
				                                    	?>
				                                    </li> -->				                                    		             
				                                </ul>

							</form>							
			                            </div>		                            
						<?php
							} 
							
						?>	                            	
	                            	
	                            	
	                            	
	                            	
	                        </div>
                        </div>
			
			
			
			
			
			<input name="ajax_item_id" id="ajax_item_id" type="hidden"  value="0">
			<input name="ajax_item_status" id="ajax_item_status" type="hidden"  value="">
			<input name="ajax_item_temp" id="ajax_item_temp" type="hidden"  value="0">
			<input name="ajax_additional" id="ajax_additional" type="hidden"  value="0">
			<input name="ajax_temp_check" id="ajax_temp_check" type="hidden"  value="0">			
			<input name="ajax_which_table" id="ajax_which_table" type="hidden"  value="0">			
			<input name="ajax_session" id="ajax_session" type="hidden"  value="0">			
			<input name="ajax_pop_up_open" id="ajax_pop_up_open" type="hidden"  value="no">			
			
			
			
			
												
				<?php
				$i = 1;
				foreach($menus as $menu){
				?>
					<div class="tab-pane personal_info" id="panel-<?php echo $i; ?>">
						<div class="row">
			                        	<div class="col-md-12 sub_top_bar">
				                            	<ul>

				                                    <li class="item1">Item</li>
				                                    <li class="item2">Unit</li>
				                                    <li class="item3">Order taken</li>
				                                    <li class="item4">cooked stock</li>
				                                    <li class="item5">Total Stock</li>
				                                    <li class="item6">To cook</li>
				                                    <li class="item7">status</li>
				                                <!--    <li class="item8">Temperature</li>	-->			                                    				                                    
				                                </ul>
			                            	</div>
							<?php  

								foreach($allitems as $item){
								if($item['menutype'] == $menu['menutypeid']){	
									$total_order_taken = 0;  
									$itemname = $item['itemname'];
									$itemunits = $item['itemunits'];
									$item_id = $item['itemid'];
									$item_temp_check = $item['itemtemperaturecheck'];
									$item_temp = $item['temperature_value'];
									
									foreach($total_cooked_stocks as $total_cooked_stock){
										if($item['itemid'] == $total_cooked_stock['item_id']){
											$to_co_stock = 	$total_cooked_stock['cooked_stock'];
											$to_collected = $total_cooked_stock['collected'];
											if($to_co_stock >= $to_collected){
												$to_co_stock = $to_co_stock - $to_collected;												
											}																						
										}									
									}																		
									
									
									foreach($temperatures as $temperature){
											if($item['itemid'] == $temperature['item_id']){
												$temp = $temperature['temperatue'];
												$additional = $temperature['additional'];
												$cooked_stock = $temperature['cooked_stock'];
												$total_order_taken = $temperature['total_order_taken'];
												$collected = $temperature['collected'];
												if($cooked_stock >= $collected){
													$cooked_stock = $cooked_stock - $collected;												
												}

												$total_order_taken = $total_order_taken - $collected;												
												$cooking_status = $temperature['status'];												
												if($to_co_stock > $total_order_taken){
													$to_cook = 0 ;
												}else{
													$to_cook = ($total_order_taken) - $to_co_stock;																								
												}

											}									
									
									}
									
									
							?>
								
							                            	
			                            <div class="col-md-12 sub_top_bar table_conntent">			                            
			                            	<form action="" method="post">
								<ul>

				                                    <li class="item1">
				                                    <?php echo ucwords(strtolower($itemname)); ?>
				                                    
				                                    <?php 
				                                    if($item_temp_check == 'yes'){ 
				                                    ?>
				                                    <img src="<?php echo base_url(); ?>extras/images/avatar_3cf58ba8866d_16.png"></li>				                                    
				                                    <?php 
				                                    	}
				                                    ?>				                                    </li>
				                                    <li class="item2"><?php echo $itemunits; ?></li>
				                                    <li class="item3"><?php echo $total_order_taken; ?></li>
				                                    <li class="item4"><?php echo $cooked_stock; ?></li>
				                                    <li class="item5"><?php  echo $to_co_stock;  ?></li>				                                    					                                    			                                    				                                     
				                                    <li class="item6"><?php echo $to_cook; ?></li>
				                                    <li class="item7">
				                                    	<?php
					                                    	if($cooking_status == "not started"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>" value="<?php echo $item_id; ?>" class="btn btn-danger"  >Start Cooking</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	
				                                    	<?php
					                                    	if($cooking_status == "started"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>"  class="btn btn-warning"   >Started</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>
				                                    	<?php
					                                    	if($cooking_status == "completed"){					                                    					                                    					                                    	
				                                    	?>

				                                    	<button onclick="return false;" id="<?php echo $item_temp_check,'_',$item_temp; ?>"  name="<?php if($additional != 0){echo $additional;}else{echo  $to_cook;} ?>"  class="btn btn-success"   >Completed</button>	                                 
				                                    	<?php
				                                    		}
				                                    	?>				                                    	
				                                    	
				                                    </li>
				                             <!--       <li class="item8">
				                                    	<?php 
				                                    		if($temp == 0){
				                                    	?>
				                                    		<button onclick="return false;"   class="btn btn-success">Not Set</button>
				                                    	<?php
				                                    		}else{ 
				                                    			echo $temp;
				                                    		} 
				                                    	?>
				                                    </li> -->				                                    		             
				                                </ul>

							</form>							
			                            </div>		                            
						<?php

						 	}
							} 
							
						?>                            			
			                            
			                        </div> 		
		                        </div>			
				<?php
					$i = $i +1;
				}
				
				?>
                         
                        </div>
                        </div>
                    </div>
                    </div>

                </div>                	
              
           
        </div>
    </div>
  </div>
 
<script type="text/javascript">
    $(document).ready(function () {
        $('#horizontalTab').easyResponsiveTabs({
            type: 'default', //Types: default, vertical, accordion           
            width: 'auto', //auto or any width like 600px
            fit: true,   // 100% fit in a container
            closed: 'accordion', // Start closed if in accordion view
            activate: function(event) { // Callback function if tab is switched
                var $tab = $(this);
                var $info = $('#tabInfo');
                var $name = $('span', $info);

                $name.text($tab.text());

                $info.show();
            }
        });

        $('#verticalTab').easyResponsiveTabs({
            type: 'vertical',
            width: 'auto',
            fit: true
        });
    });
</script> 
<script type="text/javascript">


</script>

		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquerypp.custom.js"></script>
		<script type="text/javascript" src="<?php echo base_url();?>extras/extra/js/jquery.elastislide.js"></script>
		<script type="text/javascript">
			
			$( '#carousel' ).elastislide();
				$( '#carousel1' ).elastislide();
				$( '#carousel2' ).elastislide();
				$( '#carousel3' ).elastislide();
				$( '#carousel4' ).elastislide();
				$( '#carousel5' ).elastislide();
				
				$(document).ready(function() {
					$( ".more_list" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});
      
	    $( ".arrow_side" ).click(function() {
						$(this).toggleClass('top_arrow');
 					 $(this).parent().next().slideToggle( "", function() {
						 
    
  });
});            
                });
			
		</script>


    

    
    <div class="popupWrap2a popup2">
    <div class="popupWrap2aBg"></div>
    <div class="popupbx2a">
      <p id="auth_error" style="color:black;"></p>
      <input type="text" class="form-control" name="user_id" id="user_id" placeholder="Enter Your User ID" autocomplete="off">    
      <input type="password" name="user_pin" id="user_pin" class="form-control" placeholder="Enter Your Pin Number"> 
      <p style="margin-top:6px;">
       <button name="auth" onclick="auth()" id="auth" class="btn btn-primary">Submit</button>
      </p>
      
    	
  <a href="#" class="close3a"><img src="<?php echo base_url();?>extras/images/close2.png" /></a>


  <script>
    $('#myTab a').click(function (e) {
        e.preventDefault();
        $(this).tab('show');
    });

    // store the currently selected tab in the hash value
    $("ul.nav-tabs > li > a").on("shown.bs.tab", function (e) {
        var id = $(e.target).attr("href").substr(1);
        window.location.hash = id;
    });

    // on load of the page: switch to the currently selected tab
    var hash = window.location.hash;
    $('#myTab a[href="' + hash + '"]').tab('show');
</script>
<script>
	var base_url = "<?php echo base_url(); ?>";		
</script>
<script>
$(window).bind("load", function() {
	(function ajax_reload() {

			var base_url = "<?php echo base_url(); ?>";	
			var status_table_name = "<?php echo $status_table_name; ?>";
			if(status_table_name == 'all'){                           
				$.ajax(
					{
						url: base_url + 'office',
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);

															
							}

						},															
					
					}
				);			
			}else if(status_table_name == 'morning'){
				var morning_start = $('#morning_start').val();
				var morning_end = $('#morning_end').val();
				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'office',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
					
					
					
					}
				);			
			}else if(status_table_name == 'evening'){
				var morning_start = $('#evening_start').val();
				var morning_end = $('#evening_end').val();
				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'office',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
										
					
					}
				);			
			}else if(status_table_name == 'afternoon'){
				var morning_start = $('#afternoon_start').val();
				var morning_end = $('#afternoon_end').val();

				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'office',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
					
					
					
					}
				);			
			}else if(status_table_name == 'night'){
				var morning_start = $('#night_start').val();
				var morning_end = $('#night_end').val();
				var dataString = 'start='+ morning_start + '&end=' + morning_end;		
				$.ajax(
					{
						type: "POST",
						url: base_url + 'office',
						data: dataString,
						success:function(msg){
							if($('#ajax_pop_up_open').val() == 'no'){
								$('body').html(msg);
						     		setTimeout(ajax_reload, 60000);															
							}
						},
					
					
					
					}
				);			
			}		
	
	})();
	
});
</script>




    </div>
    </div>         
    <div class="clear"></div>
    <div class="wrapper-footer"></div>         
<?php
$path = APPPATH.'views/footerkitchen.php';
include_once($path);
?>