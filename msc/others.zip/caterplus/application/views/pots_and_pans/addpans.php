  
  <div class="super-payment-bg">
    <div class="master-top-add">
      <h1>Pots And Pans</h1>
    </div>
    <div class="event_list_main">
      
      <div class="master-left">
       <form class="validate" id="add-items" action="<?php echo base_url()?>admin/settings/insert_pots" method="post" name="Add Items-form" novalidate  enctype="multipart/form-data">
          <!---->
          
          <div class="master-left-1">
           <div class="master-name">Name: *</div>         
<div class="master-select">
 <input name="pot_name" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="pot_name">
          </div>
          </div>
          <!---->
        
          
          <div class="master-left-1">
           <div class="master-name">Deposit: *</div>         
<div class="master-select">
 <input name="pot_deposit" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="pot_deposit">
          </div>
          </div>
          <!---->
 <!---->
          
          <div class="master-left-1">
           <div class="master-name">Size: *</div>         
<div class="master-select">
 <input name="pot_size" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="pot_size">
          </div>
          </div>
          <!---->
 <!---->
          
          <div class="master-left-1">
           <div class="master-name">Price: *</div>         
<div class="master-select">
 <input name="pot_price" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="pot_price">
          </div>
          </div>
          <!---->
         
        <!---->
          
          <div class="master-left-1">
           <div class="master-name">Stock: *</div>         
<div class="master-select">
 <input name="pot_stock" type="text" class="master-textfeild validate[required,custom[onlyLetterSp]]" id="pot_stock">
          </div>
          </div>
          <!---->
          
          <input class="master-submit" type="submit" name="add_ingr" value="" /> 
        </form>
        <div class="clear"></div>
      </div>
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->