<?php  $ran= $this->ran_string;  //print_r($pots_list); ?>  
<div class="super-payment-bg">
    <div class="master-top-add">
      <h1>POTS AND PANS</h1>
    </div>
    <div class="event_list_main">
      <div class="dashbord_itemlist">
        <h1><a href="<?php echo base_url()?>admin/settings/add_pots_pans">Add New</a></h1>


        <div class="row_color1">
          <ul>
            <li class="dash_cutomer_name">Name</li>
             <li class="dash_cutomer_name">Deposit</li>
                     <li class="dash_cutomer_name">Action</li>
          </ul>
        </div>
       
<?php $i=1;if($pots_list)
{ foreach($pots_list as $staff)
{ $id=$staff['pp_id']; if($i%2==0){ $i=2;} else { $i=3; } ?>
        
        
        <div class="row_color<?php echo $i; ?>">
          <ul>
  <li class="dash_cutomer_name"><?php echo $stname= $staff['pp_name']; ?></li>
            <li class="dash_cutomer_name"><?php $stname= $staff['pp_deposit']; echo $currency.' '.number_format((float)$stname, 2, '.', ''); $status_curr=$staff['pp_status']; 
if($status_curr=='active'){ $act_stat='actived'; $act_stat_label='Disable'; }else{ $act_stat=''; $act_stat_label='Enable'; }


?></li>
      
           <a href="<?php echo base_url()?>admin/settings/edit_pots/<?php echo $id;?>"> <li class="row_color2_edit"><img src="<?php echo CSSPATH;?>images/pencil.png">Edit</li></a>
           <a href="<?php echo base_url()?>admin/settings/changestat_pots/<?php echo $id; ?>"><li class="row_color4_edit <?php echo $act_stat; ?>"><img src="<?php echo CSSPATH;?>images/remove.png" class="list_img"><p><?php echo $act_stat_label; ?></p></li></a> 

          </ul>
        </div>
        
<?php    $i=$i+1; } } ?>

      </div>
      
    </div>
  </div>
  <div class="clear"></div>
</div>
<div class="clear"></div>
<!--========= content end ===============-->